/** Utilidades de DOM/arquivo do painel. Sem estado; o que é puro é testado em tests/dom-utils.test.ts. */

/** "Proposta Orvia - Hamburgueria do Zé.pdf": só caracteres aceitos pelo worker de downloads. */
export function safeFileName(base: string, ext: 'pdf' | 'png'): string {
  const clean = base
    .normalize('NFC')
    .replace(/[^\w .()\-À-ÿ]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60)
  return `${clean || 'Orvia'}.${ext}`
}

export function dataUrlToBase64(dataUrl: string): string {
  const i = dataUrl.indexOf('base64,')
  return i < 0 ? '' : dataUrl.slice(i + 7)
}

export function bytesToDataUrl(bytes: Uint8Array, mime: string): string {
  let bin = ''
  const chunk = 0x8000
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode(...bytes.subarray(i, i + chunk))
  return `data:${mime};base64,${btoa(bin)}`
}

/** Quantos preços ("R$ 12,90") a tela mostra — usado só para avisar de leitura incompleta. */
export function countPricesOnScreen(doc: Document): number {
  const text = doc.body?.innerText ?? ''
  return (text.match(/R\$\s*\d/g) ?? []).length
}

const GENERIC_TITLES = /^(card[aá]pio|in[ií]cio|home|pedidos?|financeiro|desempenho|marketing|produtos|complementos|pdv|ajuda|menu|loja|minha loja|otimizador.*|buscar.*|selecionar.*)$/i

/** true se o texto parece o NOME de uma loja (e não um título de tela ou botão). */
export function looksLikeStoreName(t: string | null | undefined): t is string {
  const v = (t ?? '').replace(/\s+/g, ' ').trim()
  return v.length >= 3 && v.length <= 80 && !GENERIC_TITLES.test(v) && !/^R\$/.test(v)
}

/**
 * Nome da loja no iFood (a conta em que o gestor está logado): seletores explícitos e,
 * depois, o texto mais à esquerda da barra superior (o seletor de loja do portal).
 */
export function guessMerchantName(doc: Document): string | null {
  const explicit = ['[data-testid*="merchant" i]', '[data-testid*="store-name" i]', '[data-testid*="shop" i]', '[class*="merchant-name" i]', '[class*="store-name" i]']
  for (const sel of explicit) {
    const t = doc.querySelector(sel)?.textContent?.replace(/\s+/g, ' ').trim()
    if (looksLikeStoreName(t)) return t
  }
  const view = doc.defaultView
  if (view) {
    const found: { left: number; text: string }[] = []
    doc.querySelectorAll<HTMLElement>('header *, nav *, body > div > div *').forEach((el) => {
      if (found.length > 60 || el.children.length > 0) return
      const text = el.textContent?.replace(/\s+/g, ' ').trim() ?? ''
      if (!looksLikeStoreName(text)) return
      const r = el.getBoundingClientRect()
      if (r.width > 0 && r.top >= 0 && r.top < 110 && r.left > 100 && r.left < view.innerWidth * 0.6) found.push({ left: r.left, text })
    })
    found.sort((a, b) => a.left - b.left)
    if (found[0]) return found[0].text
  }
  for (const sel of ['header h1', 'h1']) {
    const t = doc.querySelector(sel)?.textContent?.replace(/\s+/g, ' ').trim()
    if (looksLikeStoreName(t)) return t
  }
  return null
}

/**
 * Rola a página e os contêineres rolavéis para disparar carregamento preguiçoso
 * (listas virtualizadas, "carregar mais"). Cancelável.
 */
export async function autoScroll(doc: Document, opts: { maxMs?: number; isCancelled: () => boolean; onTick?: () => void }): Promise<void> {
  const maxMs = opts.maxMs ?? 9000
  const start = Date.now()
  const scrollers = (): HTMLElement[] => {
    const out: HTMLElement[] = []
    const root = (doc.scrollingElement as HTMLElement | null) ?? doc.documentElement
    if (root.scrollHeight > root.clientHeight + 100) out.push(root)
    doc.querySelectorAll<HTMLElement>('main, section, div, ul').forEach((el) => {
      if (out.length >= 8) return
      const st = getComputedStyle(el)
      if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 200) out.push(el)
    })
    return out
  }
  const targets = scrollers()
  for (const el of targets) {
    const original = el.scrollTop
    let last = -1
    while (Date.now() - start < maxMs && !opts.isCancelled()) {
      el.scrollTop += Math.max(300, el.clientHeight * 0.8)
      opts.onTick?.()
      await new Promise((r) => setTimeout(r, 220))
      if (el.scrollTop === last) break
      last = el.scrollTop
    }
    el.scrollTop = original
    if (opts.isCancelled() || Date.now() - start >= maxMs) break
  }
}
