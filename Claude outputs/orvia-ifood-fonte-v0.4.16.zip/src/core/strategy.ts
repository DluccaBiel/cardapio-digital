/** Estratégias da aba Análise. O texto vai para o servidor (IA + pesquisa de concorrentes do NICHO). */
export interface StrategyOption {
  value: 'mercado' | 'competitivo' | 'premium' | 'combos'
  label: string
  hint: string
  /** instrução para a IA (preferência do gestor, não ordem sobre o sistema) */
  brief: string
}

export const STRATEGIES: StrategyOption[] = [
  {
    value: 'mercado',
    label: 'Alinhar ao mercado do nicho',
    hint: 'Preços e descrições próximos do que os concorrentes do nicho praticam.',
    brief: 'Estratégia: alinhar ao mercado. Compare cada produto com os concorrentes do mesmo nicho na região e aproxime preço, nome e descrição da mediana praticada, sem sair do padrão do cliente.',
  },
  {
    value: 'competitivo',
    label: 'Ser mais competitivo que a concorrência',
    hint: 'Preço de entrada e itens-âncora levemente abaixo dos concorrentes.',
    brief: 'Estratégia: competitividade. Posicione os itens de entrada e os mais procurados ligeiramente abaixo dos concorrentes do nicho na região (sem destruir margem) e destaque o diferencial nas descrições.',
  },
  {
    value: 'premium',
    label: 'Diferenciar / posicionamento premium',
    hint: 'Mantém preço e melhora percepção de valor (descrições, combos de maior valor).',
    brief: 'Estratégia: diferenciação. Não reduza preços. Use o que os concorrentes do nicho NÃO oferecem para justificar valor: descrições ricas, ingredientes, combos de maior valor percebido.',
  },
  {
    value: 'combos',
    label: 'Foco em combos e ticket médio',
    hint: 'Combos e upsell inspirados nos combos que funcionam no nicho.',
    brief: 'Estratégia: ticket médio. Priorize combos e kits inspirados nos que os concorrentes do nicho vendem na região, com desconto moderado sobre a soma dos itens.',
  },
]

export const strategyOf = (v: string): StrategyOption => STRATEGIES.find((s) => s.value === v) ?? STRATEGIES[0]!
