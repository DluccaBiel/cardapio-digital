/**
 * Boas práticas de cardápio (documento "Plano Estratégico · Cardápio – Boas Práticas"):
 *  1 Promoções destacadas  2 Organização por categorias  3 Ordenação de preços (menor → maior)
 *  4 Fotos de qualidade    5 Descrições persuasivas       6 Preços com gatilho (19,90 | 29,90)
 * Puro (sem DOM/chrome). Gera (a) o placar mostrado no painel e (b) ações para a proposta.
 */
import type { ProposalAction } from './proposal'
import type { AnalysisContext, MenuItem, MenuSnapshot } from './schema'

const PROMO_RE = /combo|kit|fam[ií]lia|dupla|promo[cç][aã]o|promo[cç][oõ]es|oferta|destaque/i
const MIN_DESC = 40
const MAX_PRICE_MOVE = 0.05

export type PracticeId = 'promocoes' | 'categorias' | 'ordenacao' | 'fotos' | 'descricoes' | 'gatilhos'
export interface PracticeCheck {
  id: PracticeId
  title: string
  /** 'ok' cumpre · 'atencao' vale melhorar · 'falha' longe do ideal */
  level: 'ok' | 'atencao' | 'falha'
  detail: string
  /** quantos itens/categorias precisam de ajuste */
  count: number
}

const money = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const cents = (v: number) => Math.round(v * 100)
const active = (s: MenuSnapshot) => s.items.filter((i) => i.status !== 'paused' && i.price !== null && i.price > 0)
const list = (names: string[], n = 4) => `${names.slice(0, n).join(', ')}${names.length > n ? ` e +${names.length - n}` : ''}`

/** ,90 mais próximo (≤5% de variação). null = já está ou o ajuste seria grande demais. */
export function charmPrice(price: number): number | null {
  const c = cents(price)
  if (c % 100 === 90 || c % 100 === 99) return null
  const base = Math.floor(c / 100)
  const candidates = [(base - 1) * 100 + 90, base * 100 + 90].filter((x) => x > 0)
  let best = candidates[0]!
  for (const x of candidates) if (Math.abs(x - c) < Math.abs(best - c) || (Math.abs(x - c) === Math.abs(best - c) && x < best)) best = x
  if (Math.abs(best - c) / c > MAX_PRICE_MOVE) return null
  return best / 100
}

function itemsByCategory(s: MenuSnapshot): { name: string; id: string; items: MenuItem[] }[] {
  const byId = new Map(s.items.map((i) => [i.id, i]))
  return s.categories.map((c) => ({ id: c.id, name: c.name, items: c.itemIds.map((id) => byId.get(id)).filter((i): i is MenuItem => Boolean(i)) }))
}

/** Categorias (com ≥3 itens com preço) cuja ordem atual NÃO está do menor para o maior. */
export function unsortedCategories(s: MenuSnapshot): { name: string; first: string; cheapest: string }[] {
  const out: { name: string; first: string; cheapest: string }[] = []
  for (const c of itemsByCategory(s)) {
    const p = c.items.filter((i) => i.price !== null && i.price > 0 && i.status !== 'paused')
    if (p.length < 3) continue
    const sorted = p.every((it, i) => i === 0 || p[i - 1]!.price! <= it.price!)
    if (!sorted) out.push({ name: c.name, first: p[0]!.name, cheapest: [...p].sort((a, b) => a.price! - b.price!)[0]!.name })
  }
  return out
}

export function auditPractices(s: MenuSnapshot): PracticeCheck[] {
  const items = active(s)
  const total = Math.max(1, items.length)
  const out: PracticeCheck[] = []

  // 1 · promoções destacadas
  const promoIdx = s.categories.findIndex((c) => PROMO_RE.test(c.name))
  const hasComboItem = s.items.some((i) => PROMO_RE.test(i.name))
  out.push(
    promoIdx === 0 || (promoIdx >= 0 && promoIdx <= 1)
      ? { id: 'promocoes', title: 'Promoções no topo', level: 'ok', count: 0, detail: `“${s.categories[promoIdx]!.name}” está entre as primeiras categorias.` }
      : promoIdx > 1
        ? { id: 'promocoes', title: 'Promoções no topo', level: 'atencao', count: 1, detail: `“${s.categories[promoIdx]!.name}” está na posição ${promoIdx + 1}. Mova para o topo.` }
        : { id: 'promocoes', title: 'Promoções no topo', level: 'falha', count: 1, detail: hasComboItem ? 'Há combos soltos em categorias comuns; crie uma categoria “Combos e promoções” no topo.' : 'Nenhum combo/promoção. Crie combos e coloque no topo.' },
  )

  // 2 · categorias bem definidas
  const cats = itemsByCategory(s)
  const tiny = cats.filter((c) => c.items.length === 1).map((c) => c.name)
  const huge = cats.filter((c) => c.items.length > 15).map((c) => `${c.name} (${c.items.length})`)
  const generic = cats.filter((c) => /^(sem categoria|categoria \d*|outros?|diversos?)$/i.test(c.name.trim())).map((c) => c.name)
  const catIssues = tiny.length + huge.length + generic.length
  out.push({
    id: 'categorias',
    title: 'Categorias bem definidas',
    level: catIssues === 0 ? 'ok' : generic.length || huge.length ? 'falha' : 'atencao',
    count: catIssues,
    detail: catIssues === 0 ? `${cats.length} categorias equilibradas.` : [tiny.length ? `1 item só: ${list(tiny)}` : '', huge.length ? `muito longas: ${list(huge)}` : '', generic.length ? `nome genérico: ${list(generic)}` : ''].filter(Boolean).join(' · '),
  })

  // 3 · ordenação de preços
  const unsorted = unsortedCategories(s)
  out.push({
    id: 'ordenacao',
    title: 'Preços do menor para o maior',
    level: unsorted.length === 0 ? 'ok' : unsorted.length > Math.max(1, cats.length / 2) ? 'falha' : 'atencao',
    count: unsorted.length,
    detail: unsorted.length === 0 ? 'Categorias já estão em ordem crescente.' : `${unsorted.length} categoria(s) fora de ordem: ${list(unsorted.map((u) => u.name))}.`,
  })

  // 4 · fotos
  const noPhoto = items.filter((i) => !i.imageUrl)
  out.push({
    id: 'fotos',
    title: 'Fotos de qualidade',
    level: noPhoto.length === 0 ? 'ok' : noPhoto.length / total > 0.3 ? 'falha' : 'atencao',
    count: noPhoto.length,
    detail: noPhoto.length === 0 ? 'Todos os itens têm foto. Padronize luz e enquadramento.' : `${noPhoto.length} de ${items.length} sem foto: ${list(noPhoto.map((i) => i.name))}.`,
  })

  // 5 · descrições persuasivas
  const weak = items.filter((i) => i.description.trim().length < MIN_DESC)
  out.push({
    id: 'descricoes',
    title: 'Descrições persuasivas',
    level: weak.length === 0 ? 'ok' : weak.length / total > 0.4 ? 'falha' : 'atencao',
    count: weak.length,
    detail: weak.length === 0 ? 'Todas descrevem ingredientes e benefícios.' : `${weak.length} de ${items.length} vazias ou curtas (<${MIN_DESC} caracteres): ${list(weak.map((i) => i.name))}.`,
  })

  // 6 · gatilhos de preço
  const noCharm = items.filter((i) => {
    const c = cents(i.price!) % 100
    return c !== 90 && c !== 99
  })
  out.push({
    id: 'gatilhos',
    title: 'Preços com gatilho (,90)',
    level: noCharm.length === 0 ? 'ok' : noCharm.length / total > 0.5 ? 'falha' : 'atencao',
    count: noCharm.length,
    detail: noCharm.length === 0 ? 'Preços já terminam em ,90.' : `${noCharm.length} de ${items.length} fora do padrão: ${list(noCharm.map((i) => `${i.name} ${money(i.price!)}`), 3)}.`,
  })
  return out
}

/** Ações da proposta que vêm das boas práticas. Ajuste de preço é EXECUTÁVEL (risco alto → não vem marcado). */
export function practiceActions(s: MenuSnapshot, ctx: AnalysisContext, max = { prices: 15 }): ProposalAction[] {
  const actions: ProposalAction[] = []
  const locked = new Set(ctx.doNotTouchItemIds)

  if (!ctx.doNotTouchPrices) {
    let n = 0
    for (const i of active(s)) {
      if (n >= max.prices) break
      if (locked.has(i.id)) continue
      const next = charmPrice(i.price!)
      if (next === null || next === i.price) continue
      if (ctx.minPrice !== null && next < ctx.minPrice) continue
      if (ctx.maxPrice !== null && next > ctx.maxPrice) continue
      n += 1
      actions.push({
        id: `update_price:${i.id}`,
        kind: 'update_price',
        itemId: i.id,
        itemName: i.name,
        before: i.price,
        after: next,
        reason: `Boa prática: preço com gatilho (${money(next)}). Variação de ${((Math.abs(next - i.price!) / i.price!) * 100).toFixed(1).replace('.', ',')}%.`,
        source: 'regras',
        risk: 'alto',
        executable: true,
      })
    }
  }

  const unsorted = unsortedCategories(s)
  if (unsorted.length) {
    actions.push({
      id: 'rec:practice:ordenacao',
      kind: 'recommend',
      itemName: 'Ordenar preços do menor para o maior',
      itemId: null,
      before: unsorted.map((u) => `${u.name}: começa por ${u.first}`).slice(0, 4).join(' · '),
      after: 'No iFood, em Cardápio, arraste os itens de cada categoria do mais barato ao mais caro (atrai clientes iniciantes).',
      reason: `${unsorted.length} categoria(s) fora de ordem.`,
      source: 'regras',
      risk: 'medio',
      executable: false,
    })
  }
  return actions
}
