/**
 * Captura de cardápio — funções PURAS (sem DOM/chrome), testadas em tests/capture.test.ts.
 *
 * Por que existe: o portal do iFood é uma SPA e nunca garantimos o formato exato do
 * que ele carrega. Em vez de aceitar só UM formato, aqui:
 *  1) pontuamos QUALQUER JSON ("parece cardápio?") por conteúdo, não por endereço;
 *  2) juntamos várias respostas parciais (categorias + produtos + preços em
 *     chamadas separadas, como no catálogo oficial) fazendo o vínculo por productId;
 *  3) mesclamos campo a campo (uma resposta pobre nunca apaga dados de uma rica).
 */
import { finalizeSnapshot, normalizeMenuPayload } from './normalize'
import type { CaptureOrigin, MenuItem, MenuSnapshot } from './schema'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const text = (v: unknown): string | null => (typeof v === 'string' && v.trim() !== '' ? v.trim() : null)
const idOf = (v: unknown): string | null => (typeof v === 'string' && v.trim() ? v.trim() : typeof v === 'number' && Number.isFinite(v) ? String(v) : null)

const NAME_KEYS = ['name', 'title', 'label', 'itemName', 'productName']
const PRICE_KEYS = ['price', 'sellingPrice', 'unitPrice', 'originalPrice', 'amount', 'value', 'priceByCatalog']
const MEDIA_KEYS = ['imagePath', 'imageUrl', 'image', 'images', 'photo', 'picture', 'logo', 'imageResource']
const ITEM_LIST_KEYS = ['items', 'products', 'menuItems', 'dishes', 'productsList', 'itens', 'produtos']

function nameOf(o: Rec): string | null {
  for (const k of NAME_KEYS) {
    const v = text(o[k])
    if (v) return v
  }
  return null
}
function hasAny(o: Rec, keys: string[]): boolean {
  return keys.some((k) => k in o && o[k] !== null && o[k] !== undefined)
}

export interface PayloadScore {
  /** objetos com nome + preço (produto "completo") */
  priced: number
  /** objetos com nome + id + descrição/imagem, sem preço (catálogo de produtos separado) */
  catalogOnly: number
  /** objetos com nome + lista de itens */
  categories: number
  /** produtos referenciados só por productId (precisam de outra resposta para ter nome) */
  refsOnly: number
  /** produtos no formato do portal (nome + priceByCatalog): sinal forte, vale mesmo sozinho */
  catalogRows: number
  nodes: number
}

/** Conta o que o JSON contém. Limite de nós protege a página do portal. */
export function scorePayload(json: unknown, maxNodes = 30_000): PayloadScore {
  const s: PayloadScore = { priced: 0, catalogOnly: 0, categories: 0, refsOnly: 0, catalogRows: 0, nodes: 0 }
  const visit = (v: unknown, depth: number): void => {
    if (s.nodes >= maxNodes || depth > 9) return
    s.nodes += 1
    if (Array.isArray(v)) {
      for (const e of v) visit(e, depth + 1)
      return
    }
    if (!isRec(v)) return
    const name = nameOf(v)
    const isCategory = name !== null && ITEM_LIST_KEYS.some((k) => Array.isArray(v[k]) && (v[k] as unknown[]).length > 0)
    if (name && 'priceByCatalog' in v && !isCategory) s.catalogRows += 1
    if (isCategory) s.categories += 1
    else if (name && hasAny(v, PRICE_KEYS) && !isRec(v.items) && !('options' in v && Array.isArray(v.options) && !hasAny(v, ['price']))) s.priced += 1
    else if (name && idOf(v.id) !== null && (hasAny(v, MEDIA_KEYS) || text(v.description))) s.catalogOnly += 1
    else if (!name && (idOf(v.productId) !== null || isRec(v.product)) && hasAny(v, PRICE_KEYS)) s.refsOnly += 1
    for (const val of Object.values(v)) visit(val, depth + 1)
  }
  visit(json, 0)
  return s
}

/** Resposta que vale guardar: tem produtos suficientes OU peças de um cardápio dividido. */
export function isMenuLike(score: PayloadScore): boolean {
  if (score.catalogRows >= 1) return true
  const products = score.priced + score.catalogOnly + score.refsOnly
  if (score.categories >= 1 && products >= 1) return true
  return score.priced >= 2 || score.catalogOnly >= 3 || score.refsOnly >= 2
}

/** Lista de categorias do portal: [{categoryId, name, …}] (sem produtos dentro). */
export function isCategoryList(json: unknown): boolean {
  return Array.isArray(json) && json.length > 0 && json.every((e) => isRec(e) && idOf(e.categoryId) !== null && nameOf(e) !== null)
}

/** Id da categoria na URL de itens: /menu/v4/category/{id}/items  (não pega /items/stock). */
export function categoryIdFromUrl(url: string): string | null {
  const m = /\/category\/([^/?#]+)\/items(?:[?#]|$)/.exec(url)
  return m ? decodeURIComponent(m[1]!) : null
}

/** Só TIPOS (nunca valores): ajuda a descobrir o formato do preço no Diagnóstico. */
export function typeSignature(json: unknown, depth = 0): string {
  if (json === null) return 'null'
  if (Array.isArray(json)) return `[${json.length}]${json.length && depth < 5 ? typeSignature(json[0], depth + 1) : ''}`
  if (isRec(json)) {
    if (depth >= 5) return '{…}'
    return `{${Object.keys(json).slice(0, 16).map((k) => `${k}:${typeSignature(json[k], depth + 1)}`).join(',')}}`
  }
  return typeof json
}

/** Forma compacta do JSON para o Diagnóstico (só nomes de campos; nenhum valor). */
export function shapeSignature(json: unknown, depth = 0): string {
  if (Array.isArray(json)) return `[${json.length}]${json.length && depth < 4 ? shapeSignature(json[0], depth + 1) : ''}`
  if (isRec(json)) {
    if (depth >= 4) return '{…}'
    const keys = Object.keys(json).slice(0, 14)
    return `{${keys.map((k) => (isRec(json[k]) || Array.isArray(json[k]) ? `${k}:${shapeSignature(json[k], depth + 1)}` : k)).join(',')}${Object.keys(json).length > 14 ? ',…' : ''}}`
  }
  return ''
}

// ---------------------------------------------------------------------------
// Vínculo produtos × itens (catálogo dividido em várias respostas)
// ---------------------------------------------------------------------------
const PRODUCT_FIELDS = ['name', 'title', 'description', 'imagePath', 'imageUrl', 'image', 'images', 'photo', 'picture', 'serving', 'dietaryRestrictions'] as const

/** Índice id → produto (objetos com nome+id e SEM lista de itens). */
export function buildProductIndex(payloads: unknown[]): Map<string, Rec> {
  const index = new Map<string, Rec>()
  for (const p of payloads) {
    let nodes = 0
    const visit = (v: unknown, depth: number): void => {
      if (nodes++ > 60_000 || depth > 9) return
      if (Array.isArray(v)) return void v.forEach((e) => visit(e, depth + 1))
      if (!isRec(v)) return
      const id = idOf(v.id)
      const isContainer = ITEM_LIST_KEYS.some((k) => Array.isArray(v[k]))
      if (id && nameOf(v) && !isContainer && (hasAny(v, MEDIA_KEYS) || text(v.description))) {
        const prev = index.get(id)
        index.set(id, prev ? { ...prev, ...Object.fromEntries(Object.entries(v).filter(([, x]) => x !== null && x !== '')) } : v)
      }
      for (const val of Object.values(v)) visit(val, depth + 1)
    }
    visit(p, 0)
  }
  return index
}

/** Completa itens sem nome/descrição/imagem usando o produto vinculado (muda o objeto no lugar). */
export function enrichWithProducts(payload: unknown, index: Map<string, Rec>): number {
  let filled = 0
  let nodes = 0
  const visit = (v: unknown, depth: number): void => {
    if (nodes++ > 60_000 || depth > 9) return
    if (Array.isArray(v)) return void v.forEach((e) => visit(e, depth + 1))
    if (!isRec(v)) return
    const nested = isRec(v.product) ? v.product : null
    const refId = idOf(v.productId) ?? (nested ? idOf(nested.id) : null)
    const product = (refId && index.get(refId)) || nested
    if (product && (!nameOf(v) || !text(v.description) || !hasAny(v, MEDIA_KEYS))) {
      for (const f of PRODUCT_FIELDS) {
        if (product[f] !== undefined && (v[f] === undefined || v[f] === null || v[f] === '')) {
          v[f] = product[f]
          filled += 1
        }
      }
    }
    for (const [k, val] of Object.entries(v)) if (k !== 'product') visit(val, depth + 1)
  }
  visit(payload, 0)
  return filled
}

// ---------------------------------------------------------------------------
// Mesclagem
// ---------------------------------------------------------------------------
const present = (v: unknown) => v !== null && v !== undefined && v !== '' && !(Array.isArray(v) && v.length === 0)

/** Campo a campo: o valor novo só substitui se for "de verdade". */
export function mergeItem(a: MenuItem, b: MenuItem): MenuItem {
  const pick = <K extends keyof MenuItem>(k: K): MenuItem[K] => (present(b[k]) ? b[k] : a[k])
  const imageUrl = b.imageUrl ?? a.imageUrl
  return {
    ...a,
    ...b,
    name: pick('name'),
    description: pick('description'),
    price: b.price ?? a.price,
    originalPrice: b.originalPrice ?? a.originalPrice,
    status: b.status !== 'unknown' ? b.status : a.status,
    imageUrl,
    hasImage: imageUrl !== null,
    categoryId: pick('categoryId'),
    categoryName: pick('categoryName'),
    complements: b.complements.length ? b.complements : a.complements,
    available: b.available ?? a.available,
  }
}

export function mergeSnapshots(base: MenuSnapshot | null, next: MenuSnapshot): MenuSnapshot {
  if (!base) return next
  const sameStore = base.storeKey === next.storeKey || base.storeKey === 'unknown' || next.storeKey === 'unknown'
  if (!sameStore) return next
  const items = new Map(base.items.map((i) => [i.id, i]))
  for (const i of next.items) {
    const prev = items.get(i.id)
    items.set(i.id, prev ? mergeItem(prev, i) : i)
  }
  const cats = new Map(base.categories.map((c) => [c.id, c]))
  for (const c of next.categories) {
    const prev = cats.get(c.id)
    cats.set(c.id, prev ? { ...c, itemIds: [...new Set([...prev.itemIds, ...c.itemIds])] } : c)
  }
  // categorias genéricas ("Sem categoria") esvaziadas por uma resposta mais rica somem
  const used = new Set([...items.values()].map((i) => i.categoryId))
  const categories = [...cats.values()].filter((c) => c.itemIds.length > 0 || used.has(c.id)).map((c, position) => ({ ...c, position }))
  return finalizeSnapshot({
    ...next,
    merchant: next.merchant.id || next.merchant.name ? next.merchant : base.merchant,
    storeKey: next.storeKey !== 'unknown' ? next.storeKey : base.storeKey,
    catalogs: next.catalogs.length ? next.catalogs : base.catalogs,
    categories,
    items: [...items.values()],
  })
}

export interface CaptureInput {
  path: string | null
  payload: unknown
  /** id real da categoria (vem do endereço /category/{id}/items) */
  categoryId?: string | null
}

export interface BuildResult {
  snapshot: MenuSnapshot | null
  usedPayloads: number
  totalPayloads: number
  joined: number
}

/** Junta TODAS as respostas capturadas em um único cardápio. */
export function buildSnapshot(captures: CaptureInput[], opts: { origin: CaptureOrigin; domUrl: string; merchantName?: string | null }): BuildResult {
  // listas de categorias só dão NOME/ORDEM; a home (graphql) não é cardápio
  const categoryNames = new Map<string, { name: string; position: number; paused: boolean }>()
  captures.forEach((c) => {
    if (!isCategoryList(c.payload)) return
    ;(c.payload as Rec[]).forEach((e, i) => {
      const id = idOf(e.categoryId)
      const name = nameOf(e)
      if (id && name) categoryNames.set(id, { name, position: i, paused: typeof e.status === 'string' && /pause|inativ|inactive|disabled/i.test(e.status) })
    })
  })
  const usable = captures.filter((c) => !isCategoryList(c.payload) && !/graphql/i.test(c.path ?? ''))
  const index = buildProductIndex(usable.map((c) => c.payload))
  let joined = 0
  let snapshot: MenuSnapshot | null = null
  let used = 0
  for (const c of usable) {
    joined += enrichWithProducts(c.payload, index)
    const normalized = normalizeMenuPayload(c.payload, {
      origin: opts.origin,
      requestPath: c.path,
      categoryId: c.categoryId ?? null,
      domUrl: opts.domUrl,
      merchantFallback: { id: null, name: opts.merchantName ?? null },
    })
    if (!normalized) continue
    used += 1
    snapshot = mergeSnapshots(snapshot, finalizeSnapshot(normalized))
  }
  const named = snapshot ? applyCategoryNames(dropCoveredProducts(snapshot), categoryNames) : null
  return { snapshot: named, usedPayloads: used, totalPayloads: captures.length, joined }
}

/** Dá nome e ordem reais às categorias lidas por id (e atualiza o nome em cada item). */
export function applyCategoryNames(s: MenuSnapshot, names: Map<string, { name: string; position: number; paused: boolean }>): MenuSnapshot {
  if (names.size === 0) return s
  const cats = s.categories
    .map((c) => ({ ...c, name: names.get(c.id)?.name ?? c.name, _pos: names.get(c.id)?.position ?? 1000 + c.position }))
    .sort((a, b) => a._pos - b._pos)
    .map(({ _pos, ...c }, position) => ({ ...c, position }))
  const nameOfCat = new Map(cats.map((c) => [c.id, c.name]))
  const items = s.items.map((i) => (i.categoryId && nameOfCat.has(i.categoryId) ? { ...i, categoryName: nameOfCat.get(i.categoryId)! } : i))
  return finalizeSnapshot({ ...s, categories: cats, items })
}

/**
 * Catálogo dividido: o produto "P1" aparece sozinho (sem preço) e também como item
 * vendável "I1" que o referencia. Fica só o item vendável (sem duplicar).
 */
export function dropCoveredProducts(s: MenuSnapshot): MenuSnapshot {
  const referenced = new Set(s.items.map((i) => i.productId).filter((x): x is string => Boolean(x)))
  if (referenced.size === 0) return s
  const dropped = new Set(s.items.filter((i) => referenced.has(i.id) && i.price === null && i.productId == null).map((i) => i.id))
  if (dropped.size === 0) return s
  const items = s.items.filter((i) => !dropped.has(i.id))
  const categories = s.categories
    .map((c) => ({ ...c, itemIds: c.itemIds.filter((id) => !dropped.has(id)) }))
    .filter((c) => c.itemIds.length > 0)
    .map((c, position) => ({ ...c, position }))
  return finalizeSnapshot({ ...s, items, categories })
}

// ---------------------------------------------------------------------------
// Qualidade da leitura (mostrada ao usuário; nunca "sucesso" falso)
// ---------------------------------------------------------------------------
export interface Quality {
  items: number
  categories: number
  withPrice: number
  withImage: number
  withDescription: number
  level: 'boa' | 'parcial' | 'ruim'
  warnings: string[]
}

export function assessQuality(s: MenuSnapshot | null, domPriceCount = 0): Quality {
  if (!s) return { items: 0, categories: 0, withPrice: 0, withImage: 0, withDescription: 0, level: 'ruim', warnings: ['Nenhum produto lido.'] }
  const items = s.items.length
  const withPrice = s.items.filter((i) => i.price !== null).length
  const withImage = s.items.filter((i) => i.imageUrl).length
  const withDescription = s.items.filter((i) => i.description).length
  const warnings: string[] = []
  if (withPrice < items * 0.9) warnings.push(`${items - withPrice} produto(s) sem preço lido.`)
  if (s.origin === 'dom') warnings.push('Lido da tela (sem categorias nem IDs do iFood): a análise funciona, mas a aplicação automática não.')
  if (domPriceCount > items * 1.3 && domPriceCount - items >= 5) warnings.push(`A tela mostra cerca de ${domPriceCount} preços e só ${items} produtos foram lidos — o cardápio pode estar incompleto (role a página e sincronize de novo).`)
  if (s.categories.length === 1 && items > 15 && s.categories[0]?.name === 'Sem categoria') warnings.push('Categorias não identificadas.')
  const priced = s.items.filter((i) => i.price !== null)
  if (priced.length >= 5 && priced.every((i) => Number.isInteger(i.price!)) && priced.filter((i) => i.price! >= 1000).length >= priced.length * 0.6) warnings.push('Os preços parecem estar em centavos (ex.: 2990 em vez de 29,90). Confira no Diagnóstico antes de analisar.')
  const level: Quality['level'] = items === 0 ? 'ruim' : warnings.length === 0 ? 'boa' : withPrice >= items * 0.5 ? 'parcial' : 'ruim'
  return { items, categories: s.categories.length, withPrice, withImage, withDescription, level, warnings }
}
