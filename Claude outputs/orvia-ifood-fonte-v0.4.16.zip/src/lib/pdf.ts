/**
 * Gerador mínimo de PDF (texto, Helvetica, A4, várias páginas) — sem dependências,
 * roda no content script. Acentos do português saem corretos (WinAnsi/cp1252).
 * Usado para a "Apresentação da proposta" (baixada pelo usuário e enviada ao cliente).
 */
import { fmtValue, KIND_LABEL, type Proposal } from '../core/proposal'

const PAGE_W = 595
const PAGE_H = 842
const M = 48

// cp1252 acima de 0x7F que aparecem em texto pt-BR
const CP1252: Record<string, number> = { '€': 0x80, '‚': 0x82, 'ƒ': 0x83, '„': 0x84, '…': 0x85, '†': 0x86, '‡': 0x87, 'ˆ': 0x88, '‰': 0x89, 'Š': 0x8a, '‹': 0x8b, 'Œ': 0x8c, 'Ž': 0x8e, '‘': 0x91, '’': 0x92, '“': 0x93, '”': 0x94, '•': 0x95, '–': 0x96, '—': 0x97, '™': 0x99, 'š': 0x9a, '›': 0x9b, 'œ': 0x9c, 'ž': 0x9e, 'Ÿ': 0x9f }
const REPLACE: Record<string, string> = { '→': '->', '←': '<-', '−': '-', '≥': '>=', '≤': '<=', '✓': 'OK', '✗': 'X', ' ': ' ', '​': '' }

/** Texto → bytes cp1252 (caracteres fora são trocados por equivalentes simples). */
export function toWinAnsi(input: string): number[] {
  const out: number[] = []
  for (const ch of input.normalize('NFC')) {
    const rep = REPLACE[ch]
    if (rep !== undefined) {
      for (const c of rep) out.push(c.charCodeAt(0))
      continue
    }
    const code = ch.codePointAt(0)!
    if (code === 0x0a || code === 0x0d || code === 0x09) out.push(0x20)
    else if (code >= 0x20 && code <= 0x7e) out.push(code)
    else if (code >= 0xa0 && code <= 0xff) out.push(code)
    else if (CP1252[ch] !== undefined) out.push(CP1252[ch]!)
    else if (code > 0xffff || (code >= 0x2600 && code <= 0x27bf)) continue // emoji/símbolos
    else out.push(0x3f)
  }
  return out
}

/** Largura aproximada (Helvetica), em unidades de 1/1000 em. */
function charW(c: number, bold: boolean): number {
  const ch = String.fromCharCode(c)
  let w = 556
  if ('ijl.,;:\'|!'.includes(ch) || c === 0x20) w = 278
  else if ('ftI'.includes(ch)) w = 278
  else if ('mwMW@'.includes(ch)) w = 833
  else if ('rJ()-'.includes(ch)) w = 333
  else if (ch >= 'A' && ch <= 'Z') w = 667
  return bold ? w * 1.06 : w
}
export function textWidth(bytes: number[], size: number, bold: boolean): number {
  return (bytes.reduce((s, c) => s + charW(c, bold), 0) * size) / 1000
}

function wrap(text: string, size: number, bold: boolean, width: number): number[][] {
  const lines: number[][] = []
  for (const para of text.split(/\n/)) {
    let line: number[] = []
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const w = toWinAnsi(word)
      const candidate = line.length ? [...line, 0x20, ...w] : w
      if (textWidth(candidate, size, bold) <= width || line.length === 0) {
        // palavra gigante (URL): quebra por caracteres
        if (line.length === 0 && textWidth(w, size, bold) > width) {
          let chunk: number[] = []
          for (const c of w) {
            if (textWidth([...chunk, c], size, bold) > width) {
              lines.push(chunk)
              chunk = []
            }
            chunk.push(c)
          }
          line = chunk
        } else line = candidate
      } else {
        lines.push(line)
        line = w
      }
    }
    lines.push(line)
  }
  return lines
}

export interface PdfBlock {
  text: string
  size?: number
  bold?: boolean
  color?: [number, number, number]
  gap?: number
  indent?: number
}

export function buildPdf(blocks: PdfBlock[], footer: string): Uint8Array {
  const pages: string[][] = [[]]
  let y = PAGE_H - M
  const newPage = () => {
    pages.push([])
    y = PAGE_H - M
  }
  const hex = (b: number[]) => `<${b.map((x) => x.toString(16).padStart(2, '0')).join('')}>`
  for (const b of blocks) {
    const size = b.size ?? 10
    const bold = b.bold ?? false
    const lead = size * 1.35
    const indent = b.indent ?? 0
    y -= b.gap ?? 0
    for (const line of wrap(b.text, size, bold, PAGE_W - 2 * M - indent)) {
      if (y - lead < M + 16) newPage()
      y -= lead
      const [r, g, bl] = b.color ?? [0.1, 0.12, 0.18]
      pages[pages.length - 1]!.push(`BT /${bold ? 'F2' : 'F1'} ${size} Tf ${r} ${g} ${bl} rg 1 0 0 1 ${M + indent} ${y.toFixed(1)} Tm ${hex(line)} Tj ET`)
    }
  }
  const foot = toWinAnsi(footer)
  pages.forEach((p, i) => {
    p.push(`BT /F1 8 Tf 0.5 0.55 0.65 rg 1 0 0 1 ${M} 28 Tm ${hex([...foot, ...toWinAnsi(`   |   ${i + 1}/${pages.length}`)])} Tj ET`)
    p.push(`0.24 0.56 1 RG 1.2 w ${M} 40 m ${PAGE_W - M} 40 l S`)
  })

  // objetos: 1 catálogo, 2 páginas, 3 fonte regular, 4 fonte negrito, depois (página, conteúdo) por página
  const objs: string[] = []
  objs[1] = '<< /Type /Catalog /Pages 2 0 R >>'
  const kids = pages.map((_, i) => `${5 + i * 2} 0 R`).join(' ')
  objs[2] = `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`
  objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'
  objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'
  pages.forEach((ops, i) => {
    const content = ops.join('\n')
    objs[5 + i * 2] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>`
    objs[6 + i * 2] = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  })
  let out = '%PDF-1.4\n'
  const offsets: number[] = []
  for (let i = 1; i < objs.length; i += 1) {
    offsets[i] = out.length
    out += `${i} 0 obj\n${objs[i]}\nendobj\n`
  }
  const xref = out.length
  out += `xref\n0 ${objs.length}\n0000000000 65535 f \n`
  for (let i = 1; i < objs.length; i += 1) out += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`
  out += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`
  // conteúdo é ASCII puro (texto vai em hex) → 1 char = 1 byte
  const bytes = new Uint8Array(out.length)
  for (let i = 0; i < out.length; i += 1) bytes[i] = out.charCodeAt(i) & 0xff
  return bytes
}

export interface PdfMeta {
  clientName: string
  merchantName: string | null
  city: string
  itemCount: number
  date: Date
}

/** Apresentação da proposta: resumo, mudanças, combos, concorrentes e fontes. */
export function proposalPdf(p: Proposal, meta: PdfMeta): Uint8Array {
  const BLUE: [number, number, number] = [0.15, 0.4, 0.95]
  const GREY: [number, number, number] = [0.4, 0.45, 0.55]
  const blocks: PdfBlock[] = []
  const h = (text: string) => blocks.push({ text, size: 13, bold: true, color: BLUE, gap: 14 })
  blocks.push({ text: 'Orvia', size: 11, bold: true, color: BLUE })
  blocks.push({ text: 'Proposta de otimização de cardápio', size: 22, bold: true, gap: 6 })
  blocks.push({ text: `${meta.clientName}${meta.merchantName && meta.merchantName !== meta.clientName ? ` (${meta.merchantName})` : ''}`, size: 13, gap: 4 })
  blocks.push({ text: `${meta.date.toLocaleDateString('pt-BR')}  |  ${meta.itemCount} produtos analisados${meta.city ? `  |  Região: ${meta.city}` : ''}  |  Versão ${p.version}`, size: 9, color: GREY, gap: 2 })

  h('Resumo')
  blocks.push({ text: p.summary, size: 10.5, gap: 2 })
  p.notices.forEach((n) => blocks.push({ text: `Aviso: ${n}`, size: 9, color: GREY, gap: 2 }))

  const exec = p.actions.filter((a) => a.kind !== 'create_combo' && a.kind !== 'recommend')
  const combos = p.actions.filter((a) => a.kind === 'create_combo')
  const recs = p.actions.filter((a) => a.kind === 'recommend')

  if (combos.length) {
    h(`Combos sugeridos (${combos.length})`)
    combos.forEach((a, i) => {
      blocks.push({ text: `${i + 1}. ${a.itemName}`, size: 11, bold: true, gap: 8 })
      if (a.combo) {
        blocks.push({ text: a.combo.components.map((c) => `${c.quantity > 1 ? `${c.quantity}x ` : ''}${c.name}`).join(' + '), size: 10, indent: 12 })
        blocks.push({ text: `Preço separado: ${fmtValue('update_price', a.combo.fullPrice)}  ->  combo: ${fmtValue('update_price', a.combo.price)}`, size: 10, indent: 12 })
      }
      blocks.push({ text: a.reason, size: 9, color: GREY, indent: 12 })
    })
  }
  if (exec.length) {
    h(`Ajustes em produtos (${exec.length})`)
    exec.forEach((a) => {
      blocks.push({ text: `${KIND_LABEL[a.kind]}  -  ${a.itemName}`, size: 10.5, bold: true, gap: 7 })
      blocks.push({ text: `Hoje: ${fmtValue(a.kind, a.before)}`, size: 9.5, indent: 12, color: GREY })
      blocks.push({ text: `Proposto: ${fmtValue(a.kind, a.after)}`, size: 9.5, indent: 12 })
      blocks.push({ text: `Por quê: ${a.reason}`, size: 9, indent: 12, color: GREY })
    })
  }
  if (recs.length) {
    h(`Pontos de atenção (${recs.length})`)
    recs.forEach((a) => {
      blocks.push({ text: a.itemName, size: 10.5, bold: true, gap: 7 })
      blocks.push({ text: String(a.after ?? ''), size: 9.5, indent: 12 })
    })
  }
  if (p.competitors.length || p.insights.length) {
    h('O que a região está fazendo')
    p.insights.forEach((t) => blocks.push({ text: `- ${t}`, size: 10, gap: 3 }))
    p.competitors.forEach((c) => {
      blocks.push({ text: c.name, size: 10.5, bold: true, gap: 7 })
      c.highlights.forEach((t) => blocks.push({ text: `- ${t}`, size: 9.5, indent: 12 }))
      c.examples.slice(0, 4).forEach((e) => blocks.push({ text: `${e.name}${e.price !== null ? `: ${fmtValue('update_price', e.price)}` : ''}`, size: 9, indent: 12, color: GREY }))
    })
  }
  if (p.sources.length) {
    h('Fontes consultadas (informações públicas)')
    p.sources.forEach((s) => blocks.push({ text: `${s.title} - ${s.url}`, size: 8.5, color: GREY, gap: 2 }))
  }
  blocks.push({ text: 'Valores e dados de concorrentes são referências públicas no momento da consulta e podem mudar. Nada é alterado no iFood sem a sua aprovação.', size: 8.5, color: GREY, gap: 16 })
  return buildPdf(blocks, `Orvia  |  ${meta.clientName}`)
}
