/**
 * Criação de produto por DUPLICAÇÃO — receita OBSERVADA no portal real (gravação do usuário):
 *   GET  /partner-catalog-bff/product/{baseId}?ownerId=…               (produto base, DA MESMA categoria)
 *   GET  /partner-catalog-bff/product/{baseId}/available-at?ownerId=…  (categoria + preço do base)
 *   POST /partner-catalog-bff/product?ownerId=…&createDefaultCategory=false   (id:"" + nome/descrição novos; complementos copiados)
 *   POST /partner-catalog-bff/product/link/categories:batch?ownerId=…  (vincula o novo produto à MESMA categoria, com preço)
 *   PATCH /next-web-bff/menu/v4/status?ownerUUID=…                     (pausa o item recém-criado, como o portal)
 * Regras: o base precisa estar numa categoria (a nova fica nela, nunca em outra); complementos do base são
 * mantidos exatamente; estrutura desconhecida ABORTA antes de enviar; no fim relê e confere.
 * Puro: sem chrome.*, sem DOM.
 */
import type { PortalRequest } from './executor'
import type { PortalCtx } from './item-editor'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300

const PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'variant', 'unit', 'optionGroups', 'promotions', 'shouldBlock', 'tags', 'classification', 'stock', 'combo', 'comboOptionGroups'])
const GROUP_KEYS = new Set(['id', 'name', 'status', 'type', 'sequence', 'min', 'max', 'options'])
const OPTION_KEYS = new Set(['id', 'name', 'description', 'sequence', 'product', 'status', 'extensions'])
const OPTION_PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'optionGroups', 'tags', 'classification', 'stock'])
const OPT_EXT_KEYS = new Set(['status', 'price', 'catalogType', 'promotions', 'restrictions', 'id', 'itemExtensionId'])
const unknownKeys = (o: Rec, known: Set<string>) => Object.keys(o).filter((k) => !known.has(k))

export type BuiltCreate = { ok: true; body: Rec } | { ok: false; reason: string }

/** Corpo do POST /product: o produto base com id vazio, nome/descrição novos e complementos idênticos. */
export function buildCreateBody(base: unknown, over: { name: string; description?: string }): BuiltCreate {
  if (!isRec(base) || typeof base.id !== 'string') return { ok: false, reason: 'leitura do produto base inesperada' }
  const bad = unknownKeys(base, PRODUCT_KEYS)
  if (bad.length) return { ok: false, reason: `produto base com campos que não conheço (${bad.join(', ')}) — nada criado` }
  if (!isRec(base.imageResource) || !Array.isArray(base.optionGroups)) return { ok: false, reason: 'produto base sem campos esperados' }

  const optionGroups: Rec[] = []
  for (const g of base.optionGroups) {
    if (!isRec(g) || unknownKeys(g, GROUP_KEYS).length || !Array.isArray(g.options)) return { ok: false, reason: 'grupo de complementos com campos que não conheço — nada criado' }
    const options: Rec[] = []
    for (const o of g.options) {
      if (!isRec(o) || unknownKeys(o, OPTION_KEYS).length || !isRec(o.product) || !isRec(o.extensions)) return { ok: false, reason: 'complemento com campos que não conheço — nada criado' }
      if (unknownKeys(o.product, OPTION_PRODUCT_KEYS).length) return { ok: false, reason: 'complemento com campos que não conheço — nada criado' }
      const extensions: Rec = {}
      for (const [id, e] of Object.entries(o.extensions)) {
        if (!isRec(e) || unknownKeys(e, OPT_EXT_KEYS).length) return { ok: false, reason: 'preço de complemento com campos que não conheço — nada criado' }
        extensions[id] = { status: e.status, price: e.price, catalogType: e.catalogType, promotions: e.promotions ?? [], ...(e.restrictions !== undefined ? { restrictions: e.restrictions } : {}), id }
      }
      options.push({ id: o.id, sequence: o.sequence, product: { ...o.product, stock: null }, status: o.status, extensions })
    }
    optionGroups.push({ id: g.id, name: g.name, status: g.status, type: g.type ?? '', sequence: g.sequence, min: g.min, max: g.max, options })
  }

  return {
    ok: true,
    body: {
      stock: null,
      id: '',
      combo: false,
      comboOptionGroups: [],
      imageResource: base.imageResource,
      tags: Array.isArray(base.tags) ? base.tags : [],
      classification: Array.isArray(base.classification) ? base.classification : [],
      unit: typeof base.unit === 'string' && base.unit ? base.unit : 'g',
      variant: base.variant ?? 'REGULAR',
      industrialized: base.industrialized ?? false,
      description: over.description ?? (typeof base.description === 'string' ? base.description : ''),
      name: over.name,
      optionGroups,
      promotions: Array.isArray(base.promotions) ? base.promotions : [],
      shouldBlock: base.shouldBlock ?? false,
    },
  }
}

export interface CreateOpts {
  /** produto base (productId) — OBRIGATORIAMENTE um produto que já está na categoria de destino */
  baseProductId: string
  /** se informado, o base precisa estar nesta categoria; senão usa a primeira categoria dele */
  categoryId?: string | null
  name: string
  description?: string
  /** preço do novo produto; se ausente, usa o do base */
  price?: number | null
  /** cria já pausado (padrão: true — o dono revisa foto/complementos antes de ativar) */
  paused?: boolean
  ctx: PortalCtx
  request: PortalRequest
}

const urlOf = (ctx: PortalCtx, path: string, extra = '') => `${ctx.origin}${path}?ownerId=${encodeURIComponent(ctx.ownerId)}${extra}`

export async function createItemFromBase(o: CreateOpts): Promise<{ ok: boolean; message: string; productId?: string }> {
  const { ctx, request } = o
  const name = o.name.trim()
  if (name.length < 2) return { ok: false, message: 'Nome do novo produto vazio — nada criado.' }
  const [p, a] = [await request('GET', urlOf(ctx, `/partner-catalog-bff/product/${o.baseProductId}`)), await request('GET', urlOf(ctx, `/partner-catalog-bff/product/${o.baseProductId}/available-at`))]
  if (!ok2xx(p.status) || !ok2xx(a.status)) return { ok: false, message: `Não consegui ler o produto base no iFood (HTTP ${p.status}/${a.status}).` }
  if (!isRec(p.json) || p.json.id !== o.baseProductId) return { ok: false, message: 'O iFood devolveu outro produto — nada criado.' }
  if (!Array.isArray(a.json) || !a.json.length) return { ok: false, message: 'O produto base não está em nenhuma categoria — não sei onde criar o novo.' }

  const cats = a.json.filter(isRec)
  const cat = o.categoryId ? cats.find((c) => c.id === o.categoryId) : cats[0]
  if (!cat || typeof cat.id !== 'string' || !isRec(cat.extensions)) return { ok: false, message: 'O produto base não está na categoria de destino — nada criado para não cair na categoria errada.' }
  const catName = typeof cat.name === 'string' ? cat.name : ''
  const baseExt = Object.entries(cat.extensions)
  if (!baseExt.length || baseExt.some(([, e]) => !isRec(e))) return { ok: false, message: 'Preço/canal do produto base inesperado — nada criado.' }

  const built = buildCreateBody(p.json, { name, description: o.description })
  if (!built.ok) return { ok: false, message: built.reason }

  // cria o produto
  const created = await request('POST', urlOf(ctx, '/partner-catalog-bff/product', '&createDefaultCategory=false'), built.body)
  const newId = isRec(created.json) && typeof created.json.id === 'string' ? created.json.id : ''
  if (!ok2xx(created.status) || !newId) return { ok: false, message: `O iFood recusou a criação do produto (HTTP ${created.status}).` }

  // vincula à MESMA categoria do base, com o preço pedido (ou o do base)
  const extensions: Rec = {}
  for (const [catalogId, e] of baseExt) {
    const ee = e as Rec
    const price = o.price != null && Number.isFinite(o.price) ? o.price : ee.price
    extensions[catalogId] = { catalogType: ee.catalogType, id: catalogId, price, status: 'AVAILABLE' }
  }
  const link = await request('POST', urlOf(ctx, '/partner-catalog-bff/product/link/categories:batch'), [
    { productId: newId, categoryName: catName, categoryId: cat.id, availability: 'ALWAYS', extensions, shifts: [], classification: [], itemsCount: 0 },
  ])
  if (!ok2xx(link.status)) {
    return { ok: false, productId: newId, message: `Produto criado, mas o iFood recusou colocá-lo na categoria “${catName}” (HTTP ${link.status}). Ele ficou sem categoria — encontre “${name}” no portal e vincule.` }
  }

  // confere: o novo produto existe, com o nome e os mesmos complementos do base, na categoria certa
  const [np, na] = [await request('GET', urlOf(ctx, `/partner-catalog-bff/product/${newId}`)), await request('GET', urlOf(ctx, `/partner-catalog-bff/product/${newId}/available-at`))]
  const groupsOf = (j: unknown) => (isRec(j) && Array.isArray(j.optionGroups) ? j.optionGroups.map((g) => (isRec(g) ? [g.name, Array.isArray(g.options) ? g.options.length : 0] : null)) : null)
  const inCat = ok2xx(na.status) && Array.isArray(na.json) && na.json.some((c) => isRec(c) && c.id === cat.id)
  const sameName = ok2xx(np.status) && isRec(np.json) && np.json.name === name
  const sameGroups = JSON.stringify(groupsOf(np.json)) === JSON.stringify(groupsOf(p.json))
  if (!sameName || !inCat || !sameGroups) {
    return { ok: false, productId: newId, message: `Criei “${name}”, mas a conferência não bateu (${!sameName ? 'nome ' : ''}${!inCat ? 'categoria ' : ''}${!sameGroups ? 'complementos' : ''}). Confira no portal.` }
  }

  // pausa o recém-criado (o portal faz o mesmo na gravação): o dono revisa foto/complementos e ativa
  const paused = o.paused !== false
  let pauseNote = ''
  if (paused) {
    const offerId = (na.json as Rec[]).find((c) => c.id === cat.id)?.offerId
    if (typeof offerId === 'string') {
      const st = await request('PATCH', `${ctx.origin}/next-web-bff/menu/v4/status?ownerUUID=${encodeURIComponent(ctx.ownerId)}`, {
        items: [{ catalogItemId: offerId, parentCustomizationOptionId: '', status: 'AVAILABLE', statusByCatalog: baseExt.map(([catalogId]) => ({ catalogId, status: 'UNAVAILABLE' })) }],
      })
      pauseNote = ok2xx(st.status) ? ' Está pausado para você revisar e ativar.' : ' Não consegui pausar — ele ficou ATIVO; pause no portal se quiser revisar antes.'
    } else pauseNote = ' Não achei o código do item para pausar — ele ficou ATIVO.'
  }
  return { ok: true, productId: newId, message: `Criado “${name}” na categoria “${catName}” com os complementos de “${String(p.json.name)}”.${pauseNote}` }
}
