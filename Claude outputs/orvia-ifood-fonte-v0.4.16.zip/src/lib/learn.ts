/**
 * Aprendizado por exemplo: a extensão NÃO conhece (nem chuta) a API interna do
 * portal. Quando o usuário edita um produto no portal, observamos a requisição
 * de escrita que o PRÓPRIO portal fez e extraímos um "molde":
 *   - URL com o id do item no lugar de {id}
 *   - modo 'rmw' (lê o detalhe do item, altera só o campo, envia o objeto inteiro)
 *     quando o corpo enviado tem a mesma forma de uma leitura recente do item;
 *     ou 'patch' quando o corpo só contém o(s) campo(s) alterado(s)
 *   - caminho exato do campo (preço/status/nome/descrição) e unidade do preço
 * Puro: sem chrome.*, sem DOM.
 */

export type Field = 'price' | 'status' | 'name' | 'description'
export type Path = (string | number)[]

export interface Observed {
  method: string
  url: string
  body?: unknown
  json?: unknown
  status?: number
  at: number
}

export interface Template {
  field: Field
  mode: 'rmw' | 'patch'
  method: string
  urlTemplate: string
  /** rmw: GET do detalhe (mesma forma do corpo enviado) */
  detailUrlTemplate?: string
  /** rmw: caminho dentro da resposta do GET até o objeto que é enviado (ex.: ['data']) */
  unwrap?: Path
  path: Path
  unit?: 'reais' | 'centavos'
  statusValues?: { active?: unknown; paused?: unknown }
  /** patch: corpo modelo + caminhos onde vai o id */
  patchBody?: unknown
  idPaths?: Path[]
  /** qual identificador do produto o portal usa nesta chamada (padrão: id do item) */
  idKind?: 'id' | 'productId'
  /** patch: outros números do corpo que espelham o preço (ex.: oldPrice = preço anterior) */
  mirrors?: { path: Path; of: 'before' | 'after' }[]
  /** GET do detalhe do item ({id}) para conferir o preço depois de gravar */
  verifyUrlTemplate?: string
  learnedAt: string
  /** versão do aprendizado (moldes antigos/inseguros são descartados) */
  v?: number
}

export const TEMPLATE_VERSION = 2

/** Descarta moldes antigos ou inseguros (ex.: o que pausaria uma CATEGORIA em vez do produto). */
export function validTemplates(list: Template[] | undefined): Template[] {
  return (list ?? []).filter((t) => !(t.field === 'status' && t.v !== TEMPLATE_VERSION) && !(t.mode === 'patch' && (!t.idPaths || t.idPaths.length === 0) && !t.urlTemplate.includes('{id}')) && !String(t.path[0]).toLowerCase().includes('categor'))
}

const contains = (v: unknown, needle: string): boolean => (typeof v === 'string' ? v === needle : Array.isArray(v) ? v.some((x) => contains(x, needle)) : isRec(v) ? Object.values(v).some((x) => contains(x, needle)) : false)

/** Mantém só a parte do corpo que fala do PRODUTO (descarta categorias e outros itens enviados junto). */
export function pruneToId(body: Rec, id: string): Rec {
  // só poda quando o id do produto está dentro de uma LISTA (ex.: items[]) — aí as outras listas (categories[]) são de outras entidades
  const idInList = Object.values(body).some((v) => Array.isArray(v) && contains(v, id))
  if (!idInList) return body
  const out: Rec = {}
  for (const [k, v] of Object.entries(body)) {
    if (Array.isArray(v)) {
      const mine = v.filter((x) => contains(x, id))
      if (mine.length) out[k] = mine
    } else out[k] = v
  }
  return out
}

const STATUS_PAIRS: Record<string, string> = { UNAVAILABLE: 'AVAILABLE', AVAILABLE: 'UNAVAILABLE', INACTIVE: 'ACTIVE', ACTIVE: 'INACTIVE', PAUSED: 'ACTIVE', DISABLED: 'ENABLED', ENABLED: 'DISABLED' }
const PAUSED_WORD = /^(unavailable|inactive|paused|disabled|false)$/i

export type LearnResult = { ok: true; templates: Template[]; itemId: string } | { ok: false; reason: string }

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)

export function leaves(value: unknown, path: Path = [], out: { path: Path; value: unknown }[] = []) {
  if (Array.isArray(value)) value.forEach((v, i) => leaves(v, [...path, i], out))
  else if (isRec(value)) for (const [k, v] of Object.entries(value)) leaves(v, [...path, k], out)
  else out.push({ path, value })
  return out
}

export function getPath(obj: unknown, path: Path): unknown {
  let cur: any = obj
  for (const key of path) {
    if (cur === null || cur === undefined) return undefined
    cur = cur[key as any]
  }
  return cur
}

export function setPath(obj: unknown, path: Path, value: unknown): void {
  let cur: any = obj
  for (let i = 0; i < path.length - 1; i += 1) cur = cur[path[i] as any]
  cur[path[path.length - 1] as any] = value
}

export const pathKey = (p: Path) => p.map(String).join('.')

/** Diferenças folha a folha entre dois objetos de mesma forma. */
export function diffLeaves(before: unknown, after: unknown): { path: Path; before: unknown; after: unknown }[] {
  const a = new Map(leaves(before).map((l) => [pathKey(l.path), l]))
  const out: { path: Path; before: unknown; after: unknown }[] = []
  const seen = new Set<string>()
  for (const l of leaves(after)) {
    const k = pathKey(l.path)
    seen.add(k)
    const prev = a.get(k)
    if (!prev || !Object.is(prev.value, l.value)) out.push({ path: l.path, before: prev?.value, after: l.value })
  }
  for (const [k, l] of a) if (!seen.has(k)) out.push({ path: l.path, before: l.value, after: undefined })
  return out
}

function keyOverlap(a: unknown, b: unknown): number {
  if (!isRec(a) || !isRec(b)) return 0
  const ka = Object.keys(a)
  const kb = new Set(Object.keys(b))
  if (ka.length === 0) return 0
  return ka.filter((k) => kb.has(k)).length / Math.max(ka.length, kb.size)
}

const UNWRAPS: Path[] = [[], ['data'], ['item'], ['data', 'item'], ['product'], ['data', 'product']]

function classify(path: Path, value: unknown): Field | null {
  const keys = path.filter((p) => typeof p === 'string').map((p) => (p as string).toLowerCase())
  const last = keys[keys.length - 1] ?? ''
  const all = keys.join('.')
  if (typeof value === 'number' && /(price|preco|valor|value|amount)/.test(all)) return 'price'
  if ((typeof value === 'boolean' || typeof value === 'string') && /(status|available|availability|paused|enabled|active|situa)/.test(last)) return 'status'
  if (typeof value === 'string' && /(description|descricao|details)/.test(last)) return 'description'
  if (typeof value === 'string' && /^(name|title|nome)$/.test(last)) return 'name'
  return null
}

function findItemId(write: Observed, ids: Set<string>): string | null {
  const u = new URL(write.url, 'https://portal.ifood.com.br')
  for (const seg of u.pathname.split('/')) {
    if (seg && ids.has(decodeURIComponent(seg))) return decodeURIComponent(seg)
  }
  for (const v of u.searchParams.values()) if (ids.has(v)) return v
  for (const l of leaves(write.body)) if (typeof l.value === 'string' && ids.has(l.value)) return l.value
  return null
}

/**
 * Aprende moldes a partir de uma escrita observada.
 * @param itemsById itens do snapshot (preço/status atuais em reais) — usados para unidade e status
 */
export function learnFromWrite(
  write: Observed,
  recentReads: Observed[],
  itemsById: Map<string, { price: number | null; status: string }>,
  /** productId → id do item (o portal às vezes grava pelo productId) */
  productIds: Map<string, string> = new Map(),
): LearnResult {
  const method = write.method.toUpperCase()
  if (!['PUT', 'PATCH', 'POST'].includes(method)) return { ok: false, reason: 'não é escrita' }
  if (!isRec(write.body)) return { ok: false, reason: 'corpo não é objeto JSON' }
  if (write.status !== undefined && (write.status < 200 || write.status >= 300)) return { ok: false, reason: 'o portal recusou a alteração' }
  let idKind: 'id' | 'productId' = 'id'
  let itemId = findItemId(write, new Set(itemsById.keys()))
  let matched = itemId
  if (!itemId) {
    const viaProduct = findItemId(write, new Set(productIds.keys()))
    if (viaProduct) {
      matched = viaProduct
      itemId = productIds.get(viaProduct)!
      idKind = 'productId'
    }
  }
  if (!itemId || !matched) return { ok: false, reason: 'não reconheci qual produto foi alterado (abra o cardápio antes para a extensão ler os produtos)' }
  const item = itemsById.get(itemId)!
  const urlTemplate = write.url.split(matched).join('{id}')

  // Leitura do detalhe com a mesma forma do corpo enviado → modo rmw
  let rmw: { read: Observed; unwrap: Path; obj: unknown } | null = null
  for (const read of [...recentReads].sort((a, b) => b.at - a.at)) {
    if (!read.url.includes(itemId) || read.method.toUpperCase() !== 'GET') continue
    for (const unwrap of UNWRAPS) {
      const obj = unwrap.length ? getPath(read.json, unwrap) : read.json
      if (keyOverlap(obj, write.body) >= 0.6) {
        rmw = { read, unwrap, obj }
        break
      }
    }
    if (rmw) break
  }

  const body: Rec = rmw ? (write.body as Rec) : pruneToId(write.body as Rec, matched)
  const diffs = rmw
    ? diffLeaves(rmw.obj, write.body).filter((d) => d.after !== undefined)
    : leaves(body)
        .filter((l) => l.value !== matched)
        .map((l) => ({ path: l.path, before: undefined as unknown, after: l.value }))
  if (diffs.length === 0) return { ok: false, reason: 'nenhuma mudança detectada' }
  // o preço "principal" é o que NÃO é oldPrice/originalValue
  const isOld = (p: Path) => p.some((k) => typeof k === 'string' && /old|original|previous|anterior/i.test(k))
  diffs.sort((a, b) => Number(isOld(a.path)) - Number(isOld(b.path)))

  const templates: Template[] = []
  const unknownPaths: Path[] = []
  const extras: { field: Field; path: Path; value: unknown }[] = []
  for (const d of diffs) {
    const field = classify(d.path, d.after)
    if (!field) {
      unknownPaths.push(d.path)
      continue
    }
    if (templates.some((t) => t.field === field)) {
      extras.push({ field, path: d.path, value: d.after })
      continue
    }
    const base: Template = {
      field,
      mode: rmw ? 'rmw' : 'patch',
      method,
      urlTemplate,
      path: d.path,
      learnedAt: new Date(write.at).toISOString(),
      v: TEMPLATE_VERSION,
    }
    if (rmw) {
      base.detailUrlTemplate = rmw.read.url.split(matched).join('{id}')
      base.unwrap = rmw.unwrap
    }
    if (field === 'price') {
      const ref = typeof d.before === 'number' ? d.before : (d.after as number)
      const p = item.price ?? 0
      base.unit = Number.isInteger(ref) && Math.abs(ref / 100 - p) < Math.abs(ref - p) ? 'centavos' : 'reais'
    }
    if (field === 'status') {
      const wasActive = item.status !== 'paused'
      const counterpart = typeof d.after === 'string' ? STATUS_PAIRS[d.after.toUpperCase()] : undefined
      if (typeof d.after === 'string' && counterpart) {
        const keepCase = (s: string) => (d.after === (d.after as string).toLowerCase() ? s.toLowerCase() : s)
        base.statusValues = PAUSED_WORD.test(d.after) ? { paused: d.after, active: keepCase(counterpart) } : { active: d.after, paused: keepCase(counterpart) }
        templates.push(base)
        continue
      }
      base.statusValues = wasActive ? { paused: d.after, active: d.before } : { active: d.after, paused: d.before }
      if (base.statusValues.active === undefined && typeof d.after === 'boolean') base.statusValues = wasActive ? { paused: d.after, active: !d.after } : { active: d.after, paused: !d.after }
    }
    templates.push(base)
  }

  if (templates.length === 0) return { ok: false, reason: 'mudança em campo que a extensão ainda não sabe aplicar' }
  if (!rmw) {
    // Patch só é seguro se o corpo NÃO carregar outros dados do item (senão copiaríamos dados de um item para outro)
    // Corpo pequeno e sem textos longos (ex.: catalogId, moeda) = chamada específica de um campo (como /price/single): constantes da loja, seguro repetir.
    const rest = unknownPaths.map((p) => getPath(body, p))
    const smallScoped = templates.length === 1 && leaves(body).length <= 16 && rest.every((v) => v === null || typeof v === 'boolean' || (typeof v === 'string' && v.length <= 40))
    if (unknownPaths.length > 0 && !smallScoped) return { ok: false, reason: 'o portal envia o produto inteiro sem uma leitura correspondente — abra o produto no portal (para a extensão ler o detalhe) e salve de novo' }
    // valores repetidos no corpo (oldPrice = preço de antes; statusByCatalog.status = mesmo status)
    for (const ex of extras) {
      const main = templates.find((t) => t.field === ex.field)!
      const afterRaw = getPath(body, main.path)
      const beforeRaw = main.unit === 'centavos' ? Math.round((item.price ?? 0) * 100) : item.price
      const list = (main.mirrors ??= [])
      if (Object.is(ex.value, afterRaw)) list.push({ path: ex.path, of: 'after' })
      else if (ex.field === 'price' && typeof ex.value === 'number' && beforeRaw !== null && ex.value === beforeRaw) list.push({ path: ex.path, of: 'before' })
      else return { ok: false, reason: `o portal envia um segundo valor (${ex.path.join('.')}) que não consegui relacionar ao valor antigo/novo` }
    }
    const idPaths = leaves(body).filter((l) => l.value === matched).map((l) => l.path)
    if (idPaths.length === 0 && !urlTemplate.includes('{id}')) return { ok: false, reason: 'não achei onde o portal coloca o id do produto no corpo' }
    for (const t of templates) {
      t.patchBody = body
      t.idPaths = idPaths
      t.idKind = idKind
    }
  }
  const verifyRead = [...recentReads].sort((a, b) => b.at - a.at).find((r) => r.method.toUpperCase() === 'GET' && r.url.includes(matched) && isRec(r.json) && 'priceByCatalog' in r.json)
  for (const t of templates) {
    t.idKind = idKind
    if (verifyRead && !t.verifyUrlTemplate) t.verifyUrlTemplate = verifyRead.url.split(matched).join('{id}')
  }
  return { ok: true, templates, itemId }
}

export const FIELD_LABEL: Record<Field, string> = { price: 'Preço', status: 'Pausar/ativar', name: 'Nome', description: 'Descrição' }
