import { describe, expect, it } from 'vitest'
import { buildSnapshot } from '../src/core/capture'
import { auditPractices, charmPrice, practiceActions, unsortedCategories } from '../src/core/practices'
import { buildLocalProposal, defaultContext, defaultApproved } from '../src/core/proposal'

const row = (id: string, name: string, value: number, desc = 'Pão macio, carne artesanal de 150g, queijo derretido e molho da casa', img = true) => ({
  id, name, description: desc, availability: 'AVAILABLE', productId: `p${id}`,
  ...(img ? { imageResource: { baseUrl: 'https://img.x/', path: `${id}.jpg` } } : {}),
  priceByCatalog: [{ catalogId: 'k', price: { value } }],
})
function snap(lists: Record<string, { name: string; rows: ReturnType<typeof row>[] }>) {
  const caps = [
    { path: '/category', payload: Object.entries(lists).map(([id, l]) => ({ categoryId: id, name: l.name })) },
    ...Object.entries(lists).map(([id, l]) => ({ path: '/items', payload: { total: l.rows.length, rows: l.rows }, categoryId: id })),
  ]
  return buildSnapshot(caps, { origin: 'active', domUrl: '' }).snapshot!
}

describe('charmPrice (gatilho ,90)', () => {
  it('arredonda para o ,90 mais próximo dentro de 5%', () => {
    expect(charmPrice(30)).toBe(29.9)
    expect(charmPrice(28.5)).toBe(28.9)
    expect(charmPrice(39.9)).toBeNull()
    expect(charmPrice(39.99)).toBeNull()
    expect(charmPrice(5)).toBe(4.9) // -2%
    expect(charmPrice(2.5)).toBeNull() // 2,90 = +16%: grande demais
  })
})

describe('boas práticas do PDF', () => {
  const s = snap({
    a: { name: 'Lanches', rows: [row('1', 'X-Burger', 32), row('2', 'X-Bacon', 29.9), row('3', 'X-Tudo', 40, 'curto', false)] },
    b: { name: 'Bebidas', rows: [row('4', 'Refri', 6.9)] },
  })
  it('placar: 6 critérios com nível correto', () => {
    const c = Object.fromEntries(auditPractices(s).map((x) => [x.id, x]))
    expect(Object.keys(c).sort()).toEqual(['categorias', 'descricoes', 'fotos', 'gatilhos', 'ordenacao', 'promocoes'])
    expect(c.promocoes!.level).toBe('falha')
    expect(c.categorias!.level).toBe('atencao') // Bebidas com 1 item
    expect(c.ordenacao!.count).toBe(1)
    expect(c.fotos!.count).toBe(1)
    expect(c.descricoes!.count).toBe(1)
    expect(c.gatilhos!.count).toBe(2) // 32 e 40
  })
  it('ordenação: só categorias com 3+ itens fora de ordem', () => {
    expect(unsortedCategories(s).map((u) => u.name)).toEqual(['Lanches'])
  })
  it('ações: preço ,90 é executável e NÃO vem marcado; ordenação é recomendação', () => {
    const a = practiceActions(s, defaultContext('hamburgueria', 10))
    const price = a.filter((x) => x.kind === 'update_price')
    expect(price.map((x) => [x.itemName, x.after])).toEqual([['X-Burger', 31.9], ['X-Tudo', 39.9]])
    expect(price.every((x) => x.executable && x.risk === 'alto')).toBe(true)
    expect(a.some((x) => x.kind === 'recommend' && /menor para o maior/.test(x.itemName))).toBe(true)
    const p = buildLocalProposal(s, defaultContext('hamburgueria', 10))
    expect(defaultApproved(p).has('update_price:1')).toBe(false)
  })
  it('respeita "não mexer em preços" e itens travados', () => {
    expect(practiceActions(s, { ...defaultContext('x', 10), doNotTouchPrices: true }).some((x) => x.kind === 'update_price')).toBe(false)
    expect(practiceActions(s, { ...defaultContext('x', 10), doNotTouchItemIds: ['1'] }).some((x) => x.itemId === '1')).toBe(false)
  })
  it('cardápio nota 10 → tudo ok', () => {
    const g = snap({
      c: { name: 'Combos e promoções', rows: [row('1', 'Combo A', 29.9), row('2', 'Combo B', 39.9)] },
      d: { name: 'Lanches', rows: [row('3', 'X-Burger', 19.9), row('4', 'X-Bacon', 24.9), row('5', 'X-Tudo', 29.9)] },
    })
    expect(auditPractices(g).every((x) => x.level === 'ok')).toBe(true)
  })
})

import { guessNiche, NICHES } from '../src/core/rules'
import { STRATEGIES, strategyOf } from '../src/core/strategy'
describe('nicho e estratégia', () => {
  it('detecta o nicho pelos produtos', () => {
    expect(guessNiche({ items: [{ name: 'Pizza Calabresa' }, { name: 'Pizza Marguerita' }, { name: 'Coca' }] })).toBe('pizzaria')
    expect(guessNiche({ items: [{ name: 'Pastel de carne' }, { name: 'Pastéis de queijo' }] })).toBe('pastelaria')
    expect(guessNiche({ items: [{ name: 'Coca' }, { name: 'Água' }] })).toBeNull()
  })
  it('lista os nichos pedidos e 4 estratégias com instrução para a IA', () => {
    const l = NICHES.map((n) => n.label)
    expect(['Pizzaria', 'Hamburgueria', 'Pastelaria']).toEqual(expect.arrayContaining(['Pizzaria', 'Hamburgueria', 'Pastelaria'].filter((x) => l.includes(x))))
    expect(l).toEqual(expect.arrayContaining(['Pizzaria', 'Hamburgueria', 'Pastelaria']))
    expect(STRATEGIES).toHaveLength(4)
    expect(STRATEGIES.every((s) => /nicho/i.test(s.brief))).toBe(true)
    expect(strategyOf('xyz').value).toBe('mercado')
  })
})
