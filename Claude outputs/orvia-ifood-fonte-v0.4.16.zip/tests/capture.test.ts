import { describe, expect, it } from 'vitest'
import menuFixture from './fixtures/menu-payload.json'
import split from './fixtures/split-catalog.json'
import { assessQuality, buildSnapshot, isMenuLike, mergeSnapshots, scorePayload, shapeSignature } from '../src/core/capture'
import { finalizeSnapshot, normalizeMenuPayload } from '../src/core/normalize'

const dom = { origin: 'active' as const, domUrl: 'https://portal.ifood.com.br/menu/list' }

describe('scorePayload / isMenuLike', () => {
  it('reconhece o formato clássico', () => {
    expect(isMenuLike(scorePayload(menuFixture))).toBe(true)
  })
  it('reconhece cardápio dividido (categorias com productId + catálogo de produtos)', () => {
    expect(isMenuLike(scorePayload(split.categories))).toBe(true)
    expect(isMenuLike(scorePayload(split.products))).toBe(true)
  })
  it('reconhece envelope GraphQL', () => {
    const gql = { data: { menu: { sections: [{ title: 'Pizzas', products: [{ id: 1, title: 'Calabresa', unitPrice: 39 }, { id: 2, title: 'Mussarela', unitPrice: 35 }] }] } } }
    expect(isMenuLike(scorePayload(gql))).toBe(true)
  })
  it('ignora respostas que não são cardápio', () => {
    expect(isMenuLike(scorePayload({ user: { name: 'Ana', email: 'a@b.c' }, flags: [1, 2, 3] }))).toBe(false)
    expect(isMenuLike(scorePayload([{ id: 1, status: 'ok' }]))).toBe(false)
  })
  it('shapeSignature não vaza valores', () => {
    const sig = shapeSignature({ token: 'SEGREDO123', list: [{ name: 'Maria', price: 3 }] })
    expect(sig).not.toContain('SEGREDO123')
    expect(sig).not.toContain('Maria')
    expect(sig).toContain('price')
  })
})

describe('buildSnapshot: junção de respostas parciais', () => {
  it('junta categorias+preços (A) com nomes/imagens (B) via productId, em qualquer ordem', () => {
    for (const order of [['categories', 'products'], ['products', 'categories']] as const) {
      const fresh = JSON.parse(JSON.stringify(split))
      const r = buildSnapshot(order.map((k) => ({ path: `/${k}`, payload: fresh[k] })), dom)
      const s = r.snapshot!
      expect(s.items).toHaveLength(3)
      const x = s.items.find((i) => i.name === 'X-Burger')!
      expect(x.price).toBe(32.9)
      expect(x.description).toBe('Pão, carne 150g e queijo')
      expect(x.imageUrl).toMatch(/^https:\/\/.+abc\/x-burger\.jpg$/)
      expect(x.categoryName).toBe('Lanches')
      expect(s.items.find((i) => i.name === 'Refri Lata')!.status).toBe('paused')
      expect(s.categories.map((c) => c.name).sort()).toEqual(['Bebidas', 'Lanches'])
    }
  })
  it('uma resposta pobre posterior não apaga preço/imagem já lidos', () => {
    const rich = finalizeSnapshot(normalizeMenuPayload(menuFixture, { ...dom, requestPath: null })!)
    const poor = finalizeSnapshot({ ...rich, items: rich.items.map((i) => ({ ...i, price: null, description: '', imageUrl: 'https://img/x.jpg', hasImage: true })) })
    const merged = mergeSnapshots(rich, poor)
    const x = merged.items.find((i) => i.name.startsWith('X-Burger'))!
    expect(x.price).toBe(32.9)
    expect(x.description).toContain('Hambúrguer')
    expect(x.imageUrl).toBe('https://img/x.jpg')
  })
  it('aceita item único e produto aninhado em item', () => {
    const nested = { items: [{ id: 'a', price: 10, product: { name: 'Água', description: '500ml' } }, { id: 'b', price: 12, product: { name: 'Suco', description: 'Laranja' } }] }
    const r = buildSnapshot([{ path: null, payload: nested }], dom)
    expect(r.snapshot!.items.map((i) => i.name).sort()).toEqual(['Suco', 'Água'])
  })
})

describe('assessQuality', () => {
  it('avisa quando a tela mostra bem mais preços que o lido', () => {
    const s = buildSnapshot([{ path: null, payload: menuFixture }], dom).snapshot!
    const q = assessQuality(s, 40)
    expect(q.level).not.toBe('boa')
    expect(q.warnings.join(' ')).toMatch(/incompleto/)
  })
  it('sem snapshot = ruim', () => expect(assessQuality(null).level).toBe('ruim'))
})
