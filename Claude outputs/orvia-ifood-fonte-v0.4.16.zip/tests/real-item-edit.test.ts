import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-edit.json'
import { buildItemBody, editItem } from '../src/lib/item-editor'
import { planHash } from '../src/core/proposal'
import { runApproved } from '../src/lib/runner'

const clone = <T,>(v: T): T => structuredClone(v)

describe('editor de produto — receita conferida contra PUT /v2/item REAL do portal', () => {
  it('remonta EXATAMENTE o PUT que o portal enviou (produto com complementos)', () => {
    const r = buildItemBody(fx.productBefore, fx.availableAt)
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.body).toEqual(fx.putBody)
  })
  it('idem para a edição anterior (nome "Bolo Fatiaa")', () => {
    const r = buildItemBody(fx.productAfterNameEdit, fx.availableAt)
    expect(r.ok && r.body).toEqual(fx.putBodyNameEdit)
  })
  it('só nome e descrição mudam quando pedidos', () => {
    const r = buildItemBody(fx.productBefore, fx.availableAt, { name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const expected = { ...clone(fx.putBody), name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' }
    expect(r.body).toEqual(expected)
  })
  it('aborta com horário personalizado, campo desconhecido ou categoria ausente', () => {
    const shifted = clone(fx.availableAt) as any[]
    shifted[0].shifts = [{ startTime: '14:00', endTime: '19:00', monday: true, tuesday: true, wednesday: true, thursday: true, friday: true, saturday: true, sunday: true, default: false }]
    expect(buildItemBody(fx.productBefore, shifted).ok).toBe(false)
    const weird = { ...clone(fx.productBefore), novoCampo: 1 }
    expect(buildItemBody(weird, fx.availableAt).ok).toBe(false)
    expect(buildItemBody(fx.productBefore, []).ok).toBe(false)
  })

  function fakePortal() {
    const state = { product: clone(fx.productBefore) as any, puts: [] as any[], failVerify: false, corrupt: false }
    const request = async (method: string, url: string, body?: any) => {
      if (method === 'GET' && /\/available-at\?/.test(url)) return { status: 200, json: clone(fx.availableAt) }
      if (method === 'GET' && /\/partner-catalog-bff\/product\//.test(url)) return { status: 200, json: clone(state.product) }
      if (method === 'PUT') {
        state.puts.push(body)
        if (!state.failVerify) {
          state.product.name = body.name
          state.product.description = body.description
          if (state.corrupt) state.product.tags = ['X']
        }
        return { status: 200, json: {} }
      }
      return { status: 404, json: null }
    }
    return { state, request }
  }
  const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'OWNER' }

  it('edita nome+descrição ponta a ponta e confere', async () => {
    const { state, request } = fakePortal()
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' } })
    expect(r).toEqual({ ok: true, message: 'Aplicado e conferido no iFood.' })
    expect(state.puts).toHaveLength(1)
    expect(state.puts[0]).toEqual({ ...fx.putBody, name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' })
  })
  it('ERRO quando o iFood não reflete a mudança', async () => {
    const { state, request } = fakePortal()
    state.failVerify = true
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { description: 'Outra' } })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/ainda mostra o valor antigo/)
  })
  it('se outro campo mudar, restaura o original', async () => {
    const { state, request } = fakePortal()
    state.corrupt = true
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: 'Novo nome' } })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/outros campos/)
    expect(state.puts).toHaveLength(2) // alteração + restauração
    expect(state.puts[1].name).toBe(fx.productBefore.name)
  })
  it('já igual = nada enviado', async () => {
    const { state, request } = fakePortal()
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: fx.productBefore.name } })
    expect(r.ok).toBe(true)
    expect(state.puts).toHaveLength(0)
  })

  it('runner: aprovar nome+descrição executa pelo editor, sem molde aprendido', async () => {
    const { state, request } = fakePortal()
    const pid = fx.productBefore.id
    const snapshot: any = { items: [{ id: 'OFFER-1', productId: pid, name: fx.productBefore.name, price: 9.5, status: 'active' }], categories: [] }
    const mk = (kind: 'update_name' | 'update_description', after: string) => ({ id: `${kind}:OFFER-1`, kind, itemId: 'OFFER-1', itemName: fx.productBefore.name, before: '', after, reason: 'x', source: 'ia' as const, risk: 'baixo' as const, executable: true })
    const actions = [mk('update_name', 'Bolo Fatia Gigante'), mk('update_description', 'Escolha o sabor')]
    const rep = await runApproved({ actions, hash: planHash(actions) }, {
      templates: [], request, snapshot, signal: new AbortController().signal, paceMs: 0, sleep: async () => {},
      createCombo: async () => ({ ok: true, message: '' }),
      editItem: (productId, changes) => editItem({ productId, ctx, request, changes }),
    })
    expect(rep.steps.map((x) => x.status)).toEqual(['ok', 'ok'])
    expect(state.product.name).toBe('Bolo Fatia Gigante')
    expect(state.product.description).toBe('Escolha o sabor')
  })
})
