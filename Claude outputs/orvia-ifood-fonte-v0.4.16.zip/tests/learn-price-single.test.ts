import { describe, expect, it } from 'vitest'
import { learnFromWrite } from '../src/lib/learn'

const items = new Map([['it-1', { price: 9.5, status: 'active' }]])
const url = 'https://portal.ifood.com.br/next-web-bff/menu/v4/price/single?ownerUUID=o1&availablePrice=true'

describe('aprender com PATCH /price/single', () => {
  it('corpo enxuto com id do item e preço aninhado', () => {
    const r = learnFromWrite({ method: 'PATCH', url, status: 200, at: 1, body: { itemId: 'it-1', catalogId: 'c1', price: { value: { currency: 'BRL', value: 9.9 } } } }, [], items)
    expect(r.ok).toBe(true)
    if (r.ok) {
      expect(r.templates[0]).toMatchObject({ field: 'price', mode: 'patch', unit: 'reais', path: ['price', 'value', 'value'], idPaths: [['itemId']] })
    }
  })
  it('quando o portal grava pelo productId', () => {
    const r = learnFromWrite({ method: 'PATCH', url, status: 200, at: 1, body: { productId: 'p-9', price: { value: { value: 9.9 } } } }, [], items, new Map([['p-9', 'it-1']]))
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.templates[0]!.idKind).toBe('productId')
  })
})
