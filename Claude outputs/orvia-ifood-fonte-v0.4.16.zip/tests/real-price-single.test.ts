import { describe, expect, it } from 'vitest'
import { applyRaw, encode } from '../src/lib/executor'
import { learnFromWrite } from '../src/lib/learn'

// Corpo REAL observado no Diagnóstico (PATCH /next-web-bff/menu/v4/price/single), com valores de exemplo.
const url = 'https://portal.ifood.com.br/next-web-bff/menu/v4/price/single?ownerUUID=O1&availablePrice=true'
const money = (v: number) => ({ value: { currency: 'BRL', value: v }, originalValue: null })
const realBody = (id: string, now: number, old: number) => ({ items: { parentCustomizationOptionId: '', priceByCatalog: [{ price: money(now), oldPrice: money(old), catalogId: 'K1' }], catalogItemId: id } })
const items = new Map([['it-1', { price: 9.5, status: 'active' }], ['it-2', { price: 24.5, status: 'active' }]])
const detailUrl = 'https://portal.ifood.com.br/next-web-bff/menu/v4/item/it-1?ownerUUID=O1&availablePrice=true&withRanking=true'

describe('aprende e executa o PATCH real de preço', () => {
  const read = { method: 'GET', url: detailUrl, json: { id: 'it-1', priceByCatalog: [{ price: money(9.5), catalogId: 'K1', oldPrice: null }] }, status: 200, at: 1 }
  const learned = learnFromWrite({ method: 'PATCH', url, status: 200, at: 2, body: realBody('it-1', 9.9, 9.5) }, [read], items)

  it('aprende com o corpo real', () => {
    expect(learned.ok).toBe(true)
    if (!learned.ok) return
    const t = learned.templates.find((x) => x.field === 'price')!
    expect(t).toMatchObject({ mode: 'patch', method: 'PATCH', unit: 'reais', path: ['items', 'priceByCatalog', 0, 'price', 'value', 'value'] })
    expect(t.idPaths).toEqual([['items', 'catalogItemId']])
    expect(t.mirrors).toEqual([{ path: ['items', 'priceByCatalog', 0, 'oldPrice', 'value', 'value'], of: 'before' }])
    expect(t.verifyUrlTemplate).toContain('/menu/v4/item/{id}?')
  })

  it('aplica em OUTRO produto, trocando id/preço/oldPrice e conferindo na releitura', async () => {
    if (!learned.ok) throw new Error('não aprendeu')
    const sent: { method: string; url: string; body: any }[] = []
    let price = 24.5
    const request = async (method: string, u: string, body?: any) => {
      if (method === 'PATCH') {
        sent.push({ method, url: u, body })
        price = body.items.priceByCatalog[0].price.value.value
        return { status: 200, json: { itemPrice: { itemPriceClassification: 'x' } } }
      }
      return { status: 200, json: { id: 'it-2', priceByCatalog: [{ price: money(price), catalogId: 'K1', oldPrice: null }] } }
    }
    const t = learned.templates.find((x) => x.field === 'price')!
    const res = await applyRaw('it-2', { price: encode(t, 24.9) }, learned.templates, request, { beforePrice: 24.5, sleep: async () => undefined })
    expect(res.ok).toBe(true)
    expect(sent).toHaveLength(1)
    expect(sent[0]!.url).toBe(url)
    expect(sent[0]!.body).toEqual(realBody('it-2', 24.9, 24.5))
  })

  it('marca ERRO se o iFood não refletir o novo preço', async () => {
    if (!learned.ok) throw new Error('não aprendeu')
    const request = async (method: string) => (method === 'PATCH' ? { status: 200, json: {} } : { status: 200, json: { id: 'it-2', priceByCatalog: [{ price: money(24.5) }] } })
    const t = learned.templates.find((x) => x.field === 'price')!
    const res = await applyRaw('it-2', { price: encode(t, 24.9) }, learned.templates, request, { beforePrice: 24.5, sleep: async () => undefined })
    expect(res.ok).toBe(false)
    expect(res.message).toMatch(/ainda mostra R\$ 24,50/)
  })
})
