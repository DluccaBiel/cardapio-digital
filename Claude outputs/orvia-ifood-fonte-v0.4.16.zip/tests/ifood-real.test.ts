import { describe, expect, it } from 'vitest'
import { applyCategoryNames, assessQuality, buildSnapshot, categoryIdFromUrl, isCategoryList, isMenuLike, scorePayload } from '../src/core/capture'
import { priceFromCatalogs } from '../src/core/normalize'

const row = (id: string, name: string, price: unknown, extra: Record<string, unknown> = {}) => ({
  id, name, description: `${name} gostoso`, tags: [], availability: 'AVAILABLE', optionGroup: [], hasViolation: false,
  imageResource: { baseUrl: 'https://static.ifood-static.com.br/image/upload/', path: `pratos/x/${id}.jpg` },
  priceByCatalog: price, isIndustrialized: false, problems: [], productId: `p_${id}`, stockStatus: 'AVAILABLE', type: 'ITEM', violationCheckState: 'OK', ...extra,
})
const categories = [
  { categoryId: 'c-lanches', name: 'Lanches', description: '', type: 'ITEMS', itemsCount: 2, hasViolation: false, canEdit: true, status: 'AVAILABLE', items: null, available: true },
  { categoryId: 'c-bebidas', name: 'Bebidas', description: 'geladas', type: 'ITEMS', itemsCount: 1, hasViolation: false, canEdit: true, status: 'AVAILABLE', items: null, available: true },
]

describe('formato real do portal (category/{id}/items + priceByCatalog)', () => {
  it('lê preço, foto e categoria; ignora a lista de categorias e a home', () => {
    const lanches = { total: 2, rows: [row('i1', 'X-Burger', [{ catalogId: 'k', price: { value: 29.9 } }]), row('i2', 'X-Bacon', [{ catalogId: 'k', price: { value: 34.5, originalValue: 39 } }])] }
    const bebidas = { total: 1, rows: [row('i3', 'Refri', [{ catalogId: 'k', price: { value: 7 } }])] } // lista de 1 item (antes era ignorada)
    const home = { data: { home: { sections: [{ title: 'Promo', items: [{ name: 'Lixo da home', description: 'x', price: 1 }, { name: 'Outro', description: 'y', price: 2 }] }] } } }
    expect(isCategoryList(categories)).toBe(true)
    expect(isCategoryList(lanches)).toBe(false)
    expect(isMenuLike(scorePayload(bebidas))).toBe(true)
    const r = buildSnapshot(
      [
        { path: '/next-web-bff/home/graphql', payload: home },
        { path: '/next-web-bff/menu/v4/category?ownerUUID=x', payload: categories },
        { path: '/next-web-bff/menu/v4/category/{id}/items', payload: lanches, categoryId: 'c-lanches' },
        { path: '/next-web-bff/menu/v4/category/{id}/items', payload: bebidas, categoryId: 'c-bebidas' },
      ],
      { origin: 'active', domUrl: 'https://portal.ifood.com.br/menu/list' },
    )
    const s = r.snapshot!
    expect(s.items.map((i) => i.name).sort()).toEqual(['Refri', 'X-Bacon', 'X-Burger'])
    expect(s.items.find((i) => i.name === 'X-Burger')!.price).toBe(29.9)
    expect(s.items.find((i) => i.name === 'X-Bacon')).toMatchObject({ price: 34.5, originalPrice: 39 })
    expect(s.items.every((i) => i.imageUrl === `https://static.ifood-static.com.br/image/upload/pratos/x/${i.id}.jpg`)).toBe(true)
    expect(s.categories.map((c) => c.name)).toEqual(['Lanches', 'Bebidas'])
    expect(s.items.find((i) => i.name === 'Refri')!.categoryName).toBe('Bebidas')
    expect(s.items.every((i) => i.status === 'active')).toBe(true)
    const q = assessQuality(s)
    expect(q.withPrice).toBe(3)
    expect(q.warnings).toEqual([])
  })

  it('aceita variações de priceByCatalog', () => {
    expect(priceFromCatalogs([{ catalogId: 'k', price: 12.5 }]).price).toBe(12.5)
    expect(priceFromCatalogs([{ catalogId: 'k', value: 12.5, originalValue: 15 }])).toEqual({ price: 12.5, original: 15 })
    expect(priceFromCatalogs([{ catalogId: 'k', prices: { sellingPrice: 9.9 } }]).price).toBe(9.9)
    expect(priceFromCatalogs([{ catalogId: 'k', price: { value: '8,90' } }]).price).toBe(8.9)
    expect(priceFromCatalogs([{ catalogId: 'k' }]).price).toBeNull()
    expect(priceFromCatalogs(undefined).price).toBeNull()
  })

  it('id da categoria vem da URL (e não do /items/stock)', () => {
    expect(categoryIdFromUrl('https://portal.ifood.com.br/next-web-bff/menu/v4/category/abc-123/items?ownerUUID=z')).toBe('abc-123')
    expect(categoryIdFromUrl('https://portal.ifood.com.br/next-web-bff/menu/v4/category/abc-123/items/stock?ownerUUID=z')).toBeNull()
  })

  it('avisa quando os preços parecem estar em centavos', () => {
    const items = Array.from({ length: 6 }, (_, i) => row(`z${i}`, `Prato ${i}`, [{ catalogId: 'k', price: { value: 2990 + i * 100 } }]))
    const r = buildSnapshot([{ path: '/x', payload: { total: 6, rows: items }, categoryId: 'c1' }], { origin: 'active', domUrl: '' })
    expect(assessQuality(r.snapshot).warnings.join(' ')).toMatch(/centavos/)
  })

  it('applyCategoryNames sem lista de nomes não muda nada', () => {
    const r = buildSnapshot([{ path: '/x', payload: { total: 1, rows: [row('a', 'A', [{ price: { value: 5 } }])] }, categoryId: 'c9' }], { origin: 'active', domUrl: '' })
    expect(applyCategoryNames(r.snapshot!, new Map())).toBe(r.snapshot)
  })
})
