import { describe, expect, it } from 'vitest'
import { applyRaw, encode } from '../src/lib/executor'
import { learnFromWrite, validTemplates } from '../src/lib/learn'

// Corpos REAIS de PATCH /next-web-bff/menu/v4/status vistos no Diagnóstico (valores de exemplo).
const url = 'https://portal-api.ifood.com.br/next-web-bff/menu/v4/status?ownerUUID=O1'
const items = new Map([['it-1', { price: 9.5, status: 'active' }], ['it-2', { price: 24.5, status: 'paused' }]])
const itemOnly = (id: string, st: string) => ({ items: [{ catalogItemId: id, parentCustomizationOptionId: '', status: st, statusByCatalog: [{ catalogId: 'K1', status: st }] }] })
const catAndItem = { categories: [{ categoryId: 'cat-9', status: 'UNAVAILABLE' }], items: [{ catalogItemId: 'it-1', status: 'UNAVAILABLE', statusByCatalog: [{ catalogId: 'K1', status: 'UNAVAILABLE' }] }] }

describe('aprende e executa o PATCH real de status (pausar/ativar produto)', () => {
  it('corpo só do item', () => {
    const r = learnFromWrite({ method: 'PATCH', url, status: 200, at: 1, body: itemOnly('it-1', 'UNAVAILABLE') }, [], items)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const t = r.templates[0]!
    expect(t).toMatchObject({ field: 'status', path: ['items', 0, 'status'], statusValues: { paused: 'UNAVAILABLE', active: 'AVAILABLE' }, idPaths: [['items', 0, 'catalogItemId']] })
    expect(t.mirrors).toEqual([{ path: ['items', 0, 'statusByCatalog', 0, 'status'], of: 'after' }])
  })

  it('corpo com categoria + item: NUNCA aprende a pausar a categoria', () => {
    const r = learnFromWrite({ method: 'PATCH', url, status: 200, at: 1, body: catAndItem }, [], items)
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const t = r.templates[0]!
    expect(t.path).toEqual(['items', 0, 'status'])
    expect(JSON.stringify(t.patchBody)).not.toContain('cat-9')
    expect(JSON.stringify(t.patchBody)).not.toContain('categories')
    expect(validTemplates(r.templates)).toHaveLength(1)
  })

  it('molde de status antigo (sem versão) ou que mexe em categoria é descartado; preço antigo é mantido', () => {
    const old = { field: 'status', mode: 'patch', method: 'PATCH', urlTemplate: url, path: ['categories', 0, 'status'], learnedAt: 'x' } as any
    expect(validTemplates([old])).toHaveLength(0)
    expect(validTemplates([{ ...old, field: 'price', path: ['items', 'x'], idPaths: [['items', 'id']] }])).toHaveLength(1)
  })

  it('ativa/pausa OUTRO produto trocando id e os dois status', async () => {
    const r = learnFromWrite({ method: 'PATCH', url, status: 200, at: 1, body: catAndItem }, [], items)
    if (!r.ok) throw new Error('não aprendeu')
    const sent: any[] = []
    const res = await applyRaw('it-2', { status: encode(r.templates[0]!, 'active') }, r.templates, async (m, u, b) => { sent.push({ m, u, b }); return { status: 200, json: {} } })
    expect(res.ok).toBe(true)
    expect(sent).toHaveLength(1)
    expect(sent[0].u).toBe(url)
    expect(sent[0].b).toEqual({ items: [{ catalogItemId: 'it-2', status: 'AVAILABLE', statusByCatalog: [{ catalogId: 'K1', status: 'AVAILABLE' }] }] })
  })
})
