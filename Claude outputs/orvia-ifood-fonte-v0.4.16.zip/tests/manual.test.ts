import { describe, expect, it } from 'vitest'
import menuFixture from './fixtures/menu-payload.json'
import { buildSnapshot } from '../src/core/capture'
import { actionKeys, buildLocalProposal, defaultContext, dropRejected, freeze, manualAction, parseMoney, rejectedBrief, removeAction, upsertAction } from '../src/core/proposal'
import { runApproved } from '../src/lib/runner'

const snapshot = buildSnapshot([{ path: null, payload: menuFixture }], { origin: 'active', domUrl: 'https://portal.ifood.com.br/menu/list' }).snapshot!
const item = snapshot.items[0]!
const base = () => buildLocalProposal(snapshot, defaultContext('hamburgueria', 10))

describe('otimizações feitas pelo gestor', () => {
  it('parseMoney aceita 29,90 / R$ 1.234,50 / 12.5 e recusa lixo', () => {
    expect(parseMoney('29,90')).toBe(29.9)
    expect(parseMoney('R$ 1.234,50')).toBe(1234.5)
    expect(parseMoney('12.5')).toBe(12.5)
    expect(parseMoney('abc')).toBeNull()
    expect(parseMoney('0')).toBeNull()
  })
  it('mudar nome: valida, é executável e substitui a ação da IA para o mesmo item', () => {
    const r = manualAction({ kind: 'update_name', itemId: item.id, value: '  Novo   Nome  ' }, snapshot)
    expect(r.ok && r.action).toMatchObject({ kind: 'update_name', after: 'Novo Nome', executable: true, source: 'voce', id: `update_name:${item.id}` })
    if (!r.ok) return
    const p1 = upsertAction(base(), r.action)
    const r2 = manualAction({ kind: 'update_name', itemId: item.id, value: 'Outro' }, snapshot)
    if (!r2.ok) throw new Error('x')
    const p2 = upsertAction(p1, r2.action)
    expect(p2.actions.filter((a) => a.id === `update_name:${item.id}`)).toHaveLength(1)
    expect(p2.actions[0]!.after).toBe('Outro')
  })
  it('recusa nome igual/vazio, preço inválido ou igual, produto inexistente', () => {
    expect(manualAction({ kind: 'update_name', itemId: item.id, value: item.name }, snapshot).ok).toBe(false)
    expect(manualAction({ kind: 'update_name', itemId: item.id, value: ' ' }, snapshot).ok).toBe(false)
    expect(manualAction({ kind: 'update_price', itemId: item.id, value: 'grátis' }, snapshot).ok).toBe(false)
    expect(manualAction({ kind: 'update_price', itemId: 'nada', value: '10' }, snapshot).ok).toBe(false)
    if (item.price !== null) expect(manualAction({ kind: 'update_price', itemId: item.id, value: String(item.price).replace('.', ',') }, snapshot).ok).toBe(false)
  })
  it('produto novo: duplica um existente, é ASSISTIDO e aparece na execução sem fingir sucesso', async () => {
    const r = manualAction({ kind: 'create_item', name: 'Smash Duplo', description: 'Dois smashes', price: '31,90', baseItemId: item.id }, snapshot)
    if (!r.ok) throw new Error(r.reason)
    expect(r.action).toMatchObject({ kind: 'create_item', executable: false, newItem: { baseItemName: item.name, price: 31.9 } })
    const rm = manualAction({ kind: 'remove_item', itemId: snapshot.items[1]!.id, value: '' }, snapshot)
    if (!rm.ok) throw new Error(rm.reason)
    const actions = [r.action, rm.action]
    const calls: string[] = []
    const rep = await runApproved({ actions, hash: freeze(upsertAction(upsertAction(base(), r.action), rm.action), new Set(actions.map((a) => a.id))).hash }, {
      templates: [], snapshot, signal: new AbortController().signal, paceMs: 0, sleep: async () => {},
      request: async (m, u) => { calls.push(`${m} ${u}`); return { status: 500, json: null } },
      createCombo: async () => ({ ok: true, message: '' }),
    }).catch((e) => e)
    // o hash aqui é de outro conjunto → recusa: prova que o conjunto aprovado é o congelado
    expect(String(rep)).toMatch(/plano mudou/)
    const frozen = freeze(upsertAction(upsertAction({ ...base(), actions: [] }, r.action), rm.action), new Set([r.action.id, rm.action.id]))
    const rep2 = await runApproved(frozen, { templates: [], snapshot, signal: new AbortController().signal, paceMs: 0, sleep: async () => {}, request: async (m, u) => { calls.push(`${m} ${u}`); return { status: 500, json: null } }, createCombo: async () => ({ ok: true, message: '' }) })
    expect(rep2.steps.map((s) => s.status)).toEqual(['assistida', 'assistida'])
    expect(calls).toEqual([]) // nada foi enviado ao iFood
  })
  it('produto novo exige base e nome', () => {
    expect(manualAction({ kind: 'create_item', name: '', description: '', price: '', baseItemId: item.id }, snapshot).ok).toBe(false)
    expect(manualAction({ kind: 'create_item', name: 'X Y', description: '', price: '', baseItemId: 'zzz' }, snapshot).ok).toBe(false)
  })
  it('remover ação manual da lista', () => {
    const r = manualAction({ kind: 'update_name', itemId: item.id, value: 'Zeta' }, snapshot)
    if (!r.ok) throw new Error('x')
    const p = upsertAction(base(), r.action)
    expect(removeAction(p, r.action.id).actions.some((a) => a.id === r.action.id)).toBe(false)
  })
  it('reprovar: não repete ideias idênticas, mantém as do gestor e os pontos de atenção', () => {
    const p = base()
    const rejected = new Set(actionKeys(p))
    const man = manualAction({ kind: 'update_name', itemId: item.id, value: 'Zeta' }, snapshot)
    if (!man.ok) throw new Error('x')
    const next = upsertAction(base(), man.action)
    const { proposal, dropped } = dropRejected(next, new Set([...rejected, `${man.action.id}|Zeta`]))
    expect(dropped).toBeGreaterThan(0)
    expect(proposal.actions.some((a) => a.id === man.action.id)).toBe(true)
    expect(proposal.actions.filter((a) => a.kind !== 'recommend' && a.source !== 'voce')).toHaveLength(0)
    expect(proposal.actions.filter((a) => a.kind === 'recommend').length).toBe(next.actions.filter((a) => a.kind === 'recommend').length)
  })
  it('rejectedBrief cabe no limite', () => {
    expect(rejectedBrief(base(), 200).length).toBeLessThanOrEqual(200)
  })
})
