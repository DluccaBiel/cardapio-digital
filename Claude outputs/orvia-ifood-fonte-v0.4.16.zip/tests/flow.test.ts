import { describe, expect, it } from 'vitest'
import menuFixture from './fixtures/menu-payload.json'
import { buildSnapshot } from '../src/core/capture'
import { adjustFromFeedback, buildLocalProposal, defaultApproved, defaultContext, freeze, mergeAi, planHash, type AiAnalysis } from '../src/core/proposal'
import { learnFromWrite, type Observed } from '../src/lib/learn'
import { missingFields, runApproved, type RunDeps } from '../src/lib/runner'

const snapshot = buildSnapshot([{ path: null, payload: menuFixture }], { origin: 'active', domUrl: 'https://portal.ifood.com.br/menu/list' }).snapshot!

function fakePortal(failIds: string[] = []) {
  const db: Record<string, any> = {}
  for (const i of snapshot.items) db[i.id] = { id: i.id, name: i.name, description: i.description, price: { value: Math.round((i.price ?? 0) * 100) }, status: 'AVAILABLE', extras: [1] }
  const calls: { method: string; url: string }[] = []
  const request = async (method: string, url: string, body?: unknown) => {
    calls.push({ method, url })
    const id = url.split('/').pop()!
    if (method === 'GET') return db[id] ? { status: 200, json: { data: structuredClone(db[id]) } } : { status: 404, json: null }
    if (failIds.includes(id)) return { status: 500, json: null }
    db[id] = structuredClone(body)
    return { status: 200, json: { ok: true } }
  }
  return { db, calls, request }
}

function learned(field: 'price' | 'description') {
  const id = snapshot.items[0]!.id
  const before = { id, name: snapshot.items[0]!.name, description: snapshot.items[0]!.description, price: { value: 3290 }, status: 'AVAILABLE', extras: [1] }
  const after = structuredClone(before)
  if (field === 'price') after.price.value = 3490
  else after.description = 'Outra'
  const reads: Observed[] = [{ method: 'GET', url: `https://merchant-api.ifood.com.br/catalog/items/${id}`, json: { data: before }, at: 1 }]
  const write: Observed = { method: 'PUT', url: `https://merchant-api.ifood.com.br/catalog/items/${id}`, body: after, status: 200, at: 2 }
  const items = new Map(snapshot.items.map((i) => [i.id, { price: i.price, status: i.status }]))
  const r = learnFromWrite(write, reads, items)
  if (!r.ok) throw new Error(r.reason)
  return r.templates
}

const ai = (): AiAnalysis => ({
  summary: 'Resumo IA',
  updates: [
    { ifood_id: 'IF-ITEM-1', item_name: 'X-Burger Clássico (Demo)', before: { name: 'X-Burger Clássico (Demo)', description: 'Hambúrguer 150g, queijo e molho da casa', price: 32.9 }, after: { description: 'Novo texto apetitoso', price: 34.9 }, reason: 'Concorrentes cobram mais', from_competitors: true },
    { ifood_id: 'NAO-EXISTE', item_name: 'Fantasma', before: { name: 'F', description: null, price: 1 }, after: { price: 2 }, reason: 'x' },
  ],
  combos: [],
  sources: [{ title: 'Site do concorrente', url: 'https://exemplo.com.br' }],
})

describe('proposta', () => {
  const ctx = defaultContext('hamburgueria', 10)
  it('monta combos locais como ações assistidas', () => {
    const p = buildLocalProposal(snapshot, ctx)
    const combos = p.actions.filter((a) => a.kind === 'create_combo')
    expect(combos.length).toBeGreaterThan(0)
    expect(combos.every((a) => !a.executable && a.combo && a.combo.price < a.combo.fullPrice)).toBe(true)
  })
  it('mergeAi mapeia por id do iFood, ignora itens inexistentes e respeita "não mexer em preço"', () => {
    const base = buildLocalProposal(snapshot, ctx)
    const m = mergeAi(base, ai(), snapshot, ctx)
    expect(m.actions.find((a) => a.id === 'update_description:IF-ITEM-1')?.source).toBe('concorrentes')
    expect(m.actions.find((a) => a.id === 'update_price:IF-ITEM-1')?.risk).toBe('alto')
    expect(m.actions.some((a) => a.itemName === 'Fantasma')).toBe(false)
    expect(m.sources).toHaveLength(1)
    const lockedCtx = { ...ctx, doNotTouchPrices: true }
    const locked = mergeAi(buildLocalProposal(snapshot, lockedCtx), ai(), snapshot, lockedCtx)
    expect(locked.actions.some((a) => a.kind === 'update_price')).toBe(false)
  })
  it('aprovação padrão exclui risco alto e recomendações; hash muda se algo mudar', () => {
    const m = mergeAi(buildLocalProposal(snapshot, ctx), ai(), snapshot, ctx)
    const ids = defaultApproved(m)
    expect(ids.has('update_price:IF-ITEM-1')).toBe(false)
    expect([...ids].some((i) => i.startsWith('rec:'))).toBe(false)
    const f = freeze(m, ids)
    expect(planHash(f.actions)).toBe(f.hash)
    const tampered = f.actions.map((a, i) => (i === 0 ? { ...a, after: 'adulterado' } : a))
    expect(planHash(tampered)).not.toBe(f.hash)
  })
})

describe('feedback do "não fazer"', () => {
  const ctx = defaultContext('hamburgueria', 10)
  const prev = { maxCombos: 3, withCombos: true }
  it('entende preço, desconto, combos e categoria — e diz o que entendeu', () => {
    const a = adjustFromFeedback('Não quero mexer nos preços, desconto de 5%, só um combo e não mexer em Bebidas', ctx, snapshot, prev)
    expect(a.ctx.doNotTouchPrices).toBe(true)
    expect(a.ctx.comboDiscountPercent).toBe(5)
    expect(a.maxCombos).toBe(1)
    const bebidas = snapshot.categories.find((c) => c.name === 'Bebidas')!
    expect(bebidas.itemIds.every((id) => a.ctx.doNotTouchItemIds.includes(id))).toBe(true)
    expect(a.understood.length).toBeGreaterThanOrEqual(4)
  })
  it('sem combos', () => expect(adjustFromFeedback('sem combos por favor', ctx, snapshot, prev).withCombos).toBe(false))
  it('texto sem pistas não inventa ajustes', () => expect(adjustFromFeedback('não gostei', ctx, snapshot, prev).understood).toEqual([]))
})

describe('runApproved', () => {
  const ctx = defaultContext('hamburgueria', 10)
  const proposal = () => mergeAi(buildLocalProposal(snapshot, ctx), ai(), snapshot, ctx)
  const approvedFrozen = () => freeze(proposal(), new Set(['update_description:IF-ITEM-1', 'update_price:IF-ITEM-1', ...proposal().actions.filter((a) => a.kind === 'create_combo').slice(0, 1).map((a) => a.id)]))
  const base = (over: Pick<RunDeps, 'request'> & Partial<RunDeps>): RunDeps => ({
    templates: learned('price'), snapshot, signal: new AbortController().signal, sleep: async () => undefined,
    createCombo: async () => ({ ok: true, message: 'Criado no Orvia (pausado).' }), ...over,
  })

  it('executa exatamente o aprovado: preço ok, descrição pulada (não ensinada), combo assistido', async () => {
    const portal = fakePortal()
    const f = approvedFrozen()
    const rep = await runApproved(f, base({ request: portal.request }))
    const by = (id: string) => rep.steps.find((s) => s.action.id === id)!
    expect(by('update_price:IF-ITEM-1').status).toBe('ok')
    expect(portal.db['IF-ITEM-1'].price.value).toBe(3490)
    expect(by('update_description:IF-ITEM-1').status).toBe('pulada')
    expect(by('update_description:IF-ITEM-1').message).toMatch(/ensinar/)
    expect(rep.steps.find((s) => s.action.kind === 'create_combo')!.status).toBe('assistida')
    expect(rep.steps).toHaveLength(f.actions.length) // nada além do aprovado
    expect(portal.db['IF-ITEM-1'].description).not.toBe('Novo texto apetitoso') // não fingiu aplicar
  })
  it('recusa executar se o plano foi adulterado depois da aprovação', async () => {
    const f = approvedFrozen()
    f.actions[0] = { ...f.actions[0]!, after: 999 }
    await expect(runApproved(f, base({ request: fakePortal().request }))).rejects.toThrow(/mudou depois da aprovação/)
  })
  it('ESC interrompe: o que não começou fica "pulada" e nada mais é enviado', async () => {
    const portal = fakePortal()
    const ac = new AbortController()
    const f = approvedFrozen()
    const rep = await runApproved(f, base({ request: portal.request, signal: ac.signal, sleep: async () => ac.abort() }))
    expect(rep.aborted).toBe(true)
    const ran = rep.steps.filter((s) => s.status !== 'pulada' || !/ESC/.test(s.message))
    expect(ran).toHaveLength(1) // só a primeira (edições no iFood vêm antes dos combos) chegou a rodar
    expect(rep.steps.filter((s) => !ran.includes(s)).every((s) => s.status === 'pulada' && /ESC/.test(s.message))).toBe(true)
  })
  it('erro do iFood vira ERRO visível e a verificação não confirma sucesso falso', async () => {
    const rep = await runApproved(approvedFrozen(), base({ request: fakePortal(['IF-ITEM-1']).request }))
    const s = rep.steps.find((x) => x.action.id === 'update_price:IF-ITEM-1')!
    expect(s.status).toBe('erro')
    expect(s.message).toMatch(/recusou/)
  })
  it('erros de combo (Orvia) não travam as edições do iFood e rodam por último', async () => {
    const portal = fakePortal()
    const snap = snapshot.items[0]!
    const price = { id: `update_price:${snap.id}`, kind: 'update_price' as const, itemId: snap.id, itemName: snap.name, before: snap.price, after: (snap.price ?? 1) + 1, reason: 'x', source: 'ia' as const, risk: 'baixo' as const, executable: true }
    const combo = (n: number) => ({ id: `combo:${n}`, kind: 'create_combo' as const, itemId: null, itemName: `Combo ${n}`, before: null, after: 'x', reason: 'x', source: 'ia' as const, risk: 'baixo' as const, executable: false }) as any
    const actions = [combo(1), combo(2), combo(3), price]
    const rep = await runApproved({ actions, hash: planHash(actions) }, base({ request: portal.request, templates: learned('price'), createCombo: async () => ({ ok: false, message: 'sem Orvia' }) }))
    expect(rep.steps[3]!.status).toBe('ok')
    expect(rep.steps.slice(0, 3).every((s) => s.status === 'erro')).toBe(true)
  })
  it('para após 3 erros seguidos', async () => {
    const actions = snapshot.items.slice(0, 4).map((i) => ({ id: `update_price:${i.id}`, kind: 'update_price' as const, itemId: i.id, itemName: i.name, before: i.price, after: (i.price ?? 1) + 1, reason: 'x', source: 'ia' as const, risk: 'baixo' as const, executable: true }))
    const portal = fakePortal(snapshot.items.map((i) => i.id))
    const rep = await runApproved({ actions, hash: planHash(actions) }, base({ request: portal.request, templates: learned('price') }))
    expect(rep.steps.map((s) => s.status)).toEqual(['erro', 'erro', 'erro', 'pulada'])
  })
  it('missingFields avisa antes de começar', () => {
    expect(missingFields(approvedFrozen().actions, learned('price'))).toEqual([]) // nome/descrição têm editor próprio
  })
})
