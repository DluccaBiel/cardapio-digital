/**
 * Execução do que foi APROVADO. Garantias (testadas em tests/runner.test.ts):
 *  - só roda o conjunto congelado e recusa se o hash divergir;
 *  - cada ação tem um estado visível: pendente → executando → ok | erro | pulada | assistida;
 *  - ESC (AbortSignal) interrompe entre ações e marca o resto como "pulada";
 *  - nunca finge sucesso: sem molde aprendido, a ação é "pulada" com o motivo e o que fazer.
 */
import { isSyntheticItemId } from '../core/snapshots'
import { planHash, type ProposalAction } from '../core/proposal'
import type { MenuSnapshot } from '../core/schema'
import { applyRaw, coverage, encode, type Desired, type PortalRequest } from './executor'
import { FIELD_LABEL, type Field, type Template } from './learn'

export type StepStatus = 'pendente' | 'executando' | 'ok' | 'erro' | 'pulada' | 'assistida'

export interface Step {
  action: ProposalAction
  status: StepStatus
  message: string
  at: string | null
}

export interface RunReport {
  startedAt: string
  finishedAt: string
  planHash: string
  aborted: boolean
  steps: Step[]
  counts: Record<StepStatus, number>
}

export interface RunDeps {
  templates: Template[]
  request: PortalRequest
  snapshot: MenuSnapshot
  /** cria o combo no Orvia (pausado). O iFood continua assistido. */
  createCombo: (a: ProposalAction) => Promise<{ ok: boolean; message: string }>
  signal: AbortSignal
  onUpdate?: (steps: Step[]) => void
  paceMs?: number
  sleep?: (ms: number) => Promise<void>
}

const FIELD_OF: Partial<Record<ProposalAction['kind'], Field>> = {
  update_price: 'price',
  update_name: 'name',
  update_description: 'description',
  set_status: 'status',
}

/** O que falta ensinar para executar estas ações (antes de começar, para avisar o usuário). */
export function missingFields(actions: ProposalAction[], templates: Template[]): Field[] {
  const need = new Set<Field>()
  for (const a of actions) {
    const f = FIELD_OF[a.kind]
    if (f && a.executable) need.add(f)
  }
  const have = new Set(templates.map((t) => t.field))
  return [...need].filter((f) => !have.has(f))
}

export function tally(steps: Step[]): Record<StepStatus, number> {
  const c: Record<StepStatus, number> = { pendente: 0, executando: 0, ok: 0, erro: 0, pulada: 0, assistida: 0 }
  for (const s of steps) c[s.status] += 1
  return c
}

const defaultSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))

export async function runApproved(frozen: { actions: ProposalAction[]; hash: string }, deps: RunDeps): Promise<RunReport> {
  if (planHash(frozen.actions) !== frozen.hash) throw new Error('O plano mudou depois da aprovação. Nada foi executado.')
  const sleep = deps.sleep ?? defaultSleep
  const startedAt = new Date().toISOString()
  const steps: Step[] = frozen.actions.map((action) => ({ action, status: 'pendente', message: 'Aguardando', at: null }))
  const emit = () => deps.onUpdate?.(steps.map((s) => ({ ...s })))
  const set = (s: Step, status: StepStatus, message: string) => {
    s.status = status
    s.message = message
    s.at = new Date().toISOString()
    emit()
  }
  emit()

  let consecutiveErrors = 0
  let aborted = false
  for (let i = 0; i < steps.length; i += 1) {
    const step = steps[i]!
    if (deps.signal.aborted) aborted = true
    if (aborted) {
      set(step, 'pulada', 'Interrompido (ESC). Nada foi feito nesta ação.')
      continue
    }
    if (consecutiveErrors >= 3) {
      set(step, 'pulada', 'Pausado após 3 erros seguidos para não piorar. Revise o primeiro erro.')
      continue
    }
    set(step, 'executando', 'Executando…')
    const a = step.action
    try {
      if (a.kind === 'create_combo') {
        const r = await deps.createCombo(a)
        if (r.ok) {
          set(step, 'assistida', r.message)
          consecutiveErrors = 0
        } else {
          set(step, 'erro', r.message)
          consecutiveErrors += 1
        }
      } else {
        const field = FIELD_OF[a.kind]
        const item = deps.snapshot.items.find((x) => x.id === a.itemId)
        if (!field || !a.executable) set(step, 'pulada', 'Sem execução automática para este tipo de ação.')
        else if (!item || isSyntheticItemId(item.id)) set(step, 'pulada', 'Produto sem ID do iFood (leitura pela tela). Sincronize pelo portal para aplicar.')
        else {
          const desired: Desired =
            field === 'price' ? { price: Number(a.after) } : field === 'status' ? { status: a.after === 'active' ? 'active' : 'paused' } : field === 'name' ? { name: String(a.after) } : { description: String(a.after) }
          const cov = coverage(desired, deps.templates)
          if (cov.missing.length) {
            set(step, 'pulada', `Falta ensinar “${FIELD_LABEL[field]}”: edite 1 produto no portal (mude ${FIELD_LABEL[field].toLowerCase()} e salve) e rode de novo.`)
          } else {
            const t = cov.usable[0]!
            const useId = t.idKind === 'productId' ? item.productId ?? item.id : item.id
            const res = await applyRaw(useId, { [field]: encode(t, (desired as Record<string, unknown>)[field]) }, deps.templates, deps.request)
            if (res.ok) {
              set(step, 'ok', 'Aplicado e conferido no iFood.')
              consecutiveErrors = 0
            } else {
              set(step, 'erro', res.message)
              consecutiveErrors += 1
            }
          }
        }
      }
    } catch (e) {
      set(step, 'erro', e instanceof Error ? e.message : 'Falha inesperada.')
      consecutiveErrors += 1
    }
    if (deps.signal.aborted) aborted = true
    if (!aborted && i < steps.length - 1) await sleep(deps.paceMs ?? 900)
  }
  return { startedAt, finishedAt: new Date().toISOString(), planHash: frozen.hash, aborted, steps: steps.map((s) => ({ ...s })), counts: tally(steps) }
}
