/**
 * Content script (mundo isolado) no Portal do Parceiro iFood — painel guiado Orvia.
 *
 * Fluxo: [Sincronizar] → produtos (imagem + nome) → [Análise] (regras + IA + concorrentes)
 *        → proposta (PDF) → [Fazer] / [Não fazer + o que você pensa] → execução com
 *        status por ação → prints em Downloads ("print 1.png"…) + envio ao Orvia → [Sair].
 * ESC para tudo, sempre.
 *
 *  - O painel fala com o Orvia SOMENTE via service worker (a chave nunca chega aqui).
 *  - Shadow DOM fechado; nada de innerHTML com dados do portal/API.
 *  - O que é alterado no iFood é exatamente o conjunto aprovado (hash congelado).
 */
import type { MenuSnapshot } from '../core/schema'
import { finalizeSnapshot, normalizeFromDom } from '../core/normalize'
import { auditPractices, type PracticeCheck } from '../core/practices'
import { assessQuality, buildSnapshot, mergeSnapshots, type Quality } from '../core/capture'
import { guessNiche, NICHES } from '../core/rules'
import { STRATEGIES, strategyOf } from '../core/strategy'
import {
  adjustFromFeedback, buildLocalProposal, capCombos, defaultApproved, defaultContext, fmtValue, freeze, KIND_LABEL, mergeAi,
  type Proposal, type ProposalAction,
} from '../core/proposal'
import { comboComponentsFromIfood, findInSnapshot, guessClient, pendingChanges } from '../lib/bridge'
import type { HubCatalog, HubClientRow, HubPendingItem, ImportSummary } from '../lib/hub'
import { HUB_CHANGED_KEY, SELECTED_CLIENT_KEY, send } from '../lib/messages'
import { applyPending, applyRaw, coverage, desiredFromPending } from '../lib/executor'
import { FIELD_LABEL, learnFromWrite, type Field, type Observed, type Template } from '../lib/learn'
import { proposalPdf } from '../lib/pdf'
import { planHash } from '../core/proposal'
import { buildPrintPages, printFileName, renderPrintPng, STATUS_LABEL } from '../lib/prints'
import { missingFields, runApproved, tally, type RunReport, type Step, type StepStatus } from '../lib/runner'
import { autoScroll, bytesToDataUrl, countPricesOnScreen, dataUrlToBase64, guessMerchantName, looksLikeStoreName, safeFileName } from './dom-utils'
import { CSS } from './styles'

type Tab = 'produtos' | 'analise' | 'pendencias' | 'diagnostico'
type Phase = 'config' | 'analisando' | 'proposta' | 'feedback' | 'executando' | 'final'

const state = {
  snapshot: null as MenuSnapshot | null,
  quality: null as Quality | null,
  tab: 'produtos' as Tab,
  open: false,
  connected: null as null | { workspace: string } | { error: string },
  clients: [] as HubClientRow[],
  clientId: '' as string,
  pending: [] as HubPendingItem[],
  pendingLoaded: false,
  busy: false,
  notice: null as null | { kind: 'ok' | 'erro' | 'info'; text: string },
  importResult: null as ImportSummary | null,
  niche: 'hamburgueria',
  discount: 10,
  templates: [] as Template[],
  autoMode: false,
  lastLearn: null as null | { ok: boolean; text: string },
  menuWrites: 0,
  runLog: [] as { name: string; ok: boolean; text: string }[],
  undoAvailable: false,
}

/** Sincronização (passos visíveis; cancelável com ESC). */
const sync = {
  running: false,
  cancelled: false,
  log: [] as { text: string; kind: 'run' | 'ok' | 'warn' | 'erro' }[],
  lastAt: null as number | null,
}

/** Análise → proposta → execução → final. */
const flow = {
  phase: 'config' as Phase,
  cancelled: false,
  log: [] as string[],
  city: '',
  goal: 'ticket' as 'ticket' | 'conversao' | 'margem' | 'organizacao',
  competitors: true,
  strategy: 'mercado' as 'mercado' | 'competitivo' | 'premium' | 'combos',
  ctx: defaultContext('hamburgueria', 10),
  maxCombos: 3,
  withCombos: true,
  version: 1,
  feedback: [] as string[],
  understood: [] as string[],
  feedbackText: '',
  proposal: null as Proposal | null,
  approved: new Set<string>(),
  frozen: null as null | { actions: ProposalAction[]; hash: string },
  abort: null as AbortController | null,
  steps: [] as Step[],
  report: null as RunReport | null,
  prints: [] as { name: string; dataUrl: string }[],
  saved: null as null | { ok: boolean; text: string },
  upload: null as null | { ok: boolean; text: string },
  retrying: false,
}

const TEMPLATES_KEY = 'orvia.templates'
const AUTO_KEY = 'orvia.autoApply'
const UNDO_KEY = 'orvia.lastBatch'
const ARM_KEY = 'orvia.armedSync'
const CITY_KEY = 'orvia.city'
const recentReads: Observed[] = []

// ---------------------------------------------------------------------------
// Captura (page hook → aqui). O hook GUARDA as respostas; aqui nós PUXAMOS.
// ---------------------------------------------------------------------------
type HookCap = { seq: number; ts: number; method: string; path: string; status: number; products: number; categories: number; categoryId?: string | null; payload: unknown }
type HookSeen = { seq: number; ts: number; method: string; path: string; status: number; bytes: number; shape: string; menu: boolean; products: number; categories: number }
type Dump = { captures: HookCap[]; seen: HookSeen[]; headersKnown: boolean; priceShape?: string; writes?: { method: string; path: string; status: number; reqShape: string; query: string }[] }
let dump: Dump | null = null
let saveTimer: number | undefined
let passiveTimer: number | undefined

function scheduleSave() {
  window.clearTimeout(saveTimer)
  saveTimer = window.setTimeout(() => {
    if (state.snapshot) void send({ type: 'snapshot:save', snapshot: state.snapshot })
  }, 1500)
}

/** Lê o buffer do hook e monta o cardápio. `replace` = sincronização explícita. */
async function pullFromHook(mode: 'replace' | 'merge'): Promise<number> {
  const res = await pageExec({ action: 'dump' }, 15_000)
  const d = res.json as Dump | null
  if (!d || !Array.isArray(d.captures)) return state.snapshot?.items.length ?? 0
  dump = d
  if (d.captures.length) {
    const built = buildSnapshot(d.captures.map((c) => ({ path: c.path, payload: c.payload, categoryId: c.categoryId ?? null })), { origin: 'active', domUrl: location.href, merchantName: guessMerchantName(document) })
    if (built.snapshot) {
      const old = state.snapshot
      const fresh = built.snapshot
      state.snapshot = mode === 'replace' && (!old || old.origin === 'dom' || fresh.items.length >= old.items.length * 0.8) ? fresh : mergeSnapshots(old, fresh)
      scheduleSave()
    }
  }
  state.quality = assessQuality(state.snapshot, countPricesOnScreen(document))
  return state.snapshot?.items.length ?? 0
}

/** Você editou um item no portal → aprende como o portal salva aquele campo. */
const isMenuWrite = (url: string) => /\/(menu|catalog|price|item|product)/i.test(url) && !/graphql|token-exchange|support|collector|schemas/i.test(url)

async function onPortalWrite(write: Observed) {
  if (isMenuWrite(write.url) && ['PUT', 'PATCH', 'POST'].includes(write.method.toUpperCase())) {
    state.menuWrites += 1
    render()
  } else return
  if (!state.snapshot) {
    state.lastLearn = { ok: false, text: 'Vi a alteração, mas ainda não sincronizei os produtos. Toque em Sincronizar e edite de novo.' }
    return render()
  }
  const items = new Map(state.snapshot.items.map((i) => [i.id, { price: i.price, status: i.status }]))
  const productIds = new Map(state.snapshot.items.filter((i) => i.productId && i.productId !== i.id).map((i) => [i.productId as string, i.id]))
  const res = learnFromWrite(write, recentReads, items, productIds)
  if (!res.ok) {
    state.lastLearn = { ok: false, text: `Vi uma alteração no portal, mas não aprendi: ${res.reason}.` }
    return render()
  }
  const fields = new Set(res.templates.map((t) => t.field))
  state.templates = [...state.templates.filter((t) => !fields.has(t.field)), ...res.templates]
  await chrome.storage.local.set({ [TEMPLATES_KEY]: state.templates })
  state.lastLearn = { ok: true, text: `Aprendi como o iFood salva: ${res.templates.map((t) => FIELD_LABEL[t.field]).join(', ')}.` }
  render()
  // já terminou uma execução com itens "não feitos" porque faltava aprender? retoma sozinho agora que aprendeu
  if (flow.phase === 'final' && !flow.retrying && skippedForTeaching().length) void retryMissing()
}

/** Passos pulados só porque faltava ensinar um campo que agora já está aprendido. */
function skippedForTeaching(): Step[] {
  const have = new Set(state.templates.map((t) => t.field))
  return flow.steps.filter((s) => {
    if (s.status !== 'pulada' || !s.message.startsWith('Falta ensinar')) return false
    const f = (Object.keys(FIELD_LABEL) as Field[]).find((k) => s.message.includes(`“${FIELD_LABEL[k]}”`))
    return !!f && have.has(f)
  })
}

/** Executa só os passos que faltavam (mesmo plano aprovado, mesmos valores) e refaz os prints. */
async function retryMissing() {
  const snapshot = state.snapshot
  const todo = skippedForTeaching()
  if (!snapshot || !todo.length || flow.retrying) return
  flow.retrying = true
  flow.abort = new AbortController()
  const subset = todo.map((s) => s.action)
  const frozen = { actions: subset, hash: planHash(subset) }
  render()
  try {
    const rep = await runApproved(frozen, {
      templates: state.templates, request: portalRequest, snapshot, createCombo: createComboDep, signal: flow.abort.signal,
      onUpdate: (steps) => { flow.steps = flow.steps.map((s) => steps.find((n) => n.action.id === s.action.id) ?? s); render() },
    })
    flow.steps = flow.steps.map((s) => rep.steps.find((n) => n.action.id === s.action.id) ?? s)
    if (flow.report) flow.report = { ...flow.report, steps: flow.steps, counts: tally(flow.steps), aborted: flow.report.aborted || rep.aborted, finishedAt: rep.finishedAt }
  } finally {
    flow.retrying = false
  }
  render()
  await finalizeRun()
}

window.addEventListener('message', (event: MessageEvent) => {
  if (event.source !== window || event.origin !== window.location.origin) return
  const data = event.data as { source?: string; kind?: string; method?: string; url?: string; status?: number; json?: unknown; body?: unknown } | null
  if (!data || data.source !== 'orvia-hook') return
  if (data.kind === 'menu-seen') {
    // o hook guardou uma resposta de cardápio: atualiza em silêncio (não interrompe uma sincronização em curso)
    window.clearTimeout(passiveTimer)
    passiveTimer = window.setTimeout(async () => {
      if (sync.running) return
      const before = state.snapshot?.items.length ?? 0
      const n = await pullFromHook('merge')
      if (n !== before) render()
    }, 1500)
    return
  }
  if (data.kind === 'read' && data.url) {
    recentReads.push({ method: 'GET', url: data.url, json: data.json, status: data.status, at: Date.now() })
    while (recentReads.length > 40) recentReads.shift()
  }
  if (data.kind === 'write' && data.url && data.method) {
    void onPortalWrite({ method: data.method, url: data.url, body: data.body, json: data.json, status: data.status, at: Date.now() })
  }
})

function portalRequest(method: string, url: string, body?: unknown): Promise<{ status: number; json: unknown }> {
  return pageExec({ method, url, body })
}

/** Pede algo ao script da página (mesma aba) e espera a resposta. */
function pageExec(payload: Record<string, unknown>, timeoutMs = 30_000): Promise<{ status: number; json: unknown }> {
  const id = `x${Date.now()}${Math.random().toString(16).slice(2)}`
  return new Promise((resolve) => {
    const timer = window.setTimeout(() => {
      window.removeEventListener('message', onReply)
      resolve({ status: 0, json: { error: 'tempo esgotado' } })
    }, timeoutMs)
    function onReply(event: MessageEvent) {
      const d = event.data as { source?: string; id?: string; status?: number; json?: unknown } | null
      if (event.source !== window || !d || d.source !== 'orvia-exec-result' || d.id !== id) return
      window.clearTimeout(timer)
      window.removeEventListener('message', onReply)
      resolve({ status: d.status ?? 0, json: d.json })
    }
    window.addEventListener('message', onReply)
    window.postMessage({ source: 'orvia-exec', id, ...payload }, window.location.origin)
  })
}

const sleep = (ms: number) => new Promise((r) => window.setTimeout(r, ms))

/** Aplica todas as pendências de ATUALIZAÇÃO cobertas pelos moldes. Para no 1º erro real. */
function applyAll(dryRun: boolean) {
  return run(async () => {
    state.runLog = []
    const undo: { ifoodId: string; rawBefore: Partial<Record<Field, unknown>> }[] = []
    const queue = state.pending.filter((p) => p.action === 'update')
    for (const item of queue) {
      const current = findInSnapshot(state.snapshot, item)
      const res = await applyPending(item, current, state.templates, portalRequest, { dryRun })
      if (!res.ok) {
        state.runLog.push({
          name: item.name,
          ok: false,
          text: res.missing.length ? `falta ensinar: ${res.missing.map((f) => FIELD_LABEL[f]).join(', ')}` : res.message,
        })
        if (!res.missing.length) break // erro real: para o lote
        continue
      }
      if (dryRun) {
        const parts = (res.dryRun ?? []).flatMap((d) => d.changes.map((c) => `${FIELD_LABEL[c.field]}: ${JSON.stringify(c.before)} → ${JSON.stringify(c.after)}`))
        state.runLog.push({ name: item.name, ok: true, text: parts.join(' · ') || 'já igual' })
        continue
      }
      if (Object.keys(res.rawBefore).length) undo.push({ ifoodId: item.ifood_id!, rawBefore: res.rawBefore })
      const synced = await send({ type: 'hub:sync', itemId: item.id, etag: item.etag, ifoodId: item.ifood_id })
      state.runLog.push({
        name: item.name,
        ok: synced.ok,
        text: synced.ok ? 'aplicado e conferido no iFood ✓' : `aplicado no iFood, mas o Orvia não confirmou: ${synced.ok ? '' : synced.error}`,
      })
      if (synced.ok) state.pending = state.pending.filter((p) => p.id !== item.id)
      render()
      await sleep(900) // ritmo humano entre escritas
    }
    if (!dryRun && undo.length) {
      await chrome.storage.local.set({ [UNDO_KEY]: undo })
      state.undoAvailable = true
    }
    const okCount = state.runLog.filter((l) => l.ok).length
    notify(okCount ? 'ok' : 'info', dryRun ? `Simulação: ${okCount} item(ns) prontos para aplicar.` : `${okCount} item(ns) aplicados no iFood.`)
  })
}

function undoLast() {
  return run(async () => {
    const batch = ((await chrome.storage.local.get(UNDO_KEY))[UNDO_KEY] ?? []) as { ifoodId: string; rawBefore: Partial<Record<Field, unknown>> }[]
    let okCount = 0
    for (const entry of batch) {
      const res = await applyRaw(entry.ifoodId, entry.rawBefore, state.templates, portalRequest)
      if (!res.ok) {
        notify('erro', `Desfazer parou em ${entry.ifoodId}: ${res.message}`)
        return
      }
      okCount += 1
      await sleep(900)
    }
    await chrome.storage.local.remove(UNDO_KEY)
    state.undoAvailable = false
    notify('ok', `${okCount} item(ns) voltaram ao valor anterior no iFood. No Orvia eles seguem com a versão nova (voltam para Pendências).`)
  })
}

// ---------------------------------------------------------------------------
// DOM helpers (textContent sempre — nada de innerHTML com dados do portal/API)
// ---------------------------------------------------------------------------
type Child = Node | string | null | undefined | false
function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, any> = {}, ...children: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag)
  for (const [key, value] of Object.entries(props)) {
    if (value === undefined || value === null || value === false) continue
    if (key === 'class') el.className = value
    else if (key.startsWith('on')) el.addEventListener(key.slice(2).toLowerCase(), value)
    else if (key in el) (el as any)[key] = value
    else el.setAttribute(key, String(value))
  }
  for (const child of children) {
    if (child === null || child === undefined || child === false) continue
    el.append(typeof child === 'string' ? document.createTextNode(child) : child)
  }
  return el
}

const brl = (v: number | null | undefined) => (v === null || v === undefined ? '—' : `R$ ${v.toFixed(2).replace('.', ',')}`)

async function copy(text: string) {
  try {
    await navigator.clipboard.writeText(text)
    notify('info', 'Copiado.')
  } catch {
    notify('erro', 'Não foi possível copiar.')
  }
}

function notify(kind: 'ok' | 'erro' | 'info', text: string) {
  state.notice = { kind, text }
  render()
}

// ---------------------------------------------------------------------------
// Ações
// ---------------------------------------------------------------------------
async function connect() {
  const status = await send<{ configured: boolean; workspace?: { name: string } }>({ type: 'hub:status' })
  if (!status.ok) state.connected = { error: status.error }
  else if (!status.data.configured) state.connected = { error: 'Não conectada. Clique na engrenagem (⚙) e entre com seu e-mail e senha do Orvia.' }
  else {
    state.connected = { workspace: status.data.workspace?.name ?? '' }
    const clients = await send<HubClientRow[]>({ type: 'hub:clients' })
    if (clients.ok) {
      state.clients = clients.data
      const store = storeName()
      const stored = (await chrome.storage.local.get(SELECTED_CLIENT_KEY))[SELECTED_CLIENT_KEY] as { id?: string; store?: string | null } | string | undefined
      const pin = typeof stored === 'string' ? { id: stored, store: null } : (stored ?? {})
      const pinned = pin.id && clients.data.some((c) => c.id === pin.id) && (!store || pin.store === store) ? pin.id : null
      const asSnapshot = state.snapshot ?? (store ? { merchant: { id: null, name: store } } : null)
      let pick = pinned ? clients.data.find((c) => c.id === pinned) ?? null : guessClient(clients.data, asSnapshot)
      if (!pick && store) {
        // loja do iFood ainda não existe no Orvia: cadastra com o nome da conta (sem pedir nada)
        const made = await send<HubClientRow & { created: boolean }>({ type: 'hub:ensure-client', name: store, merchantId: state.snapshot?.merchant.id ?? null })
        if (made.ok) {
          pick = made.data
          if (!state.clients.some((c) => c.id === made.data.id)) state.clients = [...state.clients, made.data]
          if (made.data.created) state.notice = { kind: 'ok', text: `Cliente “${made.data.name}” cadastrado no Orvia a partir da conta do iFood.` }
        }
      }
      state.clientId = pick?.id ?? clients.data[0]?.id ?? ''
    }
  }
  render()
}

async function selectClient(id: string) {
  state.clientId = id
  state.pending = []
  state.pendingLoaded = false
  state.importResult = null
  await chrome.storage.local.set({ [SELECTED_CLIENT_KEY]: { id, store: storeName() } })
  render()
}

async function run<T>(fn: () => Promise<T>) {
  if (state.busy) return
  state.busy = true
  state.notice = null
  render()
  try {
    await fn()
  } finally {
    state.busy = false
    render()
  }
}


// ---------------------------------------------------------------------------
// Sincronizar (cascata: buffer do hook → reler listas → recarregar armado → rolar → tela)
// ---------------------------------------------------------------------------
async function waitForCaptures(cancelled: () => boolean) {
  let last = -1
  let stable = 0
  for (let i = 0; i < 20 && !cancelled(); i += 1) {
    const res = await pageExec({ action: 'dump' }, 8000)
    const count = (res.json as Dump | null)?.captures.length ?? 0
    if (count > 0 && count === last) {
      stable += 1
      if (stable >= 2) break
    } else stable = 0
    last = count
    await sleep(1000)
  }
}

const ANALYZE_KEY = 'orvia.armedAnalyze'

/** `thenAnalyze`: pedido pela aba Análise — fica nela e, ao terminar de sincronizar, já analisa. */
async function startSync(afterReload = false, thenAnalyze = false) {
  if (sync.running) return
  sync.running = true
  sync.cancelled = false
  sync.log = []
  state.notice = null
  state.tab = thenAnalyze ? 'analise' : 'produtos'
  state.open = true
  void connect() // atualiza o cabeçalho (“conectado: …”) assim que o usuário clica em Sincronizar
  const analyzeAfter = thenAnalyze || (afterReload && sessionStorage.getItem(ANALYZE_KEY) === '1')
  sessionStorage.removeItem(ANALYZE_KEY)
  if (afterReload && analyzeAfter) state.tab = 'analise'
  const say = (text: string, kind: 'run' | 'ok' | 'warn' | 'erro' = 'run') => {
    sync.log.push({ text, kind })
    render()
  }
  const mark = (kind: 'ok' | 'warn' | 'erro', text?: string) => {
    const last = sync.log[sync.log.length - 1]
    if (last) {
      last.kind = kind
      if (text) last.text = text
    }
    render()
  }
  const cancelled = () => sync.cancelled
  try {
    if (afterReload) {
      say('Página recarregada. Aguardando o portal carregar o cardápio…')
      await waitForCaptures(cancelled)
      mark('ok')
    }
    say('Lendo o que o portal já carregou…')
    let n = await pullFromHook('replace')
    mark(n ? 'ok' : 'warn', n ? `Lido do portal: ${n} produto(s).` : 'O portal ainda não carregou o cardápio nesta aba.')
    if (cancelled()) return void notify('info', 'Sincronização interrompida (ESC).')

    if (n === 0 || state.quality?.level === 'ruim') {
      say('Relendo as listas do cardápio direto no portal…')
      const r = await pageExec({ action: 'refetch-menu' }, 120_000)
      const info = (r.json ?? {}) as { known?: number; read?: number; pages?: number }
      n = await pullFromHook('replace')
      mark(n ? 'ok' : 'warn', `Listas relidas: ${info.read ?? 0} de ${info.known ?? 0}${info.pages ? ` (+${info.pages} página(s))` : ''} → ${n} produto(s).`)
    }
    if (cancelled()) return void notify('info', 'Sincronização interrompida (ESC).')

    if (n === 0 && !afterReload) {
      say('Nada capturado ainda. Recarregando a página para ler o cardápio na abertura…', 'warn')
      sessionStorage.setItem(ARM_KEY, String(Date.now()))
      if (analyzeAfter) sessionStorage.setItem(ANALYZE_KEY, '1')
      await sleep(500)
      location.reload()
      return
    }

    if (n === 0 || !state.quality || state.quality.warnings.some((w) => /incompleto/.test(w))) {
      say('Rolando a página para carregar todos os produtos…')
      await autoScroll(document, { isCancelled: cancelled })
      await sleep(900)
      n = await pullFromHook('replace')
      mark('ok', `Depois de rolar: ${n} produto(s).`)
    }
    if (cancelled()) return void notify('info', 'Sincronização interrompida (ESC).')

    if (n === 0) {
      say('Lendo os produtos pela tela (modo limitado)…', 'warn')
      const dom = normalizeFromDom(document, { domUrl: location.href, merchantName: guessMerchantName(document) })
      if (dom) {
        state.snapshot = finalizeSnapshot(dom)
        state.quality = assessQuality(state.snapshot, countPricesOnScreen(document))
        n = state.snapshot.items.length
        scheduleSave()
      }
      mark(n ? 'warn' : 'erro', n ? `Lido da tela: ${n} produto(s) (sem categorias/IDs).` : 'Não encontrei produtos na tela.')
    }

    if (n > 0 && state.snapshot && !state.snapshot.merchant.name) {
      const nm = guessMerchantName(document)
      if (nm) state.snapshot = { ...state.snapshot, merchant: { ...state.snapshot.merchant, name: nm } }
    }
    if (n > 0) {
      sync.lastAt = Date.now()
      if (state.snapshot && !nicheTouched) {
        const g = guessNiche(state.snapshot)
        if (g) state.niche = g
      }
    }
    const q = state.quality
    if (n === 0) notify('erro', 'Não consegui ler produtos. Abra Menu → Cardápio no portal e use a aba Diagnóstico para copiar o relatório.')
    else notify(q?.level === 'boa' ? 'ok' : 'info', `${n} produto(s) sincronizado(s).${q?.warnings.length ? ` Atenção: ${q.warnings[0]}` : ''}`)
  } finally {
    sync.running = false
    render()
  }
  if (sync.lastAt) await connect() // reavalia o cliente do Orvia com o cardápio recém-lido
  if (analyzeAfter && sync.lastAt && state.snapshot && !sync.cancelled) void startAnalysis()
}

// ---------------------------------------------------------------------------
// Cliente / Orvia
// ---------------------------------------------------------------------------
const isConnected = () => Boolean(state.connected && !('error' in state.connected))
/** Nome da loja na conta do iFood em que o gestor está logado (vale para prints, PDF e histórico). */
const storeName = (): string | null => {
  const fromSnap = state.snapshot?.merchant.name
  return looksLikeStoreName(fromSnap) ? fromSnap : guessMerchantName(document)
}
const clientName = () => storeName() ?? state.clients.find((c) => c.id === state.clientId)?.name ?? 'Cliente'

async function importAll(): Promise<{ ok: boolean; message: string }> {
  if (!state.snapshot || !state.clientId) return { ok: false, message: 'Escolha o cliente no Orvia.' }
  const res = await send<ImportSummary>({ type: 'hub:import', clientId: state.clientId, snapshot: state.snapshot })
  if (!res.ok) return { ok: false, message: res.code === 'merchant_mismatch' ? `Loja diferente da vinculada a “${clientName()}”. Confira o cliente selecionado.` : res.error }
  state.importResult = res.data
  return { ok: true, message: 'Cardápio enviado ao Orvia.' }
}

// ---------------------------------------------------------------------------
// Análise
// ---------------------------------------------------------------------------
function resetFlow(keepConfig = true) {
  const { city, goal, competitors } = flow
  flow.phase = 'config'
  flow.cancelled = false
  flow.log = []
  flow.ctx = defaultContext(state.niche, state.discount)
  flow.maxCombos = 3
  flow.withCombos = true
  flow.version = 1
  flow.feedback = []
  flow.understood = []
  flow.feedbackText = ''
  flow.proposal = null
  flow.approved = new Set()
  flow.frozen = null
  flow.abort = null
  flow.steps = []
  flow.report = null
  flow.prints = []
  flow.saved = null
  flow.upload = null
  if (keepConfig) Object.assign(flow, { city, goal, competitors })
}

async function startAnalysis(feedbackText?: string) {
  const snapshot = state.snapshot
  if (!snapshot || flow.phase === 'analisando') return
  flow.cancelled = false
  flow.log = []
  const prevPhase = flow.phase
  flow.phase = 'analisando'
  state.notice = null
  const say = (t: string) => {
    flow.log.push(t)
    render()
  }
  try {
    flow.ctx = { ...flow.ctx, niche: state.niche, comboDiscountPercent: flow.ctx.comboDiscountPercent ?? state.discount }
    if (feedbackText) {
      const adj = adjustFromFeedback(feedbackText, flow.ctx, snapshot, { maxCombos: flow.maxCombos, withCombos: flow.withCombos })
      flow.ctx = adj.ctx
      flow.maxCombos = adj.maxCombos
      flow.withCombos = adj.withCombos
      flow.understood = adj.understood
      flow.feedback = [...flow.feedback, feedbackText]
      flow.version += 1
      say(adj.understood.length ? `Entendi: ${adj.understood.join(' ')}` : 'Vou considerar o que você escreveu na nova análise.')
    }
    say('Analisando o cardápio com as regras locais…')
    let proposal = buildLocalProposal(snapshot, flow.ctx, { maxCombos: flow.maxCombos, withCombos: flow.withCombos, version: flow.version, feedback: flow.feedback })

    if (isConnected() && state.clientId) {
      say('Enviando o cardápio ao Orvia…')
      const imp = await importAll()
      if (flow.cancelled) return void backToConfig(prevPhase, 'Análise interrompida (ESC).')
      if (!imp.ok) proposal.notices.push(`Não enviei o cardápio ao Orvia: ${imp.message} Usando só as regras locais.`)
      else {
        say(flow.competitors ? `Analisando com IA e pesquisando concorrentes${flow.city ? ` em ${flow.city}` : ''} (pode levar 1–2 minutos)…` : 'Analisando com IA…')
        const res = await send<import('../core/proposal').AiAnalysis & { competitors_status?: string; ai_status?: string; notices?: string[] }>({
          type: 'hub:analyze',
          body: {
            client_id: state.clientId,
            goal: flow.goal,
            niche: NICHES.find((n) => n.value === state.niche)?.label ?? state.niche,
            city: flow.city.trim(),
            strategy: flow.strategy,
            strategy_brief: strategyOf(flow.strategy).brief,
            notes: flow.feedback.length ? `Pedidos do cliente nas versões anteriores: ${flow.feedback.join(' | ')}` : undefined,
            competitors: flow.competitors && flow.city.trim() !== '',
            max_price_change_pct: flow.ctx.doNotTouchPrices ? 0 : 10,
          },
        })
        if (flow.cancelled) return void backToConfig(prevPhase, 'Análise interrompida (ESC).')
        if (res.ok) {
          proposal = mergeAi(proposal, res.data, snapshot, flow.ctx)
          if (res.data.notices?.length) proposal.notices.push(...res.data.notices)
          if (flow.competitors && !flow.city.trim()) proposal.notices.push('Informe a cidade/bairro para pesquisar concorrentes da região.')
        } else proposal.notices.push(`IA e concorrentes indisponíveis agora (${res.error}). Esta proposta usa só as regras locais.`)
      }
    } else {
      proposal.notices.push('Sem conexão com o Orvia: proposta só com regras locais (combos e pontos de atenção). Conecte para análise com IA e concorrentes.')
    }
    proposal = capCombos(proposal, flow.maxCombos, flow.withCombos)
    flow.proposal = proposal
    flow.approved = defaultApproved(proposal)
    flow.phase = 'proposta'
    flow.feedbackText = ''
    render()
  } catch (e) {
    backToConfig(prevPhase, `Falha na análise: ${e instanceof Error ? e.message : 'erro inesperado'}`)
  }
}

function backToConfig(prev: Phase, text: string) {
  flow.phase = prev === 'analisando' ? 'config' : prev === 'feedback' ? 'proposta' : prev
  notify('info', text)
}

function downloadPdf() {
  return run(async () => {
    const p = flow.proposal
    if (!p || !state.snapshot) return
    const bytes = proposalPdf(p, { clientName: clientName(), merchantName: state.snapshot.merchant.name, city: flow.city, itemCount: state.snapshot.items.length, date: new Date() })
    const res = await send<{ saved: { name: string; path: string }[] }>({ type: 'downloads:save', files: [{ name: safeFileName(`Proposta Orvia - ${clientName()}`, 'pdf'), dataUrl: bytesToDataUrl(bytes, 'application/pdf') }] })
    notify(res.ok ? 'ok' : 'erro', res.ok ? `PDF salvo em Downloads: ${res.data.saved[0]?.name ?? ''}` : res.error)
  })
}

// ---------------------------------------------------------------------------
// Execução do aprovado + prints + envio
// ---------------------------------------------------------------------------
async function createComboDep(a: ProposalAction): Promise<{ ok: boolean; message: string }> {
  if (!a.combo) return { ok: false, message: 'Combo sem composição.' }
  if (!isConnected() || !state.clientId) return { ok: false, message: 'Conecte ao Orvia e escolha o cliente para criar o combo (pausado).' }
  const menu = await send<HubCatalog>({ type: 'hub:menu', clientId: state.clientId })
  if (!menu.ok) return { ok: false, message: menu.error }
  if (menu.data.items.some((i) => i.kind === 'combo' && i.name.trim().toLowerCase() === a.combo!.name.trim().toLowerCase())) {
    return { ok: true, message: 'Já existe no Orvia (pausado). Falta cadastrar no iFood.' }
  }
  const components = comboComponentsFromIfood(a.combo.components.map((c) => c.itemId), a.combo.components.map((c) => c.quantity), menu.data)
  if (!components) return { ok: false, message: 'Itens do combo ainda não estão no Orvia. Envie o cardápio e tente de novo.' }
  const r = await send({ type: 'hub:createCombo', body: { client_id: state.clientId, name: a.combo.name, description: a.combo.description, price: a.combo.price, components } })
  return r.ok ? { ok: true, message: 'Criado no Orvia (pausado). Falta cadastrar no iFood — use a aba Pendências.' } : { ok: false, message: r.error }
}

async function approveAndRun() {
  const p = flow.proposal
  const snapshot = state.snapshot
  if (!p || !snapshot || flow.phase === 'executando') return
  const frozen = freeze(p, flow.approved)
  if (frozen.actions.length === 0) return notify('erro', 'Marque pelo menos uma ação para fazer.')
  flow.frozen = frozen
  flow.phase = 'executando'
  flow.abort = new AbortController()
  flow.steps = frozen.actions.map((action) => ({ action, status: 'pendente' as StepStatus, message: 'Aguardando', at: null }))
  flow.report = null
  flow.prints = []
  flow.saved = null
  flow.upload = null
  state.notice = null
  render()
  try {
    flow.report = await runApproved(frozen, {
      templates: state.templates,
      request: portalRequest,
      snapshot,
      createCombo: createComboDep,
      signal: flow.abort.signal,
      onUpdate: (steps) => {
        flow.steps = steps
        render()
      },
    })
    flow.steps = flow.report.steps
  } catch (e) {
    flow.phase = 'proposta'
    return notify('erro', e instanceof Error ? e.message : 'Falha ao executar.')
  }
  flow.phase = 'final'
  render()
  await finalizeRun()
}

/** Gera os prints, salva em Downloads (print 1.png…) e envia ao Orvia (seção Cardápio). */
async function finalizeRun() {
  const report = flow.report
  const p = flow.proposal
  if (!report || !p) return
  const pages = buildPrintPages({ clientName: clientName(), merchantName: state.snapshot?.merchant.name ?? null, summary: p.summary, version: p.version, date: new Date(), report })
  flow.prints = pages.map((pg) => ({ name: printFileName(pg.index), dataUrl: renderPrintPng(pg, pages.length) }))
  render()
  const saved = await send<{ saved: { name: string; path: string }[] }>({ type: 'downloads:save', files: flow.prints })
  flow.saved = saved.ok ? { ok: true, text: `Salvo em Downloads: ${saved.data.saved.map((s) => s.name).join(', ')}` } : { ok: false, text: saved.error }
  render()
  await uploadEvidence()
}

async function uploadEvidence() {
  const report = flow.report
  const p = flow.proposal
  if (!report || !p || !flow.frozen) return
  if (!isConnected() || !state.clientId) await connect() // conectou depois de abrir o painel? pega agora (e cadastra a loja se preciso)
  if (!isConnected()) {
    flow.upload = { ok: false, text: 'Não enviado ao Orvia: você não está conectado. Toque na engrenagem (⚙), entre com seu e-mail e senha e depois em “Enviar ao Orvia”.' }
    return render()
  }
  if (!state.clientId) {
    flow.upload = { ok: false, text: 'Não enviado ao Orvia: não consegui identificar a loja do iFood para cadastrar o cliente. Escolha o cliente na aba Produtos e toque em “Enviar ao Orvia”.' }
    return render()
  }
  flow.upload = null
  const res = await send<{ id: string; evidence: number }>({
    type: 'hub:evidence',
    body: {
      client_id: state.clientId,
      plan_hash: flow.frozen.hash,
      version: p.version,
      summary: p.summary,
      aborted: report.aborted,
      approved: flow.frozen.actions.map((a) => ({ id: a.id, kind: a.kind, item_name: a.itemName, before: a.before, after: a.after, reason: a.reason, source: a.source })),
      results: report.steps.map((s) => ({ action_id: s.action.id, status: s.status, message: s.message })),
      evidence: flow.prints.map((f) => ({ name: f.name, content_base64: dataUrlToBase64(f.dataUrl) })),
    },
  })
  flow.upload = res.ok ? { ok: true, text: `Enviado ao Orvia (cliente ${state.clients.find((c) => c.id === state.clientId)?.name ?? clientName()}): ${res.data.evidence} imagem(ns) e o resumo do que foi feito.` } : { ok: false, text: `Não consegui enviar ao Orvia: ${res.error}` }
  render()
}

function exitFlow() {
  state.open = false
  resetFlow(true)
  render()
}

function loadPending() {
  return run(async () => {
    if (!state.clientId) return
    const res = await send<{ pending: HubPendingItem[] }>({ type: 'hub:pending', clientId: state.clientId })
    if (!res.ok) return notify('erro', res.error)
    state.pending = res.data.pending
    state.pendingLoaded = true
  })
}

function confirmApplied(item: HubPendingItem, ifoodId: string) {
  return run(async () => {
    if (item.action === 'create' && !ifoodId.trim()) {
      // permitido, mas avisamos que o vínculo ajuda nas próximas sincronizações
      notify('info', 'Sem ID do iFood: o item fica vinculado na próxima importação pelo nome.')
    }
    const res = await send({ type: 'hub:sync', itemId: item.id, etag: item.etag, ifoodId: ifoodId.trim() || null })
    if (!res.ok) {
      notify('erro', res.code === 'conflict' ? 'O item mudou no Orvia depois da leitura. Atualizei a lista — confira de novo.' : res.error)
      if (res.code === 'conflict') {
        state.busy = false
        await loadPending()
      }
      return
    }
    state.pending = state.pending.filter((p) => p.id !== item.id)
    notify('ok', `“${item.name}” confirmado no iFood.`)
  })
}

// ---------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------
// Shadow DOM FECHADO em produção: o JS do portal não consegue ler o painel
// (nomes de clientes do workspace, pendências). Build de teste E2E usa 'open'.
declare const __ORVIA_SHADOW__: 'open' | 'closed'
const host = document.createElement('div')
host.id = 'orvia-ifood-root'
const shadow = host.attachShadow({ mode: typeof __ORVIA_SHADOW__ === 'string' ? __ORVIA_SHADOW__ : 'closed' })
const style = document.createElement('style')
style.textContent = CSS
const mount = document.createElement('div')
shadow.append(style, mount)

function clientSelect() {
  if (state.clients.length === 0) {
    if (!isConnected()) return h('p', { class: 'muted' }, 'Não conectado ao Orvia. Toque na engrenagem (⚙) e entre com seu e-mail e senha.')
    const input = h('input', { class: 'input', placeholder: 'Nome da loja (como no iFood)', value: storeName() ?? '', 'aria-label': 'Nome da loja' }) as HTMLInputElement
    return h('div', { class: 'card' }, h('b', {}, 'Cadastrar este cliente no Orvia'), h('p', { class: 'muted' }, 'Ainda não há cliente. Confirme o nome da loja e cadastro agora.'), input,
      h('button', { class: 'btn', onclick: async () => {
        const name = input.value.trim()
        if (name.length < 2) return
        const made = await send<HubClientRow & { created: boolean }>({ type: 'hub:ensure-client', name, merchantId: state.snapshot?.merchant.id ?? null })
        if (made.ok) {
          state.clients = [...state.clients, made.data]
          await selectClient(made.data.id)
        } else state.notice = { kind: 'erro', text: `Não consegui cadastrar: ${made.error}` }
        render()
      } }, 'Cadastrar cliente'))
  }
  const select = h(
    'select',
    { class: 'input', 'aria-label': 'Cliente no Orvia', onchange: (e: Event) => selectClient((e.target as HTMLSelectElement).value) },
    ...state.clients.map((c) => h('option', { value: c.id, selected: c.id === state.clientId }, c.name)),
  )
  return h('label', { class: 'field' }, h('span', { class: 'label' }, 'Cliente no Orvia'), select)
}

function pendingCard(item: HubPendingItem) {
  const current = findInSnapshot(state.snapshot, item)
  const changes = pendingChanges(item, current)
  const idInput = h('input', { class: 'input', placeholder: 'ID do item no iFood (opcional)', 'aria-label': 'ID no iFood' }) as HTMLInputElement
  const title = item.action === 'create' ? (item.kind === 'combo' ? 'Criar combo no iFood' : 'Criar produto no iFood') : 'Atualizar no iFood'
  return h('div', { class: 'card' },
    h('div', { class: 'row' }, h('b', {}, item.name), h('span', { class: `pill ${item.action}` }, title)),
    item.category ? h('p', { class: 'muted' }, `Categoria: ${item.category}`) : null,
    item.action === 'update' && !current ? h('p', { class: 'warn' }, 'Item não está na leitura atual — abra a categoria dele no portal.') : null,
    h('table', { class: 'diff' },
      h('tbody', {},
        ...changes.map((c) =>
          h('tr', {},
            h('th', {}, c.field),
            h('td', { class: 'before' }, c.before),
            h('td', { class: 'after' }, c.after, ' ', h('button', { class: 'link', title: 'Copiar', onclick: () => copy(c.after.replace(/^R\$ /, '')) }, 'copiar')),
          ),
        ),
      ),
    ),
    changes.length === 0 ? h('p', { class: 'muted' }, 'O iFood já está igual ao Orvia — só confirme.') : null,
    item.kind === 'combo'
      ? h('div', { class: 'combo' },
          h('span', { class: 'label' }, `Itens do combo (separados: ${brl(item.combo_full_price)})`),
          ...item.components.map((c) => h('p', {}, `${c.quantity}× ${c.name} — ${brl(c.price)}`)),
        )
      : null,
    item.addon_groups.length ? h('p', { class: 'muted' }, `Complementos: ${item.addon_groups.join(', ')}`) : null,
    item.action === 'create' ? idInput : null,
    h('button', { class: 'btn primary', disabled: state.busy, onclick: () => confirmApplied(item, idInput.value) }, 'Apliquei no iFood ✓'),
  )
}

function tabPendencias() {
  const box = h('div', {})
  if (!state.connected || 'error' in state.connected) {
    box.append(h('p', { class: 'muted' }, state.connected && 'error' in state.connected ? state.connected.error : 'Conectando…'))
    return box
  }
  box.append(
    clientSelect(),
    h('p', { class: 'hint' }, 'Alterações feitas no Orvia que ainda não estão no iFood. Aplique no portal e confirme aqui — se o item mudar no Orvia no meio do caminho, a confirmação é recusada.'),
    h('button', { class: 'btn', disabled: state.busy || !state.clientId, onclick: loadPending }, state.pendingLoaded ? 'Atualizar lista' : 'Carregar pendências'),
  )
  box.append(automationCard())
  if (state.pendingLoaded && state.pending.length === 0) box.append(h('div', { class: 'card ok' }, 'Tudo em dia: Orvia e iFood iguais.'))
  for (const item of state.pending) box.append(pendingCard(item))
  return box
}

function automationCard() {
  const fields: Field[] = ['price', 'status', 'name', 'description']
  const learned = new Set(state.templates.map((t) => t.field))
  const updates = state.pending.filter((p) => p.action === 'update')
  const ready = updates.filter((p) => coverage(desiredFromPending(p, findInSnapshot(state.snapshot, p)), state.templates).missing.length === 0)
  const auto = h('input', {
    type: 'checkbox',
    checked: state.autoMode,
    onchange: async (e: Event) => {
      state.autoMode = (e.target as HTMLInputElement).checked
      await chrome.storage.local.set({ [AUTO_KEY]: state.autoMode })
      render()
    },
  })
  return h('div', { class: 'card' },
    h('b', {}, 'Aplicação automática no iFood'),
    h('p', { class: 'muted' }, 'A extensão aprende vendo VOCÊ editar 1 produto no portal (ex.: mude um preço e salve). Depois ela repete sozinha para os outros, conferindo antes e depois.'),
    h('div', { class: 'chips' }, ...fields.map((f) => h('span', { class: learned.has(f) ? 'pill ok' : 'pill' }, `${learned.has(f) ? '✓' : '○'} ${FIELD_LABEL[f]}`))),
    state.lastLearn ? h('p', { class: state.lastLearn.ok ? 'okText' : 'warn' }, state.lastLearn.text) : null,
    h('div', { class: 'grid2' },
      h('button', { class: 'btn', disabled: state.busy || ready.length === 0, onclick: () => applyAll(true) }, `Simular (${ready.length})`),
      h('button', { class: 'btn primary', disabled: state.busy || ready.length === 0, onclick: () => applyAll(false) }, `Aplicar automaticamente (${ready.length})`),
    ),
    updates.length > ready.length ? h('p', { class: 'hint' }, `${updates.length - ready.length} item(ns) precisam de um campo ainda não ensinado.`) : null,
    state.undoAvailable ? h('button', { class: 'btn', disabled: state.busy, onclick: undoLast }, 'Desfazer último lote no iFood') : null,
    h('label', { class: 'check' }, auto, ' Aplicar sozinho ao abrir o portal (itens já ensinados)'),
    state.runLog.length ? h('div', { class: 'log' }, ...state.runLog.map((l) => h('p', { class: l.ok ? 'okText' : 'warn' }, `${l.ok ? '✓' : '✗'} ${l.name}: ${l.text}`))) : null,
  )
}

// ---------------------------------------------------------------------------
// UI — Produtos
// ---------------------------------------------------------------------------
function placeholderImg(name: string) {
  return h('div', { class: 'pimg ph', 'aria-hidden': 'true' }, (name.trim()[0] ?? '·').toUpperCase())
}

function productCard(item: MenuSnapshot['items'][number]) {
  const media = item.imageUrl
    ? h('img', {
        class: 'pimg',
        src: item.imageUrl,
        alt: '',
        loading: 'lazy',
        referrerPolicy: 'no-referrer',
        onerror: (e: Event) => (e.target as HTMLElement).replaceWith(placeholderImg(item.name)),
      })
    : placeholderImg(item.name)
  return h('div', { class: item.status === 'paused' ? 'pcard off' : 'pcard', title: item.name },
    media,
    h('div', { class: 'pbody' },
      h('span', { class: 'pn' }, item.name),
      h('span', { class: 'pp' }, brl(item.price), item.status === 'paused' ? h('span', { class: 'tag' }, 'pausado') : null),
    ),
  )
}

let listFilter = ''
let catFilter: string | null = null
const collapsedCats = new Set<string>()
let nicheTouched = false

function connectionCta() {
  if (isConnected()) return clientSelect()
  const msg = state.connected && 'error' in state.connected ? state.connected.error : 'Conectando ao Orvia…'
  return h('div', { class: 'card' },
    h('p', { class: 'warn' }, msg),
    h('button', { class: 'btn', onclick: () => void send({ type: 'options:open' }) }, 'Conectar ao Orvia (colar a chave)'),
  )
}

/** Cartão "ensinar 1 vez": mostra ao vivo se o iFood já foi aprendido (preço, nome…). */
function teachCard() {
  const learned = state.templates.map((t) => FIELD_LABEL[t.field])
  const has = (f: Field) => state.templates.some((t) => t.field === f)
  const rows = (['price', 'status', 'name', 'description'] as Field[]).map((f) => h('span', { class: has(f) ? 'pill ok' : 'pill' }, `${has(f) ? '✓' : '○'} ${FIELD_LABEL[f]}`))
  return h('div', { class: `card ${has('price') ? 'ok' : 'warn-card'}` },
    h('b', {}, has('price') ? 'Extensão pronta para alterar preços' : 'Ensinar o iFood (só uma vez)'),
    h('div', { class: 'chips' }, ...rows),
    has('price')
      ? h('p', { class: 'muted' }, `Já aprendi: ${learned.join(', ')}. Para aprender outro campo, edite 1 produto mudando esse campo.`)
      : h('p', { class: 'muted' }, 'No portal, abra qualquer produto, mude o PREÇO e clique em Salvar — sem recarregar a página. Este cartão muda para ✓ quando eu aprender.'),
    h('p', { class: state.lastLearn?.ok ? 'okText' : 'hint' }, state.lastLearn?.text ?? (state.menuWrites ? `Vi ${state.menuWrites} gravação(ões) do cardápio.` : 'Aguardando você salvar uma edição no portal…')),
  )
}

function tabProdutos() {
  // Passo 6→7 do fluxo: primeiro o botão de sincronizar; os produtos só aparecem depois do clique.
  const s = sync.lastAt !== null ? state.snapshot : null
  const box = h('div', {})
  box.append(teachCard())
  const when = sync.lastAt ? `Sincronizado às ${new Date(sync.lastAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : null
  box.append(
    h('div', { class: 'card hero' },
      h('b', {}, s ? (s.merchant.name ?? 'Cardápio do iFood') : 'Sincronizar cardápio'),
      h('p', { class: 'muted' }, s
        ? `${s.categories.length} categorias · ${s.items.length} produtos · ${s.items.filter((i) => i.status === 'paused').length} pausados`
        : 'Abra Menu → Cardápio no portal e clique no botão abaixo. A extensão lê todos os produtos, valores e imagens.'),
      when ? h('p', { class: 'hint' }, when) : null,
      h('button', { class: 'btn primary big', disabled: sync.running, onclick: () => void startSync(false) }, sync.running ? 'Sincronizando…' : s ? '⟳ Sincronizar de novo' : '⟳ Sincronizar cardápio'),
      sync.running ? h('button', { class: 'btn', onclick: () => { sync.cancelled = true; render() } }, 'Parar (ESC)') : null,
    ),
  )
  if (sync.log.length) {
    box.append(h('div', { class: 'steps' }, ...sync.log.map((l) => h('p', { class: `st ${l.kind}` }, `${l.kind === 'ok' ? '✓' : l.kind === 'erro' ? '✗' : l.kind === 'warn' ? '!' : '…'} ${l.text}`))))
  }
  if (!s) return box

  const q = state.quality
  if (q) {
    box.append(h('div', { class: 'chips' },
      h('span', { class: `pill ${q.level === 'boa' ? 'ok' : ''}` }, `leitura ${q.level}`),
      h('span', { class: 'pill' }, `${q.withImage}/${q.items} com foto`),
      h('span', { class: 'pill' }, `${q.withPrice}/${q.items} com preço`),
      s.origin === 'dom' ? h('span', { class: 'pill' }, 'lido da tela') : null,
    ))
    q.warnings.forEach((w) => box.append(h('p', { class: 'warn' }, w)))
  }

  box.append(connectionCta())
  const term = listFilter.trim().toLowerCase()
  const visible = s.items.filter((i) => !term || `${i.name} ${i.categoryName ?? ''}`.toLowerCase().includes(term))
  box.append(h('input', {
    class: 'input', id: 'orvia-search', placeholder: 'Buscar produto…', value: listFilter, 'aria-label': 'Buscar produto',
    oninput: (e: Event) => {
      listFilter = (e.target as HTMLInputElement).value
      render()
      const el = shadow.getElementById('orvia-search') as HTMLInputElement | null
      el?.focus()
      el?.setSelectionRange(listFilter.length, listFilter.length)
    },
  }))
  const byCat = new Map<string, typeof visible>()
  for (const item of visible) byCat.set(item.categoryName ?? 'Sem categoria', [...(byCat.get(item.categoryName ?? 'Sem categoria') ?? []), item])
  if (catFilter && !byCat.has(catFilter)) catFilter = null
  const chips = h('div', { class: 'catchips' },
    h('button', { class: catFilter === null ? 'chip on' : 'chip', onclick: () => { catFilter = null; render() } }, `Todas ${visible.length}`),
    ...[...byCat].map(([cat, items]) => h('button', { class: catFilter === cat ? 'chip on' : 'chip', onclick: () => { catFilter = catFilter === cat ? null : cat; render() } }, `${cat} ${items.length}`)),
  )
  if (byCat.size > 1) box.append(chips)
  const list = h('div', { class: 'plist2' })
  for (const [cat, items] of byCat) {
    if (catFilter && catFilter !== cat) continue
    const closed = collapsedCats.has(cat) && !term
    list.append(
      h('button', { class: 'cathead', 'aria-expanded': String(!closed), onclick: () => { if (closed) collapsedCats.delete(cat); else collapsedCats.add(cat); render() } },
        h('span', {}, closed ? '▸' : '▾'), h('b', {}, cat), h('span', { class: 'muted' }, `${items.length} ${items.length === 1 ? 'produto' : 'produtos'}`)),
      ...(closed ? [] : [h('div', { class: 'pgrid' }, ...items.map(productCard))]),
    )
  }
  if (visible.length === 0) list.append(h('p', { class: 'muted' }, 'Nenhum produto com esse filtro.'))
  box.append(list)
  box.append(h('button', { class: 'btn primary', onclick: () => { state.tab = 'analise'; state.notice = null; render() } }, 'Analisar este cardápio →'))
  return box
}

// ---------------------------------------------------------------------------
// UI — Análise (config → proposta → feedback → execução → final)
// ---------------------------------------------------------------------------
const GOAL_OPTIONS: [typeof flow.goal, string][] = [['ticket', 'Aumentar o ticket médio'], ['conversao', 'Aumentar a conversão'], ['margem', 'Melhorar a margem'], ['organizacao', 'Organizar o cardápio']]

function statusBadge(status: StepStatus) {
  return h('span', { class: `badge ${status}` }, STATUS_LABEL[status])
}

function stepList(steps: Step[]) {
  return h('div', { class: 'steplist' }, ...steps.map((s) =>
    h('div', { class: `step ${s.status}` },
      h('div', { class: 'row' }, h('b', {}, s.action.kind === 'create_combo' ? `Combo: ${s.action.itemName}` : `${KIND_LABEL[s.action.kind]} · ${s.action.itemName}`), statusBadge(s.status)),
      s.action.kind !== 'create_combo' ? h('p', { class: 'muted' }, `${fmtValue(s.action.kind, s.action.before)} → ${fmtValue(s.action.kind, s.action.after)}`) : null,
      h('p', { class: s.status === 'erro' ? 'warn' : 'hint' }, s.message),
    )))
}

function actionRow(a: ProposalAction) {
  const on = flow.approved.has(a.id)
  const body = a.kind === 'create_combo' && a.combo
    ? [h('p', { class: 'muted' }, a.combo.components.map((c) => `${c.quantity > 1 ? `${c.quantity}× ` : ''}${c.name}`).join(' + ')), h('p', {}, `${brl(a.combo.fullPrice)} → `, h('b', {}, brl(a.combo.price)))]
    : [h('p', {}, h('span', { class: 'before' }, fmtValue(a.kind, a.before)), ' → ', h('b', {}, fmtValue(a.kind, a.after)))]
  return h('label', { class: on ? 'act on' : 'act' },
    h('input', { type: 'checkbox', checked: on, 'aria-label': `Fazer: ${a.itemName}`, onchange: (e: Event) => {
      if ((e.target as HTMLInputElement).checked) flow.approved.add(a.id)
      else flow.approved.delete(a.id)
      render()
    } }),
    h('div', {},
      h('div', { class: 'row' }, h('b', {}, a.kind === 'create_combo' ? a.itemName : `${KIND_LABEL[a.kind]} · ${a.itemName}`),
        h('span', { class: `pill ${a.risk === 'alto' ? 'hi' : ''}` }, a.source === 'concorrentes' ? 'concorrentes' : a.source === 'ia' ? 'IA' : 'regras')),
      ...body,
      h('p', { class: 'hint' }, a.reason),
      !a.executable ? h('p', { class: 'hint' }, 'Criado no Orvia (pausado); no iFood o cadastro é assistido.') : a.risk === 'alto' ? h('p', { class: 'warn' }, 'Mexe em preço: revise antes de marcar.') : null,
    ))
}

function syncHero(synced: boolean) {
  const s = state.snapshot
  const when = sync.lastAt ? new Date(sync.lastAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : null
  return h('div', { class: 'card hero' },
    h('b', {}, synced && s ? `${s.items.length} produtos sincronizados${when ? ` às ${when}` : ''}` : 'Sincronize para analisar'),
    h('p', { class: 'muted' }, synced ? 'Atualize antes de analisar se você mexeu no cardápio.' : 'A análise usa os produtos, preços e fotos lidos do portal e as boas práticas de cardápio.'),
    h('button', { class: 'btn primary big', disabled: sync.running, onclick: () => void startSync(false, true) }, sync.running ? 'Sincronizando…' : synced ? '⟳ Sincronizar e analisar de novo' : '⟳ Sincronizar e analisar'),
    sync.running ? h('button', { class: 'btn', onclick: () => { sync.cancelled = true; render() } }, 'Parar (ESC)') : null,
    sync.log.length ? h('div', { class: 'steps' }, ...sync.log.map((l) => h('p', { class: `st ${l.kind}` }, `${l.kind === 'ok' ? '✓' : l.kind === 'erro' ? '✗' : l.kind === 'warn' ? '!' : '…'} ${l.text}`))) : null,
  )
}

const LEVEL_ICON: Record<PracticeCheck['level'], string> = { ok: '✓', atencao: '!', falha: '✗' }
function practiceBoard(checks: PracticeCheck[]) {
  const okN = checks.filter((c) => c.level === 'ok').length
  return h('div', { class: 'card' },
    h('div', { class: 'row' }, h('b', {}, 'Boas práticas de cardápio'), h('span', { class: `pill ${okN === checks.length ? 'ok' : ''}` }, `${okN}/${checks.length} ok`)),
    ...checks.map((c) => h('div', { class: `chk ${c.level}` }, h('p', {}, h('b', {}, `${LEVEL_ICON[c.level]} ${c.title}`)), h('p', { class: 'hint' }, c.detail))),
  )
}

function analiseConfig() {
  const box = h('div', {})
  const synced = Boolean(state.snapshot) && sync.lastAt !== null
  box.append(syncHero(synced))
  if (!synced) return box
  box.append(practiceBoard(auditPractices(state.snapshot!)))
  const niche = h('select', { class: 'input', 'aria-label': 'Nicho', onchange: (e: Event) => { state.niche = (e.target as HTMLSelectElement).value; nicheTouched = true } },
    ...NICHES.map((n) => h('option', { value: n.value, selected: n.value === state.niche }, n.label)))
  const goal = h('select', { class: 'input', 'aria-label': 'Objetivo', onchange: (e: Event) => (flow.goal = (e.target as HTMLSelectElement).value as typeof flow.goal) },
    ...GOAL_OPTIONS.map(([v, l]) => h('option', { value: v, selected: v === flow.goal }, l)))
  const discount = h('input', { class: 'input', type: 'number', min: '0', max: '50', value: String(flow.ctx.comboDiscountPercent), 'aria-label': 'Desconto do combo %', oninput: (e: Event) => (flow.ctx.comboDiscountPercent = Math.min(50, Math.max(0, Number((e.target as HTMLInputElement).value) || 0))) })
  const city = h('input', { class: 'input', placeholder: 'Ex.: Asa Norte, Brasília', value: flow.city, 'aria-label': 'Cidade ou bairro', id: 'orvia-city', oninput: (e: Event) => {
    const was = flow.city.trim() === ''
    flow.city = (e.target as HTMLInputElement).value
    void chrome.storage.local.set({ [CITY_KEY]: flow.city })
    if (was !== (flow.city.trim() === '')) {
      render() // libera/trava o botão na hora
      const el = shadow.getElementById('orvia-city') as HTMLInputElement | null
      el?.focus()
      el?.setSelectionRange(flow.city.length, flow.city.length)
    }
  } })
  const strategy = h('select', { class: 'input', 'aria-label': 'Estratégia', onchange: (e: Event) => { flow.strategy = (e.target as HTMLSelectElement).value as typeof flow.strategy; render() } },
    ...STRATEGIES.map((o) => h('option', { value: o.value, selected: o.value === flow.strategy }, o.label)))
  const nicheLabel = NICHES.find((n) => n.value === state.niche)?.label ?? state.niche
  const needCity = isConnected() && flow.competitors && flow.city.trim() === ''
  box.append(
    connectionCta(),
    h('div', { class: 'card' },
      h('b', {}, 'Estratégia com base nos concorrentes'),
      h('label', { class: 'field' }, h('span', { class: 'label' }, `Nicho${nicheTouched ? '' : ' (detectado pelos produtos — confira)'}`), niche),
      h('label', { class: 'field' }, h('span', { class: 'label' }, 'Estratégia'), strategy),
      h('p', { class: 'hint' }, strategyOf(flow.strategy).hint),
      h('label', { class: 'field' }, h('span', { class: 'label' }, `Cidade / bairro (concorrentes de ${nicheLabel.toLowerCase()} da região)`), city),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: flow.competitors, onchange: (e: Event) => { flow.competitors = (e.target as HTMLInputElement).checked; render() } }), ` Pesquisar concorrentes do nicho (${nicheLabel}) na região — fontes públicas, com links`),
      needCity ? h('p', { class: 'warn' }, 'Informe a cidade/bairro para eu buscar os concorrentes certos.') : null,
      !isConnected() && flow.competitors ? h('p', { class: 'warn' }, 'A pesquisa de concorrentes precisa da conexão com o Orvia. Sem ela, a análise usa só as boas práticas.') : null,
    ),
    h('div', { class: 'grid2' }, h('label', { class: 'field' }, h('span', { class: 'label' }, 'Objetivo'), goal), h('label', { class: 'field' }, h('span', { class: 'label' }, 'Desconto combo %'), discount)),
    h('button', { class: 'btn primary big', disabled: needCity || (isConnected() && !state.clientId), onclick: () => void startAnalysis() }, 'Analisar cardápio'),
    h('p', { class: 'hint' }, isConnected() ? 'O cardápio é enviado ao Orvia para a análise com IA. Nada é alterado no iFood sem a sua aprovação.' : 'Sem conexão, a análise usa só as regras locais.'),
  )
  return box
}

function analiseProposta() {
  const p = flow.proposal!
  const box = h('div', {})
  const chosen = p.actions.filter((a) => flow.approved.has(a.id) && a.kind !== 'recommend')
  const missing = missingFields(chosen, state.templates)
  box.append(h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, `Proposta v${p.version}`), h('span', { class: 'pill' }, `${p.actions.filter((a) => a.kind !== 'recommend').length} ações`)), h('p', {}, p.summary)))
  if (flow.understood.length) box.append(h('div', { class: 'card ok' }, h('b', {}, 'Ajustei conforme você pediu'), ...flow.understood.map((u) => h('p', { class: 'okText' }, `✓ ${u}`))))
  p.notices.forEach((n) => box.append(h('p', { class: 'warn' }, n)))

  const doable = p.actions.filter((a) => a.kind !== 'recommend')
  if (doable.length) box.append(h('h3', {}, 'O que será feito (marque / desmarque)'), ...doable.map(actionRow))
  const recs = p.actions.filter((a) => a.kind === 'recommend')
  if (recs.length) box.append(h('h3', {}, `Pontos de atenção (${recs.length})`), ...recs.map((r) => h('div', { class: `card sev-${r.risk}` }, h('b', {}, r.itemName), h('p', { class: 'muted' }, String(r.before ?? '')), h('p', {}, String(r.after ?? '')))))
  if (p.insights.length || p.competitors.length) {
    box.append(h('h3', {}, 'O que a região está fazendo'), ...p.insights.map((t) => h('p', {}, `• ${t}`)),
      ...p.competitors.map((c) => h('div', { class: 'card' }, h('b', {}, c.name), ...c.highlights.map((t) => h('p', { class: 'muted' }, `• ${t}`)), ...c.examples.slice(0, 3).map((e) => h('p', { class: 'hint' }, `${e.name}${e.price !== null ? ` — ${brl(e.price)}` : ''}`)))))
  }
  if (p.sources.length) box.append(h('h3', {}, 'Fontes'), ...p.sources.slice(0, 8).map((s) => h('p', { class: 'hint' }, `${s.title} — ${s.url}`)))

  if (missing.length) {
    box.append(teachCard(), h('div', { class: 'card warn-card' }, h('b', {}, 'Falta ensinar ao iFood'),
      h('p', { class: 'muted' }, `Para alterar ${missing.map((f) => FIELD_LABEL[f].toLowerCase()).join(', ')} automaticamente, edite 1 produto no portal (mude esse campo e salve) — a extensão aprende. Sem isso, essas ações aparecem como “não feita”.`)))
  }
  box.append(
    h('button', { class: 'btn', disabled: state.busy, onclick: downloadPdf }, '⬇ Baixar apresentação (PDF)'),
    h('div', { class: 'grid2' },
      h('button', { class: 'btn', onclick: () => { flow.phase = 'feedback'; render() } }, '✗ Não fazer'),
      h('button', { class: 'btn primary', disabled: chosen.length === 0, onclick: () => void approveAndRun() }, `✓ Fazer (${chosen.length})`),
    ),
    h('p', { class: 'hint' }, 'Ao fazer, a extensão executa exatamente as ações marcadas acima, mostra o status de cada uma e para a qualquer momento com ESC.'),
  )
  return box
}

function analiseFeedback() {
  const ta = h('textarea', { class: 'input ta', rows: 5, placeholder: 'Ex.: não quero mexer nos preços, só um combo, desconto de 5%, não mexer em Bebidas…', 'aria-label': 'O que você pensa' }) as HTMLTextAreaElement
  ta.value = flow.feedbackText
  ta.addEventListener('input', () => (flow.feedbackText = ta.value))
  return h('div', {},
    h('div', { class: 'card' }, h('b', {}, 'O que você pensa sobre a proposta?'), h('p', { class: 'muted' }, 'Escreva o que não gostou ou o que prefere. Eu mostro o que entendi e gero uma nova proposta.')),
    ta,
    h('button', { class: 'btn primary', onclick: () => { const t = flow.feedbackText.trim(); if (!t) return notify('erro', 'Escreva o que você pensa para eu ajustar.'); void startAnalysis(t) } }, 'Gerar nova proposta'),
    h('button', { class: 'btn', onclick: () => { flow.phase = 'proposta'; render() } }, 'Voltar à proposta'),
  )
}

function analiseExec() {
  const done = flow.steps.filter((s) => s.status !== 'pendente' && s.status !== 'executando').length
  return h('div', {},
    h('div', { class: 'card' }, h('b', {}, 'Executando o que você aprovou'), h('p', { class: 'muted' }, `${done} de ${flow.steps.length} · ESC para parar tudo`),
      h('button', { class: 'btn', onclick: () => { flow.abort?.abort(); notify('info', 'Parando… o que não começou não será alterado.') } }, 'Parar (ESC)')),
    stepList(flow.steps),
  )
}

function analiseFinal() {
  const r = flow.report
  const c = r?.counts
  const title = r?.aborted ? 'Otimização interrompida' : c && (c.erro > 0 || c.pulada > 0) ? 'Cardápio otimizado (parcial)' : 'Cardápio otimizado'
  const box = h('div', {})
  box.append(
    h('div', { class: `card ${r?.aborted || (c && c.erro) ? '' : 'ok'}` }, h('b', { class: 'bigtitle' }, `${r?.aborted ? '■' : c && c.erro ? '!' : '✓'} ${title}`),
      c ? h('div', { class: 'chips' }, h('span', { class: 'pill ok' }, `${c.ok} aplicadas`), h('span', { class: 'pill' }, `${c.assistida} combos no Orvia`), h('span', { class: 'pill' }, `${c.pulada} não feitas`), h('span', { class: c.erro ? 'pill hi' : 'pill' }, `${c.erro} erros`)) : null),
    stepList(flow.steps),
  )
  const waiting = flow.steps.filter((s) => s.status === 'pulada' && s.message.startsWith('Falta ensinar'))
  if (waiting.length && !flow.retrying) {
    const first = waiting[0]!.action
    const f = (Object.keys(FIELD_LABEL) as Field[]).find((k) => waiting[0]!.message.includes(`“${FIELD_LABEL[k]}”`))
    box.append(h('div', { class: 'card warn-card' }, h('b', {}, 'Ensine uma vez e eu termino sozinho'),
      h('p', {}, `No portal do iFood, abra “${first.itemName}”, ${f ? `altere ${FIELD_LABEL[f].toLowerCase()}` : 'faça a alteração'}${first.after != null ? ` para ${String(first.after)}` : ''} e clique em Salvar. A extensão aprende com esse salvamento e aplica automaticamente os ${waiting.length} passo(s) restante(s).`)))
  }
  if (flow.retrying) box.append(h('div', { class: 'card' }, h('b', {}, 'Aplicando o que faltava…')))
  if (flow.prints.length) {
    box.append(h('h3', {}, 'Prints para enviar ao cliente'), ...flow.prints.map((f) => h('div', { class: 'print' }, h('img', { src: f.dataUrl, alt: f.name }), h('span', { class: 'hint' }, f.name))))
  }
  if (flow.saved) box.append(h('p', { class: flow.saved.ok ? 'okText' : 'warn' }, flow.saved.text))
  if (flow.upload) box.append(h('p', { class: flow.upload.ok ? 'okText' : 'warn' }, flow.upload.text))
  if (flow.saved && !flow.saved.ok) box.append(h('button', { class: 'btn', onclick: () => void send({ type: 'downloads:save', files: flow.prints }).then((res) => { flow.saved = res.ok ? { ok: true, text: `Salvo em Downloads: ${res.data && (res.data as any).saved.map((s: any) => s.name).join(', ')}` } : { ok: false, text: res.error }; render() }) }, 'Salvar prints de novo'))
  if (flow.upload && !flow.upload.ok) box.append(h('button', { class: 'btn', onclick: () => void uploadEvidence() }, 'Enviar ao Orvia'))
  box.append(h('button', { class: 'btn primary big', onclick: exitFlow }, 'Sair'))
  return box
}

function tabAnalise() {
  const box = h('div', {})
  if (flow.phase === 'analisando') {
    box.append(h('div', { class: 'card' }, h('b', {}, 'Analisando…'), h('div', { class: 'steps' }, ...flow.log.map((l) => h('p', { class: 'st run' }, `… ${l}`))), h('button', { class: 'btn', onclick: () => { flow.cancelled = true; render() } }, 'Parar (ESC)')))
    return box
  }
  if (flow.phase === 'proposta' && flow.proposal) return analiseProposta()
  if (flow.phase === 'feedback') return analiseFeedback()
  if (flow.phase === 'executando') return analiseExec()
  if (flow.phase === 'final') return analiseFinal()
  return analiseConfig()
}

// ---------------------------------------------------------------------------
// UI — Diagnóstico (sem valores: só caminhos e nomes de campos)
// ---------------------------------------------------------------------------
function diagReport() {
  const s = state.snapshot
  return {
    extensao: chrome.runtime.getManifest().version,
    pagina: location.pathname,
    quando: new Date().toISOString(),
    hookAtivo: dump !== null,
    cabecalhosConhecidos: dump?.headersKnown ?? false,
    formaPreco: dump?.priceShape ?? '',
    amostraPrecos: (s?.items ?? []).slice(0, 5).map((i) => ({ preco: i.price, original: i.originalPrice, foto: Boolean(i.imageUrl), categoria: i.categoryName })),
    capturas: (dump?.captures ?? []).map((c) => ({ metodo: c.method, caminho: c.path, status: c.status, produtos: c.products, categorias: c.categories })),
    respostasVistas: (dump?.seen ?? []).slice(0, 60).map((x) => ({ metodo: x.method, caminho: x.path, status: x.status, bytes: x.bytes, forma: x.shape, parecia_cardapio: x.menu })),
    gravacoesVistas: (dump?.writes ?? []).slice(0, 10).map((w) => ({ metodo: w.method, caminho: w.path, status: w.status, corpo: w.reqShape, consulta: w.query })),
    moldesAprendidos: state.templates.map((t) => ({ campo: t.field, modo: t.mode, metodo: t.method, url: t.urlTemplate, caminhoCampo: t.path.join('.'), unidade: t.unit ?? null, id: t.idKind ?? 'id' })),
    ultimoAprendizado: state.lastLearn,
    snapshot: s ? { origem: s.origin, itens: s.items.length, categorias: s.categories.length, comFoto: s.items.filter((i) => i.imageUrl).length, comPreco: s.items.filter((i) => i.price !== null).length } : null,
    qualidade: state.quality,
    precosNaTela: countPricesOnScreen(document),
  }
}

function tabDiagnostico() {
  const box = h('div', {})
  const d = dump
  box.append(
    h('div', { class: 'card' }, h('b', {}, 'Diagnóstico da leitura'),
      h('p', { class: 'muted' }, 'Use se os produtos não aparecerem. O relatório tem só caminhos e nomes de campos — nenhum nome de produto, preço, token ou dado de cliente.'),
      h('p', {}, `Versão ${chrome.runtime.getManifest().version} · ${d ? d.captures.length : 0} resposta(s) de cardápio guardada(s) · ${d ? d.seen.length : 0} resposta(s) vistas`),
      h('div', { class: 'grid2' },
        h('button', { class: 'btn', onclick: async () => { await pullFromHook('merge'); render() } }, 'Atualizar'),
        h('button', { class: 'btn primary', onclick: () => void copy(JSON.stringify(diagReport(), null, 2)) }, 'Copiar relatório'))),
  )
  const seen = (d?.seen ?? []).slice(0, 30)
  if (!d) box.append(h('p', { class: 'muted' }, 'Ainda sem dados do hook. Recarregue a página do portal (F5) e abra Menu → Cardápio.'))
  else if (seen.length === 0) box.append(h('p', { class: 'warn' }, 'O hook não viu nenhuma resposta JSON. Recarregue a página (F5) com a extensão ativa.'))
  box.append(...seen.map((x) => h('div', { class: x.menu ? 'diag on' : 'diag' }, h('p', { class: 'mono' }, `${x.menu ? '✓' : '·'} ${x.method} ${x.path} → ${x.status}`), h('p', { class: 'hint mono' }, x.shape))))
  return box
}

// ---------------------------------------------------------------------------
// ESC: para tudo, sempre
// ---------------------------------------------------------------------------
window.addEventListener('keydown', (e: KeyboardEvent) => {
  if (e.key !== 'Escape') return
  let stopped = false
  if (sync.running) { sync.cancelled = true; stopped = true }
  if (flow.phase === 'analisando') { flow.cancelled = true; stopped = true }
  if (flow.phase === 'executando' && flow.abort && !flow.abort.signal.aborted) { flow.abort.abort(); stopped = true }
  if (stopped) notify('info', 'ESC: parando tudo. O que não começou não será alterado.')
}, true)

function render() {
  mount.replaceChildren()
  const busyNow = sync.running || flow.phase === 'analisando' || flow.phase === 'executando'
  const button = h('button', { class: 'fab', 'aria-label': 'Abrir Orvia', title: 'Orvia · iFood', onclick: () => { state.open = !state.open; render() } }, 'O')
  if (state.snapshot) button.append(h('span', { class: 'dot' }))
  mount.append(button)
  if (!state.open) return

  const tabs: [Tab, string][] = [['produtos', 'Produtos'], ['analise', 'Análise'], ['pendencias', 'Pendências'], ['diagnostico', 'Diagnóstico']]
  const conn = state.connected
  const panel = h('aside', { class: 'panel', role: 'dialog', 'aria-label': 'Orvia · iFood' },
    h('header', {},
      h('div', {}, h('b', {}, 'Orvia · iFood'), h('span', { class: 'sub' }, conn && 'workspace' in conn ? `conectado: ${conn.workspace}` : 'não conectado')),
      h('div', {},
        busyNow ? h('span', { class: 'esc' }, 'ESC para parar') : null,
        h('button', { class: 'icon', title: 'Opções', onclick: () => void send({ type: 'options:open' }) }, '⚙'),
        h('button', { class: 'icon', title: 'Fechar', onclick: () => { state.open = false; render() } }, '×'),
      ),
    ),
    h('nav', {}, ...tabs.map(([key, label]) =>
      h('button', {
        class: state.tab === key ? 'tab active' : 'tab',
        onclick: () => {
          state.tab = key
          state.notice = null
          if (key === 'pendencias' && !state.pendingLoaded && state.clientId) void loadPending()
          if (key === 'diagnostico') void pullFromHook('merge').then(render)
          render()
        },
      }, label))),
    state.notice ? h('div', { class: `notice ${state.notice.kind}` }, state.notice.text) : null,
    h('section', { class: 'body' }, state.tab === 'produtos' ? tabProdutos() : state.tab === 'analise' ? tabAnalise() : state.tab === 'pendencias' ? tabPendencias() : tabDiagnostico()),
  )
  mount.append(panel)
}

async function boot() {
  document.documentElement.append(host)
  const stored = await chrome.storage.local.get([TEMPLATES_KEY, AUTO_KEY, UNDO_KEY, CITY_KEY])
  state.templates = (stored[TEMPLATES_KEY] as Template[] | undefined) ?? []
  state.autoMode = Boolean(stored[AUTO_KEY])
  state.undoAvailable = Array.isArray(stored[UNDO_KEY]) && (stored[UNDO_KEY] as unknown[]).length > 0
  flow.city = (stored[CITY_KEY] as string | undefined) ?? ''
  render()
  // Leitura silenciosa do que o portal já carregou (NÃO abre o painel sozinho).
  await pullFromHook('merge').catch(() => 0)
  render()
  await connect()
  // Conectou/desconectou nas opções com o painel aberto → atualiza na hora.
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && HUB_CHANGED_KEY in changes) void connect() })
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && !isConnected()) void connect() })
  // Recarga pedida pelo Sincronizar: termina a sincronização e mostra o painel.
  const armed = Number(sessionStorage.getItem(ARM_KEY) ?? 0)
  if (armed) {
    sessionStorage.removeItem(ARM_KEY)
    if (Date.now() - armed < 90_000) void startSync(true)
  }
  const beat = () => {
    if (document.visibilityState === 'visible') void send({ type: 'hub:heartbeat' })
  }
  beat()
  window.setInterval(beat, 120_000)
  if (state.autoMode && state.clientId) {
    for (let i = 0; i < 30 && !state.snapshot; i += 1) await sleep(1000)
    await loadPending()
    if (state.pending.some((p) => p.action === 'update')) await applyAll(false)
  }
}

void boot()
