/**
 * MAIN world no portal do Cardápio Web — SOMENTE OBSERVA. Quando VOCÊ edita algo no portal, avisa a extensão
 * (método, endereço, corpo e resposta) para ela aprender "como o portal salva". Não envia nada a ninguém.
 * Nunca lê nem repassa o token: só método/URL/corpo JSON/resposta.
 */
;(() => {
  const w = window as unknown as { __orviaCwHook?: boolean }
  if (w.__orviaCwHook) return
  w.__orviaCwHook = true
  const API = 'https://api.cardapioweb.com/'
  const MAX = 400_000
  const post = (m: Record<string, unknown>) => window.postMessage({ source: 'orvia-hook', ...m }, window.location.origin)
  const tryJson = (t: unknown): unknown => { if (typeof t !== 'string' || !t || t.length > MAX) return undefined; try { return JSON.parse(t) } catch { return undefined } }
  const report = (method: string, url: string, status: number, reqBody: unknown, text: string | null) => {
    if (!url.startsWith(API)) return
    const m = method.toUpperCase()
    const json = text ? tryJson(text) : undefined
    if (m === 'GET') { if (json !== undefined && /\/api\/v1\/company\/(categories|subitems|item)/.test(url)) post({ kind: 'read', method: m, url, status, json }) }
    else if (status >= 200 && status < 300) post({ kind: 'write', method: m, url, status, body: typeof reqBody === 'string' ? tryJson(reqBody) : undefined, json })
  }
  const of = window.fetch.bind(window)
  window.fetch = async function (input: RequestInfo | URL, init?: RequestInit) {
    const res = await of(input, init)
    try {
      const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
      const method = init?.method ?? (input instanceof Request ? input.method : 'GET')
      if (url.startsWith(API)) res.clone().text().then((t) => report(method, url, res.status, init?.body, t)).catch(() => {})
    } catch { /* observar nunca pode quebrar o portal */ }
    return res
  }
  type X = XMLHttpRequest & { __o?: { m: string; u: string } }
  const open = XMLHttpRequest.prototype.open
  const send = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.open = function (this: X, ...a: any[]) { this.__o = { m: String(a[0]), u: new URL(String(a[1]), location.href).href }; return (open as any).apply(this, a) } as typeof open
  XMLHttpRequest.prototype.send = function (this: X, body?: Document | XMLHttpRequestBodyInit | null) {
    this.addEventListener('load', () => { try { if (this.__o) report(this.__o.m, this.__o.u, this.status, body, typeof this.responseText === 'string' ? this.responseText : null) } catch { /* */ } })
    return send.call(this, body)
  }
})()
