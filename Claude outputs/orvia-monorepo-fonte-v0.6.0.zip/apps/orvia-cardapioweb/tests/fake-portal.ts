const API = 'https://api.cardapioweb.com/api/v1/company'
/** Portal falso com o contrato OBSERVADO (PUT parcial JSON, duplicate, delete, ordenation). `obey` = o portal aplica o PUT? */
export function fakePortal(opts: { obey?: boolean; dupStatus?: number } = {}) {
  const obey = opts.obey ?? true
  const items: Record<string, any>[] = [
    { id: 1, category_id: 10, name: 'SELETA', description: '', price: 10, status: 'ACTIVE', add_ons: [{ id: 1 }, { id: 2 }] },
    { id: 2, category_id: 10, name: 'Outro', description: 'd', price: 20, status: 'ACTIVE', add_ons: [] },
  ]
  let cats = [{ id: 100, position: 0 }, { id: 101, position: 1 }, { id: 102, position: 2 }]
  let nextId = 50
  const calls: string[] = []
  const request = async (method: string, url: string, body?: any) => {
    calls.push(`${method} ${url.replace(API, '')}`)
    let m: RegExpMatchArray | null
    if (method === 'GET' && (m = url.match(/category\/(\d+)\/items$/))) return { status: 200, json: items.filter((i) => String(i.category_id) === m![1]).map((i) => ({ ...i })) }
    if (method === 'PUT' && (m = url.match(/category\/(\d+)\/items\/(\d+)$/))) {
      const it = items.find((i) => String(i.id) === m![2])
      if (!it) return { status: 404, json: null }
      if (obey) Object.assign(it, body)
      return { status: 200, json: { ...it } }
    }
    if (method === 'POST' && (m = url.match(/item\/(\d+)\/duplicate$/))) {
      if (opts.dupStatus) return { status: opts.dupStatus, json: null }
      const b = items.find((i) => String(i.id) === m![1])!
      items.push({ ...b, id: (nextId += 1), add_ons: [...b.add_ons], category_id: body.category_ids.ids[0] })
      return { status: 200, json: null }
    }
    if (method === 'DELETE' && (m = url.match(/category\/(\d+)\/items\/(\d+)$/))) {
      const k = items.findIndex((i) => String(i.id) === m![2])
      if (k < 0) return { status: 404, json: null }
      items.splice(k, 1)
      return { status: 200, json: {} }
    }
    if (method === 'GET' && url.endsWith('/categories')) return { status: 200, json: cats.map((c) => ({ ...c, name: 'c' })) }
    if (method === 'PUT' && url.endsWith('/categories/ordenation')) {
      cats = body.categories_attributes.map((c: any) => ({ id: c.id, position: c.position }))
      return { status: 200, json: { success: true } }
    }
    return { status: 404, json: null }
  }
  return { request, items, calls, cats: () => cats }
}

