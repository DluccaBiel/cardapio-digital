import type { PortalRequest } from '@orvia/shared/lib/executor'
import { duplicateItem } from './cw-ops'
export async function createItemFromBase(o: { baseProductId: string; categoryId?: string | null; name: string; description?: string; price?: number | null; request: PortalRequest }): Promise<{ ok: boolean; message: string; productId?: string }> {
  if (!o.categoryId) return { ok: false, message: 'Produto-base sem categoria conhecida — nada criado.' }
  return duplicateItem(o.request, { cat: o.categoryId, baseId: o.baseProductId, name: o.name, description: o.description, price: o.price })
}
