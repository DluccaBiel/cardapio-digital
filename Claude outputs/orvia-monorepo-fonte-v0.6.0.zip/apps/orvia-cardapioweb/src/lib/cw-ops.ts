/**
 * Receitas do Cardápio Web OBSERVADAS no portal real (diagnóstico do dono, 09/11/2026):
 *   editar item   PUT    /api/v1/company/category/{cat}/items/{id}      (JSON parcial {status} confirmado; os demais campos
 *                                                                       seguem o mesmo contrato e SÃO CONFERIDOS depois de gravar)
 *   duplicar      POST   /api/v1/company/item/{id}/duplicate            {category_ids:{ids:[cat]}}
 *   excluir       DELETE /api/v1/company/category/{cat}/items/{id}
 *   reordenar     PUT    /api/v1/company/categories/ordenation          {categories_attributes:[{id,position}]}  (todas)
 *   listar        GET    /api/v1/company/category/{cat}/items   e   /api/v1/company/categories
 * Toda escrita é seguida de uma releitura: se o portal não mostra o valor pedido, o passo vira ERRO (nunca "ok" no escuro).
 * Puro: sem chrome.*, sem DOM.
 */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import { CW_API } from './cw-api'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300
const C = `${CW_API}/api/v1/company`
const itemsUrl = (cat: string) => `${C}/category/${encodeURIComponent(cat)}/items`
export type Res = { ok: boolean; message: string }

export async function listItems(request: PortalRequest, cat: string): Promise<Rec[] | null> {
  const r = await request('GET', itemsUrl(cat))
  return ok2xx(r.status) && Array.isArray(r.json) ? r.json.filter(isRec) : null
}
const findItem = (list: Rec[] | null, id: string) => list?.find((x) => String(x.id) === String(id)) ?? null
const same = (a: unknown, b: unknown) => String(a ?? '').trim() === String(b ?? '').trim()

export interface Change { name?: string; description?: string; price?: number; status?: 'ACTIVE' | 'INACTIVE' }

/** Grava e confere. `label` entra na mensagem. */
export async function patchItem(request: PortalRequest, cat: string, id: string, change: Change, label: string): Promise<Res> {
  if (!cat) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  const before = findItem(await listItems(request, cat), id)
  if (!before) return { ok: false, message: `Não achei “${label}” na categoria — sincronize de novo.` }
  const res = await request('PUT', `${itemsUrl(cat)}/${encodeURIComponent(id)}`, change)
  if (!ok2xx(res.status)) return { ok: false, message: `O Cardápio Web recusou a alteração de “${label}” (HTTP ${res.status}).` }
  const after = findItem(await listItems(request, cat), id)
  if (!after) return { ok: false, message: `Enviei a alteração de “${label}”, mas não consegui reler para conferir.` }
  const bad: string[] = []
  if (change.name !== undefined && !same(after.name, change.name)) bad.push('nome')
  if (change.description !== undefined && !same(after.description, change.description)) bad.push('descrição')
  if (change.price !== undefined && Math.abs(Number(after.price) - change.price) > 0.001) bad.push('preço')
  if (change.status !== undefined && after.status !== change.status) bad.push('status')
  if (bad.length) return { ok: false, message: `Enviei, mas o Cardápio Web ainda mostra o ${bad.join(' e ')} anterior de “${label}”. Nada mais foi mexido.` }
  return { ok: true, message: 'Aplicado e conferido no Cardápio Web.' }
}

/** Cria por DUPLICAÇÃO na mesma categoria do produto-base, depois ajusta nome/descrição/preço e deixa ATIVO. */
export async function duplicateItem(request: PortalRequest, o: { cat: string; baseId: string; name: string; description?: string; price?: number | null }): Promise<Res & { productId?: string }> {
  const name = o.name.trim()
  if (name.length < 2) return { ok: false, message: 'Nome do novo produto vazio — nada criado.' }
  const beforeList = await listItems(request, o.cat)
  const base = findItem(beforeList, o.baseId)
  if (!beforeList || !base) return { ok: false, message: 'Não achei o produto-base na categoria — nada criado.' }
  const ids = new Set(beforeList.map((x) => String(x.id)))
  const dup = await request('POST', `${C}/item/${encodeURIComponent(o.baseId)}/duplicate`, { category_ids: { ids: [Number(o.cat)] } })
  if (!ok2xx(dup.status)) return { ok: false, message: `O Cardápio Web recusou duplicar o produto-base (HTTP ${dup.status}).` }
  const fresh = (await listItems(request, o.cat) ?? []).filter((x) => !ids.has(String(x.id)))
  if (fresh.length !== 1) return { ok: false, message: `Dupliquei, mas não consegui identificar o novo item (${fresh.length} novos). Confira a categoria no portal.` }
  const newId = String(fresh[0]!.id)
  const change: Change = { name, status: 'ACTIVE', ...(o.description !== undefined ? { description: o.description } : {}), ...(o.price != null && Number.isFinite(o.price) ? { price: o.price } : {}) }
  const r = await patchItem(request, o.cat, newId, change, name)
  if (!r.ok) return { ok: false, productId: newId, message: `Dupliquei, mas não consegui ajustar o novo item (${r.message}) Ele ficou na categoria com o nome do original — corrija no portal.` }
  const fin = findItem(await listItems(request, o.cat), newId)
  const sameAddOns = Array.isArray(fin?.add_ons) && Array.isArray(base.add_ons) && fin.add_ons.length === base.add_ons.length
  return { ok: true, productId: newId, message: `Criado e ATIVO: “${name}” (duplicado de “${String(base.name)}”${sameAddOns ? ', com os mesmos complementos' : ''}).` }
}

export async function deleteItem(request: PortalRequest, cat: string, id: string, name: string): Promise<Res> {
  if (!cat) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  if (!findItem(await listItems(request, cat), id)) return { ok: true, message: `“${name}” já não está no cardápio.` }
  const del = await request('DELETE', `${itemsUrl(cat)}/${encodeURIComponent(id)}`)
  if (!ok2xx(del.status)) return { ok: false, message: `O Cardápio Web recusou excluir “${name}” (HTTP ${del.status}).` }
  return findItem(await listItems(request, cat), id)
    ? { ok: false, message: `Pedi a exclusão de “${name}”, mas ele ainda aparece. Confira no portal.` }
    : { ok: true, message: `“${name}” excluído e conferido no Cardápio Web.` }
}

const liveCats = async (request: PortalRequest): Promise<{ id: string; position: number }[] | null> => {
  const r = await request('GET', `${C}/categories`)
  if (!ok2xx(r.status) || !Array.isArray(r.json)) return null
  const rows = r.json.filter(isRec).map((c) => ({ id: String(c.id), position: Number(c.position) }))
  return rows.every((c) => c.id && Number.isFinite(c.position)) ? rows.sort((a, b) => a.position - b.position) : null
}

export async function reorderCats(request: PortalRequest, order: { id: string; name: string }[]): Promise<Res> {
  const live = await liveCats(request)
  if (!live?.length) return { ok: false, message: 'Não consegui ler a lista de categorias — ordem não alterada.' }
  const known = new Set(live.map((c) => c.id))
  const wanted = order.map((c) => c.id).filter((id) => known.has(id))
  if (wanted.length !== order.length) return { ok: false, message: 'O cardápio mudou (categoria que não existe mais). Sincronize e analise de novo — ordem não alterada.' }
  const finalIds = [...wanted, ...live.map((c) => c.id).filter((id) => !wanted.includes(id))]
  if (finalIds.every((id, i) => id === live[i]!.id)) return { ok: true, message: 'As categorias já estavam nesta ordem.' }
  const res = await request('PUT', `${C}/categories/ordenation`, { categories_attributes: finalIds.map((id, i) => ({ id: Number(id), position: i })) })
  if (!ok2xx(res.status)) return { ok: false, message: `O Cardápio Web recusou a nova ordem (HTTP ${res.status}).` }
  const after = await liveCats(request)
  if (!after) return { ok: true, message: 'Ordem enviada (HTTP 200), mas não consegui reler para conferir.' }
  return after.length === finalIds.length && after.every((c, i) => c.id === finalIds[i])
    ? { ok: true, message: `Categorias reordenadas e conferidas (${finalIds.length}).` }
    : { ok: false, message: 'Enviei a ordem, mas o portal ainda mostra a anterior. Confira no portal.' }
}
