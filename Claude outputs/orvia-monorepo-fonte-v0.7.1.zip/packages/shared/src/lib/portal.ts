/** Onde e como falar com o portal da plataforma (iFood / Cardápio Web). */
export interface PortalCtx { origin: string; ownerId: string }
