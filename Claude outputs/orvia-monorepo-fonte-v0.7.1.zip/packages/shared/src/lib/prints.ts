/**
 * Relatório do que foi feito — UMA imagem só, para enviar ao cliente.
 * Conteúdo (buildPrintPages) é puro e testado; o desenho (renderPrintPng) usa canvas
 * e roda no content script. Regras: nunca mostra erro como sucesso; mostra o status
 * real de cada ação e o que ficou para o cliente/gestor fazer.
 */
import { fmtValue, KIND_LABEL } from '../core/proposal'
import type { RunReport, Step, StepStatus } from './runner'

export interface ProductView {
  name: string
  description: string
  imageUrl: string | null
  categoryName: string | null
  price: number | null
  /** preço "de" quando há promoção por desconto */
  originalPrice: number | null
  active: boolean | null
  schedule: string
  /** null = sem promoção; senão o texto de qual promoção está ativa */
  promotion: string | null
}

export interface PrintInput {
  clientName: string
  merchantName: string | null
  summary: string
  version: number
  date: Date
  report: RunReport
  /** como cada produto ficou no iFood depois da execução (por id da ação) */
  views?: Record<string, ProductView | null>
  /** foto de reserva (do cardápio sincronizado) por id da ação */
  fallbackImages?: Record<string, string | null>
  /** ordem anterior das categorias (id → posição 1-based), para mostrar "era Nº" */
  previousOrder?: Record<string, number>
}

export interface ReportCard {
  status: StepStatus
  kindLabel: string
  title: string
  /** antes → depois do que foi pedido */
  change: string
  /** o resultado conferido (mensagem da execução) */
  result: string
  view: ProductView | null
  imageUrl: string | null
  /** só para reordenação de categorias */
  order?: { name: string; was: number | null; now: number }[]
}

export interface ReportModel {
  title: string
  verdict: { tone: 'ok' | 'erro' | 'neutro'; text: string }
  subtitle: string
  kpis: { label: string; value: string; tone: 'ok' | 'erro' | 'neutro' | 'info' }[]
  summary: string
  note: string
  cards: ReportCard[]
  /** ações que não couberam nos cartões */
  overflow: string[]
}

export const STATUS_LABEL: Record<StepStatus, string> = { pendente: 'PENDENTE', executando: 'EXECUTANDO', ok: 'OK', erro: 'ERRO', pulada: 'NÃO FEITA', assistida: 'ASSISTIDA' }
/** no relatório do cliente o selo diz com todas as letras se foi ou não executado */
export const REPORT_STATUS_LABEL: Record<StepStatus, string> = { pendente: 'PENDENTE', executando: 'EXECUTANDO', ok: 'EXECUTADO', erro: 'NÃO EXECUTADO', pulada: 'NÃO FEITO', assistida: 'REGISTRADO' }
export const MAX_CARDS = 24
export const REPORT_FILE = 'relatorio-cardapio.png'

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

function cardOf(s: Step, input: PrintInput): ReportCard {
  const a = s.action
  const view = input.views?.[a.id] ?? null
  const base = { status: s.status, kindLabel: KIND_LABEL[a.kind], result: s.message, view }
  if (a.kind === 'reorder_categories' && a.order) {
    return { ...base, title: 'Categorias do cardápio', change: 'Ordem de boas práticas', imageUrl: null, order: a.order.map((c, i) => ({ name: c.name, was: input.previousOrder?.[c.id] ?? null, now: i + 1 })) }
  }
  if (a.kind === 'create_combo' && a.combo) {
    return { ...base, title: `Combo: ${a.combo.name}`, change: `${a.combo.components.map((c) => `${c.quantity > 1 ? `${c.quantity}x ` : ''}${c.name}`).join(' + ')} — de ${fmtValue('update_price', a.combo.fullPrice)} por ${fmtValue('update_price', a.combo.price)}`, imageUrl: view?.imageUrl ?? null }
  }
  const change = a.kind === 'remove_item' ? 'Removido do cardápio' : a.kind === 'create_item' ? `Novo produto${a.newItem ? ` (duplicado de “${a.newItem.baseItemName}”)` : ''}` : `${clip(fmtValue(a.kind, a.before), 70)}  →  ${clip(fmtValue(a.kind, a.after), 90)}`
  return { ...base, title: `${KIND_LABEL[a.kind]} · ${a.itemName}`, change, imageUrl: view?.imageUrl ?? input.fallbackImages?.[a.id] ?? null }
}

export function buildReportModel(input: PrintInput): ReportModel {
  const { report } = input
  const c = report.counts
  const created = report.steps.filter((s) => (s.action.kind === 'create_combo' || s.action.kind === 'create_item') && s.status === 'ok').length
  const notDone = c.erro + c.pulada
  const when = `${input.date.toLocaleDateString('pt-BR')} às ${input.date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
  const verdict: ReportModel['verdict'] = report.aborted
    ? { tone: 'neutro', text: 'EXECUÇÃO INTERROMPIDA — o que não começou não foi alterado.' }
    : notDone > 0
      ? { tone: 'erro', text: `EXECUTADO PARCIALMENTE — ${c.ok + c.assistida} de ${report.steps.length} ação(ões) feitas; ${notDone} NÃO foram feitas.` }
      : { tone: 'ok', text: `EXECUTADO — as ${report.steps.length} ação(ões) aprovadas foram feitas e conferidas no iFood.` }
  const ordered = [...report.steps].sort((x, y) => Number(y.status === 'erro' || y.status === 'pulada') - Number(x.status === 'erro' || x.status === 'pulada'))
  const shown = ordered.slice(0, MAX_CARDS)
  return {
    title: report.aborted ? 'Otimização interrompida' : notDone > 0 ? 'Cardápio otimizado (parcial)' : 'Cardápio otimizado',
    verdict,
    subtitle: `${input.clientName}${input.merchantName && input.merchantName !== input.clientName ? ` · ${input.merchantName}` : ''} · ${when}`,
    kpis: [
      { label: 'Executadas', value: String(c.ok), tone: 'ok' },
      { label: 'Criados (combo/produto)', value: String(created), tone: 'info' },
      { label: 'Não feitas', value: String(c.pulada), tone: c.pulada ? 'neutro' : 'ok' },
      { label: 'Com erro', value: String(c.erro), tone: c.erro ? 'erro' : 'ok' },
    ],
    summary: input.summary,
    note: `Proposta versão ${input.version} · ${report.steps.length} ação(ões) aprovada(s).`,
    cards: shown.map((s) => cardOf(s, input)),
    overflow: ordered.slice(MAX_CARDS).map((s) => `${REPORT_STATUS_LABEL[s.status]} · ${KIND_LABEL[s.action.kind]} · ${s.action.itemName}`),
  }
}

// ---------------------------------------------------------------------------
// Canvas (browser)
// ---------------------------------------------------------------------------
const W = 1080
const TONE = {
  ok: { fg: '#0F7B55', bg: '#E4F6EE' },
  erro: { fg: '#B42318', bg: '#FDECEA' },
  neutro: { fg: '#6B7280', bg: '#F1F3F7' },
  info: { fg: '#1D5FD6', bg: '#E6EFFF' },
}
const STATUS_TONE: Record<StepStatus, keyof typeof TONE> = { ok: 'ok', erro: 'erro', pulada: 'neutro', assistida: 'info', pendente: 'neutro', executando: 'info' }
const FONT = 'Inter, "Segoe UI", system-ui, -apple-system, Arial, sans-serif'

function wrapCanvas(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const out: string[] = []
  for (const para of text.split('\n')) {
    let line = ''
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const next = line ? `${line} ${word}` : word
      if (ctx.measureText(next).width <= maxW || !line) line = next
      else {
        out.push(line)
        line = word
      }
    }
    out.push(line)
  }
  return out
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

type Img = CanvasImageSource & { width: number; height: number }
const brlTxt = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const THUMB = 190

/** Desenha (ou só mede, dry=true) o relatório inteiro; devolve a altura total. */
function paint(ctx: CanvasRenderingContext2D, m: ReportModel, images: Map<string, Img>, dry: boolean): number {
  const run = (fn: () => void) => { if (!dry) fn() }
  run(() => { ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, W, 100000) })
  run(() => {
    ctx.fillStyle = '#3D8EFF'
    ctx.fillRect(0, 0, W, 150)
    ctx.fillStyle = '#FFFFFF'
    roundRect(ctx, 56, 42, 66, 66, 18)
    ctx.fill()
    ctx.fillStyle = '#3D8EFF'
    ctx.font = `800 40px ${FONT}`
    ctx.textBaseline = 'middle'
    ctx.fillText('O', 78, 76)
    ctx.fillStyle = '#FFFFFF'
    ctx.font = `700 34px ${FONT}`
    ctx.fillText('Orvia', 140, 76)
    ctx.font = `500 22px ${FONT}`
    ctx.textAlign = 'right'
    ctx.fillText('relatório de execução', W - 56, 76)
    ctx.textAlign = 'left'
    ctx.textBaseline = 'alphabetic'
  })
  let y = 230
  ctx.font = `800 54px ${FONT}`
  for (const l of wrapCanvas(ctx, m.title, W - 112)) { run(() => { ctx.fillStyle = '#0B1220'; ctx.fillText(l, 56, y) }); y += 62 }
  ctx.font = `500 26px ${FONT}`
  for (const l of wrapCanvas(ctx, m.subtitle, W - 112)) { run(() => { ctx.fillStyle = '#6B7280'; ctx.fillText(l, 56, y) }); y += 36 }
  y += 14

  // veredito: foi executado ou não
  const vt = TONE[m.verdict.tone]
  ctx.font = `800 26px ${FONT}`
  const vLines = wrapCanvas(ctx, m.verdict.text, W - 112 - 40)
  const vh = 30 + vLines.length * 36
  run(() => { ctx.fillStyle = vt.bg; roundRect(ctx, 56, y, W - 112, vh, 18); ctx.fill(); ctx.fillStyle = vt.fg; ctx.font = `800 26px ${FONT}`; vLines.forEach((l, i) => ctx.fillText(l, 76, y + 44 + i * 36)) })
  y += vh + 22

  // KPIs
  const kw = (W - 112 - 18 * (m.kpis.length - 1)) / m.kpis.length
  m.kpis.forEach((k, i) => run(() => {
    const x = 56 + i * (kw + 18)
    ctx.fillStyle = TONE[k.tone].bg
    roundRect(ctx, x, y, kw, 130, 20)
    ctx.fill()
    ctx.fillStyle = TONE[k.tone].fg
    ctx.font = `800 56px ${FONT}`
    ctx.fillText(k.value, x + 22, y + 70)
    ctx.font = `600 19px ${FONT}`
    wrapCanvas(ctx, k.label, kw - 36).forEach((l, li) => ctx.fillText(l, x + 22, y + 100 + li * 22))
  }))
  y += 190
  run(() => { ctx.fillStyle = '#3D8EFF'; ctx.font = `800 22px ${FONT}`; ctx.fillText('RESUMO DA ANÁLISE APROVADA', 56, y) })
  y += 36
  ctx.font = `600 26px ${FONT}`
  for (const l of wrapCanvas(ctx, m.summary, W - 112)) { run(() => { ctx.fillStyle = '#111827'; ctx.fillText(l, 56, y) }); y += 36 }
  run(() => { ctx.fillStyle = '#6B7280'; ctx.font = `500 22px ${FONT}`; ctx.fillText(m.note, 56, y + 8) })
  y += 52
  run(() => { ctx.fillStyle = '#3D8EFF'; ctx.font = `800 22px ${FONT}`; ctx.fillText('O QUE FOI FEITO', 56, y) })
  y += 26

  for (const c of m.cards) {
    const tone = TONE[STATUS_TONE[c.status]]
    const hasThumb = !c.order
    const x0 = 76
    const tx = hasThumb ? x0 + THUMB + 24 : x0
    const tw = W - 56 - 20 - tx
    const v = c.view
    // blocos de texto
    ctx.font = `700 27px ${FONT}`
    const titleLines = wrapCanvas(ctx, c.title, tw - 250).slice(0, 2)
    ctx.font = `500 22px ${FONT}`
    const changeLines = wrapCanvas(ctx, c.change, tw).slice(0, 3)
    const info: { text: string; font: string; color: string }[] = []
    if (v) {
      info.push({ text: v.name, font: `700 25px ${FONT}`, color: '#0B1220' })
      if (v.description) info.push(...wrapCanvas((ctx.font = `500 21px ${FONT}`, ctx), v.description, tw).slice(0, 3).map((t) => ({ text: t, font: `500 21px ${FONT}`, color: '#374151' })))
      info.push({ text: `${v.price !== null ? brlTxt(v.price) : 'preço não lido'}${v.active === null ? '' : v.active ? ' · ativo' : ' · pausado'}${v.categoryName ? ` · ${v.categoryName}` : ''}`, font: `600 21px ${FONT}`, color: '#1F2937' })
      info.push({ text: `Horário: ${v.schedule}`, font: `500 21px ${FONT}`, color: '#1F2937' })
      info.push({ text: v.promotion ? `Promoção ativa: ${v.promotion}` : 'Sem promoção ativa', font: `${v.promotion ? 700 : 500} 21px ${FONT}`, color: v.promotion ? '#B45309' : '#6B7280' })
    }
    ctx.font = `500 21px ${FONT}`
    const resultLines = wrapCanvas(ctx, c.result, tw).slice(0, 3)
    let orderRows = 0
    if (c.order) orderRows = Math.ceil(c.order.length / 2)
    const textH = titleLines.length * 34 + changeLines.length * 30 + info.reduce((a, r) => a + (r.font.includes('700 25px') ? 32 : 28), 0) + resultLines.length * 27 + orderRows * 30 + 36
    const h = Math.max(hasThumb ? THUMB + 44 : 0, textH + 28)
    const top = y
    run(() => {
      ctx.fillStyle = '#F8FAFD'
      roundRect(ctx, 56, top, W - 112, h, 18)
      ctx.fill()
      ctx.strokeStyle = '#E3E8F2'
      ctx.lineWidth = 2
      ctx.stroke()
      // foto
      if (hasThumb) {
        const img = c.imageUrl ? images.get(c.imageUrl) : undefined
        ctx.save()
        roundRect(ctx, x0, top + 22, THUMB, THUMB, 14)
        ctx.clip()
        if (img) {
          const r = Math.max(THUMB / img.width, THUMB / img.height)
          ctx.drawImage(img, x0 + (THUMB - img.width * r) / 2, top + 22 + (THUMB - img.height * r) / 2, img.width * r, img.height * r)
        } else {
          ctx.fillStyle = '#E9EDF5'
          ctx.fillRect(x0, top + 22, THUMB, THUMB)
          ctx.fillStyle = '#9AA4B5'
          ctx.font = `600 20px ${FONT}`
          ctx.textAlign = 'center'
          ctx.fillText(c.imageUrl ? 'foto indisponível' : 'sem foto', x0 + THUMB / 2, top + 22 + THUMB / 2 + 6)
          ctx.textAlign = 'left'
        }
        ctx.restore()
      }
      // selo
      const label = REPORT_STATUS_LABEL[c.status]
      ctx.font = `800 17px ${FONT}`
      const bw = ctx.measureText(label).width + 30
      ctx.fillStyle = tone.bg
      roundRect(ctx, W - 56 - 20 - bw, top + 18, bw, 36, 18)
      ctx.fill()
      ctx.fillStyle = tone.fg
      ctx.fillText(label, W - 56 - 20 - bw + 15, top + 42)
      let ty = top + 48
      ctx.fillStyle = '#0B1220'
      ctx.font = `700 27px ${FONT}`
      titleLines.forEach((l) => { ctx.fillText(l, tx, ty); ty += 34 })
      ctx.fillStyle = '#6B7280'
      ctx.font = `500 22px ${FONT}`
      changeLines.forEach((l) => { ctx.fillText(l, tx, ty); ty += 30 })
      ty += 4
      info.forEach((r) => { ctx.fillStyle = r.color; ctx.font = r.font; ctx.fillText(r.text, tx, ty); ty += r.font.includes('700 25px') ? 32 : 28 })
      if (c.order) {
        ctx.font = `500 21px ${FONT}`
        const half = Math.ceil(c.order.length / 2)
        c.order.forEach((o, i) => {
          const col = i < half ? 0 : 1
          const row = i < half ? i : i - half
          ctx.fillStyle = o.was !== null && o.was === o.now ? '#6B7280' : '#0B1220'
          ctx.fillText(clip(`${o.now}. ${o.name}${o.was !== null && o.was !== o.now ? `  (era ${o.was}º)` : ''}`, 34), tx + col * (tw / 2), ty + row * 30)
        })
        ty += orderRows * 30
      }
      ty += 6
      ctx.fillStyle = c.status === 'erro' || c.status === 'pulada' ? '#B42318' : '#0F7B55'
      ctx.font = `600 21px ${FONT}`
      resultLines.forEach((l) => { ctx.fillText(l, tx, ty); ty += 27 })
    })
    y += h + 16
  }
  if (m.overflow.length) {
    ctx.font = `500 21px ${FONT}`
    run(() => { ctx.fillStyle = '#6B7280'; ctx.fillText(`+ ${m.overflow.length} ação(ões) a mais (detalhes no sistema):`, 56, y + 20) })
    y += 40
    for (const t of m.overflow.slice(0, 10)) { run(() => { ctx.fillStyle = '#6B7280'; ctx.fillText(clip(t, 90), 76, y) }); y += 28 }
  }
  y += 40
  run(() => { ctx.fillStyle = '#9AA4B5'; ctx.font = `500 20px ${FONT}`; ctx.fillText('Relatório gerado pela Orvia · valores e status conferidos no iFood no momento da execução', 56, y) })
  return y + 36
}

/** UMA imagem com tudo. A altura cresce com o número de ações. */
export function renderReportPng(model: ReportModel, images: Map<string, Img> = new Map()): string {
  const probe = document.createElement('canvas').getContext('2d')!
  const height = Math.min(30000, paint(probe, model, images, true))
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = height
  paint(canvas.getContext('2d')!, model, images, false)
  return canvas.toDataURL('image/png')
}
