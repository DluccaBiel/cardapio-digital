/**
 * Execução do que foi APROVADO. Garantias (testadas em tests/runner.test.ts):
 *  - só roda o conjunto congelado e recusa se o hash divergir;
 *  - cada ação tem um estado visível: pendente → executando → ok | erro | pulada | assistida;
 *  - ESC (AbortSignal) interrompe entre ações e marca o resto como "pulada";
 *  - nunca finge sucesso: sem molde aprendido, a ação é "pulada" com o motivo e o que fazer.
 */
import { isSyntheticItemId } from '../core/snapshots'
import { planHash, type NewItemAddOns, type ProposalAction, type Schedule } from '../core/proposal'
import type { MenuItem, MenuSnapshot } from '../core/schema'
import { applyRaw, coverage, encode, type Desired, type PortalRequest } from './executor'
import { FIELD_LABEL, type Field, type Template } from './learn'

export type StepStatus = 'pendente' | 'executando' | 'ok' | 'erro' | 'pulada' | 'assistida'

export interface Step {
  action: ProposalAction
  /** produto criado no iFood por esta ação (para o relatório mostrar o resultado) */
  productId?: string | null
  status: StepStatus
  message: string
  at: string | null
}

export interface RunReport {
  startedAt: string
  finishedAt: string
  planHash: string
  aborted: boolean
  steps: Step[]
  counts: Record<StepStatus, number>
}

export interface RunDeps {
  templates: Template[]
  request: PortalRequest
  snapshot: MenuSnapshot
  /** cria o combo no Orvia (pausado). O iFood continua assistido. */
  /** edita nome/descrição direto pelo editor do produto (sem precisar ensinar). Se ausente, cai nos moldes aprendidos. */
  editItem?: (productId: string, changes: { name?: string; description?: string; schedule?: Schedule | null }) => Promise<{ ok: boolean; message: string }>
  /** reordena as categorias (PATCH sequence/order gravado). Se ausente: ação pulada. */
  reorderCategories?: (order: { id: string; name: string }[]) => Promise<{ ok: boolean; message: string }>
  /** exclui o item do cardápio (DELETE gravado). Se ausente: ação assistida. */
  removeItem?: (itemId: string, name: string) => Promise<{ ok: boolean; message: string }>
  createCombo: (a: ProposalAction) => Promise<{ ok: boolean; message: string }>
  /** grava preço/status direto (receita própria da plataforma, sem molde aprendido). Se ausente: usa os moldes. */
  setField?: (item: MenuItem, field: 'price' | 'status', value: number | 'active' | 'paused') => Promise<{ ok: boolean; message: string }>
  /** cria produto novo no iFood duplicando um produto da MESMA categoria (receita gravada). Se ausente: ação assistida. */
  createItem?: (o: { baseProductId: string; categoryId: string | null; name: string; description: string; price: number | null; addOns?: NewItemAddOns }) => Promise<{ ok: boolean; message: string; productId?: string }>
  signal: AbortSignal
  onUpdate?: (steps: Step[]) => void
  paceMs?: number
  sleep?: (ms: number) => Promise<void>
}

const normName = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim()

/** Escolhe o produto-base (sempre um produto que JÁ está na categoria de destino) e os dados do novo. */
export function resolveCreate(a: ProposalAction, snapshot: MenuSnapshot): { ok: true; base: { productId: string; categoryId: string | null; categoryName: string | null; name: string }; name: string; description: string; price: number | null; addOns?: NewItemAddOns } | { ok: false; reason: string } {
  const withProduct = (i: MenuSnapshot['items'][number] | undefined) => (i && i.productId && !isSyntheticItemId(i.id) ? i : undefined)
  if (a.kind === 'create_item') {
    const n = a.newItem
    const base = withProduct(snapshot.items.find((i) => i.id === n?.baseItemId))
    if (!n || !base) return { ok: false, reason: 'o produto base não tem código do iFood — Sincronize pelo portal e tente de novo' }
    return { ok: true, base: { productId: base.productId!, categoryId: base.categoryId, categoryName: base.categoryName, name: base.name }, name: a.itemName, description: n.description, price: n.price, addOns: n.addOns }
  }
  // combo: cria na categoria de combos da loja, se houver; senão na categoria do primeiro componente
  const c = a.combo
  if (!c) return { ok: false, reason: 'combo sem dados' }
  const comboCat = snapshot.items.find((i) => /combo/i.test(i.categoryName ?? '') && withProduct(i))
  const first = withProduct(snapshot.items.find((i) => i.id === c.components[0]?.itemId))
  const base = comboCat ?? first
  if (!base) return { ok: false, reason: 'não achei um produto-base com código do iFood para o combo' }
  return { ok: true, base: { productId: base.productId!, categoryId: base.categoryId, categoryName: base.categoryName, name: base.name }, name: c.name, description: c.description, price: c.price }
}

const isSchedule = (a: ProposalAction) => a.kind === 'update_schedule'

const FIELD_OF: Partial<Record<ProposalAction['kind'], Field>> = {
  update_price: 'price',
  update_name: 'name',
  update_description: 'description',
  set_status: 'status',
}

/** O que falta ensinar para executar estas ações (antes de começar, para avisar o usuário). */
export function missingFields(actions: ProposalAction[], templates: Template[], auto: Field[] = []): Field[] {
  const need = new Set<Field>()
  for (const a of actions) {
    const f = FIELD_OF[a.kind]
    if (f === 'name' || f === 'description') continue // editor próprio: nada a ensinar
    if (f && a.executable) need.add(f)
  }
  const have = new Set([...templates.map((t) => t.field), ...auto])
  return [...need].filter((f) => !have.has(f))
}

export function tally(steps: Step[]): Record<StepStatus, number> {
  const c: Record<StepStatus, number> = { pendente: 0, executando: 0, ok: 0, erro: 0, pulada: 0, assistida: 0 }
  for (const s of steps) c[s.status] += 1
  return c
}

const defaultSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))

export async function runApproved(frozen: { actions: ProposalAction[]; hash: string }, deps: RunDeps): Promise<RunReport> {
  if (planHash(frozen.actions) !== frozen.hash) throw new Error('O plano mudou depois da aprovação. Nada foi executado.')
  const sleep = deps.sleep ?? defaultSleep
  const startedAt = new Date().toISOString()
  const steps: Step[] = frozen.actions.map((action) => ({ action, status: 'pendente', message: 'Aguardando', at: null }))
  const emit = () => deps.onUpdate?.(steps.map((s) => ({ ...s })))
  const set = (s: Step, status: StepStatus, message: string) => {
    s.status = status
    s.message = message
    s.at = new Date().toISOString()
    emit()
  }
  emit()

  let consecutiveErrors = 0
  let aborted = false
  // edições diretas no iFood primeiro; combos (assistidos, dependem do Orvia) por último — e o erro de um combo nunca trava as edições
  const order = steps.map((_, i) => i).sort((x, y) => Number(steps[x]!.action.kind === 'create_combo') - Number(steps[y]!.action.kind === 'create_combo') || x - y)
  for (let n = 0; n < order.length; n += 1) {
    const i = order[n]!
    const step = steps[i]!
    if (deps.signal.aborted) aborted = true
    if (aborted) {
      set(step, 'pulada', 'Interrompido (ESC). Nada foi feito nesta ação.')
      continue
    }
    if (consecutiveErrors >= 3 && step.action.kind !== 'create_combo') {
      set(step, 'pulada', 'Pausado após 3 erros seguidos para não piorar. Revise o primeiro erro.')
      continue
    }
    set(step, 'executando', 'Executando…')
    const a = step.action
    try {
      if (a.kind === 'create_combo' || a.kind === 'create_item') {
        const plan = deps.createItem ? resolveCreate(a, deps.snapshot) : null
        let done = false
        let msg = ''
        if (plan && !plan.ok) msg = `Não criei no iFood: ${plan.reason}.`
        else if (plan && plan.ok) {
          const dup = deps.snapshot.items.find((i) => i.categoryId === plan.base.categoryId && normName(i.name) === normName(plan.name))
          if (dup) {
            done = true
            step.productId = dup.productId ?? null
            msg = `Já existe “${plan.name}” em “${plan.base.categoryName ?? 'a categoria'}” — não dupliquei.`
          } else {
            const r = await deps.createItem!({ baseProductId: plan.base.productId, categoryId: plan.base.categoryId, name: plan.name, description: plan.description, price: plan.price, addOns: plan.addOns })
            done = r.ok
            msg = r.message
            step.productId = r.productId ?? null
          }
        }
        if (a.kind === 'create_combo') {
          const r = await deps.createCombo(a) // registro no Orvia (não trava o iFood)
          if (!plan && !r.ok) set(step, 'erro', r.message)
          else if (plan) set(step, done ? 'ok' : 'erro', `${msg}${r.ok ? '' : ' (registro no Orvia falhou: ' + r.message + ')'}`)
          else set(step, 'assistida', r.message)
        } else if (plan) set(step, done ? 'ok' : 'erro', msg)
        else set(step, 'assistida', `Registrado. Falta criar no iFood: duplique “${a.newItem?.baseItemName ?? 'um produto da categoria'}” e ajuste nome${a.newItem?.description ? ', descrição' : ''}${a.newItem?.price != null ? ', preço' : ''} e foto.`)
        if (done || !plan) consecutiveErrors = 0
        else if (a.kind === 'create_item') consecutiveErrors += 1
      } else if (a.kind === 'reorder_categories') {
        if (!deps.reorderCategories || !a.order) set(step, 'pulada', 'Sem como reordenar categorias aqui.')
        else {
          const r = await deps.reorderCategories(a.order)
          set(step, r.ok ? 'ok' : 'erro', r.message)
          consecutiveErrors = r.ok ? 0 : consecutiveErrors + 1
        }
      } else if (a.kind === 'remove_item') {
        const it = deps.snapshot.items.find((x) => x.id === a.itemId)
        if (!deps.removeItem) set(step, 'assistida', 'Registrado. Remova no portal ou use Pausar.')
        else if (!it || isSyntheticItemId(it.id)) set(step, 'pulada', 'Produto sem ID do iFood. Sincronize pelo portal para excluir.')
        else {
          const r = await deps.removeItem(it.id, it.name)
          set(step, r.ok ? 'ok' : 'erro', r.message)
          consecutiveErrors = r.ok ? 0 : consecutiveErrors + 1
        }
      } else {
        if (isSchedule(a)) {
          const it = deps.snapshot.items.find((x) => x.id === a.itemId)
          if (!deps.editItem) set(step, 'pulada', 'Sem editor de produto disponível.')
          else if (!it?.productId) set(step, 'pulada', 'Este produto não trouxe o código de produto do iFood. Sincronize de novo pelo portal.')
          else {
            const res = await deps.editItem(it.productId, { schedule: a.schedule ?? null })
            set(step, res.ok ? 'ok' : 'erro', res.message)
            consecutiveErrors = res.ok ? 0 : consecutiveErrors + 1
          }
          if (deps.signal.aborted) aborted = true
          if (!aborted && n < order.length - 1) await sleep(deps.paceMs ?? 900)
          continue
        }
        const field = FIELD_OF[a.kind]
        const norm = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim()
        // identifica o produto pelo id; se o id não bater, pelo NOME (único no cardápio)
        const byName = deps.snapshot.items.filter((x) => norm(x.name) === norm(a.itemName ?? ''))
        const item = deps.snapshot.items.find((x) => x.id === a.itemId) ?? (byName.length === 1 ? byName[0] : undefined)
        if (!field || !a.executable) set(step, 'pulada', 'Sem execução automática para este tipo de ação.')
        else if (!item || isSyntheticItemId(item.id)) set(step, 'pulada', 'Produto sem ID do iFood (leitura pela tela). Sincronize pelo portal para aplicar.')
        else if ((field === 'name' || field === 'description') && deps.editItem) {
          if (!item.productId) set(step, 'pulada', 'Este produto não trouxe o código de produto do iFood. Sincronize de novo pelo portal.')
          else {
            const res = await deps.editItem(item.productId, field === 'name' ? { name: String(a.after) } : { description: String(a.after) })
            if (res.ok) {
              set(step, 'ok', res.message)
              consecutiveErrors = 0
            } else {
              set(step, 'erro', res.message)
              consecutiveErrors += 1
            }
          }
        } else if ((field === 'price' || field === 'status') && deps.setField) {
          const res = await deps.setField(item, field, field === 'price' ? Number(a.after) : a.after === 'active' ? 'active' : 'paused')
          set(step, res.ok ? 'ok' : 'erro', res.message)
          consecutiveErrors = res.ok ? 0 : consecutiveErrors + 1
        } else {
          const desired: Desired =
            field === 'price' ? { price: Number(a.after) } : field === 'status' ? { status: a.after === 'active' ? 'active' : 'paused' } : field === 'name' ? { name: String(a.after) } : { description: String(a.after) }
          const cov = coverage(desired, deps.templates)
          if (cov.missing.length) {
            set(step, 'pulada', `Falta ensinar “${FIELD_LABEL[field]}”: edite 1 produto no portal (mude ${FIELD_LABEL[field].toLowerCase()} e salve) e rode de novo.`)
          } else {
            const t = cov.usable[0]!
            const useId = t.idKind === 'productId' ? item.productId ?? item.id : item.id
            const res = await applyRaw(useId, { [field]: encode(t, (desired as Record<string, unknown>)[field]) }, deps.templates, deps.request, { beforePrice: item.price, sleep: deps.sleep })
            if (res.ok) {
              set(step, 'ok', 'Aplicado e conferido no iFood.')
              consecutiveErrors = 0
            } else {
              set(step, 'erro', res.message)
              consecutiveErrors += 1
            }
          }
        }
      }
    } catch (e) {
      set(step, 'erro', e instanceof Error ? e.message : 'Falha inesperada.')
      consecutiveErrors += 1
    }
    if (deps.signal.aborted) aborted = true
    if (!aborted && n < order.length - 1) await sleep(deps.paceMs ?? 900)
  }
  return { startedAt, finishedAt: new Date().toISOString(), planHash: frozen.hash, aborted, steps: steps.map((s) => ({ ...s })), counts: tally(steps) }
}
