#!/usr/bin/env node
/**
 * E2E no Chromium REAL com a extensão carregada. Portal e API do Cardápio Web SIMULADOS (dados fictícios; formato
 * conforme o script FlyTo do dono). Uso: xvfb-run -a node scripts/e2e-cw.mjs
 */
import { createRequire } from 'node:module'
import { execSync, spawn } from 'node:child_process'
import { cpSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
const require = createRequire(import.meta.url)
let chromium
try { ;({ chromium } = require('playwright')) } catch { ;({ chromium } = require(join(execSync('npm root -g').toString().trim(), 'playwright'))) }
const ROOT = resolve(new URL('..', import.meta.url).pathname)
let bad = 0
const check = (n, ok, x = '') => { if (!ok) bad += 1; console.log(`${ok ? '  ✓' : '  ✗'} ${n}${ok ? '' : ' → ' + x}`) }

execSync('node scripts/build.mjs', { cwd: ROOT, env: { ...process.env, ORVIA_E2E: '1' }, stdio: 'inherit' })
const EXT = mkdtempSync(join(tmpdir(), 'orvia-cw-ext-'))
for (const f of ['dist', 'assets', 'flyto', 'options.html', 'manifest.json']) cpSync(join(ROOT, f), join(EXT, f), { recursive: true })

const MENU_OLD = [
  { name: 'Lanches', status: 'ACTIVE', items: [
    { id: 11, name: 'X-Burger', description: 'Pão, carne e queijo', price: 32.9, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/a.jpg', add_ons: [{ add_on_name: 'Adicionais', add_on_status: 'ACTIVE' }] },
    { id: 12, name: 'Astro Bacon', price: '41,50', status: 'ACTIVE', image_url: null, add_ons: [] },
  ] },
  { name: 'Bebidas', status: 'ACTIVE', items: [
    { id: 21, name: 'Refri Lata', price: 6, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/c.jpg' },
    { id: 22, name: 'Suco Natural', price: 9.5, status: 'INACTIVE', image_url: null },
  ] },
]
const PAGE = `<!doctype html><title>Cardápio Web</title><h1>Loja Teste</h1><script>localStorage.setItem('access_token','tok-fake');localStorage.setItem('active_company_id','77')</script>`
const CORS = { 'access-control-allow-origin': 'https://portal.cardapioweb.com', 'access-control-allow-headers': 'authorization,companyid,content-type,accept', 'access-control-allow-methods': '*' }
const apiSeen = []

const userDir = mkdtempSync(join(tmpdir(), 'orvia-cw-prof-'))
const port = 9611
const proc = spawn(chromium.executablePath(), [`--user-data-dir=${userDir}`, `--remote-debugging-port=${port}`, `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-sandbox', '--no-first-run', '--no-default-browser-check', '--window-size=1360,900', 'about:blank'], { stdio: 'ignore' })
let browser
for (let i = 0; i < 40 && !browser; i += 1) { try { browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`) } catch { await new Promise((r) => setTimeout(r, 500)) } }
try {
  const ctx = browser.contexts()[0]
  await ctx.route('https://portal.cardapioweb.com/**', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: PAGE }))
  const db = {
  cats: [{ id: 10, name: 'Lanches', position: 0 }, { id: 11, name: 'Bebidas', position: 1 }],
  items: [
    { id: 11, category_id: 10, name: 'X-Burger', description: 'Pão, carne e queijo', price: 32.9, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/a.jpg', add_ons: [{ id: 1, add_on_id: 800 }] },
    { id: 12, category_id: 10, name: 'Astro Bacon', description: '', price: 41.5, status: 'ACTIVE', image_url: null, add_ons: [] },
    { id: 21, category_id: 11, name: 'Refri Lata', description: '350ml', price: 6, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/c.jpg', add_ons: [] },
    { id: 22, category_id: 11, name: 'Suco Natural', description: '', price: 9.5, status: 'INACTIVE', image_url: null, add_ons: [] },
  ],
  next: 100,
  writes: [],
}
const menuJson = () => [...db.cats].sort((x, y) => x.position - y.position).map((c) => ({ ...c, status: 'ACTIVE', items: db.items.filter((i) => i.category_id === c.id) }))
const parseForm = (post, ct) => {
  const out = {}
  const m = /boundary=(.+)$/.exec(ct ?? '')
  if (!m) return out
  for (const part of (post ?? '').split('--' + m[1])) {
    const mm = /name="([^"]+)"\r?\n\r?\n([\s\S]*?)\r?\n$/.exec(part)
    if (mm) out[mm[1]] = mm[2]
  }
  return out
}
await ctx.route('https://api.cardapioweb.com/**', (r) => {
  const req = r.request()
  const h = req.headers()
  const u = new URL(req.url())
  const path = u.pathname.replace('/api/v1/company', '')
  apiSeen.push({ m: req.method(), u: req.url(), auth: h['authorization'], company: h['companyid'] })
  const send = (status, json) => r.fulfill({ status, contentType: 'application/json', headers: CORS, body: JSON.stringify(json) })
  let m
  if (req.method() === 'OPTIONS') return r.fulfill({ status: 204, headers: CORS })
  if (req.method() === 'GET' && path === '/categories/menu') return send(200, menuJson())
  if (req.method() === 'GET' && path === '/categories') return send(200, db.cats)
  if (req.method() === 'GET' && path === '/add_ons') return send(200, [{ id: 800, name: 'Adicionais', subitems: [{}, {}] }, { id: 900, name: 'Borda recheada', subitems: [{}, {}, {}], minimum_quantity: 0, maximum_quantity: 1 }])
  if (req.method() === 'GET' && (m = path.match(/^\/category\/(\d+)\/items$/))) return send(200, db.items.filter((i) => String(i.category_id) === m[1]))
  if (req.method() === 'PUT' && (m = path.match(/^\/category\/(\d+)\/items\/(\d+)$/))) {
    const it = db.items.find((i) => String(i.id) === m[2])
    const ct = h['content-type'] ?? ''
    const body = ct.includes('json') ? JSON.parse(req.postData() ?? '{}') : parseForm(req.postData(), ct)
    for (const [k, v] of Object.entries(body)) it[k] = k === 'price' ? Number(v) : v
    db.writes.push(`PUT ${path} ${ct.includes('json') ? 'json' : 'form'} ${Object.keys(body).join(',')}`)
    return send(200, it)
  }
  if (req.method() === 'POST' && (m = path.match(/^\/item\/(\d+)\/duplicate$/))) {
    const b = db.items.find((i) => String(i.id) === m[1])
    db.items.push({ ...b, id: (db.next += 1), add_ons: b.add_ons.map((x) => ({ ...x, id: (db.next += 1) })) })
    db.writes.push(`POST ${path}`)
    return r.fulfill({ status: 200, headers: CORS, contentType: 'text/plain', body: 'success' })
  }
  if (req.method() === 'POST' && (m = path.match(/^\/item\/(\d+)\/add_on_items$/))) {
    const it = db.items.find((i) => String(i.id) === m[1])
    const body = JSON.parse(req.postData() ?? '{}')
    it.add_ons.push({ id: (db.next += 1), add_on_id: body.add_on_item.add_on_id })
    db.writes.push(`POST ${path}`)
    return send(201, {})
  }
  if (req.method() === 'DELETE' && (m = path.match(/^\/category\/(\d+)\/items\/(\d+)$/))) {
    db.items = db.items.filter((i) => String(i.id) !== m[2])
    db.writes.push(`DELETE ${path}`)
    return send(200, {})
  }
  if (req.method() === 'PUT' && path === '/categories/ordenation') {
    const body = JSON.parse(req.postData() ?? '{}')
    for (const c of body.categories_attributes) db.cats.find((x) => x.id === c.id).position = c.position
    db.writes.push(`PUT ${path}`)
    return send(200, { success: true })
  }
  return send(404, {})
})
  const page = await ctx.newPage()
  await page.goto('https://portal.cardapioweb.com/menu')
  const orvia = page.locator('button.fab[aria-label="Abrir Orvia"]')
  await orvia.waitFor({ state: 'attached' })
  check('botão flutuante Orvia aparece no Cardápio Web', await orvia.isVisible())
  check('FlyTo (Fotos em massa) carregou junto, sem conflito', await page.locator('button#fab').isVisible())
  await orvia.click()
  await page.locator('aside.panel').waitFor()
  await page.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  await page.waitForFunction(() => /X-Burger/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
  const txt = await page.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('sincronizou os 4 produtos pela API', /X-Burger/.test(txt) && /Astro Bacon/.test(txt) && /Refri Lata/.test(txt) && /Suco Natural/.test(txt), txt.slice(0, 300))
  check('mostra "Cardápio Web" (não iFood) na tela', /Cardápio Web/.test(txt) && !/iFood/.test(txt), txt.slice(0, 200))
  const hit = apiSeen.find((x) => x.u.includes('/categories/menu'))
  check('chamou a API com Authorization + Companyid da aba', hit?.auth === 'tok-fake' && hit?.company === '77', JSON.stringify(hit))
  check('só leu: nenhuma escrita sem aprovação', apiSeen.every((x) => x.m === 'GET' || x.m === 'OPTIONS'), JSON.stringify(apiSeen.filter((x) => x.m !== 'GET')))
  // ---- Diagnóstico + aprendizado ----
  await page.evaluate(() => fetch('https://api.cardapioweb.com/api/v1/company/item/11', { method: 'PUT', headers: { Authorization: 'tok-fake', Companyid: '77', 'content-type': 'application/json' }, body: JSON.stringify({ price: 35.9 }) }))
  await page.waitForTimeout(500)
  const root = page.locator('#orvia-cw-root')
  await root.getByRole('button', { name: /Diagnóstico/ }).first().click()
  await page.waitForFunction(() => /PUT .*item.11/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 10000 }).catch(() => undefined)
  const dtxt = await page.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('Diagnóstico mostra "Leitura OK: 4 produto(s)"', /Leitura OK: 4 produto\(s\) em 2 categoria/.test(dtxt), dtxt.slice(0, 300))
  check('Diagnóstico lista a escrita feita no portal (PUT item/11)', /PUT \/api\/v1\/company\/item\/11/.test(dtxt), dtxt.slice(0, 600))
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://portal.cardapioweb.com' }).catch(() => undefined)
  await page.bringToFront()
  await root.getByRole('button', { name: /Copiar relatório/ }).first().click()
  await page.waitForTimeout(1500)
  const rep = await page.evaluate(() => navigator.clipboard.readText()).catch((e) => String(e))
  check('relatório copiado tem a escrita com corpo e sem token', /"price": 35.9/.test(rep) && !/tok-fake/.test(rep), rep.slice(0, 300))
  check('relatório tem a forma da leitura do cardápio', /leituraDoCardapio/.test(rep) && /chamadasDoPortal/.test(rep))

  // ---- plano B: login não está no localStorage, mas o portal usa nos pedidos ----
  const p2 = await ctx.newPage()
  await ctx.route('https://portal.cardapioweb.com/alt', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: '<!doctype html><title>x</title><h1>Loja</h1><script>fetch("https://api.cardapioweb.com/api/v1/company/me",{headers:{Authorization:"tok-alt",Companyid:"88"}})</script>' }))
  await p2.goto('https://portal.cardapioweb.com/alt')
  await p2.locator('button.fab[aria-label="Abrir Orvia"]').waitFor({ state: 'attached' })
  await p2.waitForTimeout(800)
  await p2.locator('button.fab[aria-label="Abrir Orvia"]').click()
  await p2.locator('aside.panel').waitFor()
  await p2.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  await p2.waitForFunction(() => /X-Burger/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
  const t2 = await p2.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('sem login no localStorage: usa o login que o portal usou e sincroniza', /X-Burger/.test(t2) && apiSeen.some((x) => x.auth === 'tok-alt' && x.company === '88' && x.u.includes('/categories/menu')), t2.slice(0, 200))
  check('status Ativo/Desativado nos produtos', /Ativo/.test(txt) && /(Desativado|Pausado|Inativo)/.test(txt), txt.slice(0, 400))
  // ---- execução completa: análise local → minha ação (duplicar com complementos) → Fazer ----
  const p3 = await ctx.newPage()
  await p3.goto('https://portal.cardapioweb.com/menu')
  const fab3 = p3.locator('button.fab[aria-label="Abrir Orvia"]')
  await fab3.waitFor({ state: 'attached' })
  await fab3.click()
  await p3.locator('aside.panel').waitFor()
  await p3.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  await p3.getByRole('button', { name: /Analisar este cardápio/ }).waitFor({ timeout: 20000 })
  await p3.getByRole('button', { name: /Analisar este cardápio/ }).click()
  await p3.getByLabel('Cidade ou bairro').fill('Asa Norte, Brasília')
  await p3.getByRole('button', { name: /^Analisar cardápio$/ }).click()
  await p3.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
  await p3.getByRole('button', { name: /Adicionar minha otimização/ }).first().click()
  await p3.getByLabel('O que fazer').first().selectOption({ label: 'Novo produto (duplicando um)' })
  await p3.locator('input[aria-label="Nome do produto novo"]').first().fill('Burger Bacon Duplo')
  await p3.locator('input[aria-label="Preço (opcional)"]').first().fill('45,90')
  await p3.locator('input[aria-label="Buscar grupo de complementos"]').first().waitFor({ timeout: 8000 })
  check('seletor de complementos lista os grupos já criados', (await p3.locator('input[aria-label="Grupo Borda recheada"]').count()) === 1)
  await p3.locator('input[aria-label="Grupo Borda recheada"]').first().check()
  await p3.getByRole('button', { name: /Adicionar à proposta/ }).first().click()
  const row = p3.locator('.act', { hasText: 'Burger Bacon Duplo' })
  await row.first().waitFor({ timeout: 5000 })
  check('ação de produto novo mostra os complementos escolhidos', /Borda recheada/.test(await row.first().innerText()))
  // aprova só ela + um preço
  await p3.getByRole('button', { name: /limpar seleção/ }).click().catch(() => undefined)
  await row.first().locator('input[type=checkbox]').check()
  await p3.getByRole('button', { name: /✓ Fazer/ }).click()
  await p3.getByText(/Cardápio otimizado/).first().waitFor({ timeout: 60000 })
  const fin = await p3.locator('aside.panel').innerText()
  const novo = db.items.find((i) => i.name === 'Burger Bacon Duplo')
  check('produto novo criado por duplicação na MESMA categoria, ATIVO, com preço', novo && novo.category_id === 10 && novo.status === 'ACTIVE' && novo.price === 45.9, JSON.stringify(novo))
  check('complementos: os do base + o grupo escolhido', novo && novo.add_ons.map((x) => x.add_on_id).sort().join() === '800,900', JSON.stringify(novo?.add_ons))
  check('relatório marca o passo como OK', /Burger Bacon Duplo\s+OK/.test(fin), fin.slice(0, 500))
} finally {
  await browser.close().catch(() => undefined)
  proc.kill('SIGKILL')
}
console.log(bad ? `\n${bad} falha(s)` : '\nTudo certo')
process.exit(bad ? 1 : 0)
