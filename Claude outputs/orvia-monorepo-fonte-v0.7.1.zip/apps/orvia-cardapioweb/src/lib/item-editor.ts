import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { Schedule } from '@orvia/shared/core/proposal'
import { patchItem } from './cw-ops'
export type { PortalCtx }
export const NOT_YET = 'O Cardápio Web ainda não tem receita gravada para isto. Faça a alteração no portal com a aba Diagnóstico aberta e me mande o relatório.'
export async function editItem(o: { productId: string; catId: string; label: string; request: PortalRequest; changes: { name?: string; description?: string; schedule?: Schedule | null } }): Promise<{ ok: boolean; message: string }> {
  if (o.changes.schedule !== undefined) return { ok: false, message: `Horário de venda: ${NOT_YET}` }
  return patchItem(o.request, o.catId, o.productId, { ...(o.changes.name !== undefined ? { name: o.changes.name } : {}), ...(o.changes.description !== undefined ? { description: o.changes.description } : {}) }, o.label)
}
