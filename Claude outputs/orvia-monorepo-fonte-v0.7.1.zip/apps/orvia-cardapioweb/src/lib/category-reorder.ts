import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { CatRef } from '@orvia/shared/lib/category-order'
import { reorderCats } from './cw-ops'
export const reorderCategories = (o: { order: CatRef[]; request: PortalRequest }) => reorderCats(o.request, o.order)
