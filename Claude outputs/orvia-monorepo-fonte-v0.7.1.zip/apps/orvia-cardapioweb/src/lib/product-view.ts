/** "Como o produto está agora" no Cardápio Web — relido do portal depois da execução, para o relatório. */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { ProductView } from '@orvia/shared/lib/prints'
import { CW_API, MENU_PATH } from './cw-api'
import { cardapioWebSnapshot } from './cw-normalize'
export type { ProductView }

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const DAY_PT: Record<string, string> = { sunday: 'dom', monday: 'seg', tuesday: 'ter', wednesday: 'qua', thursday: 'qui', friday: 'sex', saturday: 'sáb' }

/** item do endpoint /category/{cat}/items → visão do relatório (promoção: preço promocional ativo). */
export function viewFromItem(it: Rec, categoryName: string | null): ProductView | null {
  if (typeof it.name !== 'string') return null
  const regular = typeof it.price === 'number' ? it.price : Number(it.price)
  const promo = typeof it.promotional_price === 'number' ? it.promotional_price : null
  const promoOn = it.promotional_price_active === true && promo !== null && promo > 0 && Number.isFinite(regular)
  const days = Array.isArray(it.promotional_price_availability) ? it.promotional_price_availability.map((d) => DAY_PT[String(d)] ?? String(d)).join(', ') : ''
  const times = Array.isArray(it.allowed_times) ? it.allowed_times.length : 0
  return {
    name: it.name,
    description: typeof it.description === 'string' ? it.description : '',
    imageUrl: typeof it.image_url === 'string' && it.image_url ? it.image_url : null,
    categoryName,
    price: promoOn ? promo : Number.isFinite(regular) ? regular : null,
    originalPrice: promoOn ? regular : null,
    active: it.status === 'ACTIVE' ? true : it.status ? false : null,
    schedule: times ? `${times} faixa(s) de horário definida(s)` : 'sempre disponível',
    promotion: promoOn ? `promoção ${brl(promo!)} (de ${brl(regular)})${days ? ` · dias: ${days}` : ''}` : null,
  }
}

const cache = new Map<string, { at: number; v: unknown }>()
async function cached<T>(key: string, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key)
  if (hit && Date.now() - hit.at < 8000) return hit.v as T
  const v = await load()
  cache.set(key, { at: Date.now(), v })
  return v
}

export async function fetchProductView(productId: string, _ctx: PortalCtx, request: PortalRequest): Promise<ProductView | null> {
  try {
    const menu = await cached('menu', () => request('GET', CW_API + MENU_PATH))
    const snap = menu.status >= 200 && menu.status < 300 ? cardapioWebSnapshot(menu.json, null, '') : null
    const base = snap?.items.find((i) => i.id === productId)
    if (!base) return null
    const cat = base.categoryId
    const list = cat ? await cached(`cat:${cat}`, () => request('GET', `${CW_API}/api/v1/company/category/${cat}/items`)) : null
    const fresh = list && Array.isArray(list.json) ? list.json.filter(isRec).find((x) => String(x.id) === productId) : null
    if (fresh) return viewFromItem(fresh, base.categoryName)
    return { name: base.name, description: base.description, imageUrl: base.imageUrl, categoryName: base.categoryName, price: base.price, originalPrice: null, active: base.status === 'active', schedule: 'sempre disponível', promotion: null }
  } catch { return null }
}
