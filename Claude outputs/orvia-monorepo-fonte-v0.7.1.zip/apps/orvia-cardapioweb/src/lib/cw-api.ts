/**
 * Acesso à API do Cardápio Web usando o próprio login do portal (token e loja do localStorage da aba).
 * Nada é guardado nem enviado a terceiros: o token só vai para api.cardapioweb.com.
 * Observado no script FlyTo do dono: Authorization = access_token; Companyid = active_company_id.
 */
export const CW_API = 'https://api.cardapioweb.com'
export const MENU_PATH = '/api/v1/company/categories/menu?full_version=true'

/** Cabeçalhos que o próprio portal usou (visto pelo hook) — plano B quando o localStorage não tem o que esperamos. */
let observed: { Authorization?: string; Companyid?: string } = {}
export const setObservedAuth = (a: { Authorization?: string; Companyid?: string }) => { observed = a }
export function cwStorageNames(): string[] {
  const out: string[] = []
  for (const st of [localStorage, sessionStorage]) { try { for (let i = 0; i < st.length; i += 1) { const k = st.key(i) ?? ''; if (/token|company|empresa|auth|loja|store|user/i.test(k)) out.push(k) } } catch { /* */ } }
  return out
}
export function cwAuth(): { Authorization: string; Companyid: string; Accept: string } | null {
  if (observed.Authorization && observed.Companyid) return { Authorization: observed.Authorization, Companyid: observed.Companyid, Accept: 'application/json' }
  try {
    const token = localStorage.getItem('access_token')
    const company = localStorage.getItem('active_company_id')
    return token && company ? { Authorization: token, Companyid: company, Accept: 'application/json' } : null
  } catch {
    return null
  }
}
export const cwCompanyId = (): string | null => { try { return localStorage.getItem('active_company_id') ?? observed.Companyid ?? null } catch { return observed.Companyid ?? null } }

/** Registro das chamadas FEITAS PELA EXTENSÃO (o observador da página só vê as do portal). Sem token, sem valores. */
export type OwnCall = { at: string; method: string; path: string; body: string; status: number; erro?: string }
export const ownLog: OwnCall[] = []

export async function cwRequest(method: string, url: string, body?: unknown): Promise<{ status: number; json: unknown }> {
  const auth = cwAuth()
  if (!auth) return { status: 0, json: { error: 'sem login do Cardápio Web nesta aba (atualize a página)' } }
  const full = url.startsWith('http') ? url : CW_API + url
  if (!full.startsWith(CW_API + '/')) return { status: 0, json: { error: 'destino não permitido' } }
  const isForm = typeof FormData !== 'undefined' && body instanceof FormData
  let status = 0
  let json: unknown = null
  try {
    const res = await fetch(full, {
      method,
      headers: body === undefined || isForm ? auth : { ...auth, 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : isForm ? (body as FormData) : JSON.stringify(body),
      cache: 'no-store',
    })
    status = res.status
    const text = await res.text()
    try { json = text ? JSON.parse(text) : null } catch { json = text ? { texto: text.slice(0, 200) } : null }
  } catch {
    json = { error: 'falha de rede' }
  }
  if (method !== 'GET' || status < 200 || status >= 300) {
    const path = full.slice(CW_API.length).split('?')[0]!
    const keys = isForm ? `form:${[...(body as FormData).keys()].join(',')}` : body && typeof body === 'object' ? `json:${Object.keys(body as object).join(',')}` : '-'
    ownLog.unshift({ at: new Date().toISOString(), method, path, body: keys, status, ...(status < 200 || status >= 300 ? { erro: JSON.stringify(json).slice(0, 300) } : {}) })
    if (ownLog.length > 80) ownLog.length = 80
  }
  return { status, json }
}
