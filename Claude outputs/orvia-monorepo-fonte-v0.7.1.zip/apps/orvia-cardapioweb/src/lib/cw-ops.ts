/**
 * Receitas do Cardápio Web OBSERVADAS no portal real (diagnóstico do dono, 09/11/2026):
 *   editar item   PUT    /api/v1/company/category/{cat}/items/{id}      (JSON parcial {status} confirmado; os demais campos
 *                                                                       seguem o mesmo contrato e SÃO CONFERIDOS depois de gravar)
 *   duplicar      POST   /api/v1/company/item/{id}/duplicate            {category_ids:{ids:[cat]}}
 *   excluir       DELETE /api/v1/company/category/{cat}/items/{id}
 *   reordenar     PUT    /api/v1/company/categories/ordenation          {categories_attributes:[{id,position}]}  (todas)
 *   listar        GET    /api/v1/company/category/{cat}/items   e   /api/v1/company/categories
 * Toda escrita é seguida de uma releitura: se o portal não mostra o valor pedido, o passo vira ERRO (nunca "ok" no escuro).
 * Puro: sem chrome.*, sem DOM.
 */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import { CW_API } from './cw-api'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300
const C = `${CW_API}/api/v1/company`
const itemsUrl = (cat: string) => `${C}/category/${encodeURIComponent(cat)}/items`
export type Res = { ok: boolean; message: string }

export async function listItems(request: PortalRequest, cat: string): Promise<Rec[] | null> {
  const r = await request('GET', itemsUrl(cat))
  return ok2xx(r.status) && Array.isArray(r.json) ? r.json.filter(isRec) : null
}
const findItem = (list: Rec[] | null, id: string) => list?.find((x) => String(x.id) === String(id)) ?? null
const same = (a: unknown, b: unknown) => String(a ?? '').trim() === String(b ?? '').trim()

export interface Change { name?: string; description?: string; price?: number; status?: 'ACTIVE' | 'INACTIVE' }

const why = (r: { status: number; json: unknown }) => `HTTP ${r.status}${isRec(r.json) && typeof r.json.message === 'string' ? ` — ${r.json.message.slice(0, 120)}` : isRec(r.json) && typeof r.json.error === 'string' ? ` — ${r.json.error.slice(0, 120)}` : ''}`

/** Campos pedidos → formulário (o mesmo formato que o próprio portal usa: só os campos alterados, valores em texto). */
function toForm(c: Change): FormData {
  const f = new FormData()
  if (c.name !== undefined) f.append('name', c.name)
  if (c.description !== undefined) f.append('description', c.description)
  if (c.price !== undefined) f.append('price', c.price.toFixed(2))
  if (c.status !== undefined) f.append('status', c.status)
  return f
}
function mismatch(after: Rec, c: Change): string[] {
  const bad: string[] = []
  if (c.name !== undefined && !same(after.name, c.name)) bad.push('nome')
  if (c.description !== undefined && !same(after.description, c.description)) bad.push('descrição')
  if (c.price !== undefined && Math.abs(Number(after.price) - c.price) > 0.001) bad.push('preço')
  if (c.status !== undefined && after.status !== c.status) bad.push('status')
  return bad
}

/** Grava e confere. Tenta JSON; se o portal recusar ou não mostrar o valor, tenta o formulário do portal. Sempre relê. */
export async function patchItem(request: PortalRequest, cat: string, id: string, change: Change, label: string): Promise<Res> {
  if (!cat) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  if (!findItem(await listItems(request, cat), id)) return { ok: false, message: `Não achei “${label}” na categoria — sincronize de novo.` }
  const url = `${itemsUrl(cat)}/${encodeURIComponent(id)}`
  const notes: string[] = []
  for (const mode of ['json', 'form'] as const) {
    const res = await request('PUT', url, mode === 'json' ? change : toForm(change))
    if (!ok2xx(res.status)) { notes.push(`${mode}: ${why(res)}`); continue }
    const after = findItem(await listItems(request, cat), id)
    if (!after) return { ok: false, message: `Enviei a alteração de “${label}”, mas não consegui reler para conferir.` }
    const bad = mismatch(after, change)
    if (!bad.length) return { ok: true, message: 'Aplicado e conferido no Cardápio Web.' }
    notes.push(`${mode}: o portal respondeu OK mas ainda mostra o ${bad.join(' e ')} anterior`)
  }
  return { ok: false, message: `Não consegui alterar “${label}” (${notes.join(' | ')}).` }
}

/** Grupos de complementos já criados (GET /company/add_ons). */
export interface AddOnRow { id: string; name: string; options: number; min: number | null; max: number | null }
export async function listAddOns(request: PortalRequest): Promise<AddOnRow[] | null> {
  const r = await request('GET', `${C}/add_ons`)
  if (!ok2xx(r.status) || !Array.isArray(r.json)) return null
  return r.json.filter(isRec).map((g) => ({ id: String(g.id), name: String(g.name ?? ''), options: Array.isArray(g.subitems) ? g.subitems.length : 0, min: typeof g.minimum_quantity === 'number' ? g.minimum_quantity : null, max: typeof g.maximum_quantity === 'number' ? g.maximum_quantity : null }))
}

/** Ajusta os complementos do item: tira os do produto duplicado (se pedido) e vincula os grupos escolhidos. Confere no fim. */
async function setAddOns(request: PortalRequest, cat: string, itemId: string, want: { ids: string[]; keepBase: boolean }): Promise<Res> {
  let it = findItem(await listItems(request, cat), itemId)
  if (!it) return { ok: false, message: 'não achei o item para ajustar os complementos' }
  const current = (Array.isArray(it.add_ons) ? it.add_ons.filter(isRec) : []).map((x) => ({ link: String(x.id), group: String(x.add_on_id) }))
  const failures: string[] = []
  const keep = new Set<string>()
  for (const c of current) {
    if (want.keepBase || want.ids.includes(c.group)) { keep.add(c.group); continue }
    const d = await request('DELETE', `${C}/item/${encodeURIComponent(itemId)}/add_on_items/${encodeURIComponent(c.link)}`)
    if (!ok2xx(d.status)) failures.push(`remover grupo ${c.group} (${why(d)})`)
  }
  for (const g of want.ids) {
    if (keep.has(g)) continue
    const a = await request('POST', `${C}/item/${encodeURIComponent(itemId)}/add_on_items`, { add_on_item: { item_id: Number(itemId), add_on_id: Number(g) } })
    if (!ok2xx(a.status)) failures.push(`vincular grupo ${g} (${why(a)})`)
  }
  it = findItem(await listItems(request, cat), itemId)
  const now = new Set((Array.isArray(it?.add_ons) ? it!.add_ons as unknown[] : []).filter(isRec).map((x) => String(x.add_on_id)))
  const missing = want.ids.filter((g) => !now.has(g))
  const extra = want.keepBase ? [] : [...now].filter((g) => !want.ids.includes(g))
  if (failures.length || missing.length || extra.length) return { ok: false, message: `complementos: ${[...failures, ...missing.map((g) => `grupo ${g} não apareceu`), ...extra.map((g) => `grupo ${g} não saiu`)].join('; ')}` }
  return { ok: true, message: `${now.size} grupo(s) de complementos` }
}

/** Cria por DUPLICAÇÃO na mesma categoria do produto-base, depois ajusta nome/descrição/preço e deixa ATIVO. */
export async function duplicateItem(request: PortalRequest, o: { cat: string; baseId: string; name: string; description?: string; price?: number | null; addOns?: { ids: string[]; keepBase: boolean } }): Promise<Res & { productId?: string }> {
  const name = o.name.trim()
  if (name.length < 2) return { ok: false, message: 'Nome do novo produto vazio — nada criado.' }
  const beforeList = await listItems(request, o.cat)
  const base = findItem(beforeList, o.baseId)
  if (!beforeList || !base) return { ok: false, message: 'Não achei o produto-base na categoria — nada criado.' }
  const ids = new Set(beforeList.map((x) => String(x.id)))
  const dup = await request('POST', `${C}/item/${encodeURIComponent(o.baseId)}/duplicate`, { category_ids: { ids: [Number(o.cat)] } })
  if (!ok2xx(dup.status)) return { ok: false, message: `O Cardápio Web recusou duplicar o produto-base (HTTP ${dup.status}).` }
  const fresh = (await listItems(request, o.cat) ?? []).filter((x) => !ids.has(String(x.id)))
  if (fresh.length !== 1) return { ok: false, message: `Dupliquei, mas não consegui identificar o novo item (${fresh.length} novos). Confira a categoria no portal.` }
  const newId = String(fresh[0]!.id)
  const change: Change = { name, status: 'ACTIVE', ...(o.description !== undefined ? { description: o.description } : {}), ...(o.price != null && Number.isFinite(o.price) ? { price: o.price } : {}) }
  const r = await patchItem(request, o.cat, newId, change, name)
  if (!r.ok) return { ok: false, productId: newId, message: `Dupliquei, mas não consegui ajustar o novo item (${r.message}) Ele ficou na categoria com o nome do original — corrija no portal.` }
  if (o.addOns && (o.addOns.ids.length || !o.addOns.keepBase)) {
    const ao = await setAddOns(request, o.cat, newId, o.addOns)
    if (!ao.ok) return { ok: false, productId: newId, message: `Criei e ativei “${name}”, mas ${ao.message}. Ajuste os complementos no portal.` }
    return { ok: true, productId: newId, message: `Criado e ATIVO: “${name}” (duplicado de “${String(base.name)}”) com ${ao.message}.` }
  }
  const fin = findItem(await listItems(request, o.cat), newId)
  const sameAddOns = Array.isArray(fin?.add_ons) && Array.isArray(base.add_ons) && fin.add_ons.length === base.add_ons.length
  return { ok: true, productId: newId, message: `Criado e ATIVO: “${name}” (duplicado de “${String(base.name)}”${sameAddOns ? ', com os mesmos complementos' : ''}).` }
}

export async function deleteItem(request: PortalRequest, cat: string, id: string, name: string): Promise<Res> {
  if (!cat) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  if (!findItem(await listItems(request, cat), id)) return { ok: true, message: `“${name}” já não está no cardápio.` }
  const del = await request('DELETE', `${itemsUrl(cat)}/${encodeURIComponent(id)}`)
  if (!ok2xx(del.status)) return { ok: false, message: `O Cardápio Web recusou excluir “${name}” (HTTP ${del.status}).` }
  return findItem(await listItems(request, cat), id)
    ? { ok: false, message: `Pedi a exclusão de “${name}”, mas ele ainda aparece. Confira no portal.` }
    : { ok: true, message: `“${name}” excluído e conferido no Cardápio Web.` }
}

const liveCats = async (request: PortalRequest): Promise<{ id: string; position: number }[] | null> => {
  const r = await request('GET', `${C}/categories`)
  if (!ok2xx(r.status) || !Array.isArray(r.json)) return null
  const rows = r.json.filter(isRec).map((c) => ({ id: String(c.id), position: Number(c.position) }))
  return rows.every((c) => c.id && Number.isFinite(c.position)) ? rows.sort((a, b) => a.position - b.position) : null
}

export async function reorderCats(request: PortalRequest, order: { id: string; name: string }[]): Promise<Res> {
  const live = await liveCats(request)
  if (!live?.length) return { ok: false, message: 'Não consegui ler a lista de categorias — ordem não alterada.' }
  const known = new Set(live.map((c) => c.id))
  const wanted = order.map((c) => c.id).filter((id) => known.has(id))
  if (wanted.length !== order.length) return { ok: false, message: 'O cardápio mudou (categoria que não existe mais). Sincronize e analise de novo — ordem não alterada.' }
  const finalIds = [...wanted, ...live.map((c) => c.id).filter((id) => !wanted.includes(id))]
  if (finalIds.every((id, i) => id === live[i]!.id)) return { ok: true, message: 'As categorias já estavam nesta ordem.' }
  const res = await request('PUT', `${C}/categories/ordenation`, { categories_attributes: finalIds.map((id, i) => ({ id: Number(id), position: i })) })
  if (!ok2xx(res.status)) return { ok: false, message: `O Cardápio Web recusou a nova ordem (HTTP ${res.status}).` }
  const after = await liveCats(request)
  if (!after) return { ok: true, message: 'Ordem enviada (HTTP 200), mas não consegui reler para conferir.' }
  return after.length === finalIds.length && after.every((c, i) => c.id === finalIds[i])
    ? { ok: true, message: `Categorias reordenadas e conferidas (${finalIds.length}).` }
    : { ok: false, message: 'Enviei a ordem, mas o portal ainda mostra a anterior. Confira no portal.' }
}
