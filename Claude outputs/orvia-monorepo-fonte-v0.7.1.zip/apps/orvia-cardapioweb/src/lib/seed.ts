/** Cardápio Web: sem moldes pré-ensinados (preço/status ainda não gravados). Tudo é aprendido por exemplo. */
import type { Template } from '@orvia/shared/lib/learn'
import type { Field } from '@orvia/shared/lib/learn'
import type { PortalCtx } from '@orvia/shared/lib/portal'
export function withSeeds(list: Template[], _ctx: PortalCtx): { list: Template[]; added: Field[]; changed: boolean } {
  return { list, added: [], changed: false }
}
