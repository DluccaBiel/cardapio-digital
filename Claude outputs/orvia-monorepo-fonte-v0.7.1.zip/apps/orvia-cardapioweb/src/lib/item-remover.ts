import type { PortalRequest } from '@orvia/shared/lib/executor'
import { deleteItem } from './cw-ops'
export const removeItem = (o: { itemId: string; catId: string; name: string; request: PortalRequest }) => deleteItem(o.request, o.catId, o.itemId, o.name)
