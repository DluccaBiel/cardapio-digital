# Orvia · Otimizador Cardápio Web (extensão Chrome MV3)

Mesmo fluxo e mesma tela da extensão do iFood (motor compartilhado em `packages/shared`):
botão **O** → Sincronizar → produtos → Análise (concorrentes + boas práticas, PDF, aprovar/rejeitar com feedback) →
executar só o aprovado (OK/ERRO por ação, ESC para) → relatório em UMA imagem.
Inclui também o **FlyTo · Fotos em massa** (pasta `flyto/`, o seu script original, sem alteração), com o botão dele em outro canto.

## O que já funciona (verificado em portal SIMULADO)
- Sincronizar: lê `GET api.cardapioweb.com/api/v1/company/categories/menu?full_version=true` com o login da própria aba
  (`access_token` + `active_company_id`); produtos, categorias, preço, foto, Ativo/Desativado/Em falta, complementos.
- Análise, proposta, PDF, aprovar/rejeitar, relatório e envio ao Orvia: iguais ao iFood.
- Aprender por exemplo: o hook observa o que VOCÊ edita no portal (`/api/v1/company/*`) para a extensão aprender a escrita.

## O que ainda depende de gravação no portal real
Preço, nome, descrição, ativar/pausar, criar produto/combo, horários, excluir e reordenar categorias: o formato de escrita
do Cardápio Web não é conhecido (só foto: `PUT /api/v1/company/item/image/{id}`). A extensão NÃO chuta endpoint: avisa
"falta ensinar" e aprende quando você faz a alteração uma vez no portal (aba Diagnóstico).

## Testes
`npm test` (normalizador) · `xvfb-run -a node scripts/e2e-cw.mjs` (Chromium real, portal/API simulados).
