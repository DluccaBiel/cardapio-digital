import { describe, expect, it } from 'vitest'
import { cardapioWebSnapshot, cwStatus, parsePrice } from '../src/lib/cw-normalize'
import { viewFromItem } from '../src/lib/product-view'

const MENU = [
  { name: 'Lanches', status: 'ACTIVE', items: [
    { id: 11, name: 'X-Burger', description: 'Pão e carne', price: 32.9, status: 'ACTIVE', image_url: 'https://x/a.jpg', add_ons: [{ add_on_name: 'Adicionais' }] },
    { id: 12, name: 'Bacon', price: '41,50', status: 'MISSING', image_url: null },
    { id: 11, name: 'duplicado', price: 1, status: 'ACTIVE' },
  ] },
  { name: 'Bebidas', status: 'INACTIVE', items: [{ id: 'b1', name: 'Suco', price: 'R$ 1.209,90', status: 'INACTIVE' }] },
]

describe('Cardápio Web → snapshot', () => {
  it('converte preços e status', () => {
    expect(parsePrice('41,50')).toBe(41.5)
    expect(parsePrice('R$ 1.209,90')).toBe(1209.9)
    expect(parsePrice(null)).toBeNull()
    expect(cwStatus('ACTIVE')).toBe('active')
    expect(cwStatus('MISSING')).toBe('paused')
    expect(cwStatus('x')).toBe('unknown')
  })
  it('monta categorias, itens e ignora ids repetidos', () => {
    const s = cardapioWebSnapshot(MENU, 'Loja', '77')!
    expect(s.items.map((i) => i.id)).toEqual(['11', '12', 'b1'])
    expect(s.categories.map((c) => [c.name, c.itemIds.length])).toEqual([['Lanches', 2], ['Bebidas', 1]])
    expect(s.items[0]).toMatchObject({ price: 32.9, status: 'active', hasImage: true, categoryName: 'Lanches', available: true })
    expect(s.items[0]!.complements[0]!.name).toBe('Adicionais')
    expect(s.items[1]).toMatchObject({ price: 41.5, status: 'paused', hasImage: false, available: false })
    expect(s.items[2]!.available).toBe(false)
    expect(s.storeKey).toBe('cardapioweb:77')
    expect(s.id).toMatch(/^snap_/)
  })
  it('resposta inesperada ou vazia → null', () => {
    expect(cardapioWebSnapshot({ foo: 1 }, null, '1')).toBeNull()
    expect(cardapioWebSnapshot([], null, '1')).toBeNull()
  })
  it('categorias ordenadas pela posição', () => {
    const s = cardapioWebSnapshot([{ name: 'B', position: 2, items: [{ id: 1, name: 'x', price: 1, status: 'ACTIVE' }] }, { name: 'A', position: 1, items: [{ id: 2, name: 'y', price: 1, status: 'ACTIVE' }] }], null, '1')!
    expect(s.categories.map((c) => c.name)).toEqual(['A', 'B'])
  })
  it('visão do relatório com promoção ativa', () => {
    const v = viewFromItem({ name: 'SELETA', description: 'd', price: 50, promotional_price: 45, promotional_price_active: true, promotional_price_availability: ['sunday', 'monday'], status: 'ACTIVE', image_url: null, allowed_times: [] }, 'Pizzas')!
    expect(v).toMatchObject({ price: 45, originalPrice: 50, active: true, schedule: 'sempre disponível', categoryName: 'Pizzas' })
    expect(v.promotion).toBe('promoção R$ 45,00 (de R$ 50,00) · dias: dom, seg')
    const w = viewFromItem({ name: 'X', price: 10, promotional_price: null, promotional_price_active: false, status: 'INACTIVE' }, null)!
    expect(w).toMatchObject({ price: 10, originalPrice: null, active: false, promotion: null })
  })
})
