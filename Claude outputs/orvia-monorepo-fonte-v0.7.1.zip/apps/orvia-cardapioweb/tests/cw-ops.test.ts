import { describe, expect, it } from 'vitest'
import { deleteItem, duplicateItem, listAddOns, patchItem, reorderCats } from '../src/lib/cw-ops'
import { fakePortal } from './fake-portal'

describe('Cardápio Web — receitas observadas', () => {
  it('muda preço, nome, descrição e status e confere', async () => {
    const p = fakePortal()
    expect((await patchItem(p.request, '10', '1', { price: 12.9 }, 'SELETA')).ok).toBe(true)
    expect(p.items[0]!.price).toBe(12.9)
    expect((await patchItem(p.request, '10', '1', { status: 'INACTIVE' }, 'SELETA')).ok).toBe(true)
    expect(p.items[0]!.status).toBe('INACTIVE')
    expect((await patchItem(p.request, '10', '1', { name: 'Seleta Premium', description: 'Nova' }, 'SELETA')).ok).toBe(true)
    expect(p.items[0]).toMatchObject({ name: 'Seleta Premium', description: 'Nova' })
  })
  it('portal que não aplica o valor → ERRO (não diz ok no escuro)', async () => {
    const p = fakePortal({ obey: false })
    const r = await patchItem(p.request, '10', '1', { price: 99 }, 'SELETA')
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/ainda mostra o preço anterior/)
  })
  it('produto sumiu da categoria → erro sem escrever', async () => {
    const p = fakePortal()
    const r = await patchItem(p.request, '10', '999', { price: 1 }, 'x')
    expect(r.ok).toBe(false)
    expect(p.calls.some((c) => c.startsWith('PUT'))).toBe(false)
  })
  it('cria por duplicação na mesma categoria, ajusta e deixa ATIVO', async () => {
    const p = fakePortal()
    p.items[0]!.status = 'INACTIVE'
    const r = await duplicateItem(p.request, { cat: '10', baseId: '1', name: 'Combo Seleta + Refri', description: 'Desc', price: 59.9 })
    expect(r.ok).toBe(true)
    const novo = p.items.find((i) => String(i.id) === r.productId)!
    expect(novo).toMatchObject({ name: 'Combo Seleta + Refri', description: 'Desc', price: 59.9, status: 'ACTIVE', category_id: 10 })
    expect(novo.add_ons).toHaveLength(2)
    expect(p.calls.find((c) => c.startsWith('POST'))).toBe('POST /item/1/duplicate')
    expect(p.items).toHaveLength(3)
  })
  it('duplicação recusada → erro, nada mais', async () => {
    const p = fakePortal({ dupStatus: 500 })
    const r = await duplicateItem(p.request, { cat: '10', baseId: '1', name: 'Novo' })
    expect(r.ok).toBe(false)
    expect(p.items).toHaveLength(2)
  })
  it('exclui e confere; já excluído = ok', async () => {
    const p = fakePortal()
    expect((await deleteItem(p.request, '10', '2', 'Outro')).ok).toBe(true)
    expect(p.items.map((i) => i.id)).toEqual([1])
    const again = await deleteItem(p.request, '10', '2', 'Outro')
    expect(again.ok).toBe(true)
    expect(again.message).toMatch(/já não está/)
  })
  it('reordena categorias mandando TODAS e confere', async () => {
    const p = fakePortal()
    const r = await reorderCats(p.request, [{ id: '102', name: 'c' }, { id: '100', name: 'c' }])
    expect(r.ok).toBe(true)
    expect(p.cats().map((c) => c.id)).toEqual([102, 100, 101])
    expect(p.cats().map((c) => c.position)).toEqual([0, 1, 2])
  })
  it('reordenar com categoria inexistente → erro sem escrever', async () => {
    const p = fakePortal()
    const r = await reorderCats(p.request, [{ id: '777', name: 'x' }])
    expect(r.ok).toBe(false)
    expect(p.calls.some((c) => c.startsWith('PUT'))).toBe(false)
  })
  it('JSON ignorado pelo portal → tenta o formulário e confere', async () => {
    const p = fakePortal({ jsonIgnored: true })
    const r = await patchItem(p.request, '10', '1', { price: 14.5 }, 'SELETA')
    expect(r.ok).toBe(true)
    expect(p.items[0]!.price).toBe(14.5)
    expect(p.calls.filter((c) => c.startsWith('PUT'))).toHaveLength(2)
  })
  it('lista grupos de complementos já criados', async () => {
    const p = fakePortal()
    expect(await listAddOns(p.request)).toEqual([{ id: '900', name: 'Refrigerante', options: 2, min: 0, max: 1 }, { id: '901', name: 'Borda', options: 1, min: 0, max: 1 }])
  })
  it('duplica mantendo os complementos do base e vinculando grupos escolhidos', async () => {
    const p = fakePortal()
    const r = await duplicateItem(p.request, { cat: '10', baseId: '1', name: 'Novo com borda', addOns: { ids: ['900', '801'], keepBase: true } })
    expect(r.ok).toBe(true)
    const novo = p.items.find((i) => String(i.id) === r.productId)!
    expect(novo.add_ons.map((x: any) => x.add_on_id).sort()).toEqual([800, 801, 900])
    expect(r.message).toMatch(/3 grupo\(s\)/)
  })
  it('duplica trocando os complementos do base pelos escolhidos', async () => {
    const p = fakePortal()
    const r = await duplicateItem(p.request, { cat: '10', baseId: '1', name: 'Só refri', addOns: { ids: ['900'], keepBase: false } })
    expect(r.ok).toBe(true)
    const novo = p.items.find((i) => String(i.id) === r.productId)!
    expect(novo.add_ons.map((x: any) => x.add_on_id)).toEqual([900])
    expect(p.items[0]!.add_ons).toHaveLength(2) // o produto original não é tocado
  })
})
