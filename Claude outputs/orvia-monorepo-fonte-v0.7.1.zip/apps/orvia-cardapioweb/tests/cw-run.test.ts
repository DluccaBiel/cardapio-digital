import { describe, expect, it } from 'vitest'
import { planHash, type ProposalAction } from '@orvia/shared/core/proposal'
import { runApproved } from '@orvia/shared/lib/runner'
import { cardapioWebSnapshot } from '../src/lib/cw-normalize'
import { createItemFromBase } from '../src/lib/item-creator'
import { editItem } from '../src/lib/item-editor'
import { removeItem } from '../src/lib/item-remover'
import { reorderCategories } from '../src/lib/category-reorder'
import { patchItem } from '../src/lib/cw-ops'
import { fakePortal } from './fake-portal'

const MENU = [
  { id: 100, name: 'Pizzas', position: 0, status: 'ACTIVE', items: [{ id: 1, name: 'SELETA', price: 10, status: 'ACTIVE' }, { id: 2, name: 'Outro', price: 20, status: 'ACTIVE' }] },
  { id: 101, name: 'Bebidas', position: 1, status: 'ACTIVE', items: [] },
]
const act = (o: Partial<ProposalAction> & Pick<ProposalAction, 'kind' | 'id'>): ProposalAction => ({ itemId: '', itemName: '', before: null, after: null, reason: 'x', source: 'voce', risk: 'baixo', executable: true, ...o } as ProposalAction)

describe('execução aprovada no Cardápio Web (fluxo completo, portal falso)', () => {
  it('preço, status, nome, criar, excluir e reordenar — cada um OK e conferido', async () => {
    const p = fakePortal()
    // o portal falso tem os itens na categoria 10; alinhamos o cardápio a ela
    const menu = [{ id: 10, name: 'Pizzas', position: 0, status: 'ACTIVE', items: [{ id: 1, name: 'SELETA', price: 10, status: 'ACTIVE' }, { id: 2, name: 'Outro', price: 20, status: 'ACTIVE' }] }, { id: 100, name: 'Bebidas', position: 1, items: [] }, { id: 101, name: 'Lanches', position: 2, items: [] }]
    const snapshot = cardapioWebSnapshot(menu, 'Loja', '77')!
    const cat = (id: string) => snapshot.items.find((i) => i.id === id)!.categoryId ?? ''
    const actions: ProposalAction[] = [
      act({ id: 'u1', kind: 'update_price', itemId: '1', itemName: 'SELETA', before: 10, after: 12.9 }),
      act({ id: 'u2', kind: 'set_status', itemId: '2', itemName: 'Outro', before: 'active', after: 'paused' }),
      act({ id: 'u3', kind: 'update_name', itemId: '1', itemName: 'SELETA', before: 'SELETA', after: 'Seleta Premium' }),
      act({ id: 'c1', kind: 'create_item', itemId: '', itemName: 'Seleta Grande', newItem: { baseItemId: '1', baseItemName: 'SELETA', description: 'Maior', price: 39.9, categoryName: 'Pizzas' } }),
      act({ id: 'd1', kind: 'remove_item', itemId: '2', itemName: 'Outro' }),
      act({ id: 'o1', kind: 'reorder_categories', order: [{ id: '101', name: 'Lanches' }, { id: '10', name: 'Pizzas' }, { id: '100', name: 'Bebidas' }] }),
    ]
    p.cats().splice(0, 3, { id: 10, position: 0 }, { id: 100, position: 1 }, { id: 101, position: 2 })
    const rep = await runApproved({ actions, hash: planHash(actions) }, {
      templates: [], request: p.request, snapshot, signal: new AbortController().signal, sleep: async () => undefined, paceMs: 0,
      createCombo: async () => ({ ok: true, message: '' }),
      setField: (item, field, value) => patchItem(p.request, cat(item.id), item.id, field === 'price' ? { price: Number(value) } : { status: value === 'active' ? 'ACTIVE' : 'INACTIVE' }, item.name),
      editItem: (id, changes) => editItem({ productId: id, catId: cat(id), label: id, request: p.request, changes }),
      createItem: (o) => createItemFromBase({ ...o, request: p.request }),
      removeItem: (id, name) => removeItem({ itemId: id, catId: cat(id), name, request: p.request }),
      reorderCategories: (order) => reorderCategories({ order, request: p.request }),
    })
    expect(rep.steps.map((s) => `${s.action.id}:${s.status}`)).toEqual(['u1:ok', 'u2:ok', 'u3:ok', 'c1:ok', 'd1:ok', 'o1:ok'])
    const byId = (id: number) => p.items.find((i) => i.id === id)
    expect(byId(1)).toMatchObject({ price: 12.9, name: 'Seleta Premium' })
    expect(byId(2)).toBeUndefined() // excluído
    const novo = p.items.find((i) => i.name === 'Seleta Grande')!
    expect(novo).toMatchObject({ price: 39.9, status: 'ACTIVE', description: 'Maior', category_id: 10 })
    expect(p.cats().map((c) => c.id)).toEqual([101, 10, 100])
  })
  it('horário de venda ainda sem receita → ERRO claro, nada gravado', async () => {
    const p = fakePortal()
    const r = await editItem({ productId: '1', catId: '10', label: 'x', request: p.request, changes: { schedule: [] } })
    expect(r.ok).toBe(false)
    expect(p.calls.length).toBe(0)
  })
})
