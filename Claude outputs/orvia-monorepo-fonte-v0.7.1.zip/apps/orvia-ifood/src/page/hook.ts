/**
 * Roda no "MAIN world" do Portal do Parceiro iFood (document_start).
 *
 * 1) LEITURA: observa respostas JSON que o próprio portal carrega e GUARDA as que
 *    parecem cardápio num buffer da página. O painel (content script, que carrega
 *    depois, em document_idle) PUXA esse buffer com a ação `dump` — assim nenhuma
 *    resposta carregada cedo é perdida (era a causa de "não puxa os produtos").
 * 2) SINCRONIZAR ativo (`refetch-menu`): relê os endereços de cardápio já usados
 *    pelo portal (GET sempre; POST só se a resposta era cardápio e não é mutação),
 *    seguindo paginação `page`/`offset` quando existir.
 * 3) EXECUÇÃO: repete o formato aprendido pelo usuário usando a sessão do portal.
 *
 * Cabeçalhos/tokens ficam SOMENTE na memória desta página: nunca vão ao content
 * script, ao storage da extensão nem ao Orvia. Diagnóstico guarda só NOMES de campos.
 */
import { categoryIdFromUrl, isCategoryList, isMenuLike, scorePayload, shapeSignature, typeSignature } from '@orvia/shared/core/capture'
import { sanitizePath } from '@orvia/shared/core/discovery'

const SOURCE = 'orvia-hook'
const MAX_CHARS = 6_000_000
const MAX_CAPTURES = 40
const MAX_SEEN = 150
const SKIP_HEADERS = new Set(['cookie', 'content-length', 'host', 'content-type', 'accept-encoding', 'connection'])
const lastHeaders = new Map<string, Record<string, string>>()

interface Capture {
  seq: number
  ts: number
  method: string
  path: string
  url: string
  status: number
  products: number
  categories: number
  catId: string | null
  payload: unknown
  /** corpo da requisição (só POST de consulta), para repetir no Sincronizar */
  reqBody?: string
}
interface Seen {
  seq: number
  ts: number
  method: string
  path: string
  status: number
  bytes: number
  shape: string
  menu: boolean
  products: number
  categories: number
}
const captures: Capture[] = []
const seen: Seen[] = []
interface FullRec { method: string; path: string; query: string; status: number; body: unknown; response: unknown; at: number }
const fullWrites: FullRec[] = []
const fullReads: FullRec[] = []
const NOISE = /oauth|token|auth|firefly|support|collector|schemas|graphql|httpapi|telemetry|toggles|\/v1$|session_key|csat|mf-manifest|my_group_channels|\/api\/v3\/data/i
const redactQuery = (u: URL) => [...u.searchParams.entries()].map(([k, v]) => `${k}=${/owner|merchant|restaurant/i.test(k) ? '{dono}' : v.slice(0, 40)}`).join('&')
/** Guarda (limitado) o corpo COMPLETO de gravações e leituras de produto, para o Diagnóstico — nunca cabeçalhos/tokens. */
function recordFull(m: string, url: URL, status: number, reqJson: unknown, resJson: unknown) {
  if (NOISE.test(url.pathname)) return
  const cap = (v: unknown, n: number) => { try { const t = JSON.stringify(v); return t && t.length > n ? { truncado: true, inicio: t.slice(0, n) } : v } catch { return null } }
  const rec: FullRec = { method: m, path: url.pathname, query: redactQuery(url), status, body: cap(reqJson, 12000), response: cap(resJson, 3000), at: Date.now() }
  if (m !== 'GET' && m !== 'HEAD') {
    fullWrites.unshift(rec)
    fullWrites.length = Math.min(fullWrites.length, 25)
  } else if (/partner-catalog-bff|menu\/v4\/item\/|available-at|\/menu\/v4\/(catalog|category\/search)/i.test(url.pathname) && !/violation|optimization|verify-type/i.test(url.pathname)) {
    fullReads.unshift({ ...rec, body: null, response: cap(resJson, 6000) })
    fullReads.length = Math.min(fullReads.length, 16)
  }
}
const writes: { method: string; path: string; status: number; reqShape: string; query: string }[] = []
let seq = 0

/** Cabeçalhos do portal para esta chamada, sem duplicar nomes com maiúsculas diferentes. */
function execHeaders(url: URL, withBody: boolean): Record<string, string> {
  const out: Record<string, string> = { accept: 'application/json' }
  for (const [k, v] of Object.entries(lastHeaders.get(url.host) ?? {})) out[k.toLowerCase()] = v
  if (withBody) out['content-type'] = 'application/json'
  return out
}

function isIfoodApi(url: URL): boolean {
  return url.protocol === 'https:' && (url.hostname === 'ifood.com.br' || url.hostname.endsWith('.ifood.com.br'))
}
function absolute(raw: string): URL | null {
  try {
    return new URL(raw, window.location.href)
  } catch {
    return null
  }
}
/** Dono (loja) e origem da API do portal, vistos nas chamadas da própria página — só o id, nunca tokens. */
let owner: { origin: string; ownerId: string } | null = null
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
function rememberOwner(url: URL) {
  const id = url.searchParams.get('ownerUUID') ?? url.searchParams.get('ownerId')
  if (id && UUID.test(id) && isIfoodApi(url)) owner = { origin: url.origin, ownerId: id }
}
function rememberHeaders(url: URL, headers: Record<string, string>) {
  rememberOwner(url)
  const kept: Record<string, string> = {}
  for (const [k, v] of Object.entries(headers)) if (!SKIP_HEADERS.has(k.toLowerCase())) kept[k] = v
  if (Object.keys(kept).length) lastHeaders.set(url.host, kept)
}
function headersToRecord(h: HeadersInit | undefined): Record<string, string> {
  const out: Record<string, string> = {}
  if (!h) return out
  if (h instanceof Headers) h.forEach((v, k) => (out[k] = v))
  else if (Array.isArray(h)) for (const [k, v] of h) out[k] = v
  else Object.assign(out, h)
  return out
}
function parse(text: string | null | undefined): unknown {
  if (!text || text.length > MAX_CHARS) return undefined
  const first = text.trimStart()[0]
  if (first !== '{' && first !== '[') return undefined
  try {
    return JSON.parse(text)
  } catch {
    return undefined
  }
}

function keep(url: URL, method: string, status: number, payload: unknown, bytes: number, reqBody: string | undefined) {
  const score = scorePayload(payload)
  const catList = isCategoryList(payload)
  const menu = isMenuLike(score) || catList
  const products = score.priced + score.catalogOnly + score.refsOnly
  const path = sanitizePath(url.href)
  seq += 1
  seen.unshift({ seq, ts: Date.now(), method, path, status, bytes, shape: shapeSignature(payload).slice(0, 220), menu, products, categories: score.categories })
  seen.length = Math.min(seen.length, MAX_SEEN)
  if (!menu || status < 200 || status >= 300) return
  // mesma chamada de novo → substitui a anterior (versão mais nova)
  const key = `${method} ${url.href} ${reqBody ?? ''}`
  const dup = captures.findIndex((c) => `${c.method} ${c.url} ${c.reqBody ?? ''}` === key)
  if (dup >= 0) captures.splice(dup, 1)
  captures.push({ seq, ts: Date.now(), method, path, url: url.href, status, products, categories: score.categories, catId: categoryIdFromUrl(url.href), payload, reqBody })
  while (captures.length > MAX_CAPTURES) captures.shift()
  window.postMessage({ source: SOURCE, kind: 'menu-seen', seq, path, products }, window.location.origin)
}

/** Só tipos de rows[0].priceByCatalog da primeira lista de itens — para o Diagnóstico. */
function priceShape(): string {
  for (const c of captures) {
    const rows = (c.payload as { rows?: { priceByCatalog?: unknown }[] } | null)?.rows
    if (Array.isArray(rows) && rows[0] && 'priceByCatalog' in rows[0]) return typeSignature(rows[0].priceByCatalog)
  }
  return ''
}

function describeBody(body: unknown): string {
  if (body === undefined || body === null) return 'sem corpo'
  if (typeof body === 'string') return 'texto'
  return (body as { constructor?: { name?: string } }).constructor?.name ?? typeof body
}

function observe(method: string, rawUrl: string, status: number, responseText: string | null, requestText: string | undefined, bodyKind = '') {
  const url = absolute(rawUrl)
  if (!url) return
  const json = parse(responseText)
  const m = method.toUpperCase()
  if (json !== undefined) {
    // adiado: nunca atrasa o portal
    window.setTimeout(() => keep(url, m, status, json, responseText?.length ?? 0, m === 'GET' ? undefined : requestText?.slice(0, 20_000)), 0)
  }
  if (!isIfoodApi(url) && url.origin !== window.location.origin) return
  const reqJson = parse(requestText)
  recordFull(m, url, status, reqJson, json)
  if (m !== 'GET' && m !== 'HEAD') {
    writes.unshift({ method: m, path: url.pathname.replace(/[0-9a-f]{8}-[0-9a-f-]{27}|\b\d{5,}\b/gi, '{id}'), status, reqShape: reqJson !== undefined ? typeSignature(reqJson).slice(0, 1500) : `(corpo ilegível: ${bodyKind || 'desconhecido'})`, query: [...url.searchParams.keys()].join(',') })
    writes.length = Math.min(writes.length, 40)
  }
  if (m === 'GET' && json !== undefined) {
    window.postMessage({ source: SOURCE, kind: 'read', method: m, url: url.href, status, json }, window.location.origin)
  } else if (['PUT', 'PATCH', 'POST'].includes(m) && reqJson !== undefined) {
    window.postMessage({ source: SOURCE, kind: 'write', method: m, url: url.href, status, body: reqJson, json }, window.location.origin)
  }
}

/** Corpo de uma requisição como texto (string, URLSearchParams, Blob, ArrayBuffer…). Nunca lança. */
async function bodyText(body: unknown): Promise<string | undefined> {
  try {
    if (typeof body === 'string') return body
    if (body instanceof URLSearchParams) return body.toString()
    if (typeof Blob !== 'undefined' && body instanceof Blob) return await body.text()
    if (body instanceof ArrayBuffer) return new TextDecoder().decode(body)
    if (ArrayBuffer.isView(body)) return new TextDecoder().decode(body as ArrayBufferView)
  } catch {
    /* ignora */
  }
  return undefined
}

;(() => {
  const w = window as unknown as { __orviaHooked?: boolean }
  if (w.__orviaHooked) return
  w.__orviaHooked = true

  const originalFetch = window.fetch.bind(window)

  window.fetch = async function orviaFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    // fetch(new Request(...)) consome o corpo: guarda uma cópia antes de enviar
    let reqClone: Request | null = null
    try {
      if (typeof Request !== 'undefined' && input instanceof Request && init?.body === undefined && input.method !== 'GET' && input.method !== 'HEAD') reqClone = input.clone()
    } catch {
      reqClone = null
    }
    const response = await originalFetch(input as any, init)
    try {
      const rawUrl = typeof input === 'string' ? input : input instanceof URL ? input.href : (input as Request).url
      const method = (init?.method ?? (input instanceof Request ? input.method : 'GET')).toUpperCase()
      const url = absolute(rawUrl)
      if (url && isIfoodApi(url)) rememberHeaders(url, { ...(input instanceof Request ? headersToRecord(input.headers) : {}), ...headersToRecord(init?.headers) })
      const type = response.headers.get('content-type') ?? ''
      const reqPromise = reqClone ? reqClone.text().catch(() => undefined) : bodyText(init?.body)
      const hasBody = method !== 'GET' && method !== 'HEAD'
      // não depende do content-type: alguns backends respondem JSON como text/plain
      if (type.includes('json') || type.includes('text') || type === '' || hasBody) {
        Promise.all([response.clone().text(), reqPromise])
          .then(([text, reqText]) => observe(method, rawUrl, response.status, text, reqText, describeBody(init?.body ?? reqClone)))
          .catch(() => undefined)
      }
    } catch {
      /* nunca interfere no portal */
    }
    return response
  }

  type X = XMLHttpRequest & { __orvia?: { method: string; url: string; headers: Record<string, string> } }
  const originalOpen = XMLHttpRequest.prototype.open
  const originalSend = XMLHttpRequest.prototype.send
  const originalSetHeader = XMLHttpRequest.prototype.setRequestHeader
  XMLHttpRequest.prototype.open = function (this: X, ...args: any[]) {
    this.__orvia = { method: String(args[0] ?? 'GET'), url: String(args[1] ?? ''), headers: {} }
    return (originalOpen as any).apply(this, args)
  } as typeof XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.setRequestHeader = function (this: X, name: string, value: string) {
    if (this.__orvia) this.__orvia.headers[name] = value
    return originalSetHeader.call(this, name, value)
  }
  XMLHttpRequest.prototype.send = function (this: X, body?: Document | XMLHttpRequestBodyInit | null) {
    const meta = this.__orvia
    if (meta) {
      const url = absolute(meta.url)
      if (url && isIfoodApi(url)) rememberHeaders(url, meta.headers)
      const reqPromise = bodyText(body)
      this.addEventListener('load', () => {
        try {
          const text = this.responseType === '' || this.responseType === 'text' ? this.responseText : this.responseType === 'json' ? JSON.stringify(this.response) : null
          void reqPromise.then((reqText) => observe(meta.method, meta.url, this.status, text, reqText, describeBody(body)))
        } catch {
          /* ignora */
        }
      })
    }
    return originalSend.call(this, body as any)
  }

  // ---- Pedidos do content script ----------------------------------------
  /** Consulta GraphQL/POST só é repetida se NÃO for mutação. */
  const isSafeReplay = (c: Capture) => c.method === 'GET' || (c.method === 'POST' && !/\bmutation\b/i.test(c.reqBody ?? '') && c.reqBody !== undefined)

  async function fetchOne(c: { url: string; method: string; reqBody?: string }): Promise<{ ok: boolean; status: number; text: string }> {
    const url = absolute(c.url)
    if (!url) return { ok: false, status: 0, text: '' }
    const headers: Record<string, string> = { Accept: 'application/json', ...(isIfoodApi(url) ? lastHeaders.get(url.host) ?? {} : {}) }
    if (c.method === 'POST') headers['Content-Type'] = 'application/json'
    const res = await originalFetch(url.href, { method: c.method, headers, body: c.method === 'POST' ? c.reqBody : undefined, credentials: 'include' })
    return { ok: res.ok, status: res.status, text: await res.text() }
  }

  /** Se a URL tem page/offset, segue as próximas páginas até esvaziar (máx. 40). */
  async function followPages(c: Capture, report: { read: number; pages: number }): Promise<void> {
    const url = absolute(c.url)
    if (!url || c.method !== 'GET') return
    const pageKey = ['page', 'pageNumber', 'pageIndex'].find((k) => url.searchParams.has(k))
    const offsetKey = url.searchParams.has('offset') ? 'offset' : url.searchParams.has('skip') ? 'skip' : null
    const limit = Number(url.searchParams.get('limit') ?? url.searchParams.get('size') ?? url.searchParams.get('pageSize') ?? 0)
    if (!pageKey && !(offsetKey && limit > 0)) return
    let known = c.products
    for (let i = 1; i <= 40; i += 1) {
      const next = new URL(url.href)
      if (pageKey) next.searchParams.set(pageKey, String(Number(url.searchParams.get(pageKey)) + i))
      else next.searchParams.set(offsetKey!, String(Number(url.searchParams.get(offsetKey!)) + i * limit))
      const r = await fetchOne({ url: next.href, method: 'GET' }).catch(() => null)
      if (!r || !r.ok) break
      const json = parse(r.text)
      if (json === undefined) break
      const score = scorePayload(json)
      const count = score.priced + score.catalogOnly + score.refsOnly
      if (!isMenuLike(score) || count === 0) break
      keep(next, 'GET', r.status, json, r.text.length, undefined)
      report.pages += 1
      report.read += 1
      known += count
      if (known > 5000) break
    }
  }

  window.addEventListener('message', async (event: MessageEvent) => {
    if (event.source !== window || event.origin !== window.location.origin) return
    const data = event.data as { source?: string; id?: string; action?: string; method?: string; url?: string; body?: unknown } | null
    if (!data || data.source !== 'orvia-exec' || !data.id) return
    const reply = (status: number, json: unknown) => window.postMessage({ source: 'orvia-exec-result', id: data.id, status, json }, window.location.origin)

    // Entrega o que o hook já guardou (resolve a corrida "painel carregou depois")
    if (data.action === 'dump') {
      return reply(200, {
        captures: captures.map((c) => ({ seq: c.seq, ts: c.ts, method: c.method, path: c.path, status: c.status, products: c.products, categories: c.categories, categoryId: c.catId, payload: c.payload })),
        priceShape: priceShape(),
        seen: seen.slice(0, 80),
        writes: writes.slice(0, 40),
        fullWrites,
        fullReads,
        headersKnown: lastHeaders.size > 0,
      })
    }
    if (data.action === 'owner') {
      if (!owner) for (const c of captures) { const u = absolute(c.url); if (u) rememberOwner(u) }
      return reply(owner ? 200 : 404, owner ?? { error: 'ainda não vi o código da loja nas chamadas do portal' })
    }
    if (data.action === 'clear') {
      captures.length = 0
      seen.length = 0
      fullWrites.length = 0
      fullReads.length = 0
      return reply(200, { cleared: true })
    }

    // "Sincronizar": relê os endereços de cardápio já usados pelo portal nesta aba
    if (data.action === 'refetch-menu') {
      const report = { known: 0, read: 0, pages: 0, failed: 0 }
      const targets = captures.filter(isSafeReplay).slice(-12)
      report.known = targets.length
      for (const c of targets) {
        try {
          const r = await fetchOne({ url: c.url, method: c.method, reqBody: c.reqBody })
          const json = parse(r.text)
          const u = absolute(c.url)
          if (r.ok && json !== undefined && u) {
            keep(u, c.method, r.status, json, r.text.length, c.reqBody)
            report.read += 1
            const fresh = captures.find((x) => x.url === c.url && x.method === c.method)
            if (fresh) await followPages(fresh, report)
          } else report.failed += 1
        } catch {
          report.failed += 1
        }
      }
      return reply(200, report)
    }

    if (!data.url || !data.method) return
    const url = absolute(data.url)
    const method = data.method.toUpperCase()
    if (!url || !isIfoodApi(url) || !['GET', 'PUT', 'PATCH', 'POST'].includes(method)) return reply(0, { error: 'destino não permitido' })
    try {
      const res = await originalFetch(url.href, {
        method,
        headers: execHeaders(url, data.body !== undefined),
        body: data.body !== undefined ? JSON.stringify(data.body) : undefined,
        credentials: 'include',
      })
      const text = await res.text()
      reply(res.status, parse(text) ?? null)
    } catch {
      reply(0, { error: 'falha de rede' })
    }
  })
})()
