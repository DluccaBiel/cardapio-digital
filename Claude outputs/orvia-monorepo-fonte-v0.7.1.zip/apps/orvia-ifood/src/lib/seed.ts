/**
 * Moldes PRÉ-ENSINADOS. O preço e o pausar/ativar já foram gravados do portal real
 * (PATCH /menu/v4/price/single e /menu/v4/status) e conferidos pelos testes — então a
 * extensão não pede mais para ensinar: ela monta esses dois moldes sozinha com o código da
 * loja que o próprio portal usa. Se o dono ensinar outro formato, o dele vale.
 *
 * Também reaponta o código da loja nos moldes (aprendidos ou pré-ensinados): o molde é a FORMA
 * do pedido; o dono da loja vem sempre do portal aberto — nunca de outra loja.
 */
import { learnFromWrite, type Field, type Observed, type Template } from '@orvia/shared/lib/learn'
import type { PortalCtx } from './item-editor'

const money = (v: number) => ({ value: { currency: 'BRL', value: v }, originalValue: null })

export function seedTemplates(ctx: PortalCtx): Template[] {
  const o = encodeURIComponent(ctx.ownerId)
  const items = new Map([['seed-1', { price: 9.5, status: 'active' }]])
  const read: Observed = {
    method: 'GET', status: 200, at: 1,
    url: `${ctx.origin}/next-web-bff/menu/v4/item/seed-1?ownerUUID=${o}&availablePrice=true&withRanking=true`,
    json: { id: 'seed-1', priceByCatalog: [{ price: money(9.5), catalogId: 'K1', catalogType: 'DEFAULT', oldPrice: null }] },
  }
  const price = learnFromWrite({
    method: 'PATCH', status: 200, at: 2,
    url: `${ctx.origin}/next-web-bff/menu/v4/price/single?ownerUUID=${o}&availablePrice=true`,
    body: { items: { parentCustomizationOptionId: '', priceByCatalog: [{ price: money(9.9), oldPrice: money(9.5), catalogId: 'K1' }], catalogItemId: 'seed-1' } },
  }, [read], items)
  const status = learnFromWrite({
    method: 'PATCH', status: 200, at: 3,
    url: `${ctx.origin}/next-web-bff/menu/v4/status?ownerUUID=${o}`,
    body: { items: [{ catalogItemId: 'seed-1', parentCustomizationOptionId: '', status: 'UNAVAILABLE', statusByCatalog: [{ catalogId: 'K1', status: 'UNAVAILABLE' }] }] },
  }, [], items)
  return [...(price.ok ? price.templates : []), ...(status.ok ? status.templates : [])].map((t) => ({ ...t, learnedAt: 'pre-ensinado' }))
}

const OWNER_PARAM = /([?&](?:ownerUUID|ownerId)=)[^&#]*/

/** Troca o código da loja da URL do molde pelo da loja aberta agora (só em URLs do mesmo portal). */
export function rebaseOwner(list: Template[], ctx: PortalCtx): Template[] {
  const fix = (u: string | undefined) => (u && u.startsWith(ctx.origin) && OWNER_PARAM.test(u) ? u.replace(OWNER_PARAM, `$1${encodeURIComponent(ctx.ownerId)}`) : u)
  return list.map((t) => ({ ...t, urlTemplate: fix(t.urlTemplate) ?? t.urlTemplate, verifyUrlTemplate: fix(t.verifyUrlTemplate), detailUrlTemplate: fix(t.detailUrlTemplate) }))
}

/** Completa o que falta com os moldes pré-ensinados e reaponta a loja. `changed` = precisa salvar. */
export function withSeeds(list: Template[], ctx: PortalCtx): { list: Template[]; added: Field[]; changed: boolean } {
  const have = new Set(list.map((t) => t.field))
  const added: Field[] = []
  const extra = seedTemplates(ctx).filter((t) => {
    if (have.has(t.field)) return false
    added.push(t.field)
    return true
  })
  const rebased = rebaseOwner([...list, ...extra], ctx)
  const changed = added.length > 0 || JSON.stringify(rebased) !== JSON.stringify(list)
  return { list: rebased, added, changed }
}

/** Código de catálogo FALSO usado só para montar os moldes pré-ensinados. Nunca pode ir ao iFood. */
export const PLACEHOLDER_CATALOG = 'K1'

/** Troca o código de catálogo de mentira pelo catálogo REAL da loja (corpo guardado do molde). */
export function rebaseCatalog(list: Template[], catalogId: string): Template[] {
  const swap = (v: unknown): unknown => {
    if (v === PLACEHOLDER_CATALOG) return catalogId
    if (Array.isArray(v)) return v.map(swap)
    if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, swap(x)]))
    return v
  }
  return list.map((t) => (t.patchBody === undefined ? t : { ...t, patchBody: swap(t.patchBody) }))
}
export const hasPlaceholder = (t: Template): boolean => JSON.stringify(t.patchBody ?? null).includes(`"${PLACEHOLDER_CATALOG}"`)

/** Catálogo padrão da loja, a partir da resposta de GET /next-web-bff/menu/v4/catalog. */
export function pickCatalogId(json: unknown): string | null {
  const rows = Array.isArray(json) ? json.filter((c): c is Record<string, unknown> => !!c && typeof c === 'object') : []
  const pick = rows.find((c) => c.catalogType === 'DEFAULT' && typeof c.catalogId === 'string') ?? rows.find((c) => typeof c.catalogId === 'string')
  return pick ? (pick.catalogId as string) : null
}
