/**
 * "Como o produto está agora no iFood" — lido depois da execução para o relatório.
 *   GET /partner-catalog-bff/product/{id}?ownerId=…               → nome, descrição, foto (imageResource), promoções
 *   GET /partner-catalog-bff/product/{id}/available-at?ownerId=…  → categoria, preço, status, horários, promoções por catálogo
 * Puro: sem chrome.*, sem DOM.
 */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { ProductView } from '@orvia/shared/lib/prints'
import { scheduleLabel, type Slot } from '@orvia/shared/core/proposal'
import { IFOOD_IMAGE_BASE } from '@orvia/shared/core/normalize'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300

export type { ProductView }

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const
const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`

/** faixas do iFood → "10:00–12:00 · todos os dias + 15:00–21:00 · seg, ter" */
export function describeShifts(shifts: unknown): string {
  if (!Array.isArray(shifts) || !shifts.length) return 'sempre disponível'
  const byRange = new Map<string, Set<number>>()
  for (const x of shifts) {
    if (!isRec(x) || typeof x.startTime !== 'string' || typeof x.endTime !== 'string') continue
    const k = `${x.startTime}|${x.endTime}`
    const set = byRange.get(k) ?? new Set<number>()
    DAYS.forEach((d, i) => { if (x[d] === true) set.add(i) })
    byRange.set(k, set)
  }
  const slots: Slot[] = [...byRange.entries()].map(([k, days]) => ({ start: k.split('|')[0]!, end: k.split('|')[1]!, days: [...days].sort() })).filter((s) => s.days.length)
  if (slots.length === 1 && slots[0]!.days.length === 7 && slots[0]!.start === '00:00' && /^23:59/.test(slots[0]!.end)) return 'sempre disponível'
  return slots.length ? scheduleLabel(slots.sort((a, b) => a.start.localeCompare(b.start))) : 'sempre disponível'
}

/** Texto de promoções (formato do iFood não gravado): usa nome/descrição/tipo quando houver, senão "promoção ativa". */
export function describePromotions(...lists: unknown[]): string | null {
  const parts: string[] = []
  for (const l of lists) {
    if (!Array.isArray(l)) continue
    for (const p of l) {
      if (typeof p === 'string' && p.trim()) parts.push(p.trim())
      else if (isRec(p)) {
        const t = ['name', 'title', 'description', 'label', 'type'].map((k) => p[k]).find((v): v is string => typeof v === 'string' && v.trim().length > 0)
        const v = typeof p.discount === 'number' ? ` (${p.discount}%)` : typeof p.value === 'number' ? ` (${brl(p.value)})` : ''
        parts.push(`${t ?? 'promoção ativa'}${v}`)
      } else parts.push('promoção ativa')
    }
  }
  return parts.length ? [...new Set(parts)].join(' · ') : null
}

export function viewFromReads(product: unknown, availableAt: unknown): ProductView | null {
  if (!isRec(product) || typeof product.name !== 'string') return null
  const cats = Array.isArray(availableAt) ? availableAt.filter(isRec) : []
  const c0 = cats[0]
  const ext0 = c0 && isRec(c0.extensions) ? Object.values(c0.extensions).find(isRec) : undefined
  const price = ext0 && typeof ext0.price === 'number' ? ext0.price : null
  const originalPrice = ext0 && typeof ext0.originalPrice === 'number' && price !== null && ext0.originalPrice > price ? ext0.originalPrice : null
  const status = ext0 && typeof ext0.status === 'string' ? ext0.status : null
  const img = isRec(product.imageResource) && typeof product.imageResource.path === 'string' && product.imageResource.path ? product.imageResource : null
  const imageUrl = img ? `${typeof img.baseUrl === 'string' && img.baseUrl ? img.baseUrl.replace(/\/?$/, '/') : IFOOD_IMAGE_BASE}${String(img.path).replace(/^\//, '')}` : null
  const promos = describePromotions(product.promotions, ...cats.flatMap((c) => (isRec(c.extensions) ? Object.values(c.extensions).map((e) => (isRec(e) ? e.promotions : null)) : [])))
  const promotion = promos ?? (originalPrice !== null ? `de ${brl(originalPrice)} por ${brl(price!)}` : null)
  return {
    name: product.name,
    description: typeof product.description === 'string' ? product.description : '',
    imageUrl,
    categoryName: c0 && typeof c0.name === 'string' ? c0.name : null,
    price,
    originalPrice,
    active: status === null ? null : status === 'AVAILABLE',
    schedule: describeShifts(c0?.shifts),
    promotion,
  }
}

export async function fetchProductView(productId: string, ctx: PortalCtx, request: PortalRequest): Promise<ProductView | null> {
  const q = `?ownerId=${encodeURIComponent(ctx.ownerId)}`
  try {
    const [p, a] = [await request('GET', `${ctx.origin}/partner-catalog-bff/product/${productId}${q}`), await request('GET', `${ctx.origin}/partner-catalog-bff/product/${productId}/available-at${q}`)]
    return ok2xx(p.status) ? viewFromReads(p.json, ok2xx(a.status) ? a.json : null) : null
  } catch {
    return null
  }
}
