import { describe, expect, it } from 'vitest'
import { applyRaw, encode } from '@orvia/shared/lib/executor'
import { rebaseOwner, seedTemplates, withSeeds } from '../src/lib/seed'
import { validTemplates } from '@orvia/shared/lib/learn'

const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: '35443ffd-cd73-4c1b-8e3c-ad00af38b53d' }
const money = (v: number) => ({ value: { currency: 'BRL', value: v }, originalValue: null })

describe('moldes pré-ensinados (preço e pausar/ativar)', () => {
  it('monta preço e status e passam na validação', () => {
    const t = seedTemplates(ctx)
    expect(t.map((x) => x.field).sort()).toEqual(['price', 'status'])
    expect(validTemplates(t)).toHaveLength(2)
    expect(t.find((x) => x.field === 'price')!.urlTemplate).toBe(`${ctx.origin}/next-web-bff/menu/v4/price/single?ownerUUID=${ctx.ownerId}&availablePrice=true`)
    expect(t.find((x) => x.field === 'status')!.path).toEqual(['items', 0, 'status'])
  })
  it('aplica o PREÇO em um produto qualquer com o corpo real (id, preço novo, oldPrice, catalogId do item)', async () => {
    const templates = seedTemplates(ctx)
    const sent: any[] = []
    let price = 24.5
    const request = async (m: string, u: string, b?: any) => {
      if (m === 'PATCH') { sent.push({ u, b }); price = b.items.priceByCatalog[0].price.value.value; return { status: 200, json: {} } }
      return { status: 200, json: { id: 'r2', priceByCatalog: [{ price: money(price), catalogId: 'K1', oldPrice: null }] } }
    }
    const t = templates.find((x) => x.field === 'price')!
    const res = await applyRaw('r2', { price: encode(t, 24.9) }, templates, request, { beforePrice: 24.5, sleep: async () => undefined })
    expect(res.ok).toBe(true)
    expect(sent[0].u).toContain('/price/single?ownerUUID=' + ctx.ownerId)
    expect(sent[0].b).toEqual({ items: { parentCustomizationOptionId: '', priceByCatalog: [{ price: money(24.9), oldPrice: money(24.5), catalogId: 'K1' }], catalogItemId: 'r2' } })
  })
  it('aplica PAUSAR em um produto (nunca categoria)', async () => {
    const templates = seedTemplates(ctx)
    const sent: any[] = []
    const t = templates.find((x) => x.field === 'status')!
    const res = await applyRaw('r9', { status: encode(t, 'paused') }, templates, async (m, u, b) => { sent.push({ m, u, b }); return { status: 200, json: {} } })
    expect(res.ok).toBe(true)
    expect(sent[0].b).toEqual({ items: [{ catalogItemId: 'r9', parentCustomizationOptionId: '', status: 'UNAVAILABLE', statusByCatalog: [{ catalogId: 'K1', status: 'UNAVAILABLE' }] }] })
    expect(JSON.stringify(sent[0].b)).not.toContain('categories')
  })
  it('só completa o que falta e respeita o que o dono ensinou', () => {
    const mine = seedTemplates(ctx).filter((x) => x.field === 'price').map((x) => ({ ...x, learnedAt: 'ensinado pelo dono' }))
    const r = withSeeds(mine, ctx)
    expect(r.added).toEqual(['status'])
    expect(r.list.find((x) => x.field === 'price')!.learnedAt).toBe('ensinado pelo dono')
    expect(withSeeds(r.list, ctx).changed).toBe(false)
  })
  it('reaponta a loja: molde de outra loja nunca escreve na loja errada', () => {
    const old = seedTemplates({ ...ctx, ownerId: '11111111-1111-1111-1111-111111111111' })
    const r = rebaseOwner(old, ctx)
    expect(r.every((t) => t.urlTemplate.includes(ctx.ownerId) && !t.urlTemplate.includes('1111111111'))).toBe(true)
    expect(r.find((t) => t.field === 'price')!.verifyUrlTemplate).toContain(ctx.ownerId)
  })
})

import { hasPlaceholder, pickCatalogId, rebaseCatalog, PLACEHOLDER_CATALOG } from '../src/lib/seed'
describe('catálogo real no lugar do código de mentira (corrige HTTP 400 do preço/status)', () => {
  const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'owner-1' }
  it('os moldes pré-ensinados nascem com o placeholder e ele é trocado pelo catálogo real', () => {
    const seeds = seedTemplates(ctx)
    expect(seeds.every(hasPlaceholder)).toBe(true)
    const fixed = rebaseCatalog(seeds, 'e57d9cb8-real')
    expect(fixed.some(hasPlaceholder)).toBe(false)
    expect(JSON.stringify(fixed.map((t) => t.patchBody))).toContain('e57d9cb8-real')
    expect(JSON.stringify(fixed.map((t) => t.patchBody))).not.toContain(PLACEHOLDER_CATALOG + '"')
  })
  it('escolhe o catálogo DEFAULT da resposta do portal', () => {
    expect(pickCatalogId([{ catalogId: 'x', catalogType: 'OTHER' }, { catalogId: 'e57d', catalogType: 'DEFAULT' }])).toBe('e57d')
    expect(pickCatalogId([{ catalogId: 'só', catalogType: 'OTHER' }])).toBe('só')
    expect(pickCatalogId({ foo: 1 })).toBeNull()
  })
})
