import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-create.json'
import edit from './fixtures/real-item-edit.json'
import { buildCreateBody, createItemFromBase } from '../src/lib/item-creator'
import { resolveCreate, runApproved } from '@orvia/shared/lib/runner'
import { planHash, type ProposalAction } from '@orvia/shared/core/proposal'
import type { MenuSnapshot } from '@orvia/shared/core/schema'

const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: '35443ffd-cd73-4c1b-8e3c-ad00af38b53d' }
const BASE = fx.productGet.id
const NEW = fx.postResponse.id
const OFFER = 'offer-new-1'

type Call = { method: string; url: string; body?: unknown }
function mock(opts: { created?: boolean; linkStatus?: number; categories?: unknown } = {}) {
  const calls: Call[] = []
  let created = false
  const request = async (method: string, url: string, body?: unknown) => {
    calls.push({ method, url, body })
    if (method === 'GET' && url.includes(`/product/${BASE}/available-at`)) return { status: 200, json: opts.categories ?? edit.availableAt }
    if (method === 'GET' && url.includes(`/product/${BASE}`)) return { status: 200, json: fx.productGet }
    if (method === 'POST' && url.includes('/partner-catalog-bff/product?')) { created = true; return { status: 201, json: fx.postResponse } }
    if (method === 'POST' && url.includes('link/categories:batch')) return { status: opts.linkStatus ?? 201, json: null }
    if (method === 'GET' && url.includes(`/product/${NEW}/available-at`)) return { status: 200, json: created ? [{ ...(edit.availableAt[0] as object), offerId: OFFER }] : [] }
    if (method === 'GET' && url.includes(`/product/${NEW}`)) return { status: 200, json: { ...fx.postResponse } }
    if (method === 'PATCH') return { status: 200, json: null }
    return { status: 404, json: null }
  }
  return { calls, request }
}

describe('criar produto por duplicação (gravação real)', () => {
  it('o corpo montado é IDÊNTICO ao POST gravado no portal', () => {
    const b = buildCreateBody(fx.productGet, { name: 'Teste 1' })
    expect(b.ok).toBe(true)
    if (b.ok) expect(b.body).toEqual(fx.postBody)
  })

  it('cria, vincula à MESMA categoria do base, confere e deixa ATIVO', async () => {
    const m = mock()
    const r = await createItemFromBase({ baseProductId: BASE, name: 'Teste 1', price: 50, ctx, request: m.request })
    expect(m.calls.some((c) => c.method === 'PATCH')).toBe(false)
    expect(r.message).toMatch(/ATIVO/)
    const m2 = mock()
    await createItemFromBase({ baseProductId: BASE, name: 'Teste 1', price: 50, paused: true, ctx, request: m2.request })
    expect(r.ok).toBe(true)
    const post = m.calls.find((c) => c.method === 'POST' && c.url.includes('/product?'))!
    expect(post.url).toContain('createDefaultCategory=false')
    expect(post.body).toEqual(fx.postBody)
    const link = m.calls.find((c) => c.url.includes('link/categories:batch'))!
    const l = (link.body as Record<string, unknown>[])[0]!
    expect(l.productId).toBe(NEW)
    expect(l.categoryId).toBe('d5c1d4fd-b4d1-46bd-895c-6ba717b16803')
    expect(l.categoryName).toBe('Para adoçar seu Dia')
    expect((l.extensions as Record<string, { price: number }>)['e57d9cb8-1b31-409f-8a54-209baecea3de']!.price).toBe(50)
    const st = m2.calls.find((c) => c.method === 'PATCH')!
    expect(st.body).toEqual({ items: [{ catalogItemId: OFFER, parentCustomizationOptionId: '', status: 'AVAILABLE', statusByCatalog: [{ catalogId: 'e57d9cb8-1b31-409f-8a54-209baecea3de', status: 'UNAVAILABLE' }] }] })
  })

  it('usa o preço do base quando nenhum for pedido', async () => {
    const m = mock()
    await createItemFromBase({ baseProductId: BASE, name: 'Outro', ctx, request: m.request })
    const l = (m.calls.find((c) => c.url.includes('link/categories:batch'))!.body as { extensions: Record<string, { price: number }> }[])[0]!
    expect(l.extensions['e57d9cb8-1b31-409f-8a54-209baecea3de']!.price).toBe(9.5)
  })

  it('base fora da categoria pedida: não cria nada', async () => {
    const m = mock()
    const r = await createItemFromBase({ baseProductId: BASE, categoryId: 'outra-categoria', name: 'Xis', ctx, request: m.request })
    expect(r.ok).toBe(false)
    expect(m.calls.some((c) => c.method === 'POST')).toBe(false)
  })

  it('campo desconhecido no produto base: aborta sem enviar', async () => {
    const m = mock()
    const weird = { ...fx.productGet, novidade: 1 }
    const req = async (method: string, url: string, body?: unknown) => (method === 'GET' && url.includes(`/product/${BASE}?`) ? { status: 200, json: weird } : m.request(method, url, body))
    const r = await createItemFromBase({ baseProductId: BASE, name: 'Xis', ctx, request: req })
    expect(r.ok).toBe(false)
    expect(m.calls.some((c) => c.method === 'POST')).toBe(false)
  })

  it('vínculo recusado: avisa que o produto ficou sem categoria', async () => {
    const m = mock({ linkStatus: 400 })
    const r = await createItemFromBase({ baseProductId: BASE, name: 'Xis', ctx, request: m.request })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/sem categoria/)
  })
})

describe('runner: create_item / create_combo executáveis', () => {
  const item = (id: string, name: string, cat: string, catName: string, productId: string | null) => ({ id, name, categoryId: cat, categoryName: catName, productId, price: 10 }) as unknown as MenuSnapshot['items'][number]
  const snapshot = { items: [item('i1', 'Bolo Fatia', 'cat-doces', 'Para adoçar seu Dia', BASE), item('i2', 'Pão', 'cat-combo', 'Combo Capixaba', 'p-combo')] } as unknown as MenuSnapshot
  const base: Omit<ProposalAction, 'id' | 'kind'> = { itemId: null, itemName: 'Novo Bolo', before: null, after: 'Novo Bolo', reason: '', source: 'voce', risk: 'baixo', executable: true }
  const createItemAct: ProposalAction = { ...base, id: 'c1', kind: 'create_item', newItem: { baseItemId: 'i1', baseItemName: 'Bolo Fatia', description: 'desc', price: 12, categoryName: 'Para adoçar seu Dia' } }
  const comboAct: ProposalAction = { ...base, id: 'c2', kind: 'create_combo', itemName: 'Combo X', combo: { name: 'Combo X', description: 'Bolo + Pão', price: 30, fullPrice: 35, components: [{ itemId: 'i1', name: 'Bolo Fatia', quantity: 1 }] } }

  it('resolveCreate: item novo usa o base; combo usa a categoria de combos da loja', () => {
    const a = resolveCreate(createItemAct, snapshot)
    expect(a.ok && a.base.categoryId).toBe('cat-doces')
    const c = resolveCreate(comboAct, snapshot)
    expect(c.ok && c.base.categoryId).toBe('cat-combo')
  })

  it('executa e marca OK; não duplica se já existe o nome na categoria', async () => {
    const seen: unknown[] = []
    const run = (acts: ProposalAction[], snap = snapshot) =>
      runApproved({ actions: acts, hash: planHash(acts) }, {
        templates: [], request: async () => ({ status: 200, json: null }), snapshot: snap, signal: new AbortController().signal, paceMs: 0, sleep: async () => {},
        createItem: async (o) => { seen.push(o); return { ok: true, message: 'Criado.' } },
        createCombo: async () => ({ ok: true, message: 'Registrado no Orvia.' }),
      })
    const r = await run([createItemAct, comboAct])
    expect(r.steps.map((s) => s.status)).toEqual(['ok', 'ok'])
    expect(seen).toHaveLength(2)
    expect((seen[0] as { baseProductId: string }).baseProductId).toBe(BASE)
    expect((seen[1] as { baseProductId: string }).baseProductId).toBe('p-combo')
    const dupSnap = { items: [...snapshot.items, item('i3', 'Novo Bolo', 'cat-doces', 'Para adoçar seu Dia', 'p3')] } as unknown as MenuSnapshot
    seen.length = 0
    const r2 = await run([createItemAct], dupSnap)
    expect(seen).toHaveLength(0)
    expect(r2.steps[0]!.message).toMatch(/Já existe/)
  })
})
