/**
 * Proposta de otimização — o que a análise sugere, o que o usuário aprova e o que
 * é executado. Puro (sem DOM/chrome). Garantias:
 *  - cada ação diz se é EXECUTÁVEL no iFood (campos do produto) ou ASSISTIDA (combo, foto);
 *  - o conjunto aprovado é congelado com um hash; o executor recusa rodar se o
 *    hash mudar (executa exatamente o que foi aprovado).
 */
import type { AnalysisContext, ComboSuggestion, Finding, MenuSnapshot, RiskLevel } from './schema'
import { practiceActions } from './practices'
import { runRules, suggestCombos } from './rules'

export type ActionKind = 'update_name' | 'update_description' | 'update_price' | 'set_status' | 'create_combo' | 'create_item' | 'remove_item' | 'update_schedule' | 'recommend'
export type ActionSource = 'regras' | 'ia' | 'concorrentes' | 'voce'

export interface ComboDraft {
  name: string
  description: string
  price: number
  fullPrice: number
  components: { itemId: string; name: string; quantity: number }[]
}

export interface Slot { start: string; end: string; days: number[] }
/** Várias faixas de horário (ex.: 10–12h e 15–21h). null = sempre disponível. */
export type Schedule = Slot[]
export const DAY_SHORT = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']
const slotLabel = (sc: Slot) => `${sc.start}–${sc.end} · ${sc.days.length === 7 ? 'todos os dias' : sc.days.map((d) => DAY_SHORT[d]).join(', ')}`
export const scheduleLabel = (sc: Schedule | null | undefined) => (!sc || !sc.length ? 'sempre disponível' : sc.map(slotLabel).join(' + '))

export interface ProposalAction {
  id: string
  kind: ActionKind
  /** id do item no iFood (snapshot) — vazio para combos e recomendações */
  itemId: string | null
  itemName: string
  before: string | number | null
  after: string | number | null
  reason: string
  source: ActionSource
  risk: RiskLevel
  /** true = a extensão altera no iFood (depende dos moldes aprendidos); false = assistida/informativa */
  executable: boolean
  combo?: ComboDraft
  /** horário de venda do produto: null = sempre disponível; senão faixas por dia (0=seg … 6=dom) */
  schedule?: Schedule | null
  /** produto novo: criado DUPLICANDO um existente (receita gravada em item-creator.ts; o novo fica na categoria do base) */
  newItem?: { baseItemId: string | null; baseItemName: string; description: string; price: number | null; categoryName: string | null }
}

export interface Source {
  title: string
  url: string
}
export interface CompetitorInsight {
  name: string
  url: string | null
  highlights: string[]
  examples: { name: string; price: number | null }[]
}

export interface Proposal {
  version: number
  createdAt: string
  summary: string
  actions: ProposalAction[]
  competitors: CompetitorInsight[]
  insights: string[]
  sources: Source[]
  /** avisos sobre a origem (ex.: IA indisponível) — nunca escondidos do usuário */
  notices: string[]
  feedback: string[]
}

export const KIND_LABEL: Record<ActionKind, string> = {
  update_name: 'Nome',
  update_description: 'Descrição',
  update_price: 'Preço',
  set_status: 'Status',
  create_combo: 'Novo combo',
  create_item: 'Novo produto',
  remove_item: 'Remover produto',
  update_schedule: 'Horário',
  recommend: 'Recomendação',
}

const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
export const fmtValue = (kind: ActionKind, v: string | number | null): string =>
  v === null || v === '' ? '—' : kind === 'update_price' && typeof v === 'number' ? brl(v) : String(v)

// ---------------------------------------------------------------------------
// Montagem local (regras determinísticas — funcionam sem IA e sem internet)
// ---------------------------------------------------------------------------
export function defaultContext(niche: string, discount: number): AnalysisContext {
  return {
    niche,
    nicheOther: '',
    goal: 'ticket',
    targetMarginPercent: null,
    declaredCosts: '',
    minPrice: null,
    maxPrice: null,
    comboDiscountPercent: discount,
    doNotTouchPrices: false,
    doNotTouchItemIds: [],
  }
}

function comboAction(s: ComboSuggestion, snapshot: MenuSnapshot): ProposalAction {
  const comps = s.componentIds.map((id, i) => ({ itemId: id, name: snapshot.items.find((x) => x.id === id)?.name ?? s.componentNames[i] ?? id, quantity: s.componentQuantities[i] ?? 1 }))
  return {
    id: `combo:${s.id}:${s.componentIds.join('+')}`,
    kind: 'create_combo',
    itemId: null,
    itemName: s.name,
    before: null,
    after: s.price,
    reason: `${s.explanation} No iFood é criado duplicando um produto da categoria (com os complementos dele) e nasce pausado.`,
    source: 'regras',
    risk: 'medio',
    executable: false,
    combo: { name: s.name, description: s.componentNames.join(' + '), price: s.price, fullPrice: s.componentsTotal, components: comps },
  }
}

function recommendAction(f: Finding): ProposalAction {
  return {
    id: `rec:${f.id}`,
    kind: 'recommend',
    itemId: null,
    itemName: f.titulo,
    before: f.evidencia,
    after: f.sugestao,
    reason: f.evidencia,
    source: 'regras',
    risk: f.severidade,
    executable: false,
  }
}

export function buildLocalProposal(snapshot: MenuSnapshot, ctx: AnalysisContext, opts: { maxCombos?: number; withCombos?: boolean; version?: number; feedback?: string[] } = {}): Proposal {
  const maxCombos = opts.maxCombos ?? 3
  const combos = opts.withCombos === false ? [] : suggestCombos(snapshot, ctx).slice(0, maxCombos)
  const findings = runRules(snapshot, ctx).filter((f) => f.severidade !== 'baixo').slice(0, 8)
  const comboActions = combos.map((c) => comboAction(c, snapshot))
  const names = new Map<string, number>()
  for (const a of comboActions) {
    const n = (names.get(a.itemName) ?? 0) + 1
    names.set(a.itemName, n)
    if (n > 1 && a.combo) {
      a.itemName = `${a.itemName} (${a.combo.components.reduce((q, c) => q + c.quantity, 0)} itens)`
      a.combo.name = a.itemName
    }
  }
  const practice = practiceActions(snapshot, ctx)
  const actions = [...comboActions, ...practice, ...findings.map(recommendAction)]
  return {
    version: opts.version ?? 1,
    createdAt: new Date().toISOString(),
    summary: `${snapshot.items.length} produtos analisados: ${combos.length} combo(s), ${practice.filter((a) => a.kind === 'update_price').length} preço(s) para gatilho ,90 e ${findings.length} ponto(s) de atenção.`,
    actions,
    competitors: [],
    insights: [],
    sources: [],
    notices: [],
    feedback: opts.feedback ?? [],
  }
}

// ---------------------------------------------------------------------------
// Enriquecimento pelo servidor (IA + concorrentes)
// ---------------------------------------------------------------------------
export interface AiUpdate {
  ifood_id: string | null
  item_name: string
  before: { name: string; description: string | null; price: number }
  after: { name?: string; description?: string; price?: number }
  reason: string
  /** a IA usou dados de concorrentes para esta mudança */
  from_competitors?: boolean
}
export interface AiCombo {
  name: string
  description: string
  components: { ifood_id: string | null; name: string; quantity: number }[]
  price: number
  full_price: number
  reason: string
  from_competitors?: boolean
}
export interface AiAnalysis {
  summary: string
  updates: AiUpdate[]
  combos: AiCombo[]
  competitors?: CompetitorInsight[]
  insights?: string[]
  sources?: Source[]
}

export function mergeAi(base: Proposal, ai: AiAnalysis, snapshot: MenuSnapshot, ctx: AnalysisContext): Proposal {
  const actions = [...base.actions]
  const known = new Set(snapshot.items.map((i) => i.id))
  const locked = new Set(ctx.doNotTouchItemIds)
  for (const u of ai.updates) {
    const itemId = u.ifood_id && known.has(u.ifood_id) ? u.ifood_id : (snapshot.items.find((i) => i.name === u.item_name)?.id ?? null)
    if (!itemId || locked.has(itemId)) continue
    const src: ActionSource = u.from_competitors ? 'concorrentes' : 'ia'
    const push = (kind: ActionKind, before: string | number | null, after: string | number | undefined, risk: RiskLevel) => {
      if (after === undefined || after === before) return
      const dupAt = actions.findIndex((a) => a.id === `${kind}:${itemId}`)
      if (dupAt >= 0) actions.splice(dupAt, 1) // a IA (com concorrentes) vale mais que a regra local
      actions.push({ id: `${kind}:${itemId}`, kind, itemId, itemName: u.item_name, before, after, reason: u.reason, source: src, risk, executable: true })
    }
    push('update_name', u.before.name, u.after.name, 'baixo')
    push('update_description', u.before.description ?? '', u.after.description, 'baixo')
    if (!ctx.doNotTouchPrices) push('update_price', u.before.price, u.after.price, 'alto')
  }
  for (const c of ai.combos) {
    const comps = c.components.map((k) => ({ itemId: (k.ifood_id && known.has(k.ifood_id) ? k.ifood_id : snapshot.items.find((i) => i.name === k.name)?.id) ?? '', name: k.name, quantity: k.quantity }))
    if (comps.length < 2 || comps.some((k) => !k.itemId)) continue
    actions.push({
      id: `combo:ai:${comps.map((k) => k.itemId).join('+')}`,
      kind: 'create_combo',
      itemId: null,
      itemName: c.name,
      before: null,
      after: c.price,
      reason: c.reason,
      source: c.from_competitors ? 'concorrentes' : 'ia',
      risk: 'medio',
      executable: false,
      combo: { name: c.name, description: c.description, price: c.price, fullPrice: c.full_price, components: comps },
    })
  }
  const seen = new Set<string>()
  const unique = actions.filter((a) => (seen.has(a.id) ? false : (seen.add(a.id), true)))
  return {
    ...base,
    summary: ai.summary || base.summary,
    actions: unique,
    competitors: ai.competitors ?? [],
    insights: ai.insights ?? [],
    sources: ai.sources ?? [],
  }
}

// ---------------------------------------------------------------------------
// "Não fazer" → o que o usuário pensa vira ajustes explícitos
// ---------------------------------------------------------------------------
export interface FeedbackAdjust {
  ctx: AnalysisContext
  maxCombos: number
  withCombos: boolean
  understood: string[]
}

/** "não mexer", "não quero mexer", "sem alterar", "não precisa trocar"… */
const NEG = '(?:nao|sem)\\s+(?:quero\\s+|precisa\\s+|pode\\s+|vou\\s+|deve\\s+)?(?:mexer|mude|mudar|alterar|altere|trocar|tocar|tirar)'
const esc = (x: string) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const strip = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')

/**
 * Traduz o texto livre em ajustes verificáveis e DIZ o que entendeu. O texto
 * completo também segue para a IA (notes), então o que não for coberto aqui ainda
 * influencia a nova proposta.
 */
export function adjustFromFeedback(text: string, ctx: AnalysisContext, snapshot: MenuSnapshot, prev: { maxCombos: number; withCombos: boolean }): FeedbackAdjust {
  const t = strip(text)
  const out: FeedbackAdjust = { ctx: { ...ctx, doNotTouchItemIds: [...ctx.doNotTouchItemIds] }, maxCombos: prev.maxCombos, withCombos: prev.withCombos, understood: [] }
  if (new RegExp(`${NEG}\\D{0,20}(preco|valor)|preco.{0,12}(nao|fica|manter)|manter.{0,12}preco`).test(t)) {
    out.ctx.doNotTouchPrices = true
    out.understood.push('Não mexer em preços.')
  }
  const disc = t.match(/desconto\D{0,12}(\d{1,2})\s*%?|(\d{1,2})\s*%\s*(de\s+)?desconto/)
  const pct = disc ? Number(disc[1] ?? disc[2]) : NaN
  if (Number.isFinite(pct) && pct >= 0 && pct <= 50) {
    out.ctx.comboDiscountPercent = pct
    out.understood.push(`Desconto dos combos: ${pct}%.`)
  }
  if (/(sem|nao quero|nenhum|nada de)\s+combo/.test(t)) {
    out.withCombos = false
    out.understood.push('Sem combos nesta versão.')
  } else if (/(menos|poucos|so um|apenas um|1 combo)\s*(combo)?/.test(t) && /combo/.test(t)) {
    out.maxCombos = 1
    out.understood.push('Apenas 1 combo.')
  } else if (/(mais)\s+combo|combos?\s+(a\s+)?mais/.test(t)) {
    out.maxCombos = Math.min(3, prev.maxCombos + 1)
    out.understood.push('Mais combos.')
  }
  for (const cat of snapshot.categories) {
    const name = strip(cat.name)
    if (name.length >= 3 && new RegExp(`${NEG}\\D{0,16}${esc(name)}`).test(t)) {
      out.ctx.doNotTouchItemIds.push(...cat.itemIds)
      out.understood.push(`Não mexer na categoria “${cat.name}”.`)
    }
  }
  for (const item of snapshot.items) {
    const name = strip(item.name)
    if (name.length >= 4 && new RegExp(`${NEG}\\D{0,16}${esc(name)}`).test(t)) {
      out.ctx.doNotTouchItemIds.push(item.id)
      out.understood.push(`Não mexer em “${item.name}”.`)
    }
  }
  out.ctx.doNotTouchItemIds = [...new Set(out.ctx.doNotTouchItemIds)]
  return out
}

// ---------------------------------------------------------------------------
// Congelamento do aprovado
// ---------------------------------------------------------------------------
/** Hash estável (FNV-1a) do conteúdo EXECUTÁVEL de uma lista de ações. */
export function planHash(actions: ProposalAction[]): string {
  const canonical = JSON.stringify(
    actions.map((a) => [a.id, a.kind, a.itemId, a.before, a.after, a.schedule !== undefined ? [a.schedule] : null, a.combo ? [a.combo.name, a.combo.price, a.combo.components.map((c) => [c.itemId, c.quantity])] : null, ...(a.newItem ? [[a.newItem.baseItemId, a.newItem.description, a.newItem.price]] : [])]),
  )
  let h = 0x811c9dc5
  for (let i = 0; i < canonical.length; i += 1) {
    h ^= canonical.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return `${(h >>> 0).toString(16).padStart(8, '0')}-${actions.length}`
}

/** Respeita "sem combos" / "só N combos" do feedback (vale também para os combos vindos da IA). */
export function capCombos(p: Proposal, max: number, withCombos: boolean): Proposal {
  let kept = 0
  const actions = p.actions.filter((a) => {
    if (a.kind !== 'create_combo') return true
    if (!withCombos) return false
    kept += 1
    return kept <= max
  })
  return { ...p, actions }
}

export function defaultApproved(p: Proposal): Set<string> {
  return new Set(p.actions.filter((a) => a.kind !== 'recommend' && a.risk !== 'alto').map((a) => a.id))
}

export function freeze(p: Proposal, approvedIds: Set<string>): { actions: ProposalAction[]; hash: string } {
  const actions = p.actions.filter((a) => approvedIds.has(a.id) && a.kind !== 'recommend').map((a) => structuredClone(a))
  return { actions, hash: planHash(actions) }
}

// ---------------------------------------------------------------------------
// Otimizações feitas pelo gestor dentro da proposta + reprovação sem repetir ideias
// ---------------------------------------------------------------------------
export type ManualInput =
  | { kind: 'update_name' | 'update_description' | 'update_price' | 'set_status' | 'remove_item'; itemId: string; value: string }
  | { kind: 'update_schedule'; itemId: string; always: boolean; slots: { start: string; end: string; days: number[] }[] }
  | { kind: 'create_item'; name: string; description: string; price: string; baseItemId: string }

export type ManualResult = { ok: true; action: ProposalAction } | { ok: false; reason: string }

export const parseMoney = (raw: string): number | null => {
  const t = raw.replace(/[^\d,.]/g, '')
  if (!t) return null
  const n = Number(t.includes(',') ? t.replace(/\./g, '').replace(',', '.') : t)
  return Number.isFinite(n) && n > 0 && n <= 9999 ? Math.round(n * 100) / 100 : null
}

const clean = (v: string) => v.replace(/\s+/g, ' ').trim()

/** Valida e monta uma ação criada pelo gestor. O id é o mesmo da IA para o mesmo item/campo → substitui, não duplica. */
export function manualAction(input: ManualInput, snapshot: MenuSnapshot): ManualResult {
  if (input.kind === 'create_item') {
    const name = clean(input.name)
    if (name.length < 2) return { ok: false, reason: 'Dê um nome ao produto novo.' }
    const base = snapshot.items.find((i) => i.id === input.baseItemId)
    if (!base) return { ok: false, reason: 'Escolha o produto que será duplicado (de preferência da mesma categoria).' }
    const price = input.price.trim() ? parseMoney(input.price) : base.price
    if (input.price.trim() && price === null) return { ok: false, reason: 'Preço inválido. Use algo como 29,90.' }
    const description = input.description.trim()
    return {
      ok: true,
      action: {
        id: `create_item:${name.toLowerCase()}`, kind: 'create_item', itemId: null, itemName: name, before: null, after: name,
        reason: `Duplicar “${base.name}”${base.categoryName ? ` (categoria ${base.categoryName})` : ''} e ajustar nome, descrição${price !== null ? ', preço' : ''} e foto. Você pediu.`,
        source: 'voce', risk: 'baixo', executable: false,
        newItem: { baseItemId: base.id, baseItemName: base.name, description, price, categoryName: base.categoryName },
      },
    }
  }
  const item = snapshot.items.find((i) => i.id === input.itemId)
  if (!item) return { ok: false, reason: 'Escolha o produto.' }
  if (input.kind === 'update_schedule') {
    const hhmm = /^([01]\d|2[0-3]):[0-5]\d$/
    const norm = (t: string) => { const m = t.trim().match(/^(\d{1,2})(?::|h)?(\d{2})?$/); return m ? `${m[1]!.padStart(2, '0')}:${m[2] ?? '00'}` : t.trim() }
    let sc: Schedule | null = null
    if (!input.always) {
      if (!input.slots.length) return { ok: false, reason: 'Adicione ao menos uma faixa de horário.' }
      sc = input.slots.map((x) => ({ start: norm(x.start), end: norm(x.end), days: [...new Set(x.days)].filter((d) => d >= 0 && d <= 6).sort() }))
      for (const [n, x] of sc.entries()) {
        if (!hhmm.test(x.start) || !hhmm.test(x.end)) return { ok: false, reason: `Faixa ${n + 1}: horário inválido. Use algo como 10:00 e 12:00.` }
        if (x.start >= x.end) return { ok: false, reason: `Faixa ${n + 1}: o início precisa ser antes do fim (não dá para virar a meia-noite aqui).` }
        if (!x.days.length) return { ok: false, reason: `Faixa ${n + 1}: marque ao menos um dia da semana.` }
      }
      for (let d = 0; d < 7; d += 1) {
        const day = sc.filter((x) => x.days.includes(d)).sort((p, q) => p.start.localeCompare(q.start))
        for (let k = 1; k < day.length; k += 1) if (day[k]!.start < day[k - 1]!.end) return { ok: false, reason: `As faixas ${day[k - 1]!.start}–${day[k - 1]!.end} e ${day[k]!.start}–${day[k]!.end} se sobrepõem em ${DAY_SHORT[d]}.` }
      }
    }
    return { ok: true, action: { id: `update_schedule:${item.id}`, kind: 'update_schedule', itemId: item.id, itemName: item.name, before: null, after: scheduleLabel(sc), reason: 'Horário de venda pedido por você.', source: 'voce', risk: 'medio', executable: true, schedule: sc } }
  }
  const base = { id: `${input.kind}:${item.id}`, itemId: item.id, itemName: item.name, source: 'voce' as const, risk: 'baixo' as const }
  switch (input.kind) {
    case 'update_name': {
      const v = clean(input.value)
      if (v.length < 2) return { ok: false, reason: 'Escreva o novo nome.' }
      if (v === item.name) return { ok: false, reason: 'O nome novo é igual ao atual.' }
      return { ok: true, action: { ...base, kind: 'update_name', before: item.name, after: v, reason: 'Ajuste pedido por você.', executable: true } }
    }
    case 'update_description': {
      const v = input.value.trim()
      if (v === item.description.trim()) return { ok: false, reason: 'A descrição nova é igual à atual.' }
      return { ok: true, action: { ...base, kind: 'update_description', before: item.description || null, after: v, reason: 'Ajuste pedido por você.', executable: true } }
    }
    case 'update_price': {
      const v = parseMoney(input.value)
      if (v === null) return { ok: false, reason: 'Preço inválido. Use algo como 29,90.' }
      if (item.price !== null && v === item.price) return { ok: false, reason: 'O preço novo é igual ao atual.' }
      return { ok: true, action: { ...base, kind: 'update_price', before: item.price, after: v, reason: 'Ajuste pedido por você.', executable: true, risk: 'medio' } }
    }
    case 'set_status': {
      const to = input.value === 'active' ? 'active' : 'paused'
      return { ok: true, action: { ...base, kind: 'set_status', before: item.status === 'active' ? 'active' : 'paused', after: to, reason: to === 'paused' ? 'Pausar este produto (pedido por você).' : 'Ativar este produto (pedido por você).', executable: true } }
    }
    case 'remove_item':
      return { ok: true, action: { ...base, kind: 'remove_item', before: item.name, after: 'remover do cardápio', reason: 'Remoção pedida por você. É definitiva no iFood (não dá para desfazer) — só será feita se você aprovar.', executable: true, risk: 'alto' } }
  }
}

/** Entra na lista (no topo); se já existe ação com o mesmo id, ela é SUBSTITUÍDA. */
export function upsertAction(p: Proposal, a: ProposalAction): Proposal {
  const rest = p.actions.filter((x) => x.id !== a.id)
  return { ...p, actions: [a, ...rest] }
}
export function removeAction(p: Proposal, id: string): Proposal {
  return { ...p, actions: p.actions.filter((x) => x.id !== id) }
}

/** Chaves das ideias de uma proposta (usadas para não repetir o que foi reprovado). */
export function actionKeys(p: Proposal): string[] {
  return p.actions.filter((a) => a.kind !== 'recommend').map((a) => `${a.id}|${String(a.after)}`)
}
/** Tira da nova proposta as ideias idênticas às reprovadas. */
export function dropRejected(p: Proposal, rejected: Set<string>): { proposal: Proposal; dropped: number } {
  const keep = p.actions.filter((a) => a.kind === 'recommend' || a.source === 'voce' || !rejected.has(`${a.id}|${String(a.after)}`))
  return { proposal: { ...p, actions: keep }, dropped: p.actions.length - keep.length }
}
/** Resumo curto das ideias reprovadas para a IA não repetir (cabe no limite de 1200 caracteres das notas). */
export function rejectedBrief(p: Proposal, max = 600): string {
  const lines = p.actions.filter((a) => a.kind !== 'recommend').map((a) => `${KIND_LABEL[a.kind]} ${a.itemName}: ${fmtValue(a.kind, a.after)}`)
  let out = ''
  for (const l of lines) {
    if ((out + l).length + 3 > max) break
    out += `${out ? '; ' : ''}${l}`
  }
  return out
}
