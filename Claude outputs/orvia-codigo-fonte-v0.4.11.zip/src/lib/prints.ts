/**
 * "Prints" do que foi feito — imagens para enviar ao cliente (print 1.png, print 2.png, …).
 * Conteúdo (buildPrintPages) é puro e testado; o desenho (renderPrintPng) usa canvas
 * e roda no content script. Regras: nunca mostra erro como sucesso; mostra o status
 * real de cada ação e o que ficou para o cliente/gestor fazer.
 */
import { fmtValue, KIND_LABEL } from '../core/proposal'
import type { RunReport, Step, StepStatus } from './runner'

export interface PrintInput {
  clientName: string
  merchantName: string | null
  summary: string
  version: number
  date: Date
  report: RunReport
}

export type PrintRow =
  | { kind: 'kpi'; items: { label: string; value: string; tone: 'ok' | 'erro' | 'neutro' | 'info' }[] }
  | { kind: 'text'; text: string; muted?: boolean }
  | { kind: 'heading'; text: string }
  | { kind: 'step'; status: StepStatus; title: string; detail: string; note: string }

export interface PrintPage {
  /** 1-based; o arquivo é "print {index}.png" */
  index: number
  title: string
  subtitle: string
  rows: PrintRow[]
}

export const STATUS_LABEL: Record<StepStatus, string> = { pendente: 'PENDENTE', executando: 'EXECUTANDO', ok: 'OK', erro: 'ERRO', pulada: 'NÃO FEITA', assistida: 'ASSISTIDA' }
const ROWS_PER_PAGE = 6

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

function stepRow(s: Step): PrintRow {
  const a = s.action
  if (a.kind === 'create_combo' && a.combo) {
    return {
      kind: 'step',
      status: s.status,
      title: `Combo: ${a.combo.name}`,
      detail: `${a.combo.components.map((c) => `${c.quantity > 1 ? `${c.quantity}x ` : ''}${c.name}`).join(' + ')} — de ${fmtValue('update_price', a.combo.fullPrice)} por ${fmtValue('update_price', a.combo.price)}`,
      note: s.message,
    }
  }
  return {
    kind: 'step',
    status: s.status,
    title: `${KIND_LABEL[a.kind]} · ${a.itemName}`,
    detail: `${clip(fmtValue(a.kind, a.before), 70)}  →  ${clip(fmtValue(a.kind, a.after), 90)}`,
    note: s.status === 'ok' ? a.reason : s.message,
  }
}

export function buildPrintPages(input: PrintInput): PrintPage[] {
  const { report } = input
  const c = report.counts
  const done = c.ok + c.assistida
  const title = report.aborted ? 'Otimização interrompida' : c.erro > 0 || c.pulada > 0 ? 'Cardápio otimizado (parcial)' : 'Cardápio otimizado'
  const when = `${input.date.toLocaleDateString('pt-BR')} às ${input.date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
  const subtitle = `${input.clientName}${input.merchantName && input.merchantName !== input.clientName ? ` · ${input.merchantName}` : ''} · ${when}`

  const changes = report.steps.filter((s) => s.action.kind !== 'create_combo')
  const combos = report.steps.filter((s) => s.action.kind === 'create_combo')
  const notDone = report.steps.filter((s) => s.status === 'erro' || s.status === 'pulada')

  const pages: Omit<PrintPage, 'index'>[] = []
  pages.push({
    title,
    subtitle,
    rows: [
      { kind: 'kpi', items: [
        { label: 'Aplicadas no iFood', value: String(c.ok), tone: 'ok' },
        { label: 'Combos criados', value: String(c.assistida), tone: 'info' },
        { label: 'Não feitas', value: String(c.pulada), tone: c.pulada ? 'neutro' : 'ok' },
        { label: 'Com erro', value: String(c.erro), tone: c.erro ? 'erro' : 'ok' },
      ] },
      { kind: 'heading', text: 'Resumo da análise aprovada' },
      { kind: 'text', text: input.summary },
      { kind: 'text', text: `Proposta versão ${input.version} · ${report.steps.length} ação(ões) aprovada(s) · ${done} concluída(s).`, muted: true },
      ...(report.aborted ? ([{ kind: 'text', text: 'A execução foi interrompida pelo usuário (ESC). O que não começou não foi alterado.', muted: false }] as PrintRow[]) : []),
    ],
  })

  const chunks: Step[][] = []
  for (let i = 0; i < changes.length; i += ROWS_PER_PAGE) chunks.push(changes.slice(i, i + ROWS_PER_PAGE))
  if (chunks.length === 0) pages.push({ title: 'O que foi alterado', subtitle, rows: [{ kind: 'text', text: 'Nenhum ajuste direto em produtos nesta rodada.', muted: true }] })
  chunks.forEach((chunk, i) => pages.push({ title: `O que foi alterado${chunks.length > 1 ? ` (${i + 1}/${chunks.length})` : ''}`, subtitle, rows: chunk.map(stepRow) }))

  const last: PrintRow[] = []
  if (combos.length) {
    last.push({ kind: 'heading', text: 'Combos criados' })
    last.push(...combos.slice(0, 4).map(stepRow))
  }
  if (notDone.length) {
    last.push({ kind: 'heading', text: 'Ficou pendente' })
    last.push(...notDone.filter((s) => s.action.kind !== 'create_combo').slice(0, 3).map(stepRow))
  }
  if (!last.length) last.push({ kind: 'text', text: 'Sem pendências. Combos novos, quando houver, são revisados e ativados no painel antes de ir ao ar.', muted: true })
  pages.push({ title: 'Combos e próximos passos', subtitle, rows: last })

  return pages.map((p, i) => ({ ...p, index: i + 1 }))
}

export const printFileName = (index: number) => `print ${index}.png`

// ---------------------------------------------------------------------------
// Canvas (browser)
// ---------------------------------------------------------------------------
const W = 1080
const H = 1350
const TONE = {
  ok: { fg: '#0F7B55', bg: '#E4F6EE' },
  erro: { fg: '#B42318', bg: '#FDECEA' },
  neutro: { fg: '#6B7280', bg: '#F1F3F7' },
  info: { fg: '#1D5FD6', bg: '#E6EFFF' },
}
const STATUS_TONE: Record<StepStatus, keyof typeof TONE> = { ok: 'ok', erro: 'erro', pulada: 'neutro', assistida: 'info', pendente: 'neutro', executando: 'info' }
const FONT = 'Inter, "Segoe UI", system-ui, -apple-system, Arial, sans-serif'

function wrapCanvas(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const out: string[] = []
  for (const para of text.split('\n')) {
    let line = ''
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const next = line ? `${line} ${word}` : word
      if (ctx.measureText(next).width <= maxW || !line) line = next
      else {
        out.push(line)
        line = word
      }
    }
    out.push(line)
  }
  return out
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

export function renderPrintPng(page: PrintPage, total: number): string {
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')!
  ctx.fillStyle = '#FFFFFF'
  ctx.fillRect(0, 0, W, H)
  // faixa azul Orvia
  ctx.fillStyle = '#3D8EFF'
  ctx.fillRect(0, 0, W, 150)
  ctx.fillStyle = '#FFFFFF'
  roundRect(ctx, 56, 42, 66, 66, 18)
  ctx.fill()
  ctx.fillStyle = '#3D8EFF'
  ctx.font = `800 40px ${FONT}`
  ctx.textBaseline = 'middle'
  ctx.fillText('O', 78, 76)
  ctx.fillStyle = '#FFFFFF'
  ctx.font = `700 34px ${FONT}`
  ctx.fillText('Orvia', 140, 76)
  ctx.font = `500 22px ${FONT}`
  ctx.textAlign = 'right'
  ctx.fillText(`print ${page.index} de ${total}`, W - 56, 76)
  ctx.textAlign = 'left'
  ctx.textBaseline = 'alphabetic'

  let y = 230
  ctx.fillStyle = '#0B1220'
  ctx.font = `800 54px ${FONT}`
  for (const l of wrapCanvas(ctx, page.title, W - 112)) {
    ctx.fillText(l, 56, y)
    y += 62
  }
  ctx.fillStyle = '#6B7280'
  ctx.font = `500 26px ${FONT}`
  for (const l of wrapCanvas(ctx, page.subtitle, W - 112)) {
    ctx.fillText(l, 56, y)
    y += 36
  }
  y += 24

  for (const row of page.rows) {
    if (row.kind === 'kpi') {
      const w = (W - 112 - 18 * (row.items.length - 1)) / row.items.length
      row.items.forEach((k, i) => {
        const x = 56 + i * (w + 18)
        ctx.fillStyle = TONE[k.tone].bg
        roundRect(ctx, x, y, w, 150, 20)
        ctx.fill()
        ctx.fillStyle = TONE[k.tone].fg
        ctx.font = `800 64px ${FONT}`
        ctx.fillText(k.value, x + 22, y + 82)
        ctx.font = `600 20px ${FONT}`
        wrapCanvas(ctx, k.label, w - 36).forEach((l, li) => ctx.fillText(l, x + 22, y + 116 + li * 24))
      })
      y += 190
    } else if (row.kind === 'heading') {
      y += 12
      ctx.fillStyle = '#3D8EFF'
      ctx.font = `800 24px ${FONT}`
      ctx.fillText(row.text.toUpperCase(), 56, y)
      y += 40
    } else if (row.kind === 'text') {
      ctx.fillStyle = row.muted ? '#6B7280' : '#111827'
      ctx.font = `${row.muted ? 500 : 600} 28px ${FONT}`
      for (const l of wrapCanvas(ctx, row.text, W - 112)) {
        ctx.fillText(l, 56, y)
        y += 40
      }
      y += 10
    } else {
      const tone = TONE[STATUS_TONE[row.status]]
      const top = y
      ctx.font = `700 28px ${FONT}`
      const titleLines = wrapCanvas(ctx, row.title, W - 112 - 200).slice(0, 2)
      ctx.font = `500 24px ${FONT}`
      const detailLines = wrapCanvas(ctx, row.detail, W - 112 - 40).slice(0, 3)
      ctx.font = `500 21px ${FONT}`
      const noteLines = wrapCanvas(ctx, row.note, W - 112 - 40).slice(0, 2)
      const h = 28 + titleLines.length * 36 + detailLines.length * 32 + noteLines.length * 28 + 22
      ctx.fillStyle = '#F8FAFD'
      roundRect(ctx, 56, top, W - 112, h, 18)
      ctx.fill()
      ctx.strokeStyle = '#E3E8F2'
      ctx.lineWidth = 2
      ctx.stroke()
      // selo de status
      const label = STATUS_LABEL[row.status]
      ctx.font = `800 20px ${FONT}`
      const bw = ctx.measureText(label).width + 36
      ctx.fillStyle = tone.bg
      roundRect(ctx, W - 56 - 20 - bw, top + 18, bw, 40, 20)
      ctx.fill()
      ctx.fillStyle = tone.fg
      ctx.fillText(label, W - 56 - 20 - bw + 18, top + 46)
      let ty = top + 50
      ctx.fillStyle = '#0B1220'
      ctx.font = `700 28px ${FONT}`
      titleLines.forEach((l) => {
        ctx.fillText(l, 76, ty)
        ty += 36
      })
      ctx.fillStyle = '#1F2937'
      ctx.font = `500 24px ${FONT}`
      detailLines.forEach((l) => {
        ctx.fillText(l, 76, ty)
        ty += 32
      })
      ctx.fillStyle = row.status === 'erro' ? '#B42318' : '#6B7280'
      ctx.font = `500 21px ${FONT}`
      noteLines.forEach((l) => {
        ctx.fillText(l, 76, ty)
        ty += 28
      })
      y = top + h + 16
    }
    if (y > H - 110) break
  }
  ctx.fillStyle = '#9AA4B5'
  ctx.font = `500 20px ${FONT}`
  ctx.fillText('Relatório gerado pela Orvia · valores e status conferidos no momento da execução', 56, H - 44)
  return canvas.toDataURL('image/png')
}
