/**
 * Ordem das categorias — receita OBSERVADA no portal real (gravação do usuário):
 *   GET   /next-web-bff/menu/v4/category?ownerUUID=…                 → lista na ordem atual: [{categoryId,name,…}]
 *   PATCH /next-web-bff/menu/v4/sequence/order?ownerUUID=…           → {categories:[{id,order}],items:[],optionGroups:[],options:[]}
 * A lista enviada precisa conter TODAS as categorias (a gravação tem as 11 da loja).
 * Boas práticas: promoções/combos no topo → destaques → pratos → acompanhamentos → bebidas → sobremesas.
 */
import type { PortalRequest } from './executor'
import type { PortalCtx } from './item-editor'
import type { MenuSnapshot } from '../core/schema'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300

export interface CatRef { id: string; name: string }

const rank = (name: string): number => {
  if (/combo|promo|oferta|kit\b|fam[ií]lia|econom/i.test(name)) return 0
  if (/destaque|mais pedid|popular|campe|favorit|recomend|sugest/i.test(name)) return 1
  if (/sobremesa|doce|ado[cç]ar|sorvete|bolo|torta|picol[eé]|brigadeiro/i.test(name)) return 5
  if (/bebida|suco|refri|drink|cerveja|[aá]gua|vitamina|caf[eé]\b/i.test(name)) return 4
  if (/acompanh|adicion|por[cç][aã]o|porcoes|extra|molho|complemento/i.test(name)) return 3
  return 2
}

/** Ordem sugerida (estável: dentro do mesmo grupo mantém a ordem atual). null = já está boa. */
export function suggestCategoryOrder(snapshot: MenuSnapshot): CatRef[] | null {
  const cur = [...snapshot.categories].sort((a, b) => a.position - b.position).map((c) => ({ id: c.id, name: c.name }))
  if (cur.length < 3) return null
  const next = cur.map((c, i) => ({ c, i, r: rank(c.name) })).sort((a, b) => a.r - b.r || a.i - b.i).map((x) => x.c)
  return next.every((c, i) => c.id === cur[i]!.id) ? null : next
}

/** Move uma categoria para a posição `position` (1 = topo), partindo de `from`. */
export function moveCategory(from: CatRef[], categoryId: string, position: number): CatRef[] | null {
  const i = from.findIndex((c) => c.id === categoryId)
  if (i < 0) return null
  const to = Math.max(0, Math.min(from.length - 1, Math.round(position) - 1))
  if (to === i) return null
  const next = [...from]
  const [m] = next.splice(i, 1)
  next.splice(to, 0, m!)
  return next
}

export const currentCategoryOrder = (snapshot: MenuSnapshot): CatRef[] => [...snapshot.categories].sort((a, b) => a.position - b.position).map((c) => ({ id: c.id, name: c.name }))

const liveOrder = (json: unknown): string[] | null => {
  const arr = Array.isArray(json) ? json : isRec(json) && Array.isArray(json.data) ? json.data : null
  if (!arr) return null
  const ids = arr.map((e) => (isRec(e) ? (typeof e.categoryId === 'string' ? e.categoryId : typeof e.id === 'string' ? e.id : null) : null))
  return ids.every((x): x is string => !!x) ? ids : null
}

export async function reorderCategories(o: { order: CatRef[]; ctx: PortalCtx; request: PortalRequest }): Promise<{ ok: boolean; message: string }> {
  const { ctx, request } = o
  const listUrl = `${ctx.origin}/next-web-bff/menu/v4/category?ownerUUID=${encodeURIComponent(ctx.ownerId)}`
  const live = await request('GET', listUrl)
  const liveIds = ok2xx(live.status) ? liveOrder(live.json) : null
  if (!liveIds || !liveIds.length) return { ok: false, message: 'Não consegui ler a lista de categorias do iFood — ordem não alterada.' }
  const known = new Set(liveIds)
  const wanted = o.order.map((c) => c.id).filter((id) => known.has(id))
  if (wanted.length !== o.order.length) return { ok: false, message: 'O cardápio mudou (categoria que não existe mais). Sincronize e analise de novo — ordem não alterada.' }
  const rest = liveIds.filter((id) => !wanted.includes(id)) // categorias vazias/novas ficam no fim, na ordem em que estavam
  const finalIds = [...wanted, ...rest]
  if (finalIds.every((id, i) => id === liveIds[i])) return { ok: true, message: 'As categorias já estavam nesta ordem.' }
  const res = await request('PATCH', `${ctx.origin}/next-web-bff/menu/v4/sequence/order?ownerUUID=${encodeURIComponent(ctx.ownerId)}`, {
    categories: finalIds.map((id, order) => ({ id, order })),
    items: [],
    optionGroups: [],
    options: [],
  })
  if (!ok2xx(res.status)) return { ok: false, message: `O iFood recusou a nova ordem das categorias (HTTP ${res.status}).` }
  const after = await request('GET', listUrl)
  const afterIds = ok2xx(after.status) ? liveOrder(after.json) : null
  if (!afterIds) return { ok: true, message: 'Ordem enviada (HTTP 200), mas não consegui reler para conferir.' }
  const same = afterIds.length === finalIds.length && afterIds.every((id, i) => id === finalIds[i])
  return same ? { ok: true, message: `Categorias reordenadas e conferidas no iFood (${finalIds.length}).` } : { ok: false, message: 'Enviei a ordem, mas o iFood ainda mostra a anterior. Confira no portal.' }
}
