/**
 * Editor de produto do iFood (nome e descrição) — receita OBSERVADA no portal real:
 *   GET  /partner-catalog-bff/product/{productId}?ownerId=…            (produto)
 *   GET  /partner-catalog-bff/product/{productId}/available-at?ownerId=… (categorias/preço/horário)
 *   PUT  /partner-catalog-bff/v2/item?ownerId=…                         (produto inteiro + categorias)
 * O corpo do PUT é remontado a partir das duas leituras (receita conferida byte a byte contra um PUT
 * real do portal — ver tests/real-item-edit.test.ts). Qualquer estrutura desconhecida ABORTA sem enviar.
 * Depois de gravar, relê e confere; se algo além do pedido mudou, tenta restaurar o corpo original.
 * Puro: sem chrome.*, sem DOM (o `request` é injetado).
 */
import type { PortalRequest } from './executor'
import type { Schedule } from '../core/proposal'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)

export interface PortalCtx {
  /** ex.: https://portal-api.ifood.com.br */
  origin: string
  ownerId: string
}

export type Built = { ok: true; body: Rec } | { ok: false; reason: string }

const PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'variant', 'unit', 'optionGroups', 'promotions', 'shouldBlock', 'tags', 'classification'])
const GROUP_KEYS = new Set(['id', 'name', 'status', 'type', 'sequence', 'min', 'max', 'options'])
const OPTION_KEYS = new Set(['id', 'name', 'description', 'sequence', 'product', 'status', 'extensions'])
const OPTION_PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'optionGroups', 'tags', 'classification', 'stock'])
const EXT_KEYS = new Set(['status', 'price', 'catalogType', 'restrictions', 'promotions', 'itemExtensionId'])
const OPT_EXT_KEYS = new Set(['status', 'price', 'catalogType', 'promotions', 'restrictions'])
const AVAIL_KEYS = new Set(['id', 'name', 'status', 'type', 'offerId', 'extensions', 'shifts'])

const unknownKeys = (o: Rec, known: Set<string>) => Object.keys(o).filter((k) => !known.has(k))
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const
const SHIFT_KEYS = new Set(['startTime', 'endTime', 'default', ...DAYS])
const shiftOk = (x: unknown): x is Rec => isRec(x) && !unknownKeys(x, SHIFT_KEYS).length && typeof x.startTime === 'string' && typeof x.endTime === 'string'
/** faixas (do iFood) → conjunto "dia|início|fim" para comparar horários sem depender do formato */
export function shiftSet(shifts: unknown): string[] {
  if (!Array.isArray(shifts) || shifts.length === 0 || allDay(shifts)) return ['sempre']
  const out: string[] = []
  for (const x of shifts) if (isRec(x)) DAYS.forEach((d, i) => { if (x[d] === true) out.push(`${i}|${x.startTime}|${x.endTime}`) })
  return out.sort()
}
export const scheduleSet = (sc: Schedule | null): string[] => (!sc || !sc.length ? ['sempre'] : sc.flatMap((x) => x.days.map((d) => `${d}|${x.start}|${x.end}`)).sort())
const toShifts = (sc: Schedule): Rec[] => sc.flatMap((x) => x.days.map((d) => ({ startTime: x.start, endTime: x.end, ...Object.fromEntries(DAYS.map((n, i) => [n, i === d])) })))
const allDay = (shifts: unknown): boolean => {
  if (!Array.isArray(shifts) || shifts.length === 0) return true
  if (shifts.length !== 1 || !isRec(shifts[0])) return false
  const s = shifts[0]
  return s.startTime === '00:00' && s.endTime === '23:59' && ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].every((d) => s[d] === true)
}

/** Remonta o corpo do PUT /v2/item a partir das leituras. */
export function buildItemBody(product: unknown, availableAt: unknown, over: { name?: string; description?: string; schedule?: Schedule | null } = {}): Built {
  if (!isRec(product) || typeof product.id !== 'string') return { ok: false, reason: 'leitura do produto inesperada' }
  if (!Array.isArray(availableAt) || availableAt.length === 0) return { ok: false, reason: 'não achei em quais categorias o produto está' }
  const badP = unknownKeys(product, PRODUCT_KEYS)
  if (badP.length) return { ok: false, reason: `produto com campos que não conheço (${badP.join(', ')}) — não alterado` }
  if (typeof product.name !== 'string' || !isRec(product.imageResource) || !Array.isArray(product.optionGroups) || !Array.isArray(product.promotions) || !Array.isArray(product.tags)) return { ok: false, reason: 'produto sem campos esperados' }

  const categories: Rec[] = []
  for (const c of availableAt) {
    if (!isRec(c) || !isRec(c.extensions) || typeof c.id !== 'string' || typeof c.offerId !== 'string') return { ok: false, reason: 'categoria do produto inesperada' }
    if (unknownKeys(c, AVAIL_KEYS).length) return { ok: false, reason: 'categoria com campos que não conheço — não alterada' }
    if (Array.isArray(c.shifts) && !c.shifts.every(shiftOk)) return { ok: false, reason: `horário de “${String(c.name)}” com campos que não conheço — não alterado` }
    const keep = !allDay(c.shifts)
    const shifts: Rec[] = over.schedule !== undefined ? (over.schedule && over.schedule.length ? toShifts(over.schedule) : []) : keep ? (c.shifts as Rec[]).map(({ default: _d, ...r }) => r) : []
    const availability = shifts.length ? 'SHIFTS' : 'ALWAYS'
    const extensions: Rec[] = []
    for (const [id, e] of Object.entries(c.extensions)) {
      if (!isRec(e) || unknownKeys(e, EXT_KEYS).length) return { ok: false, reason: 'preço/canal com campos que não conheço — não alterado' }
      extensions.push({ status: e.status, price: e.price, catalogType: e.catalogType, restrictions: e.restrictions ?? [], promotions: e.promotions ?? [], itemExtensionId: e.itemExtensionId, id })
    }
    categories.push({ action: 'UPDATE', availability, categoryId: c.id, extensions, name: c.name, offerId: c.offerId, shifts, itemsCount: 0 })
  }

  const optionGroups: Rec[] = []
  for (const g of product.optionGroups) {
    if (!isRec(g) || unknownKeys(g, GROUP_KEYS).length || !Array.isArray(g.options)) return { ok: false, reason: 'grupo de complementos com campos que não conheço — não alterado' }
    const options: Rec[] = []
    for (const o of g.options) {
      if (!isRec(o) || unknownKeys(o, OPTION_KEYS).length || !isRec(o.product) || !isRec(o.extensions)) return { ok: false, reason: 'complemento com campos que não conheço — não alterado' }
      if (unknownKeys(o.product, OPTION_PRODUCT_KEYS).length) return { ok: false, reason: 'complemento com campos que não conheço — não alterado' }
      const prod: Rec = { ...o.product }
      prod.imageResource ??= { baseUrl: '', path: '' }
      prod.stock = null
      const oext: Rec[] = []
      for (const [id, e] of Object.entries(o.extensions)) {
        if (!isRec(e) || unknownKeys(e, OPT_EXT_KEYS).length) return { ok: false, reason: 'preço de complemento com campos que não conheço — não alterado' }
        oext.push({ status: e.status, price: e.price, catalogType: e.catalogType, promotions: e.promotions ?? [], ...(e.restrictions !== undefined ? { restrictions: e.restrictions } : {}), id })
      }
      options.push({ id: o.id, sequence: o.sequence, product: prod, status: o.status, extensions: oext })
    }
    optionGroups.push({ id: g.id, name: g.name, status: g.status, type: g.type ?? '', sequence: g.sequence, min: g.min, max: g.max, options })
  }

  return {
    ok: true,
    body: {
      categories,
      stock: null,
      shouldBlock: product.shouldBlock,
      promotions: product.promotions,
      combo: false,
      comboOptionGroups: [],
      imageResource: product.imageResource,
      tags: product.tags,
      unit: typeof product.unit === 'string' && product.unit ? product.unit : 'g',
      variant: product.variant,
      industrialized: product.industrialized,
      description: over.description ?? (typeof product.description === 'string' ? product.description : ''),
      name: over.name ?? product.name,
      optionGroups,
      productId: product.id,
    },
  }
}

const ok2xx = (s: number) => s >= 200 && s < 300
const urlOf = (ctx: PortalCtx, path: string) => `${ctx.origin}${path}?ownerId=${encodeURIComponent(ctx.ownerId)}`

/** campos do produto que NÃO podem mudar numa edição de nome/descrição */
const comparable = (p: unknown): string => {
  if (!isRec(p)) return ''
  const { name: _n, description: _d, unit: _u, classification: _c, ...rest } = p
  return JSON.stringify(rest)
}

export async function editItem(opts: { productId: string; ctx: PortalCtx; request: PortalRequest; changes: { name?: string; description?: string; schedule?: Schedule | null } }): Promise<{ ok: boolean; message: string }> {
  const { productId, ctx, request, changes } = opts
  if (!changes.name && changes.description === undefined && changes.schedule === undefined) return { ok: true, message: 'Nada a alterar.' }
  if (changes.name !== undefined && changes.name.trim().length < 2) return { ok: false, message: 'Nome novo vazio — não alterado.' }
  const pUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}`)
  const aUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}/available-at`)
  const [p, a] = [await request('GET', pUrl), await request('GET', aUrl)]
  if (!ok2xx(p.status) || !ok2xx(a.status)) return { ok: false, message: `Não consegui ler o produto no iFood (HTTP ${p.status}/${a.status}).` }
  if (!isRec(p.json) || p.json.id !== productId) return { ok: false, message: 'O iFood devolveu outro produto — nada foi enviado.' }

  const original = buildItemBody(p.json, a.json)
  if (!original.ok) return { ok: false, message: original.reason }
  const wanted = buildItemBody(p.json, a.json, { name: changes.name?.trim(), description: changes.description, schedule: changes.schedule })
  if (!wanted.ok) return { ok: false, message: wanted.reason }
  if (JSON.stringify(original.body) === JSON.stringify(wanted.body)) return { ok: true, message: 'O iFood já está igual.' }

  const put = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), wanted.body)
  if (!ok2xx(put.status)) return { ok: false, message: `O iFood recusou a alteração (HTTP ${put.status}).` }

  const check = await request('GET', pUrl)
  const after = check.json
  const nameOk = changes.name === undefined || (isRec(after) && after.name === changes.name.trim())
  const descOk = changes.description === undefined || (isRec(after) && (after.description ?? '') === changes.description)
  const restOk = comparable(after) === comparable(p.json)
  let schedOk = true
  if (changes.schedule !== undefined) {
    const av = await request('GET', aUrl)
    const want = scheduleSet(changes.schedule)
    schedOk = ok2xx(av.status) && Array.isArray(av.json) && av.json.length > 0 && av.json.every((c) => isRec(c) && JSON.stringify(shiftSet(c.shifts)) === JSON.stringify(want))
  }
  if (ok2xx(check.status) && nameOk && descOk && restOk && schedOk) return { ok: true, message: 'Aplicado e conferido no iFood.' }
  if (!restOk) {
    const undo = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), original.body)
    return { ok: false, message: `Conferência falhou: outros campos do produto mudaram. ${ok2xx(undo.status) ? 'Restaurei o original.' : 'Não consegui restaurar — confira o produto no portal.'}` }
  }
  if (!schedOk) return { ok: false, message: 'Enviado, mas o iFood ainda mostra o horário antigo. Confira no portal.' }
  return { ok: false, message: 'Enviado, mas o iFood ainda mostra o valor antigo. Confira no portal.' }
}
