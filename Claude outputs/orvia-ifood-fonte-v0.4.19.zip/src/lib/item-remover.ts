/**
 * Exclusão de produto da categoria — receita OBSERVADA no portal real (gravação do usuário):
 *   DELETE /next-web-bff/menu/v4/item/{offerId}?ownerUUID=…   → 200
 * É definitiva. Só roda para ação aprovada; confere relendo o item (deve sumir).
 */
import type { PortalRequest } from './executor'
import type { PortalCtx } from './item-editor'

export async function removeItem(o: { itemId: string; name: string; ctx: PortalCtx; request: PortalRequest }): Promise<{ ok: boolean; message: string }> {
  const url = `${o.ctx.origin}/next-web-bff/menu/v4/item/${encodeURIComponent(o.itemId)}?ownerUUID=${encodeURIComponent(o.ctx.ownerId)}`
  const before = await o.request('GET', url)
  if (before.status === 404) return { ok: true, message: `“${o.name}” já não está no cardápio.` }
  const del = await o.request('DELETE', url)
  if (del.status < 200 || del.status >= 300) return { ok: false, message: `O iFood recusou excluir “${o.name}” (HTTP ${del.status}).` }
  const after = await o.request('GET', url)
  if (after.status >= 200 && after.status < 300 && after.json && typeof after.json === 'object' && Object.keys(after.json as object).length) {
    return { ok: false, message: `Pedi a exclusão de “${o.name}”, mas o iFood ainda mostra o item. Confira no portal.` }
  }
  return { ok: true, message: `“${o.name}” excluído do cardápio e conferido no iFood.` }
}
