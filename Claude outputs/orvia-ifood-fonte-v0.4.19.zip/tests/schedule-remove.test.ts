import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-edit.json'
import { buildItemBody, editItem, scheduleSet, shiftSet } from '../src/lib/item-editor'
import { removeItem } from '../src/lib/item-remover'
import { manualAction, scheduleLabel } from '../src/core/proposal'
import type { MenuSnapshot } from '../src/core/schema'

const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'own-1' }
const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x))

describe('horário de venda (gravação real: availability SHIFTS, uma faixa por dia)', () => {
  it('monta SHIFTS com uma faixa por dia e sem o campo default', () => {
    const b = buildItemBody(fx.productBefore, fx.availableAt, { schedule: [{ start: '14:00', end: '19:00', days: [0, 4] }] })
    expect(b.ok).toBe(true)
    if (!b.ok) return
    const c = (b.body.categories as any[])[0]
    expect(c.availability).toBe('SHIFTS')
    expect(c.shifts).toEqual([
      { startTime: '14:00', endTime: '19:00', monday: true, tuesday: false, wednesday: false, thursday: false, friday: false, saturday: false, sunday: false },
      { startTime: '14:00', endTime: '19:00', monday: false, tuesday: false, wednesday: false, thursday: false, friday: true, saturday: false, sunday: false },
    ])
  })
  it('null = volta para ALWAYS sem faixas', () => {
    const b = buildItemBody(fx.productBefore, fx.availableAt, { schedule: null })
    expect(b.ok && (b.body.categories as any[])[0].availability).toBe('ALWAYS')
    expect(b.ok && (b.body.categories as any[])[0].shifts).toEqual([])
  })
  it('editItem com horário: envia, relê e confere', async () => {
    let shifts: unknown = clone(fx.availableAt[0]!.shifts)
    const request = async (method: string, url: string, body?: any) => {
      if (method === 'PUT') { shifts = body.categories[0].shifts; return { status: 200, json: null } }
      if (url.includes('/available-at')) return { status: 200, json: [{ ...clone(fx.availableAt[0]), shifts }] }
      return { status: 200, json: clone(fx.productBefore) }
    }
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { schedule: [{ start: '10:00', end: '12:00', days: [0, 1, 2, 3, 4, 5, 6] }, { start: '15:00', end: '21:00', days: [0, 1, 2, 3, 4, 5, 6] }] } })
    expect(r.ok).toBe(true)
    expect(shiftSet(shifts)).toHaveLength(14)
    expect(shiftSet(shifts)).toContain('3|15:00|21:00')
    expect(shiftSet(shifts)).toContain('3|10:00|12:00')
  })
  it('ação manual: duas faixas com intervalo, validações e sobreposição', () => {
    const snap = { items: [{ id: 'i1', name: 'Bolo', price: 5, description: '', status: 'active', categoryId: 'c', categoryName: 'C', productId: 'p' }] } as unknown as MenuSnapshot
    const all = [0, 1, 2, 3, 4, 5, 6]
    const ok = manualAction({ kind: 'update_schedule', itemId: 'i1', always: false, slots: [{ start: '10h', end: '12:00', days: all }, { start: '15:00', end: '21:00', days: [0, 1] }] }, snap)
    expect(ok.ok && ok.action.after).toBe('10:00–12:00 · todos os dias + 15:00–21:00 · seg, ter')
    const bad = (slots: any[]) => manualAction({ kind: 'update_schedule', itemId: 'i1', always: false, slots }, snap).ok
    expect(bad([{ start: '19:00', end: '14:00', days: [0] }])).toBe(false)
    expect(bad([{ start: '10:00', end: '12:00', days: [] }])).toBe(false)
    expect(bad([])).toBe(false)
    expect(bad([{ start: '10:00', end: '13:00', days: all }, { start: '12:00', end: '15:00', days: [2] }])).toBe(false)
    expect(bad([{ start: '10:00', end: '12:00', days: [0] }, { start: '11:00', end: '15:00', days: [1] }])).toBe(true) // dias diferentes não colidem
    expect(scheduleLabel(null)).toBe('sempre disponível')
  })
})

describe('excluir produto (DELETE gravado)', () => {
  it('apaga e confere que sumiu', async () => {
    let gone = false
    const calls: string[] = []
    const request = async (method: string, url: string) => {
      calls.push(`${method} ${url}`)
      if (method === 'DELETE') { gone = true; return { status: 200, json: null } }
      return gone ? { status: 404, json: null } : { status: 200, json: { id: 'x', name: 'A' } }
    }
    const r = await removeItem({ itemId: 'off-1', name: 'A', ctx, request })
    expect(r.ok).toBe(true)
    expect(calls).toContain('DELETE https://portal-api.ifood.com.br/next-web-bff/menu/v4/item/off-1?ownerUUID=own-1')
  })
  it('recusa do iFood vira erro', async () => {
    const request = async (method: string) => (method === 'DELETE' ? { status: 403, json: null } : { status: 200, json: { id: 'x' } })
    expect((await removeItem({ itemId: 'o', name: 'A', ctx, request })).ok).toBe(false)
  })
})
