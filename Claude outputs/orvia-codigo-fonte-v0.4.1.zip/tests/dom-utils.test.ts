import { describe, expect, it } from 'vitest'
import { dataUrlToBase64, safeFileName } from '../src/content/dom-utils'

describe('dom-utils', () => {
  it('safeFileName mantém acentos e remove o que o worker recusaria', () => {
    expect(safeFileName('Proposta Orvia - Hamburgueria do Zé', 'pdf')).toBe('Proposta Orvia - Hamburgueria do Zé.pdf')
    expect(safeFileName('Pizza/Lanches: <teste>*?', 'pdf')).toBe('PizzaLanches teste.pdf')
    expect(safeFileName('', 'png')).toBe('Orvia.png')
    // o nome produzido sempre passa na validação do worker
    const re = /^[\w .()\-À-ÿ]{1,80}\.(png|pdf)$/i
    for (const n of ['Café & Cia ™', 'print 1', 'a'.repeat(200)]) expect(safeFileName(n, 'png')).toMatch(re)
  })
  it('dataUrlToBase64', () => {
    expect(dataUrlToBase64('data:image/png;base64,QUJD')).toBe('QUJD')
    expect(dataUrlToBase64('lixo')).toBe('')
  })
})
