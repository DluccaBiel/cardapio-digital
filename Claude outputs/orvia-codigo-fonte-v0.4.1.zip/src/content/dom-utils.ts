/** Utilidades de DOM/arquivo do painel. Sem estado; o que é puro é testado em tests/dom-utils.test.ts. */

/** "Proposta Orvia - Hamburgueria do Zé.pdf": só caracteres aceitos pelo worker de downloads. */
export function safeFileName(base: string, ext: 'pdf' | 'png'): string {
  const clean = base
    .normalize('NFC')
    .replace(/[^\w .()\-À-ÿ]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60)
  return `${clean || 'Orvia'}.${ext}`
}

export function dataUrlToBase64(dataUrl: string): string {
  const i = dataUrl.indexOf('base64,')
  return i < 0 ? '' : dataUrl.slice(i + 7)
}

export function bytesToDataUrl(bytes: Uint8Array, mime: string): string {
  let bin = ''
  const chunk = 0x8000
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode(...bytes.subarray(i, i + chunk))
  return `data:${mime};base64,${btoa(bin)}`
}

/** Quantos preços ("R$ 12,90") a tela mostra — usado só para avisar de leitura incompleta. */
export function countPricesOnScreen(doc: Document): number {
  const text = doc.body?.innerText ?? ''
  return (text.match(/R\$\s*\d/g) ?? []).length
}

/** Nome da loja exibido no portal, quando houver um cabeçalho óbvio (melhor esforço). */
export function guessMerchantName(doc: Document): string | null {
  const candidates = ['[data-testid*="merchant" i]', '[data-testid*="store-name" i]', '[class*="merchant-name" i]', 'header h1', 'h1']
  for (const sel of candidates) {
    const el = doc.querySelector(sel)
    const t = el?.textContent?.trim()
    if (t && t.length >= 2 && t.length <= 80) return t
  }
  return null
}

/**
 * Rola a página e os contêineres rolavéis para disparar carregamento preguiçoso
 * (listas virtualizadas, "carregar mais"). Cancelável.
 */
export async function autoScroll(doc: Document, opts: { maxMs?: number; isCancelled: () => boolean; onTick?: () => void }): Promise<void> {
  const maxMs = opts.maxMs ?? 9000
  const start = Date.now()
  const scrollers = (): HTMLElement[] => {
    const out: HTMLElement[] = []
    const root = (doc.scrollingElement as HTMLElement | null) ?? doc.documentElement
    if (root.scrollHeight > root.clientHeight + 100) out.push(root)
    doc.querySelectorAll<HTMLElement>('main, section, div, ul').forEach((el) => {
      if (out.length >= 8) return
      const st = getComputedStyle(el)
      if ((st.overflowY === 'auto' || st.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 200) out.push(el)
    })
    return out
  }
  const targets = scrollers()
  for (const el of targets) {
    const original = el.scrollTop
    let last = -1
    while (Date.now() - start < maxMs && !opts.isCancelled()) {
      el.scrollTop += Math.max(300, el.clientHeight * 0.8)
      opts.onTick?.()
      await new Promise((r) => setTimeout(r, 220))
      if (el.scrollTop === last) break
      last = el.scrollTop
    }
    el.scrollTop = original
    if (opts.isCancelled() || Date.now() - start >= maxMs) break
  }
}
