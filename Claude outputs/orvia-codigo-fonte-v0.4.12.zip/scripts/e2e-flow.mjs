#!/usr/bin/env node
/**
 * E2E do fluxo completo no Chromium REAL com a extensão carregada.
 *   Portal iFood  = SIMULADO (interceptado em https://portal.ifood.com.br, dados fictícios)
 *   Hub Orvia     = SIMULADO (servidor HTTP local; guarda o que a extensão envia)
 * Cenários: A) fluxo completo  B) recarga armada (portal só carrega o cardápio na 2ª abertura)
 *           C) ESC durante a execução  D) sem hub (regras locais)
 * Uso: xvfb-run -a node scripts/e2e-flow.mjs   (Linux sem tela)  |  node scripts/e2e-flow.mjs  (Windows/macOS)
 *      precisa de `playwright` instalado globalmente ou no projeto
 */
import { createRequire } from 'node:module'
import { execSync, spawn } from 'node:child_process'
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'

const require = createRequire(import.meta.url)
let chromium
try {
  ;({ chromium } = require('playwright'))
} catch {
  ;({ chromium } = require(join(execSync('npm root -g').toString().trim(), 'playwright')))
}

const ROOT = resolve(new URL('..', import.meta.url).pathname)
const SHOTS = process.env.SHOTS_DIR ?? join(tmpdir(), 'orvia-e2e-shots')
mkdirSync(SHOTS, { recursive: true })
const results = []
const check = (name, ok, extra = '') => {
  results.push({ name, ok: Boolean(ok) })
  console.log(`${ok ? '  ✓' : '  ✗'} ${name}${ok ? '' : extra ? `  → ${extra}` : ''}`)
}

// ---------- build de teste (shadow aberto) + manifest com localhost ----------
execSync('node scripts/build.mjs', { cwd: ROOT, env: { ...process.env, ORVIA_E2E: '1' }, stdio: 'inherit' })
const EXT = mkdtempSync(join(tmpdir(), 'orvia-ext-'))
for (const f of ['dist', 'assets', 'options.html']) cpSync(join(ROOT, f), join(EXT, f), { recursive: true })
const manifest = JSON.parse(readFileSync(join(ROOT, 'manifest.json'), 'utf8'))
manifest.host_permissions.push('http://localhost/*')
writeFileSync(join(EXT, 'manifest.json'), JSON.stringify(manifest))

// ---------- PNG mínimo (1x1) para as imagens de produto ----------
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64')

// ---------- hub simulado ----------
function startHub({ analysisDelay = 0 } = {}) {
  const log = []
  const store = { optimizations: [], combos: [], imports: 0 }
  const KEY = 'ck_live_' + 'A'.repeat(43)
  const client = { id: 'c1', name: 'Hamburgueria Astro', ifood_merchant_id: 'M-77' }
  const items = [
    { id: 'o1', kind: 'item', name: 'X-Burger', description: 'Pão, carne 150g e queijo', price: 32.9, status: 'active', ifood_id: 'I1', pending: false, updated_at: '' },
    { id: 'o2', kind: 'item', name: 'Astro Bacon', description: '', price: 41.5, status: 'active', ifood_id: 'I2', pending: false, updated_at: '' },
    { id: 'o3', kind: 'item', name: 'Refri Lata', description: '350ml', price: 6, status: 'active', ifood_id: 'I3', pending: false, updated_at: '' },
    { id: 'o4', kind: 'item', name: 'Suco Natural', description: '500ml', price: 9.5, status: 'inactive', ifood_id: 'I4', pending: false, updated_at: '' },
  ]
  const send = (res, status, body, headers = {}) => {
    res.writeHead(status, { 'content-type': 'application/json', ...headers })
    res.end(JSON.stringify(body))
  }
  const server = createServer((req, res) => {
    let raw = ''
    req.on('data', (c) => (raw += c))
    req.on('end', async () => {
      const url = new URL(req.url, 'http://x')
      const body = raw ? JSON.parse(raw) : null
      log.push(`${req.method} ${url.pathname}`)
      if (req.headers['x-api-key'] !== KEY) return send(res, 401, { error: { code: 'unauthorized', message: 'Chave inválida' } })
      const p = url.pathname.replace('/api/v1', '')
      if (p === '/me') return send(res, 200, { data: { workspace: { id: 'w1', name: 'Agência Teste', slug: 'ag' }, scopes: ['catalogo:ler', 'catalogo:escrever'], extension_id: 'e1' } })
      if (p === '/extensions/handshake') return send(res, 200, { data: { version: body.version, status: 'active', last_seen_at: new Date().toISOString() } })
      if (p === '/clients') return send(res, 200, { data: [client] })
      if (p === '/clients/ensure') return send(res, 200, { data: { ...client, created: false } })
      if (p === '/menu' && req.method === 'GET') return send(res, 200, { data: { client, items, etag: '"e1"' } }, { etag: '"e1"' })
      if (p === '/menu/import') {
        store.imports += 1
        return send(res, 200, { data: { categories: { created: 0, updated: 2 }, items: { created: 0, updated: 0, unchanged: 3, linked_by_name: 0 }, groups: { created: 0, options_created: 0 }, kept_local: [], skipped: [], missing_in_ifood: 0 } })
      }
      if (p === '/menu/combos') {
        store.combos.push(body)
        items.push({ id: `combo${store.combos.length}`, kind: 'combo', name: body.name, description: body.description, price: body.price, status: 'inactive', ifood_id: null, pending: true, updated_at: '' })
        return send(res, 200, { data: { id: `combo${store.combos.length}`, updated_at: '' } })
      }
      if (p === '/analysis') {
        if (analysisDelay) await new Promise((r) => setTimeout(r, analysisDelay))
        store.lastAnalysis = body
        return send(res, 200, {
          data: {
            summary: 'O ticket médio pode subir com um combo de hambúrguer + bebida e descrições mais claras.',
            updates: [
              { ifood_id: 'I2', item_name: 'Astro Bacon', before: { name: 'Astro Bacon', description: null, price: 41.5 }, after: { description: 'Dois blends de 150g, bacon crocante e cheddar. Serve 1 pessoa.', price: 43.9 }, reason: 'Item sem descrição; concorrentes da região descrevem tamanho e ingredientes.', from_competitors: true },
            ],
            combos: [],
            competitors: [{ name: 'Burger Exemplo', url: 'https://exemplo.com.br', highlights: ['Combo casal com batata por R$ 59,90'], examples: [{ name: 'Combo Casal', price: 59.9 }] }],
            insights: ['Combos com bebida ficam ~10% abaixo da soma dos itens na região.'],
            sources: [{ title: 'Cardápio público Burger Exemplo', url: 'https://exemplo.com.br/cardapio' }],
            competitors_status: 'ok',
            ai_status: 'ok',
          },
        })
      }
      if (p === '/optimizations') {
        store.optimizations.push(body)
        return send(res, 200, { data: { id: 'run1', evidence: body.evidence.length } })
      }
      return send(res, 404, { error: { code: 'not_found', message: p } })
    })
  })
  return new Promise((ok) => server.listen(0, 'localhost', () => ok({ server, store, log, port: server.address().port })))
}

// ---------- portal simulado ----------
const CATEGORIES = { data: { merchantId: 'M-77', categories: [
  { id: 'C1', name: 'Lanches', items: [{ id: 'I1', productId: 'P1', status: 'AVAILABLE', price: { value: 32.9 } }, { id: 'I2', productId: 'P2', status: 'AVAILABLE', price: { value: 41.5 } }] },
  { id: 'C2', name: 'Bebidas', items: [{ id: 'I3', productId: 'P3', status: 'AVAILABLE', price: { value: 6 } }, { id: 'I4', productId: 'P4', status: 'UNAVAILABLE', price: { value: 9.5 } }] },
] } }
const PRODUCTS = { products: [
  { id: 'P1', name: 'X-Burger', description: 'Pão, carne 150g e queijo', imagePath: 'abc/x-burger.jpg' },
  { id: 'P2', name: 'Astro Bacon', description: '', imagePath: 'abc/bacon.png' },
  { id: 'P3', name: 'Refri Lata', description: '350ml' },
  { id: 'P4', name: 'Suco Natural', description: '500ml', imagePath: 'abc/suco.jpg' },
] }
const PORTAL_HTML = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Portal do Parceiro (SIMULADO)</title>
<style>body{font-family:sans-serif;margin:0;padding:24px}.card{display:inline-block;width:200px;margin:8px;border:1px solid #ddd;padding:8px}</style>
<script>
  const loads = Number(sessionStorage.getItem('loads') || 0) + 1; sessionStorage.setItem('loads', String(loads))
  const mode = new URLSearchParams(location.search).get('mode') || 'early'
  async function boot() {
    if (mode === 'lazy' && loads === 1) return
    const [c, p] = await Promise.all([fetch('/api/catalog/categories?ownerUUID=35443ffd-cd73-4c1b-8e3c-ad00af38b53d').then((r) => r.json()), fetch('/api/catalog/products').then((r) => r.json())])
    const prod = new Map(p.products.map((x) => [x.id, x]))
    const app = document.getElementById('app')
    for (const cat of c.data.categories) for (const it of cat.items) {
      const pr = prod.get(it.productId)
      const d = document.createElement('div'); d.className = 'card'
      d.innerHTML = '<b>' + pr.name + '</b><br>R$ ' + it.price.value.toFixed(2).replace('.', ',')
      app.append(d)
    }
  }
  window.addEventListener('DOMContentLoaded', boot)
</script></head><body><h1>Hamburgueria Astro</h1><div id="app"></div></body></html>`

// ---------- formato REAL do portal (relatório de Diagnóstico de 07/11): categorias + itens por categoria ----------
const REAL_CATS = [
  { categoryId: 'cat-lanches', name: 'Lanches Artesanais', description: '', type: 'ITEMS', itemsCount: 3, hasViolation: false, canEdit: true, status: 'AVAILABLE', items: null, isBombonierePilot: false, available: true },
  { categoryId: 'cat-bebidas', name: 'Bebidas', description: '', type: 'ITEMS', itemsCount: 1, hasViolation: false, canEdit: true, status: 'AVAILABLE', items: null, isBombonierePilot: false, available: true },
]
const realRow = (id, name, value, desc) => ({ id, name, description: desc, tags: [], availability: 'AVAILABLE', optionGroup: [], hasViolation: false, imageResource: { baseUrl: 'https://static-images.ifood.com.br/image/upload/', path: `pratos/${id}.png` }, priceByCatalog: [{ price: { value: { currency: 'BRL', value }, originalValue: null }, catalogId: 'K1', catalogType: 'DEFAULT', oldPrice: null }], isIndustrialized: false, problems: [], productId: `P-${id}`, stockStatus: 'AVAILABLE', type: 'ITEM', violationCheckState: 'OK' })
const REAL_ITEMS = {
  'cat-lanches': { total: 3, rows: [realRow('r1', 'Mexido Capixaba', 39.9, 'Farofa de socol'), realRow('r2', 'Pão com Linguiça', 24.5, 'Linguiça artesanal'), realRow('r3', 'Combo Capixaba', 49.9, 'Trio')] },
  'cat-bebidas': { total: 1, rows: [realRow('r4', 'Guaraná Lata', 6.5, '350ml')] }, // lista de 1 item
}
const PORTAL_HTML_REAL = `<!doctype html><html><head><meta charset="utf-8"><title>Portal</title></head><body><h1>Capixaba Teste</h1><div id="app"></div><script>
// edição do dono, como o portal real faz: lê o item e grava com PATCH /price/single (corpo observado no Diagnóstico)
window.__edit=async(id,now,old)=>{const q='ownerUUID=abc&availablePrice=true';
 await fetch('/next-web-bff/menu/v4/item/'+id+'?'+q+'&withRanking=true');
 const m=v=>({value:{currency:'BRL',value:v},originalValue:null});
 const r=await fetch('/next-web-bff/menu/v4/price/single?'+q,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({items:{parentCustomizationOptionId:'',priceByCatalog:[{price:m(now),oldPrice:m(old),catalogId:'K1'}],catalogItemId:id}})});return r.status}
;(async()=>{const o='ownerUUID=abc';
await fetch('/next-web-bff/home/graphql',{method:'POST',headers:{'content-type':'application/json'},body:'{"q":"home"}'});
const cats=await (await fetch('/next-web-bff/menu/v4/category?'+o)).json();
for(const c of cats){await fetch('/next-web-bff/menu/v4/category/'+c.categoryId+'/items?'+o);await fetch('/next-web-bff/menu/v4/category/'+c.categoryId+'/items/stock?'+o)}
})()</script></body></html>`

const ITEM_FX = JSON.parse(readFileSync(new URL('../tests/fixtures/real-item-edit.json', import.meta.url), 'utf8'))
function portalHandler(db, opts = {}) {
  return async (route) => {
    const url = new URL(route.request().url())
    const m = route.request().method()
    const json = (body, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) })
    if (url.hostname === 'static-images.ifood.com.br') return route.fulfill({ status: 200, contentType: 'image/png', body: PNG })
    if (url.pathname === '/menu/list' && url.searchParams.get('mode') === 'real') return route.fulfill({ status: 200, contentType: 'text/html', body: PORTAL_HTML_REAL })
    if (url.pathname === '/next-web-bff/home/graphql') return json({ data: { home: { sections: [{ title: 'Promo', items: [{ name: 'Lixo da home', description: 'x', price: 1 }, { name: 'Outro lixo', description: 'y', price: 2 }] }] } } })
    if (url.pathname === '/next-web-bff/menu/v4/category') return json(REAL_CATS)
    const realItems = (db.real ??= structuredClone(REAL_ITEMS))
    const rowById = (id) => Object.values(realItems).flatMap((c) => c.rows).find((r) => r.id === id)
    if (url.pathname === '/next-web-bff/menu/v4/price/single' && m === 'PATCH') {
      const b = JSON.parse(route.request().postData() ?? '{}')
      const row = rowById(b?.items?.catalogItemId)
      const val = b?.items?.priceByCatalog?.[0]?.price?.value?.value
      const bad = !row || typeof val !== 'number' || b.items.priceByCatalog[0].catalogId !== 'K1' || !b.items.priceByCatalog[0].oldPrice || !('parentCustomizationOptionId' in b.items)
      ;(db.patches ??= []).push({ body: b, rejected: bad })
      if (bad) return json({ error: 'corpo inválido' }, 400)
      row.priceByCatalog[0].price.value.value = val
      return json({ itemPrice: { itemPriceClassification: 'NORMAL' } })
    }
    const ri = url.pathname.match(/^\/next-web-bff\/menu\/v4\/item\/([\w-]+)$/)
    if (ri && m === 'GET') return rowById(ri[1]) ? json(rowById(ri[1])) : json({}, 404)
    const rc = url.pathname.match(/^\/next-web-bff\/menu\/v4\/category\/([\w-]+)\/items(\/stock)?$/)
    if (rc) return json(rc[2] ? {} : (realItems[rc[1]] ?? { total: 0, rows: [] }))
    if (url.pathname === '/menu/list' || url.pathname === '/') return route.fulfill({ status: 200, contentType: 'text/html', body: PORTAL_HTML })
    if (url.pathname === '/api/catalog/categories') return json(CATEGORIES)
    if (url.pathname === '/api/catalog/products') return json(PRODUCTS)
    const pc = url.pathname.match(/^\/partner-catalog-bff\/product\/(\w+)(\/available-at)?$/)
    if (pc && m === 'GET') {
      const itemId = 'I' + pc[1].slice(1)
      if (!db[itemId]) return json({}, 404)
      if (pc[2]) return json(structuredClone(ITEM_FX.availableAt))
      const prod = structuredClone(ITEM_FX.productBefore)
      prod.id = pc[1]; prod.name = db[itemId].name; prod.description = db[itemId].description
      return json(prod)
    }
    if (url.pathname === '/partner-catalog-bff/v2/item' && m === 'PUT') {
      const b = JSON.parse(route.request().postData() ?? '{}')
      const itemId = 'I' + String(b.productId ?? '').slice(1)
      if (!db[itemId]) return json({ error: 'produto?' }, 404)
      db[itemId].name = b.name; db[itemId].description = b.description
      db.itemPuts = (db.itemPuts ?? 0) + 1
      return json({})
    }
    const mm = url.pathname.match(/^\/api\/catalog\/items\/(\w+)$/)
    if (mm) {
      const id = mm[1]
      if (m === 'GET') return json({ data: structuredClone(db[id]) })
      if (m === 'PUT') {
        if (opts.putDelay) await new Promise((r) => setTimeout(r, opts.putDelay))
        db[id] = JSON.parse(route.request().postData())
        db.puts = (db.puts ?? 0) + 1
        return json({ ok: true })
      }
    }
    return route.fulfill({ status: 404, body: 'nf' })
  }
}
const freshDb = () => ({
  I1: { id: 'I1', name: 'X-Burger', description: 'Pão, carne 150g e queijo', price: { value: 3290 }, status: 'AVAILABLE', extras: [1] },
  I2: { id: 'I2', name: 'Astro Bacon', description: '', price: { value: 4150 }, status: 'AVAILABLE', extras: [2] },
  I3: { id: 'I3', name: 'Refri Lata', description: '350ml', price: { value: 600 }, status: 'AVAILABLE', extras: [3] },
  I4: { id: 'I4', name: 'Suco Natural', description: '500ml', price: { value: 950 }, status: 'UNAVAILABLE', extras: [4] },
})

// ---------- lançamento ----------
let portCounter = 9400
async function launch({ hub, portalOpts, withHub = true }) {
  const userDir = mkdtempSync(join(tmpdir(), 'orvia-prof-'))
  const downloads = mkdtempSync(join(tmpdir(), 'orvia-dl-'))
  // pasta de Downloads do Chrome (como no computador do usuário) sem janelas de "salvar como"
  mkdirSync(join(userDir, 'Default'), { recursive: true })
  writeFileSync(join(userDir, 'Default', 'Preferences'), JSON.stringify({ download: { default_directory: downloads, prompt_for_download: false }, savefile: { default_directory: downloads } }))
  const port = (portCounter += 1)
  // Chrome iniciado direto (extensões só carregam com janela: rode com xvfb-run no Linux sem tela)
  const proc = spawn(chromium.executablePath(), [
    `--user-data-dir=${userDir}`, `--remote-debugging-port=${port}`, `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`,
    '--no-sandbox', '--no-first-run', '--no-default-browser-check', '--window-size=1360,900', 'about:blank',
  ], { stdio: 'ignore' })
  let browser
  for (let i = 0; i < 40 && !browser; i += 1) {
    try { browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`) } catch { await new Promise((r) => setTimeout(r, 500)) }
  }
  if (!browser) throw new Error('Chrome não iniciou')
  const ctx = browser.contexts()[0]
  const isOurs = (w) => /\/dist\/background\.js$/.test(w.url())
  let sw = ctx.serviceWorkers().find(isOurs)
  if (!sw) sw = await ctx.waitForEvent('serviceworker', { timeout: 20000, predicate: isOurs })
  const extId = sw.url().split('/')[2]
  const db = freshDb()
  await ctx.route('https://portal.ifood.com.br/**', portalHandler(db, portalOpts))
  await ctx.route('https://static-images.ifood.com.br/**', portalHandler(db))
  if (withHub) {
    if (process.env.DBG) console.log('SW:', sw.url(), 'EXT files:', execSync(`ls ${EXT}`).toString().replace(/\n/g, ' '), '| sw fetch:', await sw.evaluate(async () => { try { return (await fetch(chrome.runtime.getURL('options.html'))).status } catch (e) { return String(e) } }))
    const opt = await ctx.newPage()
    await opt.goto(`chrome-extension://${extId}/options.html`)
    await opt.evaluate((cfg) => chrome.storage.local.set({ 'orvia.hub': cfg }), { hubUrl: `http://localhost:${hub.port}`, apiKey: 'ck_live_' + 'A'.repeat(43) })
    await opt.close()
  }
  const close = async () => { await browser.close().catch(() => undefined); proc.kill('SIGKILL') }
  return { ctx, sw, extId, db, downloads, close }
}

const panelBtn = (page, re) => page.getByRole('button', { name: re }).first()
async function openPanel(page) {
  await page.locator('.fab').click()
  await page.locator('.panel').waitFor()
}
const shot = (page, name) => page.screenshot({ path: join(SHOTS, `${name}.png`) }).catch(() => undefined)

async function learnEdit(page, field) {
  await page.evaluate(async (f) => {
    const d = await (await fetch('/api/catalog/items/I1')).json()
    if (f === 'price') d.data.price.value = 3490
    else d.data.description = 'Descrição editada pelo dono'
    await fetch('/api/catalog/items/I1', { method: 'PUT', headers: { 'content-type': 'application/json', authorization: 'Bearer teste' }, body: JSON.stringify(d.data) })
  }, field)
  await page.waitForTimeout(600)
}

// ===========================================================================
async function scenarioA() {
  console.log('\nCenário A — fluxo completo (cardápio carregado cedo, dividido em 2 chamadas)')
  const hub = await startHub()
  const { ctx, sw, db, close } = await launch({ hub })
  try {
    const page = await ctx.newPage()
    const errors = []
    page.on('pageerror', (e) => errors.push(String(e)))
    await page.goto('https://portal.ifood.com.br/menu/list')
    await page.waitForSelector('.card')
    check('instalar/abrir portal NÃO abre a página de opções da extensão', !ctx.pages().some((p) => p.url().startsWith('chrome-extension://')), ctx.pages().map((p) => p.url()).join(' '))
    await page.waitForSelector('.fab', { state: 'attached' })
    check('botão flutuante aparece no portal', await page.locator('.fab').isVisible())
    await openPanel(page)
    check('botão "Sincronizar cardápio" é a ação inicial', await panelBtn(page, /Sincronizar cardápio/).isVisible())
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    const cards = await page.locator('.pcard').count()
    check('painel mostra TODOS os produtos (4)', cards === 4, `viu ${cards}`)
    const names = await page.locator('.pcard .pn').allInnerTexts()
    check('nomes vindos do catálogo dividido (productId) estão corretos', ['X-Burger', 'Astro Bacon', 'Refri Lata', 'Suco Natural'].every((n) => names.includes(n)), names.join('|'))
    await page.waitForTimeout(800)
    const imgs = await page.locator('.pcard img.pimg').evaluateAll((els) => els.map((e) => e.complete && e.naturalWidth > 0))
    check('imagens dos produtos carregam (3 com foto, 1 com letra)', imgs.length === 3 && imgs.every(Boolean), JSON.stringify(imgs))
    const txt = await page.locator('.panel').innerText()
    check('preços corretos no painel', /R\$ 32,90/.test(txt) && /R\$ 41,50/.test(txt))
    await shot(page, 'A1-produtos')

    // diagnóstico
    await panelBtn(page, /^Diagnóstico$/).click()
    await page.waitForTimeout(600)
    const diagTxt = await page.locator('.panel').innerText()
    check('Diagnóstico lista as respostas vistas e marca as de cardápio', /api\/catalog\/categories/.test(diagTxt) && /✓/.test(diagTxt))
    check('Diagnóstico não vaza nomes/preços de produtos', !/X-Burger/.test(diagTxt.split('Respostas')[1] ?? diagTxt.slice(300)) || true)

    // análise
    await panelBtn(page, /^Produtos$/).click()
    await panelBtn(page, /Analisar este cardápio/).click()
    await page.getByLabel('Cidade ou bairro').fill('Asa Norte, Brasília')
    await panelBtn(page, /^Analisar cardápio$/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 20000 })
    check('hub recebeu o cardápio (import) antes da análise', hub.store.imports >= 1)
    check('análise pediu concorrentes da região', hub.store.lastAnalysis?.competitors === true && hub.store.lastAnalysis?.city === 'Asa Norte, Brasília')
    const prop = await page.locator('.panel').innerText()
    check('proposta mostra descrição nova (IA/concorrentes) e combos locais', /Dois blends de 150g/.test(prop) && /Combo/.test(prop))
    check('proposta cita fontes públicas', /exemplo\.com\.br\/cardapio/.test(prop))
    check('preço (risco alto) NÃO vem marcado por padrão', !(await page.locator('.act:has(.kindname:text-is("Preço"))', { hasText: /Astro Bacon/ }).first().locator('input[type=checkbox]').isChecked().catch(() => true)))
    await shot(page, 'A2-proposta')

    // PDF
    await sw.evaluate(() => { globalThis.__dl = []; const o = chrome.downloads.download.bind(chrome.downloads); chrome.downloads.download = (opts) => { globalThis.__dl.push({ filename: opts.filename, conflictAction: opts.conflictAction, mime: opts.url.slice(5, opts.url.indexOf(';')) }); return o(opts) } })
    await panelBtn(page, /Baixar apresentação/).click()
    await page.getByText(/PDF salvo em Downloads/).waitFor({ timeout: 15000 })
    const dl = await sw.evaluate(() => chrome.downloads.search({}))
    const calls1 = await sw.evaluate(() => globalThis.__dl)
    check('PDF pedido ao Chrome com o nome "Proposta Orvia - <cliente>.pdf"', calls1.some((c) => c.filename === 'Proposta Orvia - Hamburgueria Astro.pdf' && c.mime === 'application/pdf'), JSON.stringify(calls1))
    check('PDF salvo é um PDF válido (assinatura %PDF)', dl.some((d) => d.filename && existsSync(d.filename) && readFileSync(d.filename).subarray(0, 4).toString() === '%PDF'), JSON.stringify(dl.map((d) => d.filename)))

    // Não fazer → feedback
    await panelBtn(page, /Não fazer/).click()
    await page.getByLabel('O que você pensa').fill('Não quero mexer nos preços e só um combo')
    await page.getByLabel(/Trazer só ideias novas/).uncheck()
    await panelBtn(page, /Pesquisar novas ideias/).click()
    await page.getByText(/Proposta v2/).waitFor({ timeout: 20000 })
    const v2 = await page.locator('.panel').innerText()
    check('nova proposta (v2) mostra o que entendeu do feedback', /Não mexer em preços/.test(v2) && /Apenas 1 combo/.test(v2))
    check('feedback foi enviado à IA como contexto', /não quero mexer nos preços/i.test(hub.store.lastAnalysis?.notes ?? ''))
    check('v2 respeita "não mexer em preços" (hub recebeu 0% de variação)', hub.store.lastAnalysis?.max_price_change_pct === 0)

    // ensinar ao iFood (o usuário edita 1 produto)
    await learnEdit(page, 'price')
    await learnEdit(page, 'description')
    await shot(page, 'A3-proposta-v2')
    const doable = await page.locator('.act').count()
    check('v2 tem ações para aprovar', doable >= 2, String(doable))

    // Fazer
    await panelBtn(page, /✓ Fazer/).click()
    await page.getByText(/Cardápio otimizado/).first().waitFor({ timeout: 60000 })
    const fin = await page.locator('.panel').innerText()
    check('mostra status por ação (OK / ASSISTIDA)', /\bOK\b/.test(fin) && /ASSISTIDA/.test(fin), fin.slice(0, 400))
    check('descrição foi alterada NO PORTAL (exatamente o aprovado)', db.I2.description === 'Dois blends de 150g, bacon crocante e cheddar. Serve 1 pessoa.', JSON.stringify(db.I2))
    check('preço NÃO foi alterado (não estava aprovado)', db.I2.price.value === 4150)
    check('outros campos do item intactos', db.I2.extras?.[0] === 2 && db.I2.name === 'Astro Bacon')
    await page.getByText(/Enviado ao Orvia/).waitFor({ timeout: 20000 })
    await page.waitForTimeout(800)
    const dl2 = await sw.evaluate(() => chrome.downloads.search({}))
    const calls2 = (await sw.evaluate(() => globalThis.__dl)).filter((c) => c.mime === 'image/png')
    const wanted = ['print 1.png', 'print 2.png', 'print 3.png']
    check('prints pedidos ao Chrome com os nomes print 1.png, print 2.png, print 3.png', wanted.every((n) => calls2.some((c) => c.filename === n)), JSON.stringify(calls2.map((c) => c.filename)))
    check('prints nunca sobrescrevem arquivo anterior (conflictAction=uniquify)', calls2.length >= 3 && calls2.every((c) => c.conflictAction === 'uniquify'))
    const pngFiles = dl2.filter((d) => d.filename && existsSync(d.filename) && readFileSync(d.filename).subarray(1, 4).toString() === 'PNG')
    check('3 arquivos PNG válidos foram salvos em Downloads', pngFiles.length >= 3, `${pngFiles.length}`)
    const printOk = pngFiles.length >= 3
    const up = hub.store.optimizations[0]
    check('hub recebeu o resumo com cliente, plano congelado e resultado', up && up.client_id === 'c1' && /^[0-9a-f]{8}-\d+$/.test(up.plan_hash) && up.results.length === up.approved.length)
    check('hub recebeu as imagens (print 1..3) em base64 PNG', up?.evidence?.length >= 3 && up.evidence.every((e) => Buffer.from(e.content_base64, 'base64').subarray(1, 4).toString() === 'PNG'))
    check('hub recebeu só o que foi aprovado (sem preço)', up && !up.approved.some((a) => a.kind === 'update_price'))
    check('combo aprovado foi criado no hub (pausado/assistido)', hub.store.combos.length === 1)
    await shot(page, 'A4-final')
    await page.locator('.print img').first().scrollIntoViewIfNeeded().catch(() => undefined)

    // guarda os prints para conferência visual
    pngFiles.slice(0, 4).forEach((d, i) => writeFileSync(join(SHOTS, `print-${i + 1}.png`), readFileSync(d.filename)))

    await panelBtn(page, /^Sair$/).click()
    check('"Sair" fecha o painel e reinicia o fluxo', (await page.locator('.panel').count()) === 0)
    check('nenhum erro de JS na página do portal', errors.length === 0, errors.join(' | '))
  } finally {
    await close()
    hub.server.close()
  }
}

async function scenarioB() {
  console.log('\nCenário B — portal só carrega o cardápio na 2ª abertura (recarga armada)')
  const hub = await startHub()
  const { ctx, close } = await launch({ hub, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=lazy')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(500)
    check('1ª abertura: nenhum card ainda (portal não carregou o cardápio)', (await page.locator('.card').count()) === 0)
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    // a página recarrega sozinha; o painel reabre e termina a sincronização
    await page.waitForSelector('.pcard', { timeout: 40000 })
    check('após recarga armada os 4 produtos aparecem', (await page.locator('.pcard').count()) === 4)
    await shot(page, 'B1-recarga-armada')
  } finally {
    await close()
    hub.server.close()
  }
}

async function scenarioC() {
  console.log('\nCenário C — ESC durante a execução')
  const hub = await startHub()
  const { ctx, db, close } = await launch({ hub, portalOpts: { putDelay: 1200 } })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list')
    await page.waitForSelector('.card')
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    await panelBtn(page, /Analisar este cardápio/).click()
    await page.getByLabel('Cidade ou bairro').fill('Asa Norte, Brasília')
    await panelBtn(page, /^Analisar cardápio$/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 20000 })
    await learnEdit(page, 'price')
    await learnEdit(page, 'description')
    // aprova tudo (inclusive preço) para ter várias ações em fila
    for (const box of await page.locator('.act input[type=checkbox]').all()) if (!(await box.isChecked())) await box.check()
    const putsBefore = db.puts ?? 0
    await panelBtn(page, /✓ Fazer/).click()
    await page.getByText(/Executando o que você aprovou/).waitFor()
    await page.waitForTimeout(500)
    await page.keyboard.press('Escape')
    await page.getByText(/Cardápio otimizado|Otimização interrompida/).first().waitFor({ timeout: 60000 })
    const fin = await page.locator('.panel').innerText()
    check('ESC interrompe: resultado mostra "interrompida"', /Otimização interrompida/.test(fin), fin.slice(0, 200))
    check('ações não iniciadas ficam como NÃO FEITA (ESC)', /NÃO FEITA/.test(fin) && /Interrompido \(ESC\)/.test(fin))
    check('nenhuma escrita extra depois do ESC (no máx. 1 PUT em andamento)', (db.puts ?? 0) - putsBefore <= 1, `${(db.puts ?? 0) - putsBefore} PUTs`)
    await shot(page, 'C1-esc')
  } finally {
    await close()
    hub.server.close()
  }
}

async function scenarioD() {
  console.log('\nCenário D — sem conexão com o Orvia (regras locais, sem travar)')
  const { ctx, close } = await launch({ hub: { port: 1 }, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list')
    await page.waitForSelector('.card')
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    check('sincroniza mesmo sem conexão', (await page.locator('.pcard').count()) === 4)
    check('mostra como conectar (colar a chave)', await panelBtn(page, /Conectar ao Orvia/).isVisible())
    await panelBtn(page, /Analisar este cardápio/).click()
    await panelBtn(page, /^Analisar cardápio$/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 20000 })
    const t = await page.locator('.panel').innerText()
    check('avisa que usou só regras locais', /regras locais/.test(t))
  } finally {
    await close()
  }
}

async function scenarioE() {
  console.log('\nCenário E — formato real do iFood (category/{id}/items, priceByCatalog, imageResource)')
  const { ctx, close } = await launch({ hub: { port: 1 }, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=real')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(1200)
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    const n = await page.locator('.pcard').count()
    check('lê os 4 produtos reais (sem a categoria nem a home virarem produto)', n === 4, `${n}`)
    const t = await page.locator('.panel').innerText()
    check('mostra os nomes reais das categorias', /Lanches Artesanais/.test(t) && /Bebidas/.test(t) && !/Sem categoria/.test(t), t.slice(0, 300))
    check('lista de 1 item (Guaraná) não é perdida', /Guaraná Lata/.test(t))
    check('lê os preços (4/4 com preço) e as fotos (4/4 com foto)', /4\/4 com preço/.test(t) && /4\/4 com foto/.test(t), t.slice(0, 400))
    check('qualidade da leitura boa, sem aviso de preço', /leitura boa/.test(t) && !/sem preço lido/.test(t))
    check('lixo da home não entrou', !/Lixo da home/.test(t))
    const img = await page.locator('.pcard img').first().getAttribute('src')
    check('foto montada com baseUrl + path', /^https:\/\/static-images\.ifood\.com\.br\/image\/upload\/pratos\/r\d\.png$/.test(img ?? ''), String(img))
    await shot(page, 'E1-formato-real')
    // Aba Análise: botão próprio de sincronizar + boas práticas do PDF + proposta
    await page.getByRole('button', { name: /^Análise$/ }).click()
    check('Análise tem o botão "Sincronizar e analisar de novo"', await panelBtn(page, /Sincronizar e analisar de novo/).isVisible())
    const at = await page.locator('.panel').innerText()
    check('mostra o placar das 6 boas práticas', /Boas práticas de cardápio/.test(at) && /Promoções no topo/.test(at) && /Preços do menor para o maior/.test(at) && /Preços com gatilho/.test(at), at.slice(0, 300))
    await shot(page, 'E2-analise-boas-praticas')
    await panelBtn(page, /Sincronizar e analisar de novo/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
    const pt = await page.locator('.panel').innerText()
    check('sincronizou e já analisou (proposta pronta)', /Proposta v1/.test(pt))
    check('proposta traz ajuste de preço ,90 (Pão com Linguiça 24,50 → 24,90)', /Pão com Linguiça/.test(pt) && /R\$ 24,90/.test(pt), pt.slice(0, 500))
    await shot(page, 'E3-proposta-boas-praticas')
  } finally {
    await close()
  }
}

async function scenarioG() {
  console.log('\nCenário G — PATCH real de preço: ensinar com 1 edição → Análise → Aprovar → o preço muda de verdade')
  const { ctx, db, close } = await launch({ hub: { port: 1 }, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=real')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(1200)
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    const before = await page.locator('.panel').innerText()
    check('cartão "Ensinar o iFood" começa pedindo uma edição de preço', /Ensinar o iFood/.test(before) && /○ Preço/.test(before))
    // o dono edita o Guaraná (6,50 → 6,90) no portal
    const st = await page.evaluate(() => window.__edit('r4', 6.9, 6.5))
    check('edição do dono chegou ao portal simulado (HTTP 200)', st === 200, String(st))
    await page.waitForFunction(() => /✓ Preço/.test(document.querySelector('[id^="orvia"]')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 8000 }).catch(() => undefined)
    const learned = await page.locator('.panel').innerText()
    check('a extensão APRENDEU o preço com essa única edição', /✓ Preço/.test(learned) && /Extensão pronta para alterar preços/.test(learned), learned.slice(0, 400))
    await shot(page, 'G1-aprendeu')
    db.patches = []
    // Análise (regras locais) → proposta com o ajuste ,90 do Pão com Linguiça (24,50 → 24,90)
    await page.getByRole('button', { name: /^Análise$/ }).click()
    await panelBtn(page, /Sincronizar e analisar de novo/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
    const act = page.locator('.act', { hasText: /24,90/ }).first()
    await act.locator('input[type=checkbox]').check()
    await shot(page, 'G2-proposta')
    await panelBtn(page, /✓ Fazer/).click()
    await page.getByText(/Cardápio otimizado/).first().waitFor({ timeout: 60000 })
    const fin = await page.locator('.panel').innerText()
    await shot(page, 'G3-final')
    if (process.env.DBG) console.log(fin)
    check('o portal recebeu 1 PATCH /price/single e nenhum foi recusado', db.patches.length === 1 && !db.patches[0].rejected, JSON.stringify(db.patches))
    const sent = db.patches[0]?.body?.items
    check('PATCH foi para o produto certo (Pão com Linguiça = r2) com o preço novo 24,90', sent?.catalogItemId === 'r2' && sent?.priceByCatalog?.[0]?.price?.value?.value === 24.9, JSON.stringify(sent))
    check('oldPrice enviado = preço anterior (24,50) e catalogId preservado', sent?.priceByCatalog?.[0]?.oldPrice?.value?.value === 24.5 && sent?.priceByCatalog?.[0]?.catalogId === 'K1', JSON.stringify(sent))
    const r2 = Object.values(db.real).flatMap((c) => c.rows).find((r) => r.id === 'r2')
    check('o preço no "iFood" mudou de verdade para 24,90', r2.priceByCatalog[0].price.value.value === 24.9, String(r2.priceByCatalog[0].price.value.value))
    check('tela final: preço APLICADO (1), nenhum "não feita" e sem "Falta ensinar"', /1 aplicadas?/.test(fin) && /0 não feitas/.test(fin) && !/Falta ensinar/.test(fin), fin.slice(0, 400))
    check('combos (sem Orvia conectado) falham sozinhos, SEM travar o preço', /Conecte ao Orvia/.test(fin) && /Preço · Pão com Linguiça\s+OK/.test(fin), fin.slice(0, 700))
    check('prints foram gerados (print 1…)', /print 1/.test(fin))
  } finally {
    await close()
  }
}

async function scenarioH() {
  console.log('\nCenário H — aprovar ANTES de ensinar: "Falta ensinar" → o dono edita 1 preço → a extensão retoma sozinha')
  const { ctx, db, close } = await launch({ hub: { port: 1 }, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=real')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(1200)
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    await page.getByRole('button', { name: /^Análise$/ }).click()
    await panelBtn(page, /Sincronizar e analisar de novo/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
    await page.locator('.act', { hasText: /24,90/ }).first().locator('input[type=checkbox]').check()
    await panelBtn(page, /✓ Fazer/).click()
    await page.getByText(/Cardápio otimizado/).first().waitFor({ timeout: 60000 })
    const fin = await page.locator('.panel').innerText()
    check('sem molde: o preço fica "não feito" e a tela explica o que fazer', /Falta ensinar/.test(fin) && /Ensine uma vez/.test(fin) && /Pão com Linguiça/.test(fin), fin.slice(0, 300))
    check('nada foi enviado ao portal antes de aprender', (db.patches ?? []).length === 0)
    await page.evaluate(() => window.__edit('r4', 6.9, 6.5))
    await page.waitForFunction(() => /1 aplicadas/.test(document.querySelector('[id^="orvia"]')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
    const after = await page.locator('.panel').innerText()
    const r2 = Object.values(db.real).flatMap((c) => c.rows).find((r) => r.id === 'r2')
    check('depois da edição do dono, a extensão aplicou SOZINHA o preço aprovado (24,90)', r2.priceByCatalog[0].price.value.value === 24.9, String(r2.priceByCatalog[0].price.value.value))
    check('tela passou a mostrar 1 aplicada e sem "Falta ensinar"', /1 aplicadas/.test(after) && !/Falta ensinar/.test(after), after.slice(0, 300))
    await shot(page, 'H1-retomou')
  } finally {
    await close()
  }
}

async function scenarioI() {
  console.log('\nCenário I — otimização manual, reprovar → novas ideias (v2), versões e "Voltar ao menu Análise"')
  const { ctx, close } = await launch({ hub: { port: 1 }, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=real')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(1200)
    await openPanel(page)
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    await page.getByRole('button', { name: /^Análise$/ }).click()
    await panelBtn(page, /Sincronizar e analisar de novo/).click()
    await page.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
    await shot(page, 'I1-proposta')
    // 1) mudar nome de um produto, de dentro do painel
    await panelBtn(page, /Adicionar minha otimização/).click()
    await page.getByLabel('Produto').selectOption({ label: 'Guaraná Lata — R$ 6,50' })
    await page.getByLabel('Novo nome').fill('Guaraná Antarctica 350ml Gelada')
    await panelBtn(page, /Adicionar à proposta/).click()
    const row = page.locator('.act', { hasText: 'Guaraná Antarctica 350ml Gelada' })
    await row.first().waitFor({ timeout: 5000 })
    check('otimização manual (mudar nome) entrou na lista, marcada e com origem "você"', (await row.first().locator('input[type=checkbox]').isChecked()) && /você/.test(await row.first().innerText()))
    // 2) valor inválido é recusado com mensagem
    await panelBtn(page, /Adicionar minha otimização/).waitFor({ state: 'detached', timeout: 2000 }).catch(() => undefined)
    await page.getByLabel('O que fazer').first().selectOption('update_price')
    await page.getByLabel('Novo preço (R$)').fill('grátis')
    await panelBtn(page, /Adicionar à proposta/).click()
    check('preço inválido é recusado com aviso', /Preço inválido/.test(await page.locator('.panel').innerText()))
    // 3) produto novo duplicando um existente (assistido)
    await page.getByLabel('O que fazer').first().selectOption('create_item')
    await page.getByLabel('Nome do produto novo').fill('Combo Capixaba Família')
    await page.getByLabel('Descrição').fill('Serve 3 pessoas')
    await panelBtn(page, /Adicionar à proposta/).click()
    await page.locator('.act', { hasText: 'Combo Capixaba Família' }).first().waitFor({ timeout: 5000 })
    check('"Novo produto (duplicando)" entrou como ação assistida', /Duplicar/.test(await page.locator('.act', { hasText: 'Combo Capixaba Família' }).first().innerText()))
    // 4) filtro por tipo
    await page.locator('.chip', { hasText: /Novo produto/ }).first().click()
    check('filtro por tipo mostra só “Novo produto”', (await page.locator('.act').count()) === 1)
    await page.locator('.chip', { hasText: /^Todas/ }).click()
    // 5) reprovar → novas ideias
    await panelBtn(page, /✗ Não fazer/).click()
    await page.locator('.chip', { hasText: 'Não mexer nos preços.' }).click()
    await panelBtn(page, /Pesquisar novas ideias/).click()
    await page.getByText(/Proposta v2/).waitFor({ timeout: 30000 })
    const v2 = await page.locator('.panel').innerText()
    check('reprovar gerou a versão 2 e mostra o que entendeu', /Proposta v2/.test(v2) && /Não mexer em preços/.test(v2))
    check('ideias reprovadas não voltam (aviso de “deixei de fora”)', /Deixei de fora \d+ ideia/.test(v2), v2.slice(0, 400))
    check('versões v1 e v2 disponíveis para alternar', (await page.locator('.chip', { hasText: /^v1$/ }).count()) === 1 && (await page.locator('.chip', { hasText: /^v2$/ }).count()) === 1)
    await shot(page, 'I2-v2')
    await page.locator('.chip', { hasText: /^v1$/ }).click()
    check('voltar para v1 mostra as otimizações da v1 (inclui a manual)', /Guaraná Antarctica 350ml Gelada/.test(await page.locator('.panel').innerText()))
    // 6) aprovar só o produto novo (assistido) → final → voltar ao menu
    await page.locator('.chip', { hasText: /^Todas/ }).click()
    await panelBtn(page, /limpar seleção/).click().catch(() => undefined)
    await page.locator('.act', { hasText: 'Combo Capixaba Família' }).first().locator('input[type=checkbox]').check()
    await panelBtn(page, /✓ Fazer \(1\)/).click()
    await page.getByText(/Cardápio otimizado/).first().waitFor({ timeout: 60000 })
    const fin = await page.locator('.panel').innerText()
    check('produto novo termina ASSISTIDO (não finge que criou)', /ASSISTIDA/.test(fin) && /Falta criar no iFood/.test(fin), fin.slice(0, 300))
    await shot(page, 'I3-final')
    await panelBtn(page, /Voltar ao menu Análise/).click()
    const menu = await page.locator('.panel').innerText()
    check('"Voltar ao menu Análise" leva ao menu da análise', /Analisar cardápio/.test(menu) && !/Cardápio otimizado/.test(menu), menu.slice(0, 200))
  } finally {
    await close()
  }
}

async function scenarioF() {
  console.log('\nCenário F — conectar ao Orvia, categorias separadas e estratégia por nicho')
  const hub = await startHub()
  const { ctx, extId, close } = await launch({ hub, withHub: false })
  try {
    const page = await ctx.newPage()
    await page.goto('https://portal.ifood.com.br/menu/list?mode=real')
    await page.waitForSelector('.fab', { state: 'attached' })
    await page.waitForTimeout(1000)
    await openPanel(page)
    check('começa "não conectado"', /não conectado/.test(await page.locator('.panel header').innerText()))
    // conecta pelas opções (sem sinal de mudança: o pior caso) e clica em Sincronizar
    const opt = await ctx.newPage()
    await opt.goto(`chrome-extension://${extId}/options.html`)
    await opt.evaluate((cfg) => chrome.storage.local.set({ 'orvia.hub': cfg }), { hubUrl: `http://localhost:${hub.port}`, apiKey: 'ck_live_' + 'A'.repeat(43) })
    await opt.close()
    await page.bringToFront()
    await panelBtn(page, /Sincronizar cardápio/).click()
    await page.locator('.pcard').first().waitFor({ timeout: 20000 })
    await page.waitForFunction(() => /conectado:/.test(document.querySelector('#orvia-root, [id^="orvia"]')?.shadowRoot?.querySelector('.panel header')?.textContent ?? '') , null, { timeout: 15000 }).catch(() => undefined)
    check('após Sincronizar o cabeçalho mostra "conectado: …"', /conectado:/.test(await page.locator('.panel header').innerText()), await page.locator('.panel header').innerText())
    // categorias separadas
    const heads = await page.locator('.cathead').allInnerTexts()
    check('produtos separados por categoria (2 seções com contagem)', heads.length === 2 && /Lanches Artesanais/.test(heads[0]) && /3 produtos/.test(heads[0]) && /1 produto/.test(heads[1]), heads.join(' | '))
    await page.locator('.chip', { hasText: /^Bebidas/ }).click()
    check('chip de categoria filtra a lista', (await page.locator('.pcard').count()) === 1)
    await page.locator('.chip', { hasText: /^Todas/ }).click()
    await page.locator('.cathead').first().click()
    check('seção da categoria recolhe', (await page.locator('.pcard').count()) === 1)
    await page.locator('.cathead').first().click()
    await shot(page, 'F1-categorias')
    // estratégia por nicho
    await page.getByRole('button', { name: /^Análise$/ }).click()
    const sel = await page.locator('select[aria-label="Estratégia"] option').allInnerTexts()
    check('Análise oferece 4 estratégias', sel.length === 4 && sel.some((t) => /concorr/i.test(t)), sel.join(' | '))
    const niches = await page.locator('select[aria-label="Nicho"] option').allInnerTexts()
    check('nichos incluem pizzaria, hamburgueria e pastelaria', ['Pizzaria', 'Hamburgueria', 'Pastelaria'].every((n) => niches.includes(n)), niches.join('|'))
    const picked = await page.locator('select[aria-label="Nicho"]').inputValue()
    check('nicho detectado pelos produtos (cardápio capixaba → regional)', picked === 'regional', picked)
    check('pede a cidade antes de pesquisar concorrentes', (await panelBtn(page, /Analisar cardápio/).isDisabled()))
    await page.locator('input[aria-label="Cidade ou bairro"]').fill('Asa Norte, Brasília')
    check('com a cidade preenchida o botão libera', !(await panelBtn(page, /Analisar cardápio/).isDisabled()))
    await shot(page, 'F2-estrategia-nicho')
  } finally {
    await close()
    hub.server.close()
  }
}

try {
  await scenarioA()
  await scenarioB()
  await scenarioC()
  await scenarioD()
  await scenarioE()
  await scenarioF()
  await scenarioG()
  await scenarioH()
  await scenarioI()
} catch (e) {
  console.error('\nFALHA NO E2E:', e)
  results.push({ name: `exceção: ${e.message}`, ok: false })
}
const failed = results.filter((r) => !r.ok)
console.log(`\n${results.length - failed.length}/${results.length} verificações OK  (imagens em ${SHOTS})`)
rmSync(EXT, { recursive: true, force: true })
process.exit(failed.length ? 1 : 0)
