import { authenticate, isResponse } from '@/lib/api/auth'
import { err, ok, preflight, readJson } from '@/lib/api/http'
import { audit } from '@/lib/audit'
import { z } from 'zod'

export const dynamic = 'force-dynamic'
export const OPTIONS = preflight

const bodySchema = z.object({
  name: z.string().trim().min(1).max(160),
  ifood_merchant_id: z.string().trim().min(1).max(80).nullable().optional(),
})

const escapeLike = (s: string) => s.replace(/[\\%_]/g, (m) => `\\${m}`)

/**
 * "Garante" o cliente da loja do iFood: acha pelo ID da loja ou pelo nome (sem diferenciar
 * maiúsculas) e, se não existir, cria — assim os prints e o histórico caem no cliente certo
 * sem cadastro manual. Escopo catalogo:escrever (o da extensão). Idempotente.
 */
export async function POST(req: Request) {
  const auth = await authenticate(req, 'catalogo:escrever')
  if (isResponse(auth)) return auth
  const parsed = bodySchema.safeParse(await readJson(req))
  if (!parsed.success) return err(req, 'validation_failed', 'Informe o nome da loja.')
  const { name, ifood_merchant_id: merchantId } = parsed.data
  const db = auth.ctx.db
  const cols = 'id, name, ifood_merchant_id'

  if (merchantId) {
    const { data } = await db.from('clients').select(cols).eq('workspace_id', auth.workspaceId).eq('ifood_merchant_id', merchantId).is('archived_at', null).maybeSingle()
    if (data) return ok(req, { ...data, created: false })
  }
  const { data: byName } = await db.from('clients').select(cols).eq('workspace_id', auth.workspaceId).is('archived_at', null).ilike('name', escapeLike(name)).limit(1)
  const found = byName?.[0]
  if (found) {
    if (merchantId && !found.ifood_merchant_id) {
      const upd = await db.from('clients').update({ ifood_merchant_id: merchantId }).eq('id', found.id).eq('workspace_id', auth.workspaceId).is('ifood_merchant_id', null)
      if (!upd.error) found.ifood_merchant_id = merchantId
    }
    return ok(req, { ...found, created: false })
  }
  const { data: created, error } = await db.from('clients').insert({ workspace_id: auth.workspaceId, name, ifood_merchant_id: merchantId ?? null }).select(cols).single()
  if (error || !created) return err(req, 'internal', 'Não consegui cadastrar o cliente.')
  await audit({ workspaceId: auth.workspaceId, actorType: 'api_key', actorId: auth.keyId, action: 'client.created_by_extension', entityType: 'client', entityId: created.id, metadata: { source: 'ifood' } })
  return ok(req, { ...created, created: true }, { status: 201 })
}
