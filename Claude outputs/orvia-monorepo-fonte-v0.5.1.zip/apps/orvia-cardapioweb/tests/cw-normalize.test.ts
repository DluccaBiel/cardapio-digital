import { describe, expect, it } from 'vitest'
import { cardapioWebSnapshot, cwStatus, parsePrice } from '../src/lib/cw-normalize'
import { viewFromSnapshotItem } from '../src/lib/product-view'

const MENU = [
  { name: 'Lanches', status: 'ACTIVE', items: [
    { id: 11, name: 'X-Burger', description: 'Pão e carne', price: 32.9, status: 'ACTIVE', image_url: 'https://x/a.jpg', add_ons: [{ add_on_name: 'Adicionais' }] },
    { id: 12, name: 'Bacon', price: '41,50', status: 'MISSING', image_url: null },
    { id: 11, name: 'duplicado', price: 1, status: 'ACTIVE' },
  ] },
  { name: 'Bebidas', status: 'INACTIVE', items: [{ id: 'b1', name: 'Suco', price: 'R$ 1.209,90', status: 'INACTIVE' }] },
]

describe('Cardápio Web → snapshot', () => {
  it('converte preços e status', () => {
    expect(parsePrice('41,50')).toBe(41.5)
    expect(parsePrice('R$ 1.209,90')).toBe(1209.9)
    expect(parsePrice(null)).toBeNull()
    expect(cwStatus('ACTIVE')).toBe('active')
    expect(cwStatus('MISSING')).toBe('paused')
    expect(cwStatus('x')).toBe('unknown')
  })
  it('monta categorias, itens e ignora ids repetidos', () => {
    const s = cardapioWebSnapshot(MENU, 'Loja', '77')!
    expect(s.items.map((i) => i.id)).toEqual(['11', '12', 'b1'])
    expect(s.categories.map((c) => [c.name, c.itemIds.length])).toEqual([['Lanches', 2], ['Bebidas', 1]])
    expect(s.items[0]).toMatchObject({ price: 32.9, status: 'active', hasImage: true, categoryName: 'Lanches', available: true })
    expect(s.items[0]!.complements[0]!.name).toBe('Adicionais')
    expect(s.items[1]).toMatchObject({ price: 41.5, status: 'paused', hasImage: false, available: false })
    expect(s.items[2]!.available).toBe(false)
    expect(s.storeKey).toBe('cardapioweb:77')
    expect(s.id).toMatch(/^snap_/)
  })
  it('resposta inesperada ou vazia → null', () => {
    expect(cardapioWebSnapshot({ foo: 1 }, null, '1')).toBeNull()
    expect(cardapioWebSnapshot([], null, '1')).toBeNull()
  })
  it('visão do produto para o relatório', () => {
    const v = viewFromSnapshotItem(MENU, '11')!
    expect(v).toMatchObject({ name: 'X-Burger', price: 32.9, active: true, categoryName: 'Lanches' })
    expect(viewFromSnapshotItem(MENU, 'nada')).toBeNull()
  })
})
