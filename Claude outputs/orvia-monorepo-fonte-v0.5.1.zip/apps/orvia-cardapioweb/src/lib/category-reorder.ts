import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { CatRef } from '@orvia/shared/lib/category-order'
import { NOT_YET } from './item-editor'
export async function reorderCategories(_o: { order: CatRef[]; ctx: PortalCtx; request: PortalRequest }): Promise<{ ok: boolean; message: string }> {
  return { ok: false, message: `Reordenar categorias: ${NOT_YET}` }
}
