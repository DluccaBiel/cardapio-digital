/** Cardápio Web: nome/descrição/horário ainda NÃO têm receita gravada — a extensão não adivinha endpoint. */
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { Schedule } from '@orvia/shared/core/proposal'
export type { PortalCtx }
export const NOT_YET = 'O Cardápio Web ainda não tem receita gravada para isto. Edite um item no portal com a extensão aberta (aba Diagnóstico) para a Orvia aprender.'
export async function editItem(_o: { productId: string; ctx: PortalCtx; request: PortalRequest; changes: { name?: string; description?: string; schedule?: Schedule | null } }): Promise<{ ok: boolean; message: string }> {
  return { ok: false, message: NOT_YET }
}
