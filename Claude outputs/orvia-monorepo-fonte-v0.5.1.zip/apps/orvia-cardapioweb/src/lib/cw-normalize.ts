/**
 * Cardápio Web → MenuSnapshot (mesmo formato do iFood, então análise/proposta/PDF/relatório são os mesmos).
 * Fonte: GET /api/v1/company/categories/menu?full_version=true  → categorias[{name,status,items[…]}]
 * Só os campos CONFIRMADOS (id, name, price, status ACTIVE|INACTIVE|MISSING, image_url, add_ons) são certos;
 * os demais (id da categoria, descrição) são lidos com tolerância a variações de nome.
 * Puro: sem chrome.*, sem DOM.
 */
import type { MenuItem, MenuSnapshot } from '@orvia/shared/core/schema'
import { finalizeSnapshot } from '@orvia/shared/core/normalize'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : '')

export function parsePrice(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null
  if (typeof v !== 'string') return null
  const s = v.replace(/[^\d,.-]/g, '')
  if (!s) return null
  const n = s.includes(',') ? Number(s.replace(/\./g, '').replace(',', '.')) : Number(s)
  return Number.isFinite(n) ? n : null
}

export function cwStatus(s: unknown): MenuItem['status'] {
  if (s === 'ACTIVE') return 'active'
  if (s === 'INACTIVE' || s === 'MISSING') return 'paused'
  return 'unknown'
}
export const CW_STATUS_LABEL: Record<string, string> = { ACTIVE: 'Ativo', INACTIVE: 'Inativo', MISSING: 'Em falta' }

const first = (o: Rec, keys: string[]): unknown => keys.map((k) => o[k]).find((v) => v !== undefined && v !== null && v !== '')

/** a lista de categorias pode vir direto ou embrulhada ({categories|data|results|menu: […]}) */
export function menuArray(raw: unknown): unknown[] | null {
  if (Array.isArray(raw)) return raw
  if (!isRec(raw)) return null
  for (const k of ['categories', 'data', 'results', 'menu', 'content']) {
    const v = raw[k]
    if (Array.isArray(v)) return v
    if (isRec(v)) { const inner = menuArray(v); if (inner) return inner }
  }
  return null
}
const itemsOf = (c: Rec): Rec[] => {
  for (const k of ['items', 'products', 'itens', 'menu_items']) if (Array.isArray(c[k])) return (c[k] as unknown[]).filter(isRec)
  return []
}

export function cardapioWebSnapshot(raw: unknown, merchantName: string | null, companyId: string): MenuSnapshot | null {
  const cats = menuArray(raw)
  if (!cats) return null
  const items: MenuItem[] = []
  const categories: MenuSnapshot['categories'] = []
  const seen = new Set<string>()
  cats.filter(isRec).forEach((c, pos) => {
    const name = str(c.name) || `Categoria ${pos + 1}`
    const catId = str(first(c, ['id', 'category_id', 'uuid'])) || name
    const ids: string[] = []
    for (const it of itemsOf(c)) {
      const id = str(it.id)
      if (!id || seen.has(id)) continue
      seen.add(id)
      const price = parsePrice(first(it, ['price', 'value', 'sale_price']))
      const orig = parsePrice(first(it, ['original_price', 'old_price', 'price_from', 'promotional_from']))
      const addOns = Array.isArray(it.add_ons) ? it.add_ons.filter(isRec) : []
      const image = str(first(it, ['image_url', 'thumbnail_url', 'raw_image_url']))
      items.push({
        id,
        productId: id,
        name: str(it.name),
        description: str(first(it, ['description', 'desc', 'details'])),
        price,
        originalPrice: orig !== null && price !== null && orig > price ? orig : null,
        status: cwStatus(it.status),
        hasImage: !!image,
        imageUrl: image || null,
        categoryId: catId,
        categoryName: name,
        complements: [...new Set(addOns.map((a) => str(first(a, ['add_on_name', 'name', 'title']))).filter(Boolean))].map((n) => ({ id: null, name: n, min: null, max: null, required: null, options: [] })),
        available: it.status === 'ACTIVE' && str(c.status || 'ACTIVE') === 'ACTIVE',
      })
      ids.push(id)
    }
    categories.push({ id: catId, name, position: pos, itemIds: ids })
  })
  if (!items.length) return null
  return finalizeSnapshot({
    schemaVersion: 1,
    id: '',
    capturedAt: new Date().toISOString(),
    origin: 'active',
    merchant: { id: companyId || null, name: merchantName },
    storeKey: `cardapioweb:${companyId}`,
    catalogs: [],
    categories,
    items,
    source: { requestPath: '/api/v1/company/categories/menu', domUrl: '' },
  })
}
