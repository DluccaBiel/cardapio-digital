import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import { NOT_YET } from './item-editor'
export async function createItemFromBase(_o: { baseProductId: string; categoryId?: string | null; name: string; description?: string; price?: number | null; paused?: boolean; ctx: PortalCtx; request: PortalRequest }): Promise<{ ok: boolean; message: string; productId?: string }> {
  return { ok: false, message: `Criar produto/combo: ${NOT_YET}` }
}
