import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import { NOT_YET } from './item-editor'
export async function removeItem(o: { itemId: string; name: string; ctx: PortalCtx; request: PortalRequest }): Promise<{ ok: boolean; message: string }> {
  return { ok: false, message: `Excluir “${o.name}”: ${NOT_YET}` }
}
