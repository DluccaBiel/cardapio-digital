/** "Como o produto está agora" no Cardápio Web — relido do cardápio (categories/menu) para o relatório. */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { ProductView } from '@orvia/shared/lib/prints'
import { CW_API, MENU_PATH } from './cw-api'
import { cardapioWebSnapshot } from './cw-normalize'
export type { ProductView }

export function viewFromSnapshotItem(raw: unknown, itemId: string): ProductView | null {
  const snap = cardapioWebSnapshot(raw, null, '')
  const it = snap?.items.find((i) => i.id === itemId)
  if (!it) return null
  return {
    name: it.name, description: it.description, imageUrl: it.imageUrl, categoryName: it.categoryName,
    price: it.price, originalPrice: it.originalPrice, active: it.status === 'active' ? true : it.status === 'paused' ? false : null,
    schedule: 'não informado pelo portal', promotion: it.originalPrice !== null && it.price !== null ? `de R$ ${it.originalPrice.toFixed(2).replace('.', ',')} por R$ ${it.price.toFixed(2).replace('.', ',')}` : null,
  }
}
export async function fetchProductView(productId: string, _ctx: PortalCtx, request: PortalRequest): Promise<ProductView | null> {
  try {
    const r = await request('GET', CW_API + MENU_PATH)
    return r.status >= 200 && r.status < 300 ? viewFromSnapshotItem(r.json, productId) : null
  } catch { return null }
}
