/**
 * Acesso à API do Cardápio Web usando o próprio login do portal (token e loja do localStorage da aba).
 * Nada é guardado nem enviado a terceiros: o token só vai para api.cardapioweb.com.
 * Observado no script FlyTo do dono: Authorization = access_token; Companyid = active_company_id.
 */
export const CW_API = 'https://api.cardapioweb.com'
export const MENU_PATH = '/api/v1/company/categories/menu?full_version=true'

/** Cabeçalhos que o próprio portal usou (visto pelo hook) — plano B quando o localStorage não tem o que esperamos. */
let observed: { Authorization?: string; Companyid?: string } = {}
export const setObservedAuth = (a: { Authorization?: string; Companyid?: string }) => { observed = a }
export function cwStorageNames(): string[] {
  const out: string[] = []
  for (const st of [localStorage, sessionStorage]) { try { for (let i = 0; i < st.length; i += 1) { const k = st.key(i) ?? ''; if (/token|company|empresa|auth|loja|store|user/i.test(k)) out.push(k) } } catch { /* */ } }
  return out
}
export function cwAuth(): { Authorization: string; Companyid: string; Accept: string } | null {
  if (observed.Authorization && observed.Companyid) return { Authorization: observed.Authorization, Companyid: observed.Companyid, Accept: 'application/json' }
  try {
    const token = localStorage.getItem('access_token')
    const company = localStorage.getItem('active_company_id')
    return token && company ? { Authorization: token, Companyid: company, Accept: 'application/json' } : null
  } catch {
    return null
  }
}
export const cwCompanyId = (): string | null => { try { return localStorage.getItem('active_company_id') ?? observed.Companyid ?? null } catch { return observed.Companyid ?? null } }

export async function cwRequest(method: string, url: string, body?: unknown): Promise<{ status: number; json: unknown }> {
  const auth = cwAuth()
  if (!auth) return { status: 0, json: { error: 'sem login do Cardápio Web nesta aba (atualize a página)' } }
  const full = url.startsWith('http') ? url : CW_API + url
  if (!full.startsWith(CW_API + '/')) return { status: 0, json: { error: 'destino não permitido' } }
  try {
    const res = await fetch(full, {
      method,
      headers: body !== undefined ? { ...auth, 'Content-Type': 'application/json' } : auth,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    })
    const text = await res.text()
    let json: unknown = null
    try { json = text ? JSON.parse(text) : null } catch { json = null }
    return { status: res.status, json }
  } catch {
    return { status: 0, json: { error: 'falha de rede' } }
  }
}
