/**
 * MAIN world no portal do Cardápio Web — SOMENTE OBSERVA. Guarda um registro de TODAS as chamadas do portal à
 * API (api.cardapioweb.com): método, caminho, forma do pedido/resposta; e avisa a extensão quando VOCÊ edita algo
 * (para ela aprender "como o portal salva"). Não envia nada a ninguém. O token só fica na memória da aba, nunca
 * entra em relatório.
 */
;(() => {
  const w = window as unknown as { __orviaCwHook?: boolean }
  if (w.__orviaCwHook) return
  w.__orviaCwHook = true
  const API = 'https://api.cardapioweb.com/'
  const MAX = 600_000
  type Rec = { seq: number; ts: number; method: string; path: string; query: string; status: number; reqType: string; reqKeys: string; reqBody?: unknown; resShape: string; resSample?: unknown }
  const log: Rec[] = []
  let seq = 0
  let auth: { Authorization?: string; Companyid?: string } = {}
  const post = (m: Record<string, unknown>) => window.postMessage({ source: 'orvia-hook', ...m }, window.location.origin)
  const tryJson = (t: unknown): unknown => { if (typeof t !== 'string' || !t || t.length > MAX) return undefined; try { return JSON.parse(t) } catch { return undefined } }

  /** forma sem valores: chaves e tipos (arrays mostram só o 1º elemento) */
  const shape = (v: unknown, d = 0): string => {
    if (v === null) return 'null'
    if (Array.isArray(v)) return d > 3 ? '[…]' : `[${v.length}×${v.length ? shape(v[0], d + 1) : ''}]`
    if (typeof v === 'object') return d > 3 ? '{…}' : `{${Object.entries(v as object).slice(0, 40).map(([k, x]) => `${k}:${shape(x, d + 1)}`).join(',')}}`
    return typeof v
  }
  /** corta textos longos/ listas grandes só para caber no relatório */
  const trim = (v: unknown, d = 0): unknown => {
    if (Array.isArray(v)) return v.slice(0, 2).map((x) => trim(x, d + 1))
    if (v && typeof v === 'object') return d > 5 ? '{…}' : Object.fromEntries(Object.entries(v as object).slice(0, 50).map(([k, x]) => [k, trim(x, d + 1)]))
    return typeof v === 'string' && v.length > 120 ? v.slice(0, 120) + '…' : v
  }

  const take = (headers: Record<string, string>) => {
    for (const [k, v] of Object.entries(headers)) {
      const l = k.toLowerCase()
      if (l === 'authorization') auth.Authorization = v
      if (l === 'companyid') auth.Companyid = v
    }
  }
  const hdrs = (h: HeadersInit | undefined): Record<string, string> => {
    const out: Record<string, string> = {}
    if (!h) return out
    if (h instanceof Headers) h.forEach((v, k) => (out[k] = v))
    else if (Array.isArray(h)) for (const [k, v] of h) out[k] = v
    else Object.assign(out, h)
    return out
  }

  function report(method: string, rawUrl: string, status: number, reqBody: unknown, text: string | null) {
    let u: URL
    try { u = new URL(rawUrl, location.href) } catch { return }
    if (!u.href.startsWith(API)) return
    const m = method.toUpperCase()
    const res = text ? tryJson(text) : undefined
    const isForm = typeof FormData !== 'undefined' && reqBody instanceof FormData
    const reqJson = typeof reqBody === 'string' ? tryJson(reqBody) : undefined
    const write = m !== 'GET' && m !== 'OPTIONS' && m !== 'HEAD'
    const isMenu = m === 'GET' && /\/(categories|subitems|item|items|products|menu)/i.test(u.pathname)
    const rec: Rec = {
      seq: (seq += 1), ts: Date.now(), method: m, path: u.pathname, query: [...u.searchParams.keys()].join('&'), status,
      reqType: isForm ? 'multipart' : reqJson !== undefined ? 'json' : reqBody == null ? '-' : 'outro',
      reqKeys: isForm ? [...(reqBody as FormData).keys()].join(',') : reqJson !== undefined ? shape(reqJson) : '',
      resShape: res === undefined ? (text ? `texto ${text.length}b` : '-') : shape(res),
    }
    if (write && reqJson !== undefined) rec.reqBody = trim(reqJson)
    if (write && res !== undefined) rec.resSample = trim(res)
    if (isMenu && res !== undefined) rec.resSample = trim(res)
    log.unshift(rec)
    if (log.length > 120) log.length = 120
    if (write && status >= 200 && status < 300 && !isForm) post({ kind: 'write', method: m, url: u.href, status, body: reqJson, json: res })
    else if (m === 'GET' && res !== undefined) post({ kind: 'read', method: m, url: u.href, status, json: res })
  }

  const of = window.fetch.bind(window)
  window.fetch = async function (input: RequestInfo | URL, init?: RequestInit) {
    const res = await of(input, init)
    try {
      const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
      if (new URL(url, location.href).href.startsWith(API)) {
        const method = init?.method ?? (input instanceof Request ? input.method : 'GET')
        take({ ...(input instanceof Request ? hdrs(input.headers) : {}), ...hdrs(init?.headers) })
        res.clone().text().then((t) => report(method, url, res.status, init?.body, t)).catch(() => {})
      }
    } catch { /* observar nunca pode quebrar o portal */ }
    return res
  }
  type X = XMLHttpRequest & { __o?: { m: string; u: string } }
  const open = XMLHttpRequest.prototype.open
  const send = XMLHttpRequest.prototype.send
  const setH = XMLHttpRequest.prototype.setRequestHeader
  XMLHttpRequest.prototype.open = function (this: X, ...a: any[]) { this.__o = { m: String(a[0]), u: String(a[1]) }; return (open as any).apply(this, a) } as typeof open
  XMLHttpRequest.prototype.setRequestHeader = function (this: X, k: string, v: string) { try { if (this.__o && new URL(this.__o.u, location.href).href.startsWith(API)) take({ [k]: v }) } catch { /* */ } return setH.call(this, k, v) }
  XMLHttpRequest.prototype.send = function (this: X, body?: Document | XMLHttpRequestBodyInit | null) {
    this.addEventListener('load', () => { try { if (this.__o) report(this.__o.m, this.__o.u, this.status, body, typeof this.responseText === 'string' ? this.responseText : null) } catch { /* */ } })
    return send.call(this, body)
  }

  window.addEventListener('message', (e: MessageEvent) => {
    const d = e.data as { source?: string; id?: string; action?: string } | null
    if (e.source !== window || !d || d.source !== 'orvia-exec' || !d.id) return
    const reply = (json: unknown) => window.postMessage({ source: 'orvia-exec-result', id: d.id, status: 200, json }, window.location.origin)
    if (d.action === 'dump') return reply({ log, hasAuth: !!auth.Authorization, hasCompany: !!auth.Companyid })
    if (d.action === 'auth') return reply(auth)
  })
})()
