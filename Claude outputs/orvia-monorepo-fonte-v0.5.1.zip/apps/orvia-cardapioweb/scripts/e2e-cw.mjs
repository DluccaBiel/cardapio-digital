#!/usr/bin/env node
/**
 * E2E no Chromium REAL com a extensão carregada. Portal e API do Cardápio Web SIMULADOS (dados fictícios; formato
 * conforme o script FlyTo do dono). Uso: xvfb-run -a node scripts/e2e-cw.mjs
 */
import { createRequire } from 'node:module'
import { execSync, spawn } from 'node:child_process'
import { cpSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
const require = createRequire(import.meta.url)
let chromium
try { ;({ chromium } = require('playwright')) } catch { ;({ chromium } = require(join(execSync('npm root -g').toString().trim(), 'playwright'))) }
const ROOT = resolve(new URL('..', import.meta.url).pathname)
let bad = 0
const check = (n, ok, x = '') => { if (!ok) bad += 1; console.log(`${ok ? '  ✓' : '  ✗'} ${n}${ok ? '' : ' → ' + x}`) }

execSync('node scripts/build.mjs', { cwd: ROOT, env: { ...process.env, ORVIA_E2E: '1' }, stdio: 'inherit' })
const EXT = mkdtempSync(join(tmpdir(), 'orvia-cw-ext-'))
for (const f of ['dist', 'assets', 'flyto', 'options.html', 'manifest.json']) cpSync(join(ROOT, f), join(EXT, f), { recursive: true })

const MENU = [
  { name: 'Lanches', status: 'ACTIVE', items: [
    { id: 11, name: 'X-Burger', description: 'Pão, carne e queijo', price: 32.9, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/a.jpg', add_ons: [{ add_on_name: 'Adicionais', add_on_status: 'ACTIVE' }] },
    { id: 12, name: 'Astro Bacon', price: '41,50', status: 'ACTIVE', image_url: null, add_ons: [] },
  ] },
  { name: 'Bebidas', status: 'ACTIVE', items: [
    { id: 21, name: 'Refri Lata', price: 6, status: 'ACTIVE', image_url: 'https://img.cardapioweb.com/c.jpg' },
    { id: 22, name: 'Suco Natural', price: 9.5, status: 'INACTIVE', image_url: null },
  ] },
]
const PAGE = `<!doctype html><title>Cardápio Web</title><h1>Loja Teste</h1><script>localStorage.setItem('access_token','tok-fake');localStorage.setItem('active_company_id','77')</script>`
const CORS = { 'access-control-allow-origin': 'https://portal.cardapioweb.com', 'access-control-allow-headers': 'authorization,companyid,content-type,accept', 'access-control-allow-methods': '*' }
const apiSeen = []

const userDir = mkdtempSync(join(tmpdir(), 'orvia-cw-prof-'))
const port = 9611
const proc = spawn(chromium.executablePath(), [`--user-data-dir=${userDir}`, `--remote-debugging-port=${port}`, `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-sandbox', '--no-first-run', '--no-default-browser-check', '--window-size=1360,900', 'about:blank'], { stdio: 'ignore' })
let browser
for (let i = 0; i < 40 && !browser; i += 1) { try { browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`) } catch { await new Promise((r) => setTimeout(r, 500)) } }
try {
  const ctx = browser.contexts()[0]
  await ctx.route('https://portal.cardapioweb.com/**', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: PAGE }))
  await ctx.route('https://api.cardapioweb.com/**', (r) => {
    const req = r.request()
    const h = req.headers()
    apiSeen.push({ m: req.method(), u: req.url(), auth: h['authorization'], company: h['companyid'] })
    if (req.method() === 'OPTIONS') return r.fulfill({ status: 204, headers: CORS })
    if (req.url().includes('/categories/menu')) return r.fulfill({ status: 200, contentType: 'application/json', headers: CORS, body: JSON.stringify(MENU) })
    return r.fulfill({ status: 404, headers: CORS, body: '{}' })
  })
  const page = await ctx.newPage()
  await page.goto('https://portal.cardapioweb.com/menu')
  const orvia = page.locator('button.fab[aria-label="Abrir Orvia"]')
  await orvia.waitFor({ state: 'attached' })
  check('botão flutuante Orvia aparece no Cardápio Web', await orvia.isVisible())
  check('FlyTo (Fotos em massa) carregou junto, sem conflito', await page.locator('button#fab').isVisible())
  await orvia.click()
  await page.locator('aside.panel').waitFor()
  await page.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  await page.waitForFunction(() => /X-Burger/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
  const txt = await page.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('sincronizou os 4 produtos pela API', /X-Burger/.test(txt) && /Astro Bacon/.test(txt) && /Refri Lata/.test(txt) && /Suco Natural/.test(txt), txt.slice(0, 300))
  check('mostra "Cardápio Web" (não iFood) na tela', /Cardápio Web/.test(txt) && !/iFood/.test(txt), txt.slice(0, 200))
  const hit = apiSeen.find((x) => x.u.includes('/categories/menu'))
  check('chamou a API com Authorization + Companyid da aba', hit?.auth === 'tok-fake' && hit?.company === '77', JSON.stringify(hit))
  check('só leu: nenhuma escrita sem aprovação', apiSeen.every((x) => x.m === 'GET' || x.m === 'OPTIONS'), JSON.stringify(apiSeen.filter((x) => x.m !== 'GET')))
  // ---- Diagnóstico + aprendizado ----
  await page.evaluate(() => fetch('https://api.cardapioweb.com/api/v1/company/item/11', { method: 'PUT', headers: { Authorization: 'tok-fake', Companyid: '77', 'content-type': 'application/json' }, body: JSON.stringify({ price: 35.9 }) }))
  await page.waitForTimeout(500)
  const root = page.locator('#orvia-cw-root')
  await root.getByRole('button', { name: /Diagnóstico/ }).first().click()
  await page.waitForFunction(() => /PUT .*item.11/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 10000 }).catch(() => undefined)
  const dtxt = await page.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('Diagnóstico mostra "Leitura OK: 4 produto(s)"', /Leitura OK: 4 produto\(s\) em 2 categoria/.test(dtxt), dtxt.slice(0, 300))
  check('Diagnóstico lista a escrita feita no portal (PUT item/11)', /PUT \/api\/v1\/company\/item\/11/.test(dtxt), dtxt.slice(0, 600))
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://portal.cardapioweb.com' }).catch(() => undefined)
  await page.bringToFront()
  await root.getByRole('button', { name: /Copiar relatório/ }).first().click()
  await page.waitForTimeout(1500)
  const rep = await page.evaluate(() => navigator.clipboard.readText()).catch((e) => String(e))
  check('relatório copiado tem a escrita com corpo e sem token', /"price": 35.9/.test(rep) && !/tok-fake/.test(rep), rep.slice(0, 300))
  check('relatório tem a forma da leitura do cardápio', /leituraDoCardapio/.test(rep) && /chamadasDoPortal/.test(rep))

  // ---- plano B: login não está no localStorage, mas o portal usa nos pedidos ----
  const p2 = await ctx.newPage()
  await ctx.route('https://portal.cardapioweb.com/alt', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: '<!doctype html><title>x</title><h1>Loja</h1><script>fetch("https://api.cardapioweb.com/api/v1/company/me",{headers:{Authorization:"tok-alt",Companyid:"88"}})</script>' }))
  await p2.goto('https://portal.cardapioweb.com/alt')
  await p2.locator('button.fab[aria-label="Abrir Orvia"]').waitFor({ state: 'attached' })
  await p2.waitForTimeout(800)
  await p2.locator('button.fab[aria-label="Abrir Orvia"]').click()
  await p2.locator('aside.panel').waitFor()
  await p2.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  await p2.waitForFunction(() => /X-Burger/.test(document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
  const t2 = await p2.evaluate(() => document.querySelector('#orvia-cw-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('sem login no localStorage: usa o login que o portal usou e sincroniza', /X-Burger/.test(t2) && apiSeen.some((x) => x.auth === 'tok-alt' && x.company === '88' && x.u.includes('/categories/menu')), t2.slice(0, 200))
  check('status Ativo/Desativado nos produtos', /Ativo/.test(txt) && /(Desativado|Pausado|Inativo)/.test(txt), txt.slice(0, 400))
} finally {
  await browser.close().catch(() => undefined)
  proc.kill('SIGKILL')
}
console.log(bad ? `\n${bad} falha(s)` : '\nTudo certo')
process.exit(bad ? 1 : 0)
