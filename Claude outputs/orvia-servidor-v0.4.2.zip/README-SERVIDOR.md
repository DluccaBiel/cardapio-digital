# Servidor — o que copiar para o repositório (nada aqui sobrescreve arquivos existentes)

| Arquivo | Destino | O que faz |
|---|---|---|
| supabase/migrations/0005_menu_optimizations.sql | idem | tabelas de histórico + bucket privado `optimization-evidence` |
| lib/ai/competitors.ts | idem | pesquisa de concorrentes (fontes públicas, citadas) |
| lib/menu/optimizations.ts | idem | validação (zod) e checagem de PNG |
| app/api/v1/analysis/route.ts | idem | POST: IA + concorrentes → sugestões (não grava) |
| app/api/v1/optimizations/route.ts | idem | POST: salva plano/resultado/prints; GET: histórico com URL assinada |

Antes de aplicar: BACKUP (`npx supabase db dump --linked`), teste com `npx supabase db reset` local.
Variáveis na Vercel: `ANTHROPIC_API_KEY`. Depois: `npx supabase db push`.
Não testado contra Supabase/Anthropic reais (só tipos e validação). A busca de concorrentes usa a ferramenta
`web_search_20250305`; se o SDK/modelo da conta não a aceitar, a análise segue sem concorrentes (competitors_status=indisponivel).
Tela "Cardápio → Otimizações" no painel: ainda não feita (os dados já ficam acessíveis por GET /api/v1/optimizations?client_id=).
