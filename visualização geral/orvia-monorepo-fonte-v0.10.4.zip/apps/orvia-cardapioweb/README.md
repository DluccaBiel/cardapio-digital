# Orvia · Otimizador Cardápio Web (extensão Chrome MV3)

Mesmo fluxo e mesma tela da extensão do iFood (motor compartilhado em `packages/shared`):
botão **O** → Sincronizar → produtos → Análise (concorrentes + boas práticas, PDF, aprovar/rejeitar com feedback) →
executar só o aprovado (OK/ERRO por ação, ESC para) → relatório em UMA imagem.
Inclui também o **FlyTo · Fotos em massa** (pasta `flyto/`, o seu script original, sem alteração), com o botão dele em outro canto.

## O que já funciona (verificado em portal SIMULADO)
- Sincronizar: lê `GET api.cardapioweb.com/api/v1/company/categories/menu?full_version=true` com o login da própria aba
  (`access_token` + `active_company_id`); produtos, categorias, preço, foto, Ativo/Desativado/Em falta, complementos.
- Análise, proposta, PDF, aprovar/rejeitar, relatório e envio ao Orvia: iguais ao iFood.
- Aprender por exemplo: o hook observa o que VOCÊ edita no portal (`/api/v1/company/*`) para a extensão aprender a escrita.

## O que ainda depende de gravação no portal real
Preço, nome, descrição, ativar/pausar, criar produto/combo, horários, excluir e reordenar categorias: o formato de escrita
do Cardápio Web não é conhecido (só foto: `PUT /api/v1/company/item/image/{id}`). A extensão NÃO chuta endpoint: avisa
"falta ensinar" e aprende quando você faz a alteração uma vez no portal (aba Diagnóstico).

## Testes
`npm test` (normalizador) · `xvfb-run -a node scripts/e2e-cw.mjs` (Chromium real, portal/API simulados).

## v0.4.0
- Seta **↻** no topo do painel (e botão "↻ Propor novas otimizações" no card da proposta): nova rodada de ideias com 1 clique; as já mostradas não voltam e as versões anteriores ficam em "Versões".
- **Montar PDF**: escolha itens (só as marcadas / todas / uma a uma), seções (resumo, combos, ajustes, pontos de atenção, concorrentes, fontes), título e observação. Desmarcar no PDF não altera o que será executado.
- Re-render não tira mais o cursor do campo em que você está digitando.

## v0.4.1
- Clicar em produto/ação não joga mais a tela para o início: a rolagem é mantida (painel e listas).
- PDF agora é uma **apresentação** (slides paisagem, tema dashboard): visão geral com previsão, combos, ajustes por produto com "hoje (ponto fraco) → depois → para que serve", pontos de atenção, região e próximos passos. Formatos: Resumido (1 linha por produto) e Completo (1 cartão por produto).
- ↻ sem ideias novas mantém a proposta atual e avisa, em vez de deixar a lista vazia.

## v0.4.3 — integração com o hub real (docs/integracao-extensoes-hub.md)
- Login manda `extension: "orvia-cardapioweb"`; depois confere `GET /me` (`extension` igual) — se diferente, apaga a chave local e pede novo login.
- Handshake manda o nome real do manifest (antes mandava "Otimizador iFood").
- `chrome.alarms` a cada 1 min: heartbeat + reenvio da fila offline de otimizações (rede/5xx/429 reenvia; 4xx descarta; 401 apaga a chave).
- Prints: até 6 PNG, nome válido, ≤ 2,5 MB cada, corpo ≤ 4,5 MB (reduz antes de enviar).

## v0.4.4
- ↻ abre a tela "Propor novas otimizações": você escreve o que quer propor (ou deixa em branco), informa cidade/bairro e liga a pesquisa de concorrentes (consulta o servidor do Orvia, modo gratuito).
- Diagnóstico → "Servidor Orvia (consulta real)": conexão, canal, último contato, fila offline, última análise (modo gratuito/IA, nº de lojas/fontes/ideias) e as últimas chamadas (sem chave/corpo). Botão "Testar servidor agora".
- Ao perder a chave (401/canal errado) o e-mail fica salvo para reconectar sem digitar de novo.
