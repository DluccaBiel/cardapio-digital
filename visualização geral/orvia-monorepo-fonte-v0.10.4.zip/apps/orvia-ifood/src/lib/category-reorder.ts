/** Executa a nova ordem no iFood (PATCH gravado). Sugestão/ordem atual ficam em category-order (compartilhado). */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { CatRef } from '@orvia/shared/lib/category-order'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300

const liveOrder = (json: unknown): string[] | null => {
  const arr = Array.isArray(json) ? json : isRec(json) && Array.isArray(json.data) ? json.data : null
  if (!arr) return null
  const ids = arr.map((e) => (isRec(e) ? (typeof e.categoryId === 'string' ? e.categoryId : typeof e.id === 'string' ? e.id : null) : null))
  return ids.every((x): x is string => !!x) ? ids : null
}

export async function reorderCategories(o: { order: CatRef[]; ctx: PortalCtx; request: PortalRequest; sleep?: (ms: number) => Promise<void> }): Promise<{ ok: boolean; message: string }> {
  const { ctx, request } = o
  const listUrl = `${ctx.origin}/next-web-bff/menu/v4/category?ownerUUID=${encodeURIComponent(ctx.ownerId)}`
  const live = await request('GET', listUrl)
  const liveIds = ok2xx(live.status) ? liveOrder(live.json) : null
  if (!liveIds || !liveIds.length) return { ok: false, message: 'Não consegui ler a lista de categorias do iFood — ordem não alterada.' }
  const known = new Set(liveIds)
  const wanted = o.order.map((c) => c.id).filter((id) => known.has(id))
  if (wanted.length !== o.order.length) return { ok: false, message: 'O cardápio mudou (categoria que não existe mais). Sincronize e analise de novo — ordem não alterada.' }
  const rest = liveIds.filter((id) => !wanted.includes(id)) // categorias vazias/novas ficam no fim, na ordem em que estavam
  const finalIds = [...wanted, ...rest]
  if (finalIds.every((id, i) => id === liveIds[i])) return { ok: true, message: 'As categorias já estavam nesta ordem.' }
  const res = await request('PATCH', `${ctx.origin}/next-web-bff/menu/v4/sequence/order?ownerUUID=${encodeURIComponent(ctx.ownerId)}`, {
    categories: finalIds.map((id, order) => ({ id, order })),
    items: [],
    optionGroups: [],
    options: [],
  })
  if (!ok2xx(res.status)) return { ok: false, message: `O iFood recusou a nova ordem das categorias (HTTP ${res.status}).` }
  // o iFood processa a ordem aos poucos: relê com paciência (até ~20 s) antes de dar erro
  const sleep = o.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)))
  let afterIds: string[] | null = null
  for (const wait of [0, 1000, 2000, 3000, 4000, 5000, 5000]) {
    if (wait) await sleep(wait)
    const after = await request('GET', listUrl)
    afterIds = ok2xx(after.status) ? liveOrder(after.json) : null
    if (afterIds && afterIds.length === finalIds.length && afterIds.every((id, i) => id === finalIds[i])) return { ok: true, message: `Categorias reordenadas e conferidas no iFood (${finalIds.length}).` }
  }
  if (!afterIds) return { ok: true, message: 'Ordem enviada (HTTP 200), mas não consegui reler para conferir.' }
  return { ok: false, message: 'Enviei a ordem, mas o iFood ainda mostra a anterior depois de esperar ~20 s. Confira no portal (pode demorar a atualizar).' }
}
