/**
 * Editor de produto do iFood (nome e descrição) — receita OBSERVADA no portal real:
 *   GET  /partner-catalog-bff/product/{productId}?ownerId=…            (produto)
 *   GET  /partner-catalog-bff/product/{productId}/available-at?ownerId=… (categorias/preço/horário)
 *   PUT  /partner-catalog-bff/v2/item?ownerId=…                         (produto inteiro + categorias)
 * O corpo do PUT é remontado a partir das duas leituras (receita conferida byte a byte contra um PUT
 * real do portal — ver tests/real-item-edit.test.ts). Qualquer estrutura desconhecida ABORTA sem enviar.
 * Depois de gravar, relê e confere; se algo além do pedido mudou, tenta restaurar o corpo original.
 * Puro: sem chrome.*, sem DOM (o `request` é injetado).
 */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { Schedule } from '@orvia/shared/core/proposal'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)

export type { PortalCtx }

export type Built = { ok: true; body: Rec } | { ok: false; reason: string }

const PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'variant', 'unit', 'optionGroups', 'promotions', 'shouldBlock', 'tags', 'classification'])
const GROUP_KEYS = new Set(['id', 'name', 'status', 'type', 'sequence', 'min', 'max', 'options'])
const OPTION_KEYS = new Set(['id', 'name', 'description', 'sequence', 'product', 'status', 'extensions'])
const OPTION_PRODUCT_KEYS = new Set(['id', 'name', 'description', 'imageResource', 'industrialized', 'optionGroups', 'tags', 'classification', 'stock', 'variant'])
const EXT_KEYS = new Set(['status', 'price', 'catalogType', 'restrictions', 'promotions', 'itemExtensionId'])
const OPT_EXT_KEYS = new Set(['status', 'price', 'catalogType', 'promotions', 'restrictions', 'externalCode'])
const AVAIL_KEYS = new Set(['id', 'name', 'status', 'type', 'offerId', 'extensions', 'shifts'])

const unknownKeys = (o: Rec, known: Set<string>) => Object.keys(o).filter((k) => !known.has(k))
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const
const SHIFT_KEYS = new Set(['startTime', 'endTime', 'default', ...DAYS])
const shiftOk = (x: unknown): x is Rec => isRec(x) && !unknownKeys(x, SHIFT_KEYS).length && typeof x.startTime === 'string' && typeof x.endTime === 'string'
/** faixas (do iFood) → conjunto "dia|início|fim" para comparar horários sem depender do formato */
export function shiftSet(shifts: unknown): string[] {
  if (!Array.isArray(shifts) || shifts.length === 0 || allDay(shifts)) return ['sempre']
  const out: string[] = []
  for (const x of shifts) if (isRec(x)) DAYS.forEach((d, i) => { if (x[d] === true) out.push(`${i}|${x.startTime}|${x.endTime}`) })
  return out.sort()
}
export const scheduleSet = (sc: Schedule | null): string[] => (!sc || !sc.length ? ['sempre'] : sc.flatMap((x) => x.days.map((d) => `${d}|${x.start}|${x.end}`)).sort())
const toShifts = (sc: Schedule): Rec[] => sc.flatMap((x) => x.days.map((d) => ({ startTime: x.start, endTime: x.end, ...Object.fromEntries(DAYS.map((n, i) => [n, i === d])) })))
const allDay = (shifts: unknown): boolean => {
  if (!Array.isArray(shifts) || shifts.length === 0) return true
  if (shifts.length !== 1 || !isRec(shifts[0])) return false
  const s = shifts[0]
  return s.startTime === '00:00' && s.endTime === '23:59' && ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].every((d) => s[d] === true)
}

/** Remonta o corpo do PUT /v2/item a partir das leituras. */
export function buildItemBody(productIn: unknown, availableAt: unknown, over: { name?: string; description?: string; schedule?: Schedule | null; imageResource?: { baseUrl: string; path: string } } = {}): Built {
  if (!isRec(productIn) || typeof productIn.id !== 'string') return { ok: false, reason: 'leitura do produto inesperada' }
  let product: Rec = productIn
  if (!Array.isArray(availableAt) || availableAt.length === 0) return { ok: false, reason: 'não achei em quais categorias o produto está' }
  const badP = unknownKeys(product, PRODUCT_KEYS)
  if (badP.length) return { ok: false, reason: `produto com campos que não conheço (${badP.join(', ')}) — não alterado` }
  // produto sem foto/promoções/tags/complementos pode vir SEM esses campos (ou null): usa o vazio do portal. Só recusa se faltar o essencial.
  if (typeof product.name !== 'string') return { ok: false, reason: 'produto sem nome na leitura do iFood — não alterado' }
  const bad = (['imageResource', 'optionGroups', 'promotions', 'tags'] as const).filter((k) => product[k] !== undefined && product[k] !== null && (k === 'imageResource' ? !isRec(product[k]) : !Array.isArray(product[k])))
  if (bad.length) return { ok: false, reason: `produto com campos em formato inesperado (${bad.join(', ')}) — não alterado` }
  product = { ...product, imageResource: isRec(product.imageResource) ? product.imageResource : { baseUrl: '', path: '' }, optionGroups: Array.isArray(product.optionGroups) ? product.optionGroups : [], promotions: Array.isArray(product.promotions) ? product.promotions : [], tags: Array.isArray(product.tags) ? product.tags : [] }

  const categories: Rec[] = []
  for (const c of availableAt) {
    if (!isRec(c) || !isRec(c.extensions) || typeof c.id !== 'string' || typeof c.offerId !== 'string') return { ok: false, reason: 'categoria do produto inesperada' }
    if (unknownKeys(c, AVAIL_KEYS).length) return { ok: false, reason: 'categoria com campos que não conheço — não alterada' }
    if (Array.isArray(c.shifts) && !c.shifts.every(shiftOk)) return { ok: false, reason: `horário de “${String(c.name)}” com campos que não conheço — não alterado` }
    const keep = !allDay(c.shifts)
    const shifts: Rec[] = over.schedule !== undefined ? (over.schedule && over.schedule.length ? toShifts(over.schedule) : []) : keep ? (c.shifts as Rec[]).map(({ default: _d, ...r }) => r) : []
    const availability = shifts.length ? 'SHIFTS' : 'ALWAYS'
    const extensions: Rec[] = []
    for (const [id, e] of Object.entries(c.extensions)) {
      if (!isRec(e) || unknownKeys(e, EXT_KEYS).length) return { ok: false, reason: 'preço/canal com campos que não conheço — não alterado' }
      extensions.push({ status: e.status, price: e.price, catalogType: e.catalogType, restrictions: e.restrictions ?? [], promotions: e.promotions ?? [], itemExtensionId: e.itemExtensionId, id })
    }
    categories.push({ action: 'UPDATE', availability, categoryId: c.id, extensions, name: c.name, offerId: c.offerId, shifts, itemsCount: 0 })
  }

  const optionGroups: Rec[] = []
  for (const g of product.optionGroups as unknown[]) {
    if (!isRec(g) || unknownKeys(g, GROUP_KEYS).length || !Array.isArray(g.options)) return { ok: false, reason: 'grupo de complementos com campos que não conheço — não alterado' }
    const options: Rec[] = []
    for (const o of g.options) {
      if (!isRec(o) || unknownKeys(o, OPTION_KEYS).length || !isRec(o.product) || !isRec(o.extensions)) return { ok: false, reason: 'complemento com campos que não conheço — não alterado' }
      if (unknownKeys(o.product, OPTION_PRODUCT_KEYS).length) return { ok: false, reason: 'complemento com campos que não conheço — não alterado' }
      const prod: Rec = { ...o.product }
      prod.imageResource ??= { baseUrl: '', path: '' }
      prod.stock = null
      const oext: Rec[] = []
      for (const [id, e] of Object.entries(o.extensions)) {
        if (!isRec(e) || unknownKeys(e, OPT_EXT_KEYS).length) return { ok: false, reason: 'preço de complemento com campos que não conheço — não alterado' }
        oext.push({ status: e.status, price: e.price, catalogType: e.catalogType, promotions: e.promotions ?? [], ...(e.restrictions !== undefined ? { restrictions: e.restrictions } : {}), id })
      }
      options.push({ id: o.id, sequence: o.sequence, product: prod, status: o.status, extensions: oext })
    }
    optionGroups.push({ id: g.id, name: g.name, status: g.status, type: g.type ?? '', sequence: g.sequence, min: g.min, max: g.max, options })
  }

  return {
    ok: true,
    body: {
      categories,
      stock: null,
      shouldBlock: product.shouldBlock,
      promotions: product.promotions,
      combo: false,
      comboOptionGroups: [],
      imageResource: over.imageResource ?? product.imageResource,
      tags: product.tags,
      unit: typeof product.unit === 'string' && product.unit ? product.unit : 'g',
      variant: product.variant,
      industrialized: product.industrialized,
      description: over.description ?? (typeof product.description === 'string' ? product.description : ''),
      name: over.name ?? product.name,
      optionGroups,
      productId: product.id,
    },
  }
}

const ok2xx = (s: number) => s >= 200 && s < 300
const urlOf = (ctx: PortalCtx, path: string) => `${ctx.origin}${path}?ownerId=${encodeURIComponent(ctx.ownerId)}`

/** campos do produto que NÃO podem mudar numa edição de nome/descrição */
const EMPTY_IMG = { baseUrl: '', path: '' }
/** JSON com chaves ordenadas: a ordem em que o iFood devolve os campos varia e não é mudança. */
const canon = (v: unknown): unknown => (Array.isArray(v) ? v.map(canon) : isRec(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canon(v[k])])) : v)
const stable = (v: unknown): string => JSON.stringify(canon(v))
/** O iFood passa a devolver `name`/`description` também na opção do complemento depois de salvar: não é mudança. */
const stableGroups = (gs: unknown): unknown =>
  Array.isArray(gs) ? gs.map((g) => (isRec(g) && Array.isArray(g.options) ? { ...g, options: g.options.map((o) => { if (!isRec(o)) return o; const { name: _n, description: _d, ...r } = o; return r }) } : g)) : []
const comparable = (p: unknown): string => {
  if (!isRec(p)) return ''
  const { name: _n, description: _d, unit: _u, classification: _c, ...rest } = p
  // ausente/null/vazio contam como iguais (o iFood pode devolver "[]" onde antes não vinha o campo)
  return stable({ ...rest, imageResource: isRec(rest.imageResource) ? rest.imageResource : EMPTY_IMG, promotions: rest.promotions ?? [], tags: rest.tags ?? [], optionGroups: stableGroups(rest.optionGroups) })
}

export async function editItem(opts: { productId: string; ctx: PortalCtx; request: PortalRequest; changes: { name?: string; description?: string; schedule?: Schedule | null } }): Promise<{ ok: boolean; message: string }> {
  const { productId, ctx, request, changes } = opts
  if (!changes.name && changes.description === undefined && changes.schedule === undefined) return { ok: true, message: 'Nada a alterar.' }
  if (changes.name !== undefined && changes.name.trim().length < 2) return { ok: false, message: 'Nome novo vazio — não alterado.' }
  const pUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}`)
  const aUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}/available-at`)
  const [p, a] = [await request('GET', pUrl), await request('GET', aUrl)]
  if (!ok2xx(p.status) || !ok2xx(a.status)) return { ok: false, message: `Não consegui ler o produto no iFood (HTTP ${p.status}/${a.status}).` }
  if (!isRec(p.json) || p.json.id !== productId) return { ok: false, message: 'O iFood devolveu outro produto — nada foi enviado.' }

  const original = buildItemBody(p.json, a.json)
  if (!original.ok) return { ok: false, message: original.reason }
  const wanted = buildItemBody(p.json, a.json, { name: changes.name?.trim(), description: changes.description, schedule: changes.schedule })
  if (!wanted.ok) return { ok: false, message: wanted.reason }
  if (JSON.stringify(original.body) === JSON.stringify(wanted.body)) return { ok: true, message: 'O iFood já está igual.' }

  const put = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), wanted.body)
  if (!ok2xx(put.status)) return { ok: false, message: `O iFood recusou a alteração (HTTP ${put.status}).` }

  const check = await request('GET', pUrl)
  const after = check.json
  const nameOk = changes.name === undefined || (isRec(after) && after.name === changes.name.trim())
  const descOk = changes.description === undefined || (isRec(after) && (after.description ?? '') === changes.description)
  const restOk = comparable(after) === comparable(p.json)
  let schedOk = true
  if (changes.schedule !== undefined) {
    const av = await request('GET', aUrl)
    const want = scheduleSet(changes.schedule)
    schedOk = ok2xx(av.status) && Array.isArray(av.json) && av.json.length > 0 && av.json.every((c) => isRec(c) && JSON.stringify(shiftSet(c.shifts)) === JSON.stringify(want))
  }
  if (ok2xx(check.status) && nameOk && descOk && restOk && schedOk) return { ok: true, message: 'Aplicado e conferido no iFood.' }
  if (!restOk) {
    const undo = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), original.body)
    return { ok: false, message: `Conferência falhou: outros campos do produto mudaram. ${ok2xx(undo.status) ? 'Restaurei o original.' : 'Não consegui restaurar — confira o produto no portal.'}` }
  }
  if (!schedOk) return { ok: false, message: 'Enviado, mas o iFood ainda mostra o horário antigo. Confira no portal.' }
  return { ok: false, message: 'Enviado, mas o iFood ainda mostra o valor antigo. Confira no portal.' }
}

// ── complementos (criar grupo / ajustar grupo existente) ────────────────────────
const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim()
const money = (v: number) => Math.round(v * 100) / 100
type Draft = { groupName: string; min: number | null; max: number | null; options: { name: string; price: number | null }[] }
const newOption = (name: string, price: number, seq: number, catalogs: Map<string, string>): Rec => ({
  status: 'AVAILABLE', sequence: seq,
  extensions: [...catalogs].map(([id, catalogType]) => ({ id, status: 'AVAILABLE', externalCode: '', price: money(price), catalogType })),
  product: { stock: null, imageResource: { baseUrl: '', path: '' }, description: '', name: name.trim() },
  id: '',
})

/**
 * Complemento de um produto (receita observada: PUT /v2/item com `optionGroups`; grupo/opção novos vão com id vazio).
 *  - grupo com esse nome NÃO existe → cria (mín./máx. em branco: opcional e até o nº de opções; preço em branco: grátis);
 *  - grupo JÁ existe → ajusta: mín./máx. (se informados), preço só das opções com preço informado e DIFERENTE do atual
 *    (em branco = mantém o preço), e acrescenta as opções que faltam. Nada é removido.
 * Relê e confere; se algo além disso mudou, restaura o corpo original.
 */
export async function addComplementGroup(opts: { productId: string; ctx: PortalCtx; request: PortalRequest; sleep?: (ms: number) => Promise<void>; group: Draft }): Promise<{ ok: boolean; message: string }> {
  const { productId, ctx, request, group } = opts
  const name = group.groupName.trim()
  if (name.length < 2 || !group.options.length) return { ok: false, message: 'Complemento sem nome ou sem opções — nada enviado.' }
  const pUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}`)
  const aUrl = urlOf(ctx, `/partner-catalog-bff/product/${productId}/available-at`)
  const [p, a] = [await request('GET', pUrl), await request('GET', aUrl)]
  if (!ok2xx(p.status) || !ok2xx(a.status)) return { ok: false, message: `Não consegui ler o produto no iFood (HTTP ${p.status}/${a.status}).` }
  if (!isRec(p.json) || p.json.id !== productId) return { ok: false, message: 'O iFood devolveu outro produto — nada foi enviado.' }
  const original = buildItemBody(p.json, a.json)
  if (!original.ok) return { ok: false, message: original.reason }
  const catalogs = new Map<string, string>()
  for (const c of Array.isArray(a.json) ? a.json : []) if (isRec(c) && isRec(c.extensions)) for (const [id, e] of Object.entries(c.extensions)) if (isRec(e) && !catalogs.has(id)) catalogs.set(id, typeof e.catalogType === 'string' ? e.catalogType : 'DEFAULT')
  if (!catalogs.size) return { ok: false, message: 'Não achei o catálogo do produto — nada enviado.' }

  const body = structuredClone(original.body) as Rec
  const groups = body.optionGroups as Rec[]
  const nameOfOpt = (o: Rec) => String(isRec(o.product) ? o.product.name ?? '' : '')
  const priceOfOpt = (o: Rec): number | null => { const e = Array.isArray(o.extensions) ? (o.extensions as unknown[]).find(isRec) : undefined; return e && typeof e.price === 'number' ? e.price : null }
  const found = groups.find((g) => norm(String(g.name ?? '')) === norm(name))
  const changes: string[] = []
  if (!found) {
    const n = group.options.length
    const min = group.min ?? 0
    const max = group.max ?? n
    if (max < 1 || max > n || max < min || min > n) return { ok: false, message: `Mínimo/máximo incompatível com ${n} opção(ões) (mín. ${min}, máx. ${max}) — nada enviado.` }
    groups.push({ options: group.options.map((o, i) => newOption(o.name, o.price ?? 0, i, catalogs)), type: 'SPECIFICATION', status: 'AVAILABLE', max, min, name, id: '', step: 0, radio: 'specification', sequence: groups.length })
    body.pricingType = body.pricingType ?? 'TOTAL' // igual ao que o próprio painel envia ao criar complemento
    changes.push('grupo criado')
  } else {
    const opts2 = found.options as Rec[]
    for (const w of group.options) {
      const ex = opts2.find((o) => norm(nameOfOpt(o)) === norm(w.name))
      if (!ex) { opts2.push(newOption(w.name, w.price ?? 0, opts2.length, catalogs)); changes.push(`opção “${w.name}” adicionada`); continue }
      if (w.price !== null && priceOfOpt(ex) !== null && Math.abs(priceOfOpt(ex)! - money(w.price)) > 0.004) {
        for (const e of ex.extensions as Rec[]) e.price = money(w.price)
        changes.push(`preço de “${w.name}”`)
      }
    }
    const total = opts2.length
    const min = group.min ?? (found.min as number)
    const max = group.max ?? (found.max as number)
    if (max < 1 || max > total || max < min || min > total) return { ok: false, message: `Mínimo/máximo incompatível com as ${total} opção(ões) do grupo “${name}” (mín. ${min}, máx. ${max}) — nada enviado.` }
    if (min !== found.min) { found.min = min; changes.push(`mínimo ${min}`) }
    if (max !== found.max) { found.max = max; changes.push(`máximo ${max}`) }
    if (!changes.length) return { ok: true, message: `O grupo “${name}” já está assim no iFood — nada a mudar.` }
  }
  const put = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), body)
  if (!ok2xx(put.status)) return { ok: false, message: `O iFood recusou o complemento (HTTP ${put.status}).` }

  const sleep = opts.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)))
  const wantedMin = (groups.find((g) => norm(String(g.name ?? '')) === norm(name)) as Rec).min as number
  const wantedMax = (groups.find((g) => norm(String(g.name ?? '')) === norm(name)) as Rec).max as number
  const priceNow = (o: Rec): number | null => { const e = isRec(o.extensions) ? Object.values(o.extensions).find(isRec) : undefined; return e && typeof e.price === 'number' ? e.price : null }
  let after: unknown = null
  let problems: string[] = ['o iFood ainda não mostra o grupo']
  let afterGroups: Rec[] = []
  for (const wait of [0, 800, 1500, 2500]) {
    if (wait) await sleep(wait)
    after = (await request('GET', pUrl)).json
    afterGroups = isRec(after) && Array.isArray(after.optionGroups) ? after.optionGroups.filter(isRec) : []
    const g = afterGroups.find((x) => norm(String(x.name ?? '')) === norm(name))
    problems = []
    if (!g) { problems.push('o iFood ainda não mostra o grupo'); continue }
    if (g.min !== wantedMin || g.max !== wantedMax) problems.push(`mín./máx. no iFood: ${String(g.min)}/${String(g.max)}`)
    const os = Array.isArray(g.options) ? g.options.filter(isRec) : []
    for (const w of group.options) {
      const o = os.find((x) => norm(String(x.name ?? (isRec(x.product) ? x.product.name : ''))) === norm(w.name))
      if (!o) { problems.push(`falta a opção “${w.name}”`); continue }
      if (w.price !== null && (priceNow(o) === null || Math.abs(priceNow(o)! - money(w.price)) > 0.004)) problems.push(`preço de “${w.name}” = ${priceNow(o) === null ? '?' : priceNow(o)}`)
    }
    if (!problems.length) break
  }
  const existingBefore = Array.isArray(p.json.optionGroups) ? (p.json.optionGroups as unknown[]).filter(isRec) : []
  const keptOk = existingBefore.every((g) => afterGroups.some((x) => x.id === g.id)) && (problems.length > 0 || afterGroups.length === existingBefore.length + (found ? 0 : 1))
  const drift = isRec(after) ? driftKeys(p.json, after) : ['(leitura)']
  const restOk = drift.length === 0
  if (!problems.length && keptOk && restOk) return { ok: true, message: `“${name}”: ${changes.join(', ')} — conferido no iFood.` }
  if (!keptOk || !restOk) {
    const undo = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), original.body)
    return { ok: false, message: `Conferência falhou: outros dados do produto mudaram${drift.length ? ` (${drift.join(', ')})` : ''}. ${ok2xx(undo.status) ? 'Restaurei o original.' : 'Não consegui restaurar — confira o produto no portal.'}` }
  }
  return { ok: false, message: `Enviado, mas ${problems.join('; ')}. Confira no portal.` }
}
/** Campos que o iFood preenche/normaliza sozinho ao salvar um complemento — não contam como "mudou". */
const DERIVED = new Set(['optionGroups', 'description', 'unit', 'classification', 'pricingType', 'name', 'updatedAt', 'createdAt', 'version'])
/** Chaves do produto (já conhecidas antes) cujo valor mudou; chaves novas que só o iFood acrescentou são ignoradas. */
function driftKeys(before: unknown, after: unknown): string[] {
  if (!isRec(before) || !isRec(after)) return ['(leitura)']
  const norm1 = (k: string, v: unknown) => (v === undefined || v === null ? (k === 'promotions' || k === 'tags' ? [] : null) : v)
  const out: string[] = []
  for (const k of Object.keys(before)) {
    if (DERIVED.has(k)) continue
    if (JSON.stringify(norm1(k, before[k])) !== JSON.stringify(norm1(k, after[k]))) out.push(k)
  }
  return out
}
const comparableNoGroups = (p: unknown): string => {
  if (!isRec(p)) return ''
  const { optionGroups: _g, description: _d, unit: _u, classification: _c, ...rest } = p
  return stable({ ...rest, imageResource: isRec(rest.imageResource) ? rest.imageResource : EMPTY_IMG, promotions: rest.promotions ?? [], tags: rest.tags ?? [] })
}

/** Troca a foto do produto: lê o produto, reenvia o corpo com o imageResource novo (já enviado à galeria) e confere relendo. */
export async function setProductImage(opts: { productId: string; ctx: PortalCtx; request: PortalRequest; image: { baseUrl: string; path: string } }): Promise<{ ok: boolean; message: string }> {
  const { productId, ctx, request, image } = opts
  const pUrl = urlOf(ctx, `/partner-catalog-bff/product/${encodeURIComponent(productId)}`)
  const aUrl = urlOf(ctx, `/partner-catalog-bff/product/${encodeURIComponent(productId)}/available-at`)
  const [p, a] = await Promise.all([request('GET', pUrl), request('GET', aUrl)])
  if (!ok2xx(p.status) || !ok2xx(a.status)) return { ok: false, message: `Não consegui ler o produto no iFood (HTTP ${p.status}/${a.status}) — a foto foi para a galeria, mas o produto não foi alterado.` }
  if (!isRec(p.json) || p.json.id !== productId) return { ok: false, message: 'O iFood devolveu outro produto — nada foi alterado.' }
  const original = buildItemBody(p.json, a.json)
  if (!original.ok) return { ok: false, message: original.reason }
  const wanted = buildItemBody(p.json, a.json, { imageResource: image })
  if (!wanted.ok) return { ok: false, message: wanted.reason }
  const put = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), wanted.body)
  if (!ok2xx(put.status)) return { ok: false, message: `O iFood recusou a troca da foto (HTTP ${put.status}).` }
  const check = await request('GET', pUrl)
  const after = check.json
  const img = isRec(after) && isRec(after.imageResource) ? after.imageResource : null
  const imgOk = !!img && img.path === image.path
  const strip = (x: unknown) => { if (!isRec(x)) return x; const { imageResource: _i, ...r } = x; return r }
  const restOk = comparable(strip(after)) === comparable(strip(p.json))
  if (ok2xx(check.status) && imgOk && restOk) return { ok: true, message: 'Foto trocada e conferida no iFood.' }
  if (!restOk) {
    const undo = await request('PUT', urlOf(ctx, '/partner-catalog-bff/v2/item'), original.body)
    return { ok: false, message: `Conferência falhou: outros campos do produto mudaram. ${ok2xx(undo.status) ? 'Restaurei o original.' : 'Não consegui restaurar — confira o produto no portal.'}` }
  }
  return { ok: false, message: 'O iFood aceitou, mas ainda mostra a foto antiga. Recarregue o portal e confira.' }
}
