import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-edit.json'
import { setProductImage } from '../src/lib/item-editor'
import { manualAction } from '@orvia/shared/core/proposal'

const clone = <T,>(v: T): T => structuredClone(v)
const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'OWNER' }
const IMG = { baseUrl: 'https://static-images.ifood.com.br/pratos/', path: 'm/202611111405_D28B_i.jpg' }

function portal(opts: { ignore?: boolean; corrupt?: boolean } = {}) {
  const state = { product: clone(fx.productBefore) as any, puts: [] as any[] }
  const request = async (method: string, url: string, body?: any) => {
    if (method === 'GET' && /available-at/.test(url)) return { status: 200, json: clone(fx.availableAt) }
    if (method === 'GET') return { status: 200, json: clone(state.product) }
    if (method === 'PUT') {
      state.puts.push(body)
      if (!opts.ignore) state.product.imageResource = body.imageResource
      if (opts.corrupt) state.product.tags = ['X']
      return { status: 200, json: {} }
    }
    return { status: 404, json: null }
  }
  return { state, request }
}

describe('trocar a foto do produto', () => {
  it('envia o PUT com o imageResource novo e confere', async () => {
    const { state, request } = portal()
    const r = await setProductImage({ productId: fx.productBefore.id, ctx, request, image: IMG })
    expect(r).toEqual({ ok: true, message: 'Foto trocada e conferida no iFood.' })
    expect(state.puts).toHaveLength(1)
    expect(state.puts[0].imageResource).toEqual(IMG)
    expect({ ...state.puts[0], imageResource: null }).toEqual({ ...fx.putBody, imageResource: null }) // o resto do corpo não muda
  })
  it('ERRO quando o iFood não mostra a foto nova', async () => {
    const { request } = portal({ ignore: true })
    const r = await setProductImage({ productId: fx.productBefore.id, ctx, request, image: IMG })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/foto antiga/)
  })
  it('se outro campo mudar, restaura o original', async () => {
    const { state, request } = portal({ corrupt: true })
    const r = await setProductImage({ productId: fx.productBefore.id, ctx, request, image: IMG })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/Restaurei/)
    expect(state.puts).toHaveLength(2)
    expect(state.puts[1].imageResource).toEqual(fx.productBefore.imageResource)
  })
  it('ação manual exige a imagem e vira ação executável', () => {
    const snap = { items: [{ id: 'i1', name: 'Marmita P', productId: 'p1' }] } as never
    expect(manualAction({ kind: 'update_image', itemId: 'i1', fileName: '', ref: '', size: 0 }, snap).ok).toBe(false)
    const r = manualAction({ kind: 'update_image', itemId: 'i1', fileName: 'p.jpg', ref: 'ph1', size: 2048 }, snap)
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.action).toMatchObject({ kind: 'update_image', executable: true, image: { ref: 'ph1' } })
  })
})
