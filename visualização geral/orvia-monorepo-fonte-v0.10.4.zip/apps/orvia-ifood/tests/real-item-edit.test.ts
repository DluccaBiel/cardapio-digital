import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-edit.json'
import { buildItemBody, editItem } from '../src/lib/item-editor'
import { planHash } from '@orvia/shared/core/proposal'
import { runApproved } from '@orvia/shared/lib/runner'

const clone = <T,>(v: T): T => structuredClone(v)

describe('editor de produto — receita conferida contra PUT /v2/item REAL do portal', () => {
  it('remonta EXATAMENTE o PUT que o portal enviou (produto com complementos)', () => {
    const r = buildItemBody(fx.productBefore, fx.availableAt)
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.body).toEqual(fx.putBody)
  })
  it('idem para a edição anterior (nome "Bolo Fatiaa")', () => {
    const r = buildItemBody(fx.productAfterNameEdit, fx.availableAt)
    expect(r.ok && r.body).toEqual(fx.putBodyNameEdit)
  })
  it('só nome e descrição mudam quando pedidos', () => {
    const r = buildItemBody(fx.productBefore, fx.availableAt, { name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' })
    expect(r.ok).toBe(true)
    if (!r.ok) return
    const expected = { ...clone(fx.putBody), name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' }
    expect(r.body).toEqual(expected)
  })
  it('aborta com horário personalizado, campo desconhecido ou categoria ausente', () => {
    const shifted = clone(fx.availableAt) as any[]
    shifted[0].shifts = [{ startTime: '14:00', endTime: '19:00', monday: true, tuesday: true, wednesday: true, thursday: true, friday: true, saturday: true, sunday: true, default: false }]
    const kept = buildItemBody(fx.productBefore, shifted)
    expect(kept.ok).toBe(true) // horário personalizado agora é PRESERVADO, não recusado
    if (kept.ok) {
      const c0 = (kept.body.categories as any[])[0]
      expect(c0.availability).toBe('SHIFTS')
      expect(c0.shifts[0]).not.toHaveProperty('default')
    }
    const weird = { ...clone(fx.productBefore), novoCampo: 1 }
    expect(buildItemBody(weird, fx.availableAt).ok).toBe(false)
    expect(buildItemBody(fx.productBefore, []).ok).toBe(false)
  })

  function fakePortal() {
    const state = { product: clone(fx.productBefore) as any, puts: [] as any[], failVerify: false, corrupt: false }
    const request = async (method: string, url: string, body?: any) => {
      if (method === 'GET' && /\/available-at\?/.test(url)) return { status: 200, json: clone(fx.availableAt) }
      if (method === 'GET' && /\/partner-catalog-bff\/product\//.test(url)) return { status: 200, json: clone(state.product) }
      if (method === 'PUT') {
        state.puts.push(body)
        if (!state.failVerify) {
          state.product.name = body.name
          state.product.description = body.description
          if (state.corrupt) state.product.tags = ['X']
        }
        return { status: 200, json: {} }
      }
      return { status: 404, json: null }
    }
    return { state, request }
  }
  const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'OWNER' }

  it('edita nome+descrição ponta a ponta e confere', async () => {
    const { state, request } = fakePortal()
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' } })
    expect(r).toEqual({ ok: true, message: 'Aplicado e conferido no iFood.' })
    expect(state.puts).toHaveLength(1)
    expect(state.puts[0]).toEqual({ ...fx.putBody, name: 'Bolo Fatia Gigante', description: 'Escolha o sabor' })
  })
  it('ERRO quando o iFood não reflete a mudança', async () => {
    const { state, request } = fakePortal()
    state.failVerify = true
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { description: 'Outra' } })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/ainda mostra o valor antigo/)
  })
  it('se outro campo mudar, restaura o original', async () => {
    const { state, request } = fakePortal()
    state.corrupt = true
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: 'Novo nome' } })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/outros campos/)
    expect(state.puts).toHaveLength(2) // alteração + restauração
    expect(state.puts[1].name).toBe(fx.productBefore.name)
  })
  it('já igual = nada enviado', async () => {
    const { state, request } = fakePortal()
    const r = await editItem({ productId: fx.productBefore.id, ctx, request, changes: { name: fx.productBefore.name } })
    expect(r.ok).toBe(true)
    expect(state.puts).toHaveLength(0)
  })

  it('runner: aprovar nome+descrição executa pelo editor, sem molde aprendido', async () => {
    const { state, request } = fakePortal()
    const pid = fx.productBefore.id
    const snapshot: any = { items: [{ id: 'OFFER-1', productId: pid, name: fx.productBefore.name, price: 9.5, status: 'active' }], categories: [] }
    const mk = (kind: 'update_name' | 'update_description', after: string) => ({ id: `${kind}:OFFER-1`, kind, itemId: 'OFFER-1', itemName: fx.productBefore.name, before: '', after, reason: 'x', source: 'ia' as const, risk: 'baixo' as const, executable: true })
    const actions = [mk('update_name', 'Bolo Fatia Gigante'), mk('update_description', 'Escolha o sabor')]
    const rep = await runApproved({ actions, hash: planHash(actions) }, {
      templates: [], request, snapshot, signal: new AbortController().signal, paceMs: 0, sleep: async () => {},
      createCombo: async () => ({ ok: true, message: '' }),
      editItem: (productId, changes) => editItem({ productId, ctx, request, changes }),
    })
    expect(rep.steps.map((x) => x.status)).toEqual(['ok', 'ok'])
    expect(state.product.name).toBe('Bolo Fatia Gigante')
    expect(state.product.description).toBe('Escolha o sabor')
  })
})

describe('produto que JÁ tem complemento (leitura real do iFood: externalCode e product.variant)', () => {
  it('monta o corpo de nome/descrição sem recusar e preserva os campos', () => {
    const product = {
      ...(fx.productBefore as Record<string, unknown>),
      optionGroups: [{ id: 'g1', name: 'Marmita P (Sabado)', status: 'AVAILABLE', type: 'SPECIFICATION', sequence: 0, min: 1, max: 1, options: [{ id: 'o1', sequence: 0, status: 'AVAILABLE', product: { id: 'p1', name: 'Feijoada gorda', description: '', imageResource: { baseUrl: '', path: '' }, industrialized: false, optionGroups: [], tags: [], classification: [], variant: 'SPECIFICATION' }, extensions: { c1: { status: 'AVAILABLE', externalCode: '', price: 0, catalogType: 'DEFAULT', promotions: [] } } }] }],
    }
    const r = buildItemBody(product, fx.availableAt, { description: 'Novo' })
    expect(r.ok).toBe(true)
    if (r.ok) {
      const g = (r.body.optionGroups as { options: { product: { variant?: string } }[] }[])[0]!
      expect(g.options[0]!.product.variant).toBe('SPECIFICATION')
    }
  })
})

describe('conferência tolera o que o iFood acrescenta depois de salvar (leitura real, produto com complemento)', () => {
  it('name/description nas opções e imageResource ausente não derrubam a edição do nome', async () => {
    const product: any = clone(fx.productBefore)
    product.imageResource = { baseUrl: '', path: '' }
    product.optionGroups = [{ id: 'g1', name: 'Marmita P (Sabado)', status: 'AVAILABLE', type: 'SPECIFICATION', sequence: 0, min: 1, max: 1, options: [{ id: 'o1', sequence: 0, status: 'AVAILABLE', product: { id: 'p1', name: 'Feijoada', description: '', imageResource: { baseUrl: '', path: '' }, industrialized: false, optionGroups: [], tags: [], classification: [] }, extensions: { c1: { status: 'AVAILABLE', price: 0, catalogType: 'DEFAULT', promotions: [] } } }] }]
    let saved = false
    const request = async (method: string, url: string, body?: any) => {
      if (method === 'GET' && /available-at/.test(url)) return { status: 200, json: clone(fx.availableAt) }
      if (method === 'GET') {
        const out: any = clone(product)
        if (saved) {
          out.name = body?.name ?? out.name
          delete out.imageResource
          out.optionGroups[0].options[0].name = 'Feijoada'
          out.optionGroups[0].options[0].description = ''
        }
        return { status: 200, json: out }
      }
      if (method === 'PUT') { saved = true; product.name = body.name; return { status: 200, json: {} } }
      return { status: 404, json: null }
    }
    // a leitura "depois" precisa do nome novo: devolve o que foi salvo
    const wrapped = async (m: string, u: string, b?: any) => { const r = await request(m, u, b); if (m === 'GET' && saved && !/available-at/.test(u)) (r.json as any).name = product.name; return r }
    const r = await editItem({ productId: product.id, ctx: { origin: 'https://portal-api.ifood.com.br', ownerId: 'OWNER' }, request: wrapped, changes: { name: 'Novo nome' } })
    expect(r).toEqual({ ok: true, message: 'Aplicado e conferido no iFood.' })
  })
})
