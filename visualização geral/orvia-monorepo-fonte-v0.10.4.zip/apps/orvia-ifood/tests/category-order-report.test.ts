import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-category-order.json'
import { moveCategory, suggestCategoryOrder } from '@orvia/shared/lib/category-order'
import { reorderCategories } from '../src/lib/category-reorder'
import { describePromotions, describeShifts, viewFromReads } from '../src/lib/product-view'
import { buildReportModel } from '@orvia/shared/lib/prints'
import { reorderAction, type ProposalAction } from '@orvia/shared/core/proposal'
import type { MenuSnapshot } from '@orvia/shared/core/schema'
import type { RunReport } from '@orvia/shared/lib/runner'

const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'own-1' }
const names = ['Lanches', 'Bebidas', 'Combo Capixaba', 'Para adoçar seu Dia', 'Pratos']
const snap = { items: [], categories: names.map((name, position) => ({ id: `c${position}`, name, position, itemIds: [] })) } as unknown as MenuSnapshot

describe('ordem das categorias', () => {
  it('boas práticas: combos no topo, bebidas e doces no fim; estável nos demais', () => {
    expect(suggestCategoryOrder(snap)?.map((c) => c.name)).toEqual(['Combo Capixaba', 'Lanches', 'Pratos', 'Bebidas', 'Para adoçar seu Dia'])
  })
  it('já bem ordenado → nenhuma sugestão', () => {
    const ok = { ...snap, categories: ['Combos', 'Lanches', 'Bebidas'].map((name, position) => ({ id: `x${position}`, name, position, itemIds: [] })) } as unknown as MenuSnapshot
    expect(suggestCategoryOrder(ok)).toBeNull()
  })
  it('mover uma categoria para a posição pedida', () => {
    const a = reorderAction(snap, { categoryId: 'c4', position: 1 })
    expect(a.ok && a.action.order?.[0]?.name).toBe('Pratos')
    expect(moveCategory([{ id: 'a', name: 'A' }], 'a', 1)).toBeNull()
  })
  it('PATCH idêntico ao gravado no portal e conferência pela releitura', async () => {
    const ids = fx.orderBody.categories.map((c: { id: string }) => c.id)
    let live = [...ids.slice(1, 2), ids[0], ...ids.slice(2)] // estado atual: 2º no topo (como no segundo PATCH gravado)
    const calls: { method: string; url: string; body?: any }[] = []
    const request = async (method: string, url: string, body?: any) => {
      calls.push({ method, url, body })
      if (method === 'PATCH') { live = body.categories.map((c: { id: string }) => c.id); return { status: 200, json: null } }
      return { status: 200, json: live.map((id) => ({ categoryId: id, name: id })) }
    }
    const r = await reorderCategories({ order: ids.map((id: string) => ({ id, name: id })), ctx, request })
    expect(r.ok).toBe(true)
    const patch = calls.find((c) => c.method === 'PATCH')!
    expect(patch.url).toBe('https://portal-api.ifood.com.br/next-web-bff/menu/v4/sequence/order?ownerUUID=own-1')
    expect(patch.body).toEqual(fx.orderBody)
  })
  it('categoria que não existe mais: não envia nada', async () => {
    const calls: string[] = []
    const request = async (method: string) => { calls.push(method); return { status: 200, json: [{ categoryId: 'a' }] } }
    const r = await reorderCategories({ order: [{ id: 'zzz', name: 'Z' }], ctx, request })
    expect(r.ok).toBe(false)
    expect(calls).not.toContain('PATCH')
  })
})

describe('relatório único', () => {
  it('descreve horários e promoções do produto', () => {
    const day = (d: number) => Object.fromEntries(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map((n, i) => [n, i === d]))
    expect(describeShifts([{ startTime: '10:00', endTime: '12:00', ...day(0) }, { startTime: '10:00', endTime: '12:00', ...day(1) }, { startTime: '15:00', endTime: '21:00', ...day(0) }])).toBe('10:00–12:00 · seg, ter + 15:00–21:00 · seg')
    expect(describeShifts([])).toBe('sempre disponível')
    expect(describePromotions([])).toBeNull()
    expect(describePromotions([{ name: 'Leve 2 pague 1' }])).toBe('Leve 2 pague 1')
    const v = viewFromReads({ name: 'Bolo', description: 'd', imageResource: { baseUrl: '', path: 'o/x.jpg' }, promotions: [] }, [{ name: 'Doces', shifts: [], extensions: { k: { price: 5, originalPrice: 8, status: 'AVAILABLE', promotions: [] } } }])
    expect(v?.promotion).toBe('de R$ 8,00 por R$ 5,00')
    expect(v?.imageUrl).toMatch(/static-images\.ifood\.com\.br\/.*o\/x\.jpg$/)
    expect(v?.active).toBe(true)
  })
  it('um só relatório com status real de cada ação; erro nunca vira sucesso', () => {
    const act = (id: string, kind: ProposalAction['kind'], extra: Partial<ProposalAction> = {}): ProposalAction => ({ id, kind, itemId: id, itemName: `Item ${id}`, before: 'a', after: 'b', reason: '', source: 'regras', risk: 'baixo', executable: true, ...extra })
    const steps = [
      { action: act('1', 'update_name'), status: 'ok' as const, message: 'Nome conferido.', at: null },
      { action: act('2', 'update_price'), status: 'erro' as const, message: 'iFood recusou.', at: null },
      { action: act('3', 'reorder_categories', { order: [{ id: 'c1', name: 'Combos' }, { id: 'c0', name: 'Lanches' }] }), status: 'ok' as const, message: 'Reordenadas.', at: null },
    ]
    const report = { startedAt: '', finishedAt: '', planHash: 'h', aborted: false, steps, counts: { ok: 2, erro: 1, pulada: 0, assistida: 0, pendente: 0, executando: 0 } } as unknown as RunReport
    const m = buildReportModel({ clientName: 'Loja', merchantName: null, summary: 's', version: 1, date: new Date(), report, previousOrder: { c0: 1, c1: 2 } })
    expect(m.verdict.tone).toBe('erro')
    expect(m.verdict.text).toMatch(/PARCIALMENTE/)
    expect(m.cards[0]!.status).toBe('erro') // o que NÃO foi feito aparece primeiro
    const ord = m.cards.find((c) => c.order)!
    expect(ord.order).toEqual([{ name: 'Combos', was: 2, now: 1 }, { name: 'Lanches', was: 1, now: 2 }])
    expect(m.cards).toHaveLength(3)
  })

  it('ordem demora a aparecer: espera e confere', async () => {
    const ids = fx.orderBody.categories.map((c: { id: string }) => c.id)
    let live = [...ids].reverse()
    let reads = 0
    const request = async (method: string, _u: string, body?: any) => {
      if (method === 'PATCH') return { status: 200, json: null }
      reads += 1
      if (reads >= 4) live = ids
      return { status: 200, json: live.map((id: string) => ({ categoryId: id })) }
    }
    const r = await reorderCategories({ order: ids.map((id: string) => ({ id, name: id })), ctx, request, sleep: async () => undefined })
    expect(r.ok).toBe(true)
  })
})
