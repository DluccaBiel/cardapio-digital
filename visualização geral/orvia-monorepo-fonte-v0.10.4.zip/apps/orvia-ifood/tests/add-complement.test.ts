import { describe, expect, it } from 'vitest'
import fx from './fixtures/real-item-edit.json'
import { addComplementGroup } from '../src/lib/item-editor'
import { manualAction, parseComplementLines, planHash, type ProposalAction } from '@orvia/shared/core/proposal'
import { runApproved } from '@orvia/shared/lib/runner'
import type { MenuSnapshot } from '@orvia/shared/core/schema'

const clone = <T,>(v: T): T => structuredClone(v)
const ctx = { origin: 'https://portal-api.ifood.com.br', ownerId: 'OWNER' }
const group = { groupName: 'Adicionais', min: 0 as number | null, max: 2 as number | null, options: [{ name: 'Bacon extra', price: 4.5 as number | null }, { name: 'Queijo extra', price: 3 as number | null }] }
const pid = (fx.productBefore as any).id as string

function fakePortal(mode: 'ok' | 'ignore' | 'corrupt' = 'ok') {
  const st = { product: clone(fx.productBefore) as any, puts: [] as any[] }
  const request = async (method: string, url: string, body?: any) => {
    if (method === 'GET' && /\/available-at\?/.test(url)) return { status: 200, json: clone(fx.availableAt) }
    if (method === 'GET' && /\/partner-catalog-bff\/product\//.test(url)) return { status: 200, json: clone(st.product) }
    if (method === 'PUT') {
      st.puts.push(body)
      if (mode === 'ignore') return { status: 200, json: {} }
      st.product.optionGroups = body.optionGroups.map((g: any, i: number) => ({
        ...g, id: g.id || `new-g${i}`,
        options: g.options.map((o: any, k: number) => ({ id: o.id || `new-o${i}-${k}`, sequence: o.sequence, status: o.status, name: o.product.name, product: { ...o.product, id: o.product.id ?? `p${i}${k}`, industrialized: false, optionGroups: [], tags: [], classification: [] },
          extensions: Object.fromEntries(o.extensions.map((e: any) => [e.id, { status: e.status, externalCode: e.externalCode ?? '', price: e.price, catalogType: e.catalogType, promotions: e.promotions ?? [] }])) })),
      }))
      if (mode === 'corrupt') st.product.tags = ['X']
      return { status: 200, json: {} }
    }
    return { status: 404, json: null }
  }
  return { st, request }
}

describe('criar complemento (grupo novo) — receita do PUT /v2/item gravado', () => {
  it('envia o grupo novo (id vazio) com opções/preços por catálogo, mantém os grupos que já existiam e confere', async () => {
    const { st, request } = fakePortal()
    const before = (st.product.optionGroups as any[]).length
    const r = await addComplementGroup({ productId: pid, ctx, request, group, sleep: async () => {} })
    expect(r.ok).toBe(true)
    const body = st.puts[0]
    expect(body.optionGroups).toHaveLength(before + 1)
    const g = body.optionGroups[before]
    expect(g).toMatchObject({ id: '', name: 'Adicionais', type: 'SPECIFICATION', status: 'AVAILABLE', min: 0, max: 2, sequence: before })
    expect(g.options[0]).toMatchObject({ id: '', status: 'AVAILABLE', sequence: 0, product: { name: 'Bacon extra', stock: null } })
    expect(g.options[0].extensions[0]).toMatchObject({ status: 'AVAILABLE', price: 4.5, catalogType: 'DEFAULT', externalCode: '' })
    expect(typeof g.options[0].extensions[0].id).toBe('string')
    for (let i = 0; i < before; i += 1) expect(body.optionGroups[i].id).toBe((fx.productBefore as any).optionGroups[i].id)
  })
  it('sem opções informadas → nada é enviado', async () => {
    const { st, request } = fakePortal()
    const name = (st.product.optionGroups as any[])[0].name
    const r = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: name, min: null, max: null, options: [] } , sleep: async () => {} })
    expect(r.ok).toBe(false) // sem opções informadas
    expect(st.puts).toHaveLength(0)
  })
  it('iFood aceita mas não mostra o grupo → ERRO (nunca finge sucesso)', async () => {
    const { request } = fakePortal('ignore')
    const r = await addComplementGroup({ productId: pid, ctx, request, group, sleep: async () => {} })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/ainda não mostra o grupo/)
  })
  it('se outro dado do produto mudar, restaura o original', async () => {
    const { st, request } = fakePortal('corrupt')
    const r = await addComplementGroup({ productId: pid, ctx, request, group, sleep: async () => {} })
    expect(r.ok).toBe(false)
    expect(r.message).toMatch(/Restaurei/)
    expect(st.puts).toHaveLength(2)
  })
})

const snap = { items: [{ id: 'i1', productId: pid, name: 'Marmita P', description: 'Antiga', price: 19.9, categoryName: 'Marmitas de terça', categoryId: 'c1', status: 'active' }], categories: [] } as unknown as MenuSnapshot

describe('complemento na proposta', () => {
  it('lê "Nome - valor" por linha (sem valor = grátis)', () => {
    expect(parseComplementLines('Bacon extra - R$ 4,50\nQueijo extra 3\nGuaraná\n\n')).toEqual([{ name: 'Bacon extra', price: '4,50' }, { name: 'Queijo extra', price: '3' }, { name: 'Guaraná', price: '' }])
  })
  it('valida e monta a ação (várias mudanças no mesmo produto têm ids diferentes)', () => {
    const c = manualAction({ kind: 'add_complement', itemId: 'i1', groupName: 'Adicionais', min: '0', max: '2', options: [{ name: 'Bacon extra', price: '4,50' }, { name: 'Queijo extra', price: '0' }] }, snap)
    const n = manualAction({ kind: 'update_name', itemId: 'i1', value: 'Marmita P Uma Carne' }, snap)
    const d = manualAction({ kind: 'update_description', itemId: 'i1', value: 'Nova' }, snap)
    expect(c.ok && n.ok && d.ok).toBe(true)
    if (c.ok && n.ok && d.ok) {
      expect(new Set([c.action.id, n.action.id, d.action.id]).size).toBe(3)
      expect(c.action.complement).toEqual({ groupName: 'Adicionais', min: 0, max: 2, options: [{ name: 'Bacon extra', price: 4.5 }, { name: 'Queijo extra', price: 0 }] })
      expect(c.action.after).toMatch(/Bacon extra \+R\$ 4,50.*Queijo extra \(grátis\)/)
    }
  })
  it('recusa dados inválidos', () => {
    const bad = (o: Partial<{ groupName: string; min: string; max: string; options: { name: string; price: string }[] }>) => manualAction({ kind: 'add_complement', itemId: 'i1', groupName: 'Ad', min: '0', max: '1', options: [{ name: 'Bacon', price: '1' }], ...o }, snap)
    expect(bad({ groupName: '' }).ok).toBe(false)
    expect(bad({ options: [] }).ok).toBe(false)
    expect(bad({ options: [{ name: 'Bacon', price: 'abc' }] }).ok).toBe(false)
    expect(bad({ max: '0' }).ok).toBe(false)
    expect(bad({ min: '2', max: '1', options: [{ name: 'A1', price: '1' }, { name: 'B1', price: '1' }] }).ok).toBe(false)
    expect(bad({ options: [{ name: 'Bacon', price: '1' }, { name: 'bacon', price: '2' }] }).ok).toBe(false)
  })
  it('o executor roda nome + descrição + complemento do mesmo produto, em sequência', async () => {
    const acts: ProposalAction[] = []
    for (const i of [{ kind: 'update_name', itemId: 'i1', value: 'Marmita P Uma Carne' }, { kind: 'update_description', itemId: 'i1', value: 'Nova' }, { kind: 'add_complement', itemId: 'i1', groupName: 'Adicionais', min: '', max: '', options: [{ name: 'Bacon extra', price: '4,5' }] }] as const) {
      const r = manualAction(i as any, snap)
      if (r.ok) acts.push(r.action)
    }
    const calls: string[] = []
    const rep = await runApproved({ actions: acts, hash: planHash(acts) }, {
      templates: [], request: async () => ({ status: 404, json: null }), snapshot: snap, signal: new AbortController().signal, paceMs: 0, sleep: async () => {},
      createCombo: async () => ({ ok: true, message: '' }),
      editItem: async (_p, ch) => { calls.push(ch.name ? 'nome' : 'descricao'); return { ok: true, message: 'ok' } },
      addComplement: async (_p, c) => { calls.push(`compl:${c.groupName}:${c.options.length}`); return { ok: true, message: 'ok' } },
    })
    expect(rep.counts.ok).toBe(3)
    expect(calls).toEqual(['nome', 'descricao', 'compl:Adicionais:1'])
  })
})

describe('complemento: produto sem campos opcionais e ajuste de grupo existente', () => {
  it('produto SEM optionGroups/imageResource/tags/promotions na leitura (marmita sem complemento) não é recusado', async () => {
    const { st, request } = fakePortal()
    const { optionGroups: _o, imageResource: _i, tags: _t, promotions: _p, ...bare } = st.product
    st.product = bare
    const r = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: 'Marmita P', min: 1, max: 1, options: [{ name: 'Estrogonoff de frango', price: null }, { name: 'Almôndegas', price: null }, { name: 'Picadinho', price: null }] }, sleep: async () => {} })
    expect(r.ok).toBe(true)
    expect(st.puts[0].optionGroups).toHaveLength(1)
    expect(st.puts[0].optionGroups[0]).toMatchObject({ name: 'Marmita P', min: 1, max: 1 })
    expect(st.puts[0].optionGroups[0].options.map((o: any) => o.extensions[0].price)).toEqual([0, 0, 0])
    expect(st.puts[0].imageResource).toEqual({ baseUrl: '', path: '' })
  })
  it('grupo existente: ajusta só mín./máx. e acrescenta opção nova; preço em branco mantém o que já está', async () => {
    const { st, request } = fakePortal()
    const g0 = (st.product.optionGroups as any[])[0]
    const first = g0.options[0]
    const nm = first.name ?? first.product.name
    const priceBefore = Object.values(first.extensions as any)[0] as any
    const r = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: g0.name, min: 1, max: g0.options.length + 1, options: [{ name: nm, price: null }, { name: 'Opção nova', price: 2 }] }, sleep: async () => {} })
    expect(r.ok).toBe(true)
    const sent = st.puts[0].optionGroups[0]
    expect(sent.id).toBe(g0.id)
    expect(sent.min).toBe(1)
    expect(sent.max).toBe(g0.options.length + 1)
    expect(sent.options).toHaveLength(g0.options.length + 1)
    expect(sent.options[0].extensions[0].price).toBe(priceBefore.price)
    expect(sent.options.at(-1)).toMatchObject({ id: '', product: { name: 'Opção nova' } })
  })
  it('mesmo pedido de novo → "já está assim", sem enviar nada', async () => {
    const { st, request } = fakePortal()
    const g0 = (st.product.optionGroups as any[])[0]
    const r = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: g0.name, min: g0.min, max: g0.max, options: [] as any }, sleep: async () => {} })
    expect(r.ok).toBe(false) // sem opções = pedido vazio
    const r2 = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: g0.name, min: g0.min, max: g0.max, options: [{ name: g0.options[0].name ?? g0.options[0].product.name, price: null }] }, sleep: async () => {} })
    expect(r2.ok).toBe(true)
    expect(r2.message).toMatch(/nada a mudar/)
    expect(st.puts).toHaveLength(0)
  })
  it('máximo maior que o nº de opções é recusado antes de enviar', async () => {
    const { st, request } = fakePortal()
    const r = await addComplementGroup({ productId: pid, ctx, request, group: { groupName: 'Novo grupo', min: 1, max: 5, options: [{ name: 'A1', price: 1 }, { name: 'B1', price: 1 }] }, sleep: async () => {} })
    expect(r.ok).toBe(false)
    expect(st.puts).toHaveLength(0)
  })
})
