#!/usr/bin/env node
/**
 * E2E no Chromium REAL com a extensão carregada. Painel e API do Anota AI SIMULADOS (dados fictícios e formato SINTÉTICO — o real não foi observado). Uso: xvfb-run -a node scripts/e2e-aa.mjs
 */
import { createRequire } from 'node:module'
import { execSync, spawn } from 'node:child_process'
import { cpSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
const require = createRequire(import.meta.url)
let chromium
try { ;({ chromium } = require('playwright')) } catch { ;({ chromium } = require(join(execSync('npm root -g').toString().trim(), 'playwright'))) }
const ROOT = resolve(new URL('..', import.meta.url).pathname)
let bad = 0
const check = (n, ok, x = '') => { if (!ok) bad += 1; console.log(`${ok ? '  ✓' : '  ✗'} ${n}${ok ? '' : ' → ' + x}`) }

execSync('node scripts/build.mjs', { cwd: ROOT, env: { ...process.env, ORVIA_E2E: '1' }, stdio: 'inherit' })
const EXT = mkdtempSync(join(tmpdir(), 'orvia-aa-ext-'))
for (const f of ['dist', 'assets', 'options.html', 'manifest.json']) cpSync(join(ROOT, f), join(EXT, f), { recursive: true })


const week = (p) => ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'].map((d, i) => ({ price: p, short_name: d, price_base: p, is_promotion: false, discount: 0, is_discount_percentage: false, _id: `w${i}` }))
const db = {
  cats: [{ _id: 'cA', title: 'Lanches', order: 0, page: 'loja1', published: true }, { _id: 'cB', title: 'Bebidas', order: 1, page: 'loja1', published: true }],
  items: [
    { _id: 'ci1', item: 'it1', category: 'cA', price: 'pr1', item_title: 'X-Burger', item_description: 'Pão, carne e queijo', item_image: 'https://img.anota.ai/a.jpg', order: 1, simple_price: true, is_paused: false, week: week(30), non_active_weekdays: [] },
    { _id: 'ci2', item: 'it2', category: 'cA', price: 'pr2', item_title: 'Astro Bacon', item_description: '', item_image: '', order: 2, simple_price: true, is_paused: false, week: week(41.5), non_active_weekdays: [] },
    { _id: 'ci3', item: 'it3', category: 'cB', price: 'pr3', item_title: 'Refri Lata', item_description: '350ml', item_image: 'https://img.anota.ai/c.jpg', order: 1, simple_price: true, is_paused: false, week: week(6), non_active_weekdays: [] },
    { _id: 'ci4', item: 'it4', category: 'cB', price: 'pr4', item_title: 'Suco Natural', item_description: '', item_image: '', order: 2, simple_price: true, is_paused: true, week: week(9.5), non_active_weekdays: [] },
  ],
  writes: [],
}
const PAGE = `<!doctype html><title>Anota AI</title><h1>Loja Teste</h1><script>
const H = { headers: { Authorization: 'Bearer tok-aa', 'x-app': 'admin' } };
fetch('https://api-menu.anota.ai/auth/v2/nm-category/for/admin/only-categories?page=1&root=true&title=&limit=10', H).then(r => r.json()).then(j => j.docs.forEach(c => fetch('https://api-menu.anota.ai/auth/v2/nm-category/for/admin/itens/' + c._id + '?_=1', H)));
fetch('https://api.anota.ai/auth/target', H);
</script>`
const CORS = { 'access-control-allow-origin': 'https://admin.anota.ai', 'access-control-allow-headers': 'authorization,content-type,x-app', 'access-control-allow-methods': '*' }
const apiSeen = []
const userDir = mkdtempSync(join(tmpdir(), 'orvia-aa-prof-'))
const port = 9631
const proc = spawn(chromium.executablePath(), [`--user-data-dir=${userDir}`, `--remote-debugging-port=${port}`, `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-sandbox', '--no-first-run', '--no-default-browser-check', '--window-size=1360,900', 'about:blank'], { stdio: 'ignore' })
let browser
for (let i = 0; i < 40 && !browser; i += 1) { try { browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`) } catch { await new Promise((r) => setTimeout(r, 500)) } }
try {
  const ctx = browser.contexts()[0]
  await ctx.route('https://admin.anota.ai/**', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: PAGE }))
  await ctx.route('https://api.anota.ai/**', (r) => r.fulfill({ status: 200, contentType: 'application/json', headers: CORS, body: '{}' }))
  await ctx.route('https://api-menu.anota.ai/**', (r) => {
    const req = r.request()
    const u = new URL(req.url())
    const path = u.pathname.replace('/auth/v2', '')
    const h = req.headers()
    apiSeen.push({ m: req.method(), path, auth: h['authorization'], xapp: h['x-app'] })
    const send = (json) => r.fulfill({ status: 200, contentType: 'application/json', headers: CORS, body: JSON.stringify(json) })
    if (req.method() === 'OPTIONS') return r.fulfill({ status: 204, headers: CORS })
    let m
    if (path === '/nm-category/for/admin/only-categories') return send({ docs: db.cats, page: 1, pages: 1, total: db.cats.length })
    if ((m = path.match(/^\/nm-category\/for\/admin\/itens\/(\w+)$/))) return send({ success: true, categoryItems: db.items.filter((i) => i.category === m[1]) })
    if (req.method() === 'POST' && path === '/category-item/edit/price') {
      const b = JSON.parse(req.postData() ?? '{}').document
      const it = db.items.find((i) => i._id === b.categoryItem)
      it.week = b.price.week
      db.writes.push(`POST ${path} ${it.item_title} ${b.price.price}`)
      return send({ success: true, categoryItem: it })
    }
    return send({})
  })
  const page = await ctx.newPage()
  await page.goto('https://admin.anota.ai/main/menu-v4/manager')
  const orvia = page.locator('button.fab[aria-label="Abrir Undercut"]')
  await orvia.waitFor({ state: 'attached' })
  check('botão flutuante Undercut aparece no Anota AI', await orvia.isVisible())
  await page.waitForTimeout(800)
  await orvia.click()
  await page.locator('aside.panel').waitFor()
  await page.getByRole('button', { name: /Sincronizar cardápio/ }).first().click()
  const syncTxt = await page.evaluate(() => document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.syncbtn')?.textContent ?? 'sem-botão')
  check('botão de sincronizar mostra "Carregando…" ao clicar', /Carregando/.test(syncTxt) || syncTxt === 'sem-botão', syncTxt)
  await page.waitForFunction(() => /X-Burger/.test(document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 20000 }).catch(() => undefined)
  if (process.env.SHOTS) await page.locator('aside.panel').screenshot({ path: `${process.env.SHOTS}/1-produtos.png` })
  const txt = await page.evaluate(() => document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('leu os 4 produtos das respostas que o painel já carregou', /X-Burger/.test(txt) && /Astro Bacon/.test(txt) && /Refri Lata/.test(txt) && /Suco Natural/.test(txt), txt.slice(0, 300))
  check('mostra "Anota AI" (não iFood/Cardápio Web)', /Anota AI/.test(txt) && !/iFood|Cardápio Web/.test(txt), txt.slice(0, 200))
  check('leitura reutilizou o login do painel (Authorization + cabeçalho próprio)', apiSeen.filter((x) => x.m === 'GET').length >= 6 && apiSeen.every((x) => x.m === 'OPTIONS' || (x.auth === 'Bearer tok-aa' && x.xapp === 'admin')), JSON.stringify(apiSeen.slice(-4)))
  check('só leu até aqui: nenhuma escrita sem aprovação', db.writes.length === 0)
  const root = page.locator('#orvia-aa-root')
  await root.getByRole('button', { name: /Diagnóstico/ }).first().click()
  await page.waitForFunction(() => /Leitura OK/.test(document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 10000 }).catch(() => undefined)
  const dtxt = await page.evaluate(() => document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? '')
  check('Diagnóstico: "Leitura OK: 4 produto(s) em 2 categoria"', /Leitura OK: 4 produto\(s\) em 2 categoria/.test(dtxt), dtxt.slice(0, 300))
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://admin.anota.ai' }).catch(() => undefined)
  await page.bringToFront()
  await root.getByRole('button', { name: /Copiar relatório/ }).first().click()
  await page.waitForTimeout(1200)
  const rep = await page.evaluate(() => navigator.clipboard.readText()).catch((e) => String(e))
  check('relatório copiado sem token e sem dados de pedido/cliente', !/tok-aa/.test(rep) , rep.slice(0, 300))
  check('relatório lista as chamadas vistas (only-categories)', /only-categories/.test(rep) && /chamadasDoPortal/.test(rep))
  // ---- análise local → proposta → Fazer recusa (modo gravador) ----
  await root.getByRole('button', { name: /^Produtos$/ }).first().click().catch(() => undefined)
  await page.getByRole('button', { name: /Analisar este cardápio/ }).click({ timeout: 10000 })
  await page.getByLabel('Cidade ou bairro').fill('Asa Norte, Brasília')
  await page.getByRole('button', { name: /^Analisar cardápio$/ }).click()
  await page.getByText(/Proposta v1/).waitFor({ timeout: 30000 })
  const ptxt = await page.locator('aside.panel').innerText()
  check('proposta gerada e mostra o que é automático no Anota AI', /Anota AI — o que é automático/.test(ptxt), ptxt.slice(0, 300))
  // ---- ↻ escrever o pedido → ação → Fazer → preço gravado e conferido ----
  await page.getByRole('button', { name: /Propor novas otimizações/ }).first().click()
  await page.getByLabel('O que você quer propor').fill('reduzir 5% o preço do X-Burger')
  await page.getByRole('button', { name: 'Propor novas ideias' }).click()
  await page.getByText(/Proposta v2/).waitFor({ timeout: 30000 })
  await page.getByRole('button', { name: /✓ Fazer/ }).click()
  await page.waitForFunction(() => /Cardápio otimizado|OK/.test(document.querySelector('#orvia-aa-root')?.shadowRoot?.querySelector('.panel')?.textContent ?? ''), null, { timeout: 60000 }).catch(() => undefined)
  await page.waitForTimeout(800)
  const fin = await page.locator('aside.panel').innerText()
  const burger = db.items.find((i) => i.item_title === 'X-Burger')
  check('preço gravado no Anota AI (30 → 28,90) nos 7 dias, com o login do painel', burger.week.length === 7 && burger.week.every((d) => d.price === 28.9), JSON.stringify(db.writes))
  check('escrita usou o login do painel', apiSeen.filter((x) => x.m === 'POST').every((x) => x.auth === 'Bearer tok-aa'))
  check('relatório marca OK', /X-Burger/i.test(fin) && /OK/.test(fin), fin.slice(0, 500))
  check('só houve a escrita aprovada', db.writes.length === 1, JSON.stringify(db.writes))
  const cards = page.locator('.sc')
  check('execução aparece em cartões FECHADOS (detalhe só ao clicar)', (await cards.count()) >= 1 && (await page.locator('.scbody').count()) === 0)
  if (process.env.SHOTS) await page.locator('aside.panel').screenshot({ path: `${process.env.SHOTS}/2-final-fechado.png` })
  await cards.first().locator('.schead').click()
  check('clicar no cartão abre os detalhes', (await page.locator('.scbody').count()) === 1)
  if (process.env.SHOTS) await page.locator('aside.panel').screenshot({ path: `${process.env.SHOTS}/3-final-aberto.png` })
  await root.getByRole('button', { name: /Pendências/ }).first().click()
  await page.waitForTimeout(900)
  const pend = await page.locator('aside.panel').textContent()
  check('relatório ficou salvo na aba Pendências, com o cliente', /Relatórios salvos/i.test(pend) && /1 relatório/i.test(pend) && /X-Burger|Anota AI/i.test(pend), pend.slice(0, 400))
  if (process.env.SHOTS) await page.locator('aside.panel').screenshot({ path: `${process.env.SHOTS}/4-pendencias.png` })
  await page.locator('.rephead').first().click()
  await page.waitForTimeout(400)
  if (process.env.SHOTS) { const src = await page.locator('.repimgs img').first().getAttribute('src').catch(() => null); if (src) require('node:fs').writeFileSync(`${process.env.SHOTS}/repimg.jpg`, Buffer.from(src.split(',')[1], 'base64')) }
  if (process.env.SHOTS) await page.locator('aside.panel').screenshot({ path: `${process.env.SHOTS}/5-relatorio-aberto.png` })
  await page.getByRole('button', { name: /Montar apresentação/ }).click({ timeout: 5000 }).catch(() => undefined)
} finally {
  await browser.close().catch(() => undefined)
  proc.kill('SIGKILL')
}
console.log(bad ? `\n${bad} falha(s)` : '\nTudo certo')
process.exit(bad ? 1 : 0)
