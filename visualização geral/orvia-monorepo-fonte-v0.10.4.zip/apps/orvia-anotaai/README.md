# Orvia · Otimizador Anota AI (extensão Chrome MV3) — v0.2.0

Mesma estrutura das extensões iFood e Cardápio Web: botão flutuante → Sincronizar → Produtos → Análise (concorrentes/boas práticas, PDF,
↻ escrever o que quer propor, aprovar/reprovar) → executar → relatório (PNG) enviado ao hub Orvia (canal `orvia-anotaai`).

## Receitas OBSERVADAS no painel real (diagnóstico de 10/11/2026) — API `https://api-menu.anota.ai/auth/v2`
- Ler: `GET /nm-category/for/admin/only-categories` (paginado) + `GET /nm-category/for/admin/itens/{categoria}`.
- Preço: `POST /category-item/edit/price` (7 dias; recusa item com promoção por dia).
- Nome/descrição: `PUT /item/update` (corpo completo do portal).
- Produto novo: `POST /item/duplicate` + `PUT /item/update`. Remover: `DELETE /item/{id}`. Ordem das categorias: `PUT /nm-category/order/update`.
- Toda escrita é conferida relendo; o login é o do próprio painel (cabeçalhos da última chamada), só na memória da aba.

## Ainda sem receita (aparece como "falta ensinar")
- Pausar/ativar produto e horário de venda. Para ligar: Diagnóstico aberto → pause e reative 1 produto → Copiar relatório.

## Hub (servidor)
- Aceitar `extension: "orvia-anotaai"` no login, `/me` (extension/platform `anotaai`) e handshake `manifest_name` = "Orvia · Otimizador Anota AI".
