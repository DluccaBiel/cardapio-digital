import { describe, expect, it } from 'vitest'
import { anotaSnapshot, bestMenu, aaStatus } from '../src/lib/aa-normalize'

// DADOS SINTÉTICOS (formas plausíveis) — o formato real do Anota AI ainda não foi observado.
const nested = { data: { menu: [
  { _id: 'c1', name: 'Lanches', order: 1, itens: [{ _id: 'p1', name: 'X-Burger', description: 'Pão e carne', price: 29.9, active: true, image: 'https://img.test/a.jpg', complementos: [{ name: 'Adicionais', itens: [{ name: 'Bacon', price: 4 }] }] }, { _id: 'p2', name: 'X-Bacon', price: '34,90', active: false }] },
  { _id: 'c2', name: 'Bebidas', order: 0, itens: [{ _id: 'p3', name: 'Coca 2L', price: 12, status: 'ACTIVE' }] },
] } }
const flat = [{ id: 1, nome: 'Pizza Calabresa', preco: 45, categoria: 'Pizzas' }, { id: 2, nome: 'Pizza Mussarela', preco: 42, categoria: 'Pizzas' }, { id: 3, nome: 'Guaraná', preco: 8, categoria: 'Bebidas' }]

describe('leitor tolerante do Anota AI', () => {
  it('categorias aninhadas: ordem, preço em texto, status, imagem; complementos não viram produto', () => {
    const s = anotaSnapshot(nested, 'Loja X', '99')!
    expect(s.categories.map((c) => c.name)).toEqual(['Bebidas', 'Lanches'])
    expect(s.items).toHaveLength(3)
    const x = s.items.find((i) => i.id === 'p2')!
    expect(x).toMatchObject({ price: 34.9, status: 'paused', categoryName: 'Lanches' })
    expect(s.items.find((i) => i.id === 'p1')).toMatchObject({ hasImage: true, status: 'active' })
    expect(s.items.find((i) => i.id === 'p1')!.complements.map((c) => c.name)).toEqual(['Adicionais'])
    expect(s.storeKey).toBe('anotaai:99')
  })
  it('lista plana com categoria em texto', () => {
    const s = anotaSnapshot(flat, null, '')!
    expect(s.categories.map((c) => c.name).sort()).toEqual(['Bebidas', 'Pizzas'])
    expect(s.items).toHaveLength(3)
  })
  it('resposta sem cardápio → null; bestMenu escolhe a maior', () => {
    expect(anotaSnapshot({ ok: true, user: { name: 'A', price: 1 } }, null, '')).toBeNull()
    const b = bestMenu([{ path: '/x', json: { a: 1 } }, { path: '/menu', json: nested }, { path: '/flat', json: flat }], null, '1')!
    expect(b.path).toBe('/menu')
  })
  it('status', () => {
    expect(aaStatus({ paused: true })).toBe('paused')
    expect(aaStatus({ ativo: 1 })).toBe('active')
    expect(aaStatus({})).toBe('unknown')
  })
})
