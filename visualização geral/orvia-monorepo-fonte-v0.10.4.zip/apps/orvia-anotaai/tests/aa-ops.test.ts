import { describe, expect, it } from 'vitest'
import { API, nonActiveOf, setStatus, setPrice, editItem, removeItem, createFromBase, reorderCategories, readAnotaMenu } from '../src/lib/aa-ops'

// Servidor FALSO que imita o contrato OBSERVADO no painel real (ids e textos fictícios).
type Rec = Record<string, any>
function fake() {
  const week = (p: number, base = p) => ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'].map((d, i) => ({ price: p, short_name: d, price_base: base, is_promotion: false, discount: 0, is_discount_percentage: false, _id: `w${p}${i}` }))
  const db = {
    cats: [{ _id: 'cA', title: 'Promoção ', order: 0, page: 'loja1' }, { _id: 'cB', title: 'Bebidas', order: 1, page: 'loja1' }, { _id: 'cC', title: 'Combos', order: 2, page: 'loja1' }] as Rec[],
    items: [
      { _id: 'ci1', item: 'it1', category: 'cA', price: 'pr1', item_title: 'X-Burger', item_description: 'Pão e carne', item_image: 'https://img/a', order: 1, simple_price: true, is_paused: false, week: week(30), selling_unit: { mode: 'quantity', type_mode: 'unit' }, non_active_weekdays: [] },
      { _id: 'ci2', item: 'it2', category: 'cB', price: 'pr2', item_title: 'Refri Lata', item_description: '', item_image: '', order: 1, simple_price: true, is_paused: false, week: week(6), non_active_weekdays: [] },
      { _id: 'ci3', item: 'it3', category: 'cB', price: 'pr3', item_title: 'Suco Promo', item_description: '', item_image: '', order: 2, simple_price: true, is_paused: true, week: week(8).map((d, i) => (i === 0 ? { ...d, is_promotion: true } : d)), non_active_weekdays: [] },
    ] as Rec[],
    calls: [] as string[], bodies: [] as Rec[], n: 100,
  }
  const request = async (method: string, url: string, body?: any) => {
    const u = new URL(url)
    const path = u.pathname.replace('/auth/v2', '')
    db.calls.push(`${method} ${path}`)
    if (body) db.bodies.push(body)
    let m: RegExpMatchArray | null
    if (method === 'GET' && path === '/nm-category/for/admin/only-categories') {
      const page = Number(u.searchParams.get('page'))
      const sorted = [...db.cats].sort((a, b) => a.order - b.order)
      return { status: 200, json: { docs: page === 1 ? sorted.slice(0, 2) : sorted.slice(2), page, pages: 2, total: 3 } }
    }
    if (method === 'GET' && (m = path.match(/^\/nm-category\/for\/admin\/itens\/(\w+)$/))) return { status: 200, json: { success: true, categoryItems: db.items.filter((i) => i.category === m![1]) } }
    if (method === 'POST' && path === '/category-item/edit/price') {
      const ci = db.items.find((i) => i._id === body.document.categoryItem)!
      ci.week = body.document.price.week
      return { status: 200, json: { success: true, categoryItem: ci } }
    }
    if (method === 'PUT' && path === '/item/update') {
      const d = body.document
      const ci = db.items.find((i) => i._id === d.category_item)!
      Object.assign(ci, { item_title: d.title, item_description: d.description, week: d.week })
      return { status: 200, json: { success: true, categoryItemCompleted: ci } }
    }
    if (method === 'POST' && path === '/item/duplicate') {
      const b = db.items.find((i) => i.item === body.document.item)!
      db.n += 1
      const nc = { ...b, _id: `ci${db.n}`, item: `it${db.n}`, item_title: `${b.item_title} - Cópia` }
      db.items.push(nc)
      return { status: 200, json: { success: true, newCategoryItem: nc } }
    }
    if (method === 'DELETE' && (m = path.match(/^\/item\/(\w+)$/))) { db.items = db.items.filter((i) => i.item !== m![1]); return { status: 200, json: { success: true } } }
    if (method === 'PUT' && path === '/nm-category/order/update') { for (const o of body.document.ordenation) db.cats.find((c) => c._id === o.categoryId)!.order = o.order; return { status: 200, json: { success: true } } }
    if (method === 'PUT' && (m = path.match(/^\/item\/out-stock\/(\w+)$/))) {
      for (const ci of db.items.filter((i) => i.item === m![1])) ci.out = body.document.isOut
      return { status: 200, json: { success: true, message: 'Estoque alterado' } }
    }
    if (method === 'PUT' && (m = path.match(/^\/item\/availability\/(\w+)$/))) {
      for (const ci of db.items.filter((i) => i.item === m![1])) ci.non_active_weekdays = body.document.non_active_weekdays
      return { status: 200, json: { success: true, message: 'A disponibilidade do item foi alterada com sucesso.' } }
    }
    return { status: 404, json: {} }
  }
  return { db, request }
}

describe('Anota AI — receitas observadas, com servidor falso', () => {
  it('lê categorias paginadas e itens de cada uma', async () => {
    const { request } = fake()
    const r = await readAnotaMenu(request, null, 'Loja')
    expect(r.snapshot!.categories.map((c) => c.name)).toEqual(['Promoção', 'Bebidas'])
    expect(r.snapshot!.items.map((i) => i.name).sort()).toEqual(['Refri Lata', 'Suco Promo', 'X-Burger'])
    expect(r.snapshot!.items.find((i) => i.name === 'X-Burger')).toMatchObject({ price: 30, id: 'ci1', productId: 'it1', status: 'active' })
    expect(r.snapshot!.items.find((i) => i.name === 'Suco Promo')).toMatchObject({ status: 'paused', price: 8 })
  })
  it('preço: corpo no formato do painel, os 7 dias, e confere relendo', async () => {
    const { db, request } = fake()
    const r = await setPrice(request, 'cA', 'ci1', 32.9, 'X-Burger')
    expect(r).toMatchObject({ ok: true })
    const b = db.bodies[0]!.document
    expect(b.categoryItem).toBe('ci1')
    expect(b.price).toMatchObject({ price: 32.9, price_base: 32.9, simple_price: true })
    expect(b.price.week).toHaveLength(7)
    expect(b.price.week.every((d: Rec) => d.price === 32.9 && d.price_base === 32.9 && typeof d._id === 'string')).toBe(true)
  })
  it('preço: item com promoção por dia NÃO é alterado', async () => {
    const { db, request } = fake()
    const r = await setPrice(request, 'cB', 'ci3', 9.9, 'Suco Promo')
    expect(r.ok).toBe(false)
    expect(db.calls.some((c) => c.startsWith('POST'))).toBe(false)
  })
  it('nome/descrição: PUT item/update com o corpo completo do portal; preserva imagem e preços', async () => {
    const { db, request } = fake()
    const r = await editItem(request, { catId: 'cA', productId: 'it1', label: 'X-Burger', changes: { name: 'X-Burger Artesanal' } })
    expect(r).toMatchObject({ ok: true })
    const d = db.bodies[0]!.document
    expect(d).toMatchObject({ category: 'cA', title: 'X-Burger Artesanal', description: 'Pão e carne', image: 'https://img/a', item: 'it1', category_item: 'ci1', price_base: 30 })
    expect(d.week).toHaveLength(7)
  })
  it('horário: 10–14h seg–sex vira intervalos SEM venda e é conferido', async () => {
    const { db, request } = fake()
    const r = await editItem(request, { catId: 'cA', productId: 'it1', label: 'X', changes: { schedule: [{ start: '10:00', end: '14:00', days: [0, 1, 2, 3, 4] }] } })
    expect(r).toMatchObject({ ok: true })
    expect(db.calls).toContain('PUT /item/availability/it1')
    const d = (db.items[0]!.non_active_weekdays as Rec[])
    expect(d.filter((x) => x.short_name === 'mon').map((x) => [x.start, x.end])).toEqual([[0, 35940], [50400, 86340]])
    expect(d.filter((x) => x.short_name === 'sat').map((x) => [x.start, x.end])).toEqual([[0, 86340]])
  })
  it('horário: sempre disponível limpa a lista; repetir não chama de novo', async () => {
    const { db, request } = fake()
    await editItem(request, { catId: 'cA', productId: 'it1', label: 'X', changes: { schedule: [{ start: '10:00', end: '14:00', days: [0] }] } })
    const r = await editItem(request, { catId: 'cA', productId: 'it1', label: 'X', changes: { schedule: null } })
    expect(r.ok).toBe(true)
    expect(db.items[0]!.non_active_weekdays).toEqual([])
    db.calls.length = 0
    const r2 = await editItem(request, { catId: 'cA', productId: 'it1', label: 'X', changes: { schedule: null } })
    expect(r2.message).toContain('já está')
    expect(db.calls.filter((c) => c.startsWith('PUT'))).toHaveLength(0)
  })
  it('horário: gravação do usuário (01:00 em diante → 0–3540)', () => {
    expect(nonActiveOf([{ start: '01:00', end: '23:59', days: [6] }]).filter((x) => x.short_name === 'sun')).toEqual([{ short_name: 'sun', start: 0, end: 3540 }])
  })
  it('produto novo: duplica, ajusta nome+descrição+preço e confere', async () => {
    const { db, request } = fake()
    const r = await createFromBase(request, { catId: 'cA', baseId: 'it1', name: 'Burger Bacon Duplo', description: 'Bacon e queijo', price: 45.9 })
    expect(r).toMatchObject({ ok: true })
    const nc = db.items.find((i) => i.item_title === 'Burger Bacon Duplo')!
    expect(nc.item_description).toBe('Bacon e queijo')
    expect(nc.week.every((d: Rec) => d.price === 45.9)).toBe(true)
    expect(db.bodies[0]!.document).toMatchObject({ item: 'it1', category: 'cA', selectedPriceId: 'pr1', next_steps: [] })
  })
  it('remover: DELETE no item e confere', async () => {
    const { db, request } = fake()
    expect(await removeItem(request, { catId: 'cB', itemId: 'ci2', name: 'Refri' })).toMatchObject({ ok: true })
    expect(db.items.some((i) => i._id === 'ci2')).toBe(false)
  })
  it('ordem das categorias: manda TODAS (inclusive a 2ª página) e confere', async () => {
    const { db, request } = fake()
    const r = await reorderCategories(request, null, [{ id: 'cC', name: 'Combos' }, { id: 'cA', name: 'Promoção' }])
    expect(r).toMatchObject({ ok: true })
    expect(db.bodies[0]!.document.ordenation).toEqual([{ categoryId: 'cC', order: 0 }, { categoryId: 'cA', order: 1 }, { categoryId: 'cB', order: 2 }])
  })
  it('categoria que sumiu → não envia nada', async () => {
    const { db, request } = fake()
    const r = await reorderCategories(request, null, [{ id: 'zzz', name: 'x' }])
    expect(r.ok).toBe(false)
    expect(db.calls.some((c) => c.startsWith('PUT'))).toBe(false)
  })
  it('API usa o host observado', () => { expect(API).toBe('https://api-menu.anota.ai/auth/v2') })

  it('pausa e ativa pelo "Esgotado" do painel, conferindo ao reler', async () => {
    const { db, request } = fake()
    const p = await setStatus(request, { catId: 'cA', itemId: 'ci1', label: 'X-Burger', status: 'paused' })
    expect(p.ok).toBe(true)
    expect(db.bodies.at(-1)).toEqual({ document: { isOut: true } })
    expect(db.items[0]!.out).toBe(true)
    expect((await setStatus(request, { catId: 'cA', itemId: 'ci1', label: 'X-Burger', status: 'paused' })).message).toMatch(/já estava pausado/)
    expect((await setStatus(request, { catId: 'cA', itemId: 'ci1', label: 'X-Burger', status: 'active' })).ok).toBe(true)
    expect(db.items[0]!.out).toBe(false)
    expect((await setStatus(request, { catId: 'cA', itemId: 'ci1', label: 'X-Burger', status: 'active' })).message).toMatch(/já estava ativo/)
  })
})
