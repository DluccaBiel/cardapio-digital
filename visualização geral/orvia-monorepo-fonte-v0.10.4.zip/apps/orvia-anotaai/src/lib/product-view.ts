/** "Como o produto está agora" (prints antes/depois): relê a categoria no Anota AI. */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { ProductView } from '@orvia/shared/lib/prints'
import type { MenuSnapshot } from '@orvia/shared/core/schema'
import { categoryItems } from './aa-ops'
import { weekPrices } from './aa-normalize'
export type { ProductView }
let latest: MenuSnapshot | null = null
export const setLatestSnapshot = (s: MenuSnapshot | null) => { latest = s }
export async function fetchProductView(productId: string, _ctx: PortalCtx, request: PortalRequest): Promise<ProductView | null> {
  const known = latest?.items.find((i) => i.id === productId || i.productId === productId)
  if (!known?.categoryId) return null
  const ci = (await categoryItems(request, known.categoryId))?.find((x) => String(x._id) === known.id)
  if (!ci) return null
  const w = weekPrices(ci)
  const restricted = Array.isArray(ci.non_active_weekdays) && ci.non_active_weekdays.length > 0
  return { name: String(ci.item_title ?? known.name), description: String(ci.item_description ?? ''), imageUrl: typeof ci.item_image === 'string' && ci.item_image ? ci.item_image : null, categoryName: known.categoryName, price: w.price, originalPrice: w.original, active: ci.is_paused !== true, schedule: restricted ? 'horário restrito' : 'sempre disponível', promotion: w.promo ? 'preço promocional por dia' : null }
}
