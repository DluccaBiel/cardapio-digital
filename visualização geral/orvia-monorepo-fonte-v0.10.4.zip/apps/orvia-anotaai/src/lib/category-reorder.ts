import type { PortalRequest } from '@orvia/shared/lib/executor'
import { reorderCategories as reorder } from './aa-ops'
export let categoriesHint: string | null = null
export const setCategoriesHint = (u: string | null) => { categoriesHint = u }
export const reorderCategories = (o: { order: { id: string; name: string }[]; request: PortalRequest }) => reorder(o.request, categoriesHint, o.order)
