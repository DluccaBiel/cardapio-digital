import type { PortalRequest } from '@orvia/shared/lib/executor'
import type { PortalCtx } from '@orvia/shared/lib/portal'
import type { Schedule } from '@orvia/shared/core/proposal'
import { editItem as edit } from './aa-ops'
export type { PortalCtx }
export const editItem = (o: { productId: string; catId: string; label: string; request: PortalRequest; changes: { name?: string; description?: string; schedule?: Schedule | null } }) => edit(o.request, { catId: o.catId, productId: o.productId, label: o.label, changes: o.changes })
