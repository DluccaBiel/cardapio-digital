import type { PortalRequest } from '@orvia/shared/lib/executor'
import { createFromBase } from './aa-ops'
export async function createItemFromBase(o: { baseProductId: string; categoryId?: string | null; name: string; description?: string; price?: number | null; addOns?: unknown; request: PortalRequest }): Promise<{ ok: boolean; message: string; productId?: string }> {
  return createFromBase(o.request, { catId: o.categoryId ?? '', baseId: o.baseProductId, name: o.name, description: o.description, price: o.price })
}
