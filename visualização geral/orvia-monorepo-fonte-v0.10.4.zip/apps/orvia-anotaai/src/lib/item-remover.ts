import type { PortalRequest } from '@orvia/shared/lib/executor'
import { removeItem as remove } from './aa-ops'
export const removeItem = (o: { itemId: string; catId: string; name: string; request: PortalRequest }) => remove(o.request, { catId: o.catId, itemId: o.itemId, name: o.name })
