/** Anota AI: chamadas à API do cardápio rodam na página (hook) com o login que o próprio painel usa. */
export type OwnCall = { at: string; method: string; path: string; body: string; status: number; erro?: string }
export const ownLog: OwnCall[] = []
/** Id estável da loja (só como reserva): o host do painel. */
export const aaStoreHost = (): string => { try { return location.hostname } catch { return 'anota.ai' } }
