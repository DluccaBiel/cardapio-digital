/**
 * Anota AI — receitas OBSERVADAS no painel real (diagnóstico do dono, 10/11/2026). API: https://api-menu.anota.ai/auth/v2
 *   listar categorias  GET    /nm-category/for/admin/only-categories?page&root&title&limit   → {docs,page,pages,total}
 *   itens da categoria GET    /nm-category/for/admin/itens/{cat}                             → {categoryItems:[…]}
 *   preço              POST   /category-item/edit/price   {document:{categoryItem,price:{price,price_base,simple_price,week:[…]}}}
 *   nome/descrição     PUT    /item/update                {document:{category,title,description,image,order,item,is_weighable,price_base,simple_price,week,selling_unit,category_item,non_active_weekdays}}
 *   duplicar           POST   /item/duplicate             {document:{item,category,selectedPriceId,next_steps:[]}} → {newCategoryItem}
 *   excluir            DELETE /item/{item}
 *   ordem categorias   PUT    /nm-category/order/update   {document:{ordenation:[{categoryId,order}]}}
 * pausar/ativar  PUT    /item/out-stock/{item}      {document:{isOut:true|false}}  ("Esgotado" do painel; `out` na leitura)
 * NÃO gravado ainda: horário de venda por faixa (PUT /item/availability/{item}, janelas em que NÃO vende).
 * Puro: sem chrome.*, sem DOM (o `request` é injetado).
 */
import type { PortalRequest } from '@orvia/shared/lib/executor'
import { anotaMenuSnapshot, weekPrices, type AnotaCatDoc } from './aa-normalize'
import type { MenuSnapshot } from '@orvia/shared/core/schema'

export const API = 'https://api-menu.anota.ai/auth/v2'
export const WRITES_LEARNED = true
export const NOT_LEARNED = 'Horário de venda por faixa ainda não tem receita gravada no Anota AI. Faça no painel ou me envie a gravação.'
export type Res = { ok: boolean; message: string }
export type AddOnRow = { id: string; name: string; options: number; min: number | null; max: number | null }
export const notLearned = async (..._args: unknown[]): Promise<Res> => ({ ok: false, message: NOT_LEARNED })
export const listAddOns = async (): Promise<AddOnRow[] | null> => null

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const ok2xx = (s: number) => s >= 200 && s < 300
const okBody = (j: unknown) => !isRec(j) || j.success !== false
const why = (r: { status: number; json: unknown }) => `HTTP ${r.status}${isRec(r.json) && typeof r.json.message === 'string' ? ` — ${r.json.message.slice(0, 140)}` : isRec(r.json) && typeof r.json.error === 'string' ? ` — ${r.json.error.slice(0, 140)}` : ''}`
const same = (a: unknown, b: unknown) => String(a ?? '').trim() === String(b ?? '').trim()
const eq = (a: number, b: number) => Math.abs(a - b) < 0.001

// ── leitura ─────────────────────────────────────────────────────────────────────
function catListUrl(hint: string | null, page: number): string {
  try {
    const u = new URL(hint ?? `${API}/nm-category/for/admin/only-categories?page=1&root=true&title=&limit=100`)
    u.searchParams.set('page', String(page))
    u.searchParams.set('limit', '100')
    return u.href
  } catch { return `${API}/nm-category/for/admin/only-categories?page=${page}&root=true&title=&limit=100` }
}
export async function listCategories(request: PortalRequest, hint: string | null): Promise<{ cats: AnotaCatDoc[]; error?: string }> {
  const cats: AnotaCatDoc[] = []
  let pages = 1
  for (let page = 1; page <= Math.min(pages, 20); page += 1) {
    const r = await request('GET', catListUrl(hint, page))
    if (!ok2xx(r.status) || !isRec(r.json) || !Array.isArray(r.json.docs)) return { cats, error: `lista de categorias recusada (${why(r)})` }
    for (const d of r.json.docs) if (isRec(d) && typeof d._id === 'string' && typeof d.title === 'string') cats.push({ _id: d._id, title: d.title, order: Number(d.order) || 0, published: d.published === true, page: typeof d.page === 'string' ? d.page : undefined, category_type: typeof d.category_type === 'string' ? d.category_type : undefined, deleted: d.deleted === true })
    pages = Number(r.json.pages) || 1
  }
  return { cats }
}
export async function categoryItems(request: PortalRequest, catId: string): Promise<Rec[] | null> {
  const r = await request('GET', `${API}/nm-category/for/admin/itens/${encodeURIComponent(catId)}?_=${Date.now()}`)
  return ok2xx(r.status) && isRec(r.json) && Array.isArray(r.json.categoryItems) ? r.json.categoryItems.filter(isRec) : null
}
const findCi = (list: Rec[] | null, id: string): Rec | null => list?.find((x) => String(x._id) === String(id) || String(x.item) === String(id)) ?? null

export async function readAnotaMenu(request: PortalRequest, hint: string | null, merchantName: string | null): Promise<{ snapshot: MenuSnapshot | null; categorias: number; erro?: string }> {
  const { cats, error } = await listCategories(request, hint)
  if (!cats.length) return { snapshot: null, categorias: 0, erro: error ?? 'nenhuma categoria encontrada' }
  const byCat: Record<string, Rec[]> = {}
  const queue = [...cats]
  let failed = 0
  await Promise.all(Array.from({ length: 4 }, async () => {
    for (let c = queue.shift(); c; c = queue.shift()) {
      const list = await categoryItems(request, c._id)
      if (list) byCat[c._id] = list
      else failed += 1
    }
  }))
  const store = cats.find((c) => c.page)?.page ?? ''
  const snapshot = anotaMenuSnapshot(cats, byCat, merchantName, store)
  return { snapshot, categorias: cats.length, erro: snapshot ? (failed ? `${failed} categoria(s) não puderam ser lidas` : undefined) : 'categorias sem produtos' }
}

// ── escrita ─────────────────────────────────────────────────────────────────────
export async function setPrice(request: PortalRequest, catId: string, id: string, price: number, label: string): Promise<Res> {
  if (!catId) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  const ci = findCi(await categoryItems(request, catId), id)
  if (!ci) return { ok: false, message: `Não achei “${label}” na categoria — sincronize de novo.` }
  const w = weekPrices(ci)
  if (w.promo) return { ok: false, message: `“${label}” tem preço promocional por dia — altere no painel para não perder a promoção.` }
  const week = (Array.isArray(ci.week) ? ci.week.filter(isRec) : [])
  if (!week.length) return { ok: false, message: `“${label}” sem tabela de preço por dia — não alterado.` }
  if (w.uniform && w.price !== null && eq(w.price, price)) return { ok: true, message: 'O Anota AI já está com este preço.' }
  const body = { document: { categoryItem: ci._id, price: { price, price_base: price, simple_price: ci.simple_price !== false, week: week.map((d) => ({ ...d, price, price_base: price })) } } }
  const res = await request('POST', `${API}/category-item/edit/price`, body)
  if (!ok2xx(res.status) || !okBody(res.json)) return { ok: false, message: `O Anota AI recusou o preço de “${label}” (${why(res)}).` }
  const after = findCi(await categoryItems(request, catId), id)
  if (!after) return { ok: false, message: `Enviei o preço de “${label}”, mas não consegui reler para conferir.` }
  const a = weekPrices(after)
  return a.price !== null && a.uniform && eq(a.price, price) ? { ok: true, message: 'Aplicado e conferido no Anota AI.' } : { ok: false, message: `Enviei o preço, mas o Anota AI ainda mostra ${a.price === null ? 'outro valor' : `R$ ${a.price.toFixed(2).replace('.', ',')}`}. Confira no painel.` }
}

function updateBody(ci: Rec, over: { name?: string; description?: string; price?: number }): Rec {
  const week = (Array.isArray(ci.week) ? ci.week.filter(isRec) : []).map((d) => (over.price !== undefined ? { ...d, price: over.price, price_base: over.price } : d))
  const base = over.price ?? (week[0] && typeof week[0].price_base === 'number' ? week[0].price_base : weekPrices(ci).price ?? 0)
  return {
    document: {
      category: ci.category, title: over.name ?? ci.item_title, description: over.description ?? ci.item_description ?? '', image: ci.item_image ?? '', order: ci.order ?? 9999, item: ci.item,
      is_weighable: ci.is_weighable === true, price_base: base, simple_price: ci.simple_price !== false, week, selling_unit: ci.selling_unit ?? { mode: 'quantity', type_mode: 'unit' },
      category_item: ci._id, non_active_weekdays: Array.isArray(ci.non_active_weekdays) ? ci.non_active_weekdays : [],
    },
  }
}

/** nome / descrição / horário (e preço, no produto novo) */
export async function editItem(request: PortalRequest, o: { catId: string; productId: string; label: string; changes: { name?: string; description?: string; schedule?: unknown } }): Promise<Res> {
  if (!o.catId) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  const ci = findCi(await categoryItems(request, o.catId), o.productId)
  if (!ci) return { ok: false, message: `Não achei “${o.label}” na categoria — sincronize de novo.` }
  const { schedule, ...rest } = o.changes
  if (schedule !== undefined) {
    const r = await setSchedule(request, o.catId, ci, schedule as SlotLike[] | null, o.label)
    if (!r.ok || (rest.name === undefined && rest.description === undefined)) return r
  }
  return applyUpdate(request, o.catId, ci, rest, o.label)
}

type SlotLike = { start: string; end: string; days: number[] }
const SHORT = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
const toSec = (hhmm: string): number => { const [h, m] = hhmm.split(':').map(Number); return (h || 0) * 3600 + (m || 0) * 60 }
const DAY_END = 86340

/** Horário de venda → lista de intervalos em que o item NÃO vende (formato do painel: segundos desde 00:00). */
export function nonActiveOf(schedule: SlotLike[] | null): { short_name: string; start: number; end: number }[] {
  if (!schedule || !schedule.length) return []
  const out: { short_name: string; start: number; end: number }[] = []
  SHORT.forEach((short, day) => {
    const slots = schedule.filter((s) => s.days.includes(day)).map((s) => [toSec(s.start), toSec(s.end)] as const).sort((a, b) => a[0] - b[0])
    if (!slots.length) { out.push({ short_name: short, start: 0, end: DAY_END }); return }
    let cursor = 0
    for (const [a, b] of slots) {
      if (a - 60 >= cursor) out.push({ short_name: short, start: cursor, end: a - 60 })
      cursor = Math.max(cursor, b)
    }
    if (cursor < DAY_END) out.push({ short_name: short, start: cursor, end: DAY_END })
  })
  return out
}
const norm = (l: unknown): string => JSON.stringify((Array.isArray(l) ? l : []).filter(isRec).map((x) => [String(x.short_name), Number(x.start), Number(x.end)]).sort())

export async function setSchedule(request: PortalRequest, catId: string, ci: Rec, schedule: SlotLike[] | null, label: string): Promise<Res> {
  const want = nonActiveOf(schedule)
  if (norm(ci.non_active_weekdays) === norm(want)) return { ok: true, message: 'O Anota AI já está com este horário.' }
  const res = await request('PUT', `${API}/item/availability/${encodeURIComponent(String(ci.item))}`, { document: { non_active_weekdays: want } })
  if (!ok2xx(res.status) || !okBody(res.json)) return { ok: false, message: `O Anota AI recusou o horário de “${label}” (${why(res)}).` }
  const after = findCi(await categoryItems(request, catId), String(ci._id))
  if (!after) return { ok: false, message: `Enviei o horário de “${label}”, mas não consegui reler para conferir.` }
  return norm(after.non_active_weekdays) === norm(want) ? { ok: true, message: 'Horário aplicado e conferido no Anota AI.' } : { ok: false, message: 'Enviei o horário, mas o Anota AI ainda mostra o anterior. Confira no painel.' }
}
async function applyUpdate(request: PortalRequest, catId: string, ci: Rec, ch: { name?: string; description?: string; price?: number }, label: string): Promise<Res> {
  if (ch.price !== undefined && weekPrices(ci).promo) return { ok: false, message: `“${label}” tem preço promocional por dia — preço não alterado.` }
  const res = await request('PUT', `${API}/item/update`, updateBody(ci, ch))
  if (!ok2xx(res.status) || !okBody(res.json)) return { ok: false, message: `O Anota AI recusou a alteração de “${label}” (${why(res)}).` }
  const after = findCi(await categoryItems(request, catId), String(ci._id))
  if (!after) return { ok: false, message: `Enviei a alteração de “${label}”, mas não consegui reler para conferir.` }
  const bad: string[] = []
  if (ch.name !== undefined && !same(after.item_title, ch.name)) bad.push('nome')
  if (ch.description !== undefined && !same(after.item_description, ch.description)) bad.push('descrição')
  if (ch.price !== undefined) { const p = weekPrices(after); if (p.price === null || !eq(p.price, ch.price)) bad.push('preço') }
  return bad.length ? { ok: false, message: `Enviado, mas o Anota AI ainda mostra o ${bad.join(' e ')} anterior. Confira no painel.` } : { ok: true, message: 'Aplicado e conferido no Anota AI.' }
}

export async function removeItem(request: PortalRequest, o: { catId: string; itemId: string; name: string }): Promise<Res> {
  if (!o.catId) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  const ci = findCi(await categoryItems(request, o.catId), o.itemId)
  if (!ci) return { ok: true, message: `“${o.name}” já não está no cardápio.` }
  const del = await request('DELETE', `${API}/item/${encodeURIComponent(String(ci.item))}`)
  if (!ok2xx(del.status) || !okBody(del.json)) return { ok: false, message: `O Anota AI recusou excluir “${o.name}” (${why(del)}).` }
  return findCi(await categoryItems(request, o.catId), o.itemId)
    ? { ok: false, message: `Pedi a exclusão de “${o.name}”, mas ele ainda aparece. Confira no painel.` }
    : { ok: true, message: `“${o.name}” excluído e conferido no Anota AI.` }
}

/** produto novo por DUPLICAÇÃO na mesma categoria, depois nome/descrição/preço numa só gravação */
export async function createFromBase(request: PortalRequest, o: { catId: string; baseId: string; name: string; description?: string; price?: number | null }): Promise<Res & { productId?: string }> {
  const name = o.name.trim()
  if (name.length < 2) return { ok: false, message: 'Nome do novo produto vazio — nada criado.' }
  if (!o.catId) return { ok: false, message: 'Produto-base sem categoria conhecida — nada criado.' }
  const base = findCi(await categoryItems(request, o.catId), o.baseId)
  if (!base) return { ok: false, message: 'Não achei o produto-base na categoria — nada criado.' }
  const dup = await request('POST', `${API}/item/duplicate`, { document: { item: base.item, category: o.catId, selectedPriceId: base.price, next_steps: [] } })
  const nc = isRec(dup.json) && isRec(dup.json.newCategoryItem) ? dup.json.newCategoryItem : null
  if (!ok2xx(dup.status) || !okBody(dup.json) || !nc) return { ok: false, message: `O Anota AI recusou duplicar o produto-base (${why(dup)}).` }
  const change = { name, ...(o.description !== undefined ? { description: o.description } : {}), ...(o.price != null && Number.isFinite(o.price) ? { price: o.price } : {}) }
  const r = await applyUpdate(request, o.catId, nc, change, name)
  if (!r.ok) {
    const del = await request('DELETE', `${API}/item/${encodeURIComponent(String(nc.item))}`)
    return { ok: false, productId: String(nc.item), message: `Dupliquei, mas não consegui ajustar o novo item (${r.message})${ok2xx(del.status) ? ' A cópia foi removida.' : ' A cópia “- Cópia” ficou na categoria — apague no painel.'}` }
  }
  return { ok: true, productId: String(nc.item), message: `Criado: “${name}” (duplicado de “${String(base.item_title)}”${nc.is_paused === true ? '; o painel copia o status do original — ele está PAUSADO, ative no painel' : ''}).` }
}

export async function reorderCategories(request: PortalRequest, hint: string | null, order: { id: string; name: string }[]): Promise<Res> {
  const live = await listCategories(request, hint)
  if (!live.cats.length) return { ok: false, message: `Não consegui ler a lista de categorias — ordem não alterada${live.error ? ` (${live.error})` : ''}.` }
  const cur = live.cats.filter((c) => c.deleted !== true).sort((a, b) => a.order - b.order).map((c) => c._id)
  const known = new Set(cur)
  const wanted = order.map((c) => c.id).filter((id) => known.has(id))
  if (wanted.length !== order.length) return { ok: false, message: 'O cardápio mudou (categoria que não existe mais). Sincronize e analise de novo — ordem não alterada.' }
  const finalIds = [...wanted, ...cur.filter((id) => !wanted.includes(id))]
  if (finalIds.every((id, i) => id === cur[i])) return { ok: true, message: 'As categorias já estavam nesta ordem.' }
  const res = await request('PUT', `${API}/nm-category/order/update`, { document: { ordenation: finalIds.map((categoryId, i) => ({ categoryId, order: i })) } })
  if (!ok2xx(res.status) || !okBody(res.json)) return { ok: false, message: `O Anota AI recusou a nova ordem (${why(res)}).` }
  const after = (await listCategories(request, hint)).cats.filter((c) => c.deleted !== true).sort((a, b) => a.order - b.order).map((c) => c._id)
  return after.length === finalIds.length && after.every((id, i) => id === finalIds[i]) ? { ok: true, message: `Categorias reordenadas e conferidas (${finalIds.length}).` } : { ok: false, message: 'Enviei a ordem, mas o painel ainda mostra a anterior. Confira no painel.' }
}

// ── pausar / ativar = "Esgotado" do painel ─────────────────────────────────────
export async function setStatus(request: PortalRequest, o: { catId: string; itemId: string; label: string; status: 'active' | 'paused' }): Promise<Res> {
  if (!o.catId) return { ok: false, message: 'Produto sem categoria conhecida — sincronize de novo.' }
  const ci = findCi(await categoryItems(request, o.catId), o.itemId)
  if (!ci) return { ok: false, message: `Não achei “${o.label}” na categoria — sincronize de novo.` }
  const out = o.status === 'paused'
  if ((ci.out === true) === out) return { ok: true, message: out ? 'O produto já estava pausado (esgotado).' : 'O produto já estava ativo.' }
  const res = await request('PUT', `${API}/item/out-stock/${encodeURIComponent(String(ci.item))}`, { document: { isOut: out } })
  if (!ok2xx(res.status) || !okBody(res.json)) return { ok: false, message: `O Anota AI recusou ${out ? 'pausar' : 'ativar'} “${o.label}” (${why(res)}).` }
  const after = findCi(await categoryItems(request, o.catId), o.itemId)
  if (!after) return { ok: false, message: `Enviei, mas não consegui reler “${o.label}” para conferir.` }
  if ((after.out === true) !== out) return { ok: false, message: `Enviei, mas o Anota AI ainda mostra o produto ${out ? 'ativo' : 'pausado'}. Confira no painel.` }
  const note = !out && after.is_paused === true ? ' (atenção: ele continua indisponível agora por restrição de dia/horário do produto)' : ''
  return { ok: true, message: `“${o.label}” ${out ? 'pausado (esgotado)' : 'ativado'} e conferido no Anota AI${note}.` }
}
