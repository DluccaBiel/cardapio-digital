/**
 * Anota AI → MenuSnapshot (mesmo formato dos outros canais: análise/proposta/PDF/relatório são os mesmos).
 * ATENÇÃO: o formato real das respostas do painel do Anota AI AINDA NÃO FOI OBSERVADO. Este leitor é TOLERANTE:
 * procura, em qualquer resposta JSON que o próprio painel carregou, listas de objetos com nome + preço
 * (agrupados em categorias quando houver) e escolhe a resposta com mais produtos. O que ele leu aparece no
 * Diagnóstico para conferência. Puro: sem chrome.*, sem DOM.
 */
import type { MenuItem, MenuSnapshot } from '@orvia/shared/core/schema'
import { finalizeSnapshot } from '@orvia/shared/core/normalize'

type Rec = Record<string, unknown>
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v)
const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : '')
const first = (o: Rec, keys: string[]): unknown => keys.map((k) => o[k]).find((v) => v !== undefined && v !== null && v !== '')

const NAME_KEYS = ['name', 'nome', 'title', 'titulo']
const PRICE_KEYS = ['price', 'preco', 'preço', 'valor', 'value', 'sale_price', 'unit_price', 'salePrice', 'unitPrice']
const DESC_KEYS = ['description', 'descricao', 'descrição', 'desc', 'details', 'detalhes']
const IMG_KEYS = ['image_url', 'imageUrl', 'image', 'imagem', 'photo', 'foto', 'picture', 'thumbnail', 'thumb', 'img']
const COMPL_KEYS = ['complements', 'complementos', 'add_ons', 'addOns', 'addons', 'adicionais', 'extras', 'options', 'opcoes', 'opções']
const ID_KEYS = ['id', '_id', 'uuid', 'codigo', 'code', 'sku', 'key']
const CATID_KEYS = ['id', '_id', 'uuid', 'codigo', 'code']

export function parsePrice(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) && v >= 0 ? v : null
  if (typeof v !== 'string') return null
  const s = v.replace(/[^\d,.-]/g, '')
  if (!s) return null
  const n = s.includes(',') ? Number(s.replace(/\./g, '').replace(',', '.')) : Number(s)
  return Number.isFinite(n) && n >= 0 ? n : null
}

export function aaStatus(o: Rec): MenuItem['status'] {
  for (const k of ['status', 'active', 'ativo', 'enabled', 'available', 'disponivel', 'visible', 'paused', 'pausado']) {
    const v = o[k]
    if (v === undefined || v === null) continue
    const neg = k === 'paused' || k === 'pausado'
    if (typeof v === 'boolean') return (neg ? !v : v) ? 'active' : 'paused'
    if (typeof v === 'number') return (neg ? v === 0 : v !== 0) ? 'active' : 'paused'
    const s = String(v).toLowerCase()
    if (/^(active|ativo|ativa|enabled|available|disponivel|disponível|on|true|1)$/.test(s)) return neg ? 'paused' : 'active'
    if (/^(inactive|inativo|inativa|paused|pausado|disabled|unavailable|indisponivel|indisponível|off|false|0|missing|esgotado)$/.test(s)) return neg ? 'active' : 'paused'
  }
  return 'unknown'
}

const nameOf = (o: Rec) => str(first(o, NAME_KEYS))
const priceOf = (o: Rec) => parsePrice(first(o, PRICE_KEYS))
const isProduct = (o: Rec) => !!nameOf(o) && priceOf(o) !== null && !Array.isArray(first(o, PRICE_KEYS))

function imageOf(o: Rec): string {
  const v = first(o, IMG_KEYS)
  if (typeof v === 'string') return /^https?:\/\//.test(v) ? v : ''
  if (isRec(v)) return str(first(v, ['url', 'src', 'href']))
  if (Array.isArray(v) && v.length) { const f = v[0]; return typeof f === 'string' ? f : isRec(f) ? str(first(f, ['url', 'src'])) : '' }
  return ''
}
function complementsOf(o: Rec): MenuItem['complements'] {
  const out = new Set<string>()
  for (const k of COMPL_KEYS) {
    const v = o[k]
    if (!Array.isArray(v)) continue
    for (const g of v) if (isRec(g)) { const n = nameOf(g); if (n && !isProduct(g)) out.add(n); else if (n && Array.isArray(first(g, ['itens', 'items', 'options']))) out.add(n) }
  }
  return [...out].map((name) => ({ id: null, name, min: null, max: null, required: null, options: [] }))
}

interface Cat { id: string; name: string; position: number; products: Rec[] }

/** percorre o JSON achando "categorias" (objeto com nome + lista de produtos) e produtos soltos */
function harvest(raw: unknown): { cats: Cat[]; loose: Rec[] } {
  const cats: Cat[] = []
  const loose: Rec[] = []
  const seenArr = new WeakSet<object>()
  const walk = (v: unknown, depth: number, parent: Rec | null) => {
    if (depth > 9 || v === null || typeof v !== 'object') return
    if (Array.isArray(v)) {
      if (seenArr.has(v)) return
      seenArr.add(v)
      const recs = v.filter(isRec)
      const prods = recs.filter(isProduct)
      if (prods.length && prods.length >= recs.length * 0.6) {
        if (parent && nameOf(parent) && !isProduct(parent)) cats.push({ id: str(first(parent, CATID_KEYS)), name: nameOf(parent), position: Number(first(parent, ['position', 'order', 'ordem', 'index', 'sort'])), products: prods })
        else loose.push(...prods)
        return
      }
      for (const r of recs) walk(r, depth + 1, null)
      return
    }
    for (const [k, x] of Object.entries(v as Rec)) {
      if (COMPL_KEYS.includes(k) && isProduct(v as Rec)) continue
      walk(x, depth + 1, v as Rec)
    }
  }
  walk(raw, 0, null)
  return { cats, loose }
}

const slug = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

export function anotaSnapshot(raw: unknown, merchantName: string | null, storeId: string): MenuSnapshot | null {
  const { cats, loose } = harvest(raw)
  const groups: Cat[] = [...cats]
  if (loose.length) {
    // produtos soltos: agrupa pelo campo de categoria se existir
    const byCat = new Map<string, Rec[]>()
    for (const p of loose) {
      const cname = str(isRec(p.category) ? nameOf(p.category) : first(p, ['category_name', 'categoria', 'categoryName', 'category']))
      byCat.set(cname || 'Sem categoria', [...(byCat.get(cname || 'Sem categoria') ?? []), p])
    }
    for (const [name, products] of byCat) groups.push({ id: '', name, position: NaN, products })
  }
  const ordered = groups.map((g, i) => ({ g, i })).sort((a, b) => (Number.isFinite(a.g.position) && Number.isFinite(b.g.position) ? a.g.position - b.g.position : 0) || a.i - b.i).map((x) => x.g)
  const items: MenuItem[] = []
  const categories: MenuSnapshot['categories'] = []
  const seen = new Set<string>()
  ordered.forEach((g, pos) => {
    const catId = g.id || `cat:${slug(g.name)}`
    const ids: string[] = []
    for (const p of g.products) {
      const id = str(first(p, ID_KEYS)) || `aa:${slug(g.name)}:${slug(nameOf(p))}`
      if (seen.has(id)) continue
      seen.add(id)
      const price = priceOf(p)
      const image = imageOf(p)
      const orig = parsePrice(first(p, ['original_price', 'old_price', 'preco_original', 'price_from', 'valor_original']))
      items.push({
        id, productId: id, name: nameOf(p), description: str(first(p, DESC_KEYS)), price,
        originalPrice: orig !== null && price !== null && orig > price ? orig : null,
        status: aaStatus(p), hasImage: !!image, imageUrl: image || null, categoryId: catId, categoryName: g.name,
        complements: complementsOf(p), available: aaStatus(p) === 'active' ? true : aaStatus(p) === 'paused' ? false : null,
      })
      ids.push(id)
    }
    if (ids.length) categories.push({ id: catId, name: g.name, position: pos, itemIds: ids })
  })
  if (items.length < 2) return null
  return finalizeSnapshot({
    schemaVersion: 1, id: '', capturedAt: new Date().toISOString(), origin: 'active',
    merchant: { id: storeId || null, name: merchantName }, storeKey: `anotaai:${storeId || 'loja'}`, catalogs: [], categories, items,
    source: { requestPath: null, domUrl: '' },
  })
}

/** escolhe, entre várias respostas, a que parece o cardápio (mais produtos, depois mais categorias) */
export function bestMenu(candidates: { path: string; json: unknown }[], merchantName: string | null, storeId: string): { snapshot: MenuSnapshot; path: string; tried: number } | null {
  let best: { snapshot: MenuSnapshot; path: string } | null = null
  for (const c of candidates) {
    const s = anotaSnapshot(c.json, merchantName, storeId)
    if (s && (!best || s.items.length > best.snapshot.items.length || (s.items.length === best.snapshot.items.length && s.categories.length > best.snapshot.categories.length))) best = { snapshot: s, path: c.path }
  }
  return best ? { ...best, tried: candidates.length } : null
}

// ───────────── formato REAL observado (diagnóstico do dono, 10/11/2026) ─────────────
//  GET api-menu.anota.ai/auth/v2/nm-category/for/admin/only-categories?page&root&title&limit → {docs:[{_id,title,order,published,page,category_type,…}],page,pages,total}
//  GET api-menu.anota.ai/auth/v2/nm-category/for/admin/itens/{categoryId}                     → {success,categoryItems:[{_id,item,price,category,item_title,item_description,item_image,week:[{price,price_base,short_name,is_promotion,…}],is_paused,out,…}]}
export interface AnotaCatDoc { _id: string; title: string; order: number; published?: boolean; page?: string; category_type?: string; deleted?: boolean }
const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null)

/** preço do item = menor preço da semana; "de" = maior preço-base quando maior que o preço (promoção) */
export function weekPrices(ci: Rec): { price: number | null; original: number | null; uniform: boolean; promo: boolean } {
  const week = Array.isArray(ci.week) ? ci.week.filter(isRec) : []
  const prices = week.map((d) => num(d.price)).filter((x): x is number => x !== null)
  if (!prices.length) return { price: null, original: null, uniform: false, promo: false }
  const price = Math.min(...prices)
  const bases = week.map((d) => num(d.price_base)).filter((x): x is number => x !== null)
  const base = bases.length ? Math.max(...bases) : null
  return { price, original: base !== null && base > price ? base : null, uniform: prices.every((p) => Math.abs(p - price) < 0.001), promo: week.some((d) => d.is_promotion === true) }
}

export function anotaMenuSnapshot(cats: AnotaCatDoc[], itemsByCat: Record<string, Rec[]>, merchantName: string | null, storeId: string): MenuSnapshot | null {
  const categories: MenuSnapshot['categories'] = []
  const items: MenuItem[] = []
  const seen = new Set<string>()
  const ordered = [...cats].filter((c) => c.deleted !== true).sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  ordered.forEach((c, pos) => {
    const ids: string[] = []
    for (const ci of itemsByCat[c._id] ?? []) {
      if (ci.deleted === true || ci.item_deleted === true) continue
      const id = str(ci._id)
      const name = str(ci.item_title)
      if (!id || !name || seen.has(id)) continue
      seen.add(id)
      const w = weekPrices(ci)
      const img = str(ci.item_image)
      const paused = ci.is_paused === true || ci.out === true
      items.push({
        id, productId: str(ci.item) || id, name, description: str(ci.item_description), price: w.price, originalPrice: w.original,
        status: paused ? 'paused' : 'active', hasImage: !!img, imageUrl: img || null, categoryId: c._id, categoryName: c.title.trim(), complements: [], available: !paused,
      })
      ids.push(id)
    }
    categories.push({ id: c._id, name: c.title.trim(), position: pos, itemIds: ids })
  })
  if (items.length < 1) return null
  return finalizeSnapshot({
    schemaVersion: 1, id: '', capturedAt: new Date().toISOString(), origin: 'active',
    merchant: { id: storeId || null, name: merchantName }, storeKey: `anotaai:${storeId || 'loja'}`, catalogs: [], categories: categories.filter((c) => c.itemIds.length), items,
    source: { requestPath: null, domUrl: '' },
  })
}
