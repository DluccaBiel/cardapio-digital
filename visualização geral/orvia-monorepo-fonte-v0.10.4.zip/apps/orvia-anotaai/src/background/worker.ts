/**
 * Service worker: único lugar que conhece a chave de API e fala com o Undercut.
 * Content script e página de opções conversam com ele por mensagens.
 */
import { extensionMatches, HubClient, isValidApiKey, loginToHub, normalizeHubUrl, KNOWN_HUBS, originMatchesPatterns, PRODUCTION_HUB, WRONG_EXTENSION_MESSAGE, type ExtensionSlug, type HubConfig, type HubResult, type HubCallLog, type OptimizationUpload } from '@orvia/shared/lib/hub'
import { fitEvidence } from '@orvia/shared/lib/evidence'
import { enqueue, flush, isRetriable, type Outbox } from '@orvia/shared/lib/outbox'
import { snapshotToImport } from '@orvia/shared/lib/bridge'
import { DEVICE_ID_KEY, HUB_CHANGED_KEY, HUB_CONFIG_KEY, type Msg, type Reply } from '@orvia/shared/lib/messages'
import { listSnapshots, saveSnapshot } from '@orvia/shared/storage/store'

const VERSION = chrome.runtime.getManifest().version
/** canal desta extensão no servidor Undercut + nome real do manifest (vai no handshake) */
const EXTENSION_SLUG: ExtensionSlug = 'orvia-anotaai'
// nome enviado ao servidor no handshake: mantém o nome antigo para o servidor reconhecer o canal
const MANIFEST_NAME = 'Orvia · Otimizador Anota AI'
const OUTBOX_KEY = 'orvia.outbox'
const ALARM = 'orvia-sync'
const LOG_KEY = 'orvia.hubLog'
const ANALYSIS_KEY = 'orvia.lastAnalysis'
const HANDSHAKE_KEY = 'orvia.lastHandshake'

/** Registro (sem segredos) das chamadas ao servidor, para o Diagnóstico mostrar que a consulta é real. */
let logChain: Promise<unknown> = Promise.resolve()
function logCall(e: HubCallLog) {
  logChain = logChain.then(async () => {
    const cur = ((await chrome.storage.local.get(LOG_KEY))[LOG_KEY] as HubCallLog[] | undefined) ?? []
    const extra = e.path === '/extensions/handshake' && e.status === 200 ? { [HANDSHAKE_KEY]: e.at } : {}
    await chrome.storage.local.set({ [LOG_KEY]: [e, ...cur].slice(0, 30), ...extra })
  }).catch(() => undefined)
}
const newClient = (cfg: HubConfig) => new HubClient(cfg, undefined, logCall)
let handshakeDone = false
let lastHeartbeat = 0

async function deviceId(): Promise<string> {
  const stored = (await chrome.storage.local.get(DEVICE_ID_KEY))[DEVICE_ID_KEY] as string | undefined
  if (stored) return stored
  const id = crypto.randomUUID()
  await chrome.storage.local.set({ [DEVICE_ID_KEY]: id })
  return id
}

async function loadConfig(): Promise<HubConfig | null> {
  const stored = (await chrome.storage.local.get(HUB_CONFIG_KEY))[HUB_CONFIG_KEY] as Partial<HubConfig> | undefined
  if (!stored?.apiKey) return null
  return { hubUrl: stored.hubUrl || PRODUCTION_HUB, apiKey: stored.apiKey }
}

async function hub(): Promise<HubClient | string> {
  const cfg = await loadConfig()
  if (!cfg) return 'Extensão ainda não conectada ao Undercut. Abra as opções e cole a chave.'
  try {
    const client = newClient(cfg)
    if (!handshakeDone) {
      const hs = await client.handshake(VERSION, MANIFEST_NAME)
      if (hs.ok) handshakeDone = true
    }
    return client
  } catch (error) {
    return error instanceof Error ? error.message : 'Configuração inválida.'
  }
}

function reply<T>(res: HubResult<T>): Reply<T> {
  if (res.ok) return { ok: true, data: res.data }
  if (res.status === 401) handshakeDone = false
  return { ok: false, error: res.message, code: res.code, details: res.details }
}

/** Como reply(), mas 401 (chave revogada/expirada) apaga a chave local — a UI pede novo login. */
function replyAuthed<T>(res: HubResult<T>): Reply<T> {
  if (!res.ok && res.status === 401) void dropKey()
  return reply(res)
}

/** Chave inválida (401) ou de outro canal: apaga SÓ a chave (mantém o endereço) e avisa a página. */
async function dropKey(): Promise<void> {
  const cfg = await loadConfig()
  const prev = ((await chrome.storage.local.get(HUB_CONFIG_KEY))[HUB_CONFIG_KEY] ?? {}) as { email?: string; workspace?: string }
  await chrome.storage.local.set({ [HUB_CONFIG_KEY]: { hubUrl: cfg?.hubUrl ?? PRODUCTION_HUB, email: prev.email, workspace: prev.workspace }, [HUB_CHANGED_KEY]: Date.now() })
  handshakeDone = false
}

const outbox: Outbox = {
  read: async () => ((await chrome.storage.local.get(OUTBOX_KEY))[OUTBOX_KEY] as OptimizationUpload[] | undefined) ?? [],
  write: (list) => chrome.storage.local.set({ [OUTBOX_KEY]: list }),
}
let flushing = false
async function flushOutbox(client: HubClient): Promise<void> {
  if (flushing) return
  flushing = true
  try {
    await flush(outbox, (o) => client.saveOptimization(o))
  } finally {
    flushing = false
  }
}

/** Redimensiona um PNG (base64) com OffscreenCanvas — só para caber nos limites do servidor. */
async function shrinkPng(b64: string, factor: number): Promise<string | null> {
  try {
    const bin = atob(b64)
    const bytes = new Uint8Array(bin.length)
    for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i)
    const bmp = await createImageBitmap(new Blob([bytes], { type: 'image/png' }))
    const w = Math.max(1, Math.round(bmp.width * factor))
    const h = Math.max(1, Math.round(bmp.height * factor))
    const cv = new OffscreenCanvas(w, h)
    cv.getContext('2d')!.drawImage(bmp, 0, 0, w, h)
    const out = new Uint8Array(await (await cv.convertToBlob({ type: 'image/png' })).arrayBuffer())
    let s = ''
    for (let i = 0; i < out.length; i += 0x8000) s += String.fromCharCode(...out.subarray(i, i + 0x8000))
    return btoa(s)
  } catch {
    return null
  }
}

/** Salva na pasta Downloads. `uniquify`: nunca sobrescreve um print anterior ("print 1 (1).png"). */
async function saveDownloads(files: { name: string; dataUrl: string }[]): Promise<Reply<unknown>> {
  if (!Array.isArray(files) || files.length === 0 || files.length > 12) return { ok: false, error: 'Arquivos inválidos.' }
  const saved: { name: string; path: string }[] = []
  for (const f of files) {
    if (!/^[\w .()\-À-ÿ]{1,80}\.(png|pdf)$/i.test(f.name) || !/^data:(image\/png|application\/pdf);base64,/.test(f.dataUrl)) return { ok: false, error: `Arquivo recusado: ${f.name}` }
    try {
      const id = await chrome.downloads.download({ url: f.dataUrl, filename: f.name, conflictAction: 'uniquify', saveAs: false })
      let path = f.name
      for (let i = 0; i < 20; i += 1) {
        const [item] = await chrome.downloads.search({ id })
        if (item?.state === 'complete') {
          path = item.filename
          break
        }
        if (item?.state === 'interrupted') return { ok: false, error: `O Chrome não conseguiu salvar ${f.name} (${item.error ?? 'interrompido'}).` }
        await new Promise((r) => setTimeout(r, 250))
      }
      saved.push({ name: f.name, path })
    } catch (e) {
      return { ok: false, error: `Não foi possível salvar ${f.name}: ${e instanceof Error ? e.message : 'erro'}` }
    }
  }
  return { ok: true, data: { saved } }
}

async function handle(msg: Msg): Promise<Reply<unknown>> {
  switch (msg.type) {
    case 'snapshot:save': {
      const res = await saveSnapshot(msg.snapshot)
      return { ok: true, data: { saved: res.saved } }
    }
    case 'snapshot:latest': {
      const list = await listSnapshots()
      return { ok: true, data: list[0] ?? null }
    }
    case 'options:open': {
      await chrome.runtime.openOptionsPage()
      return { ok: true, data: null }
    }
    case 'image:fetch': {
      // foto do produto para o relatório (o service worker não sofre CORS; só aceita o CDN de imagens do Anota AI)
      if (!/^https:\/\/([a-z0-9-]+\.)*(anota\.ai|cloudfront\.net|amazonaws\.com|googleusercontent\.com|firebasestorage\.googleapis\.com)\//.test(msg.url)) return { ok: false, error: 'Endereço de imagem não permitido.' }
      try {
        const r = await fetch(msg.url)
        if (!r.ok) return { ok: false, error: `HTTP ${r.status}` }
        const buf = new Uint8Array(await r.arrayBuffer())
        if (buf.length > 3_000_000) return { ok: false, error: 'Imagem grande demais.' }
        let bin = ''
        for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000))
        return { ok: true, data: `data:${r.headers.get('content-type') ?? 'image/jpeg'};base64,${btoa(bin)}` }
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : 'Falha ao baixar a imagem.' }
      }
    }
    case 'aa:fetch': {
      // Anota AI: chamada à API do cardápio feita AQUI (o service worker não sofre CORS), com o login que o painel usa. Só api-menu.anota.ai/auth/.
      if (!/^https:\/\/api-menu\.anota\.ai\/auth\//.test(msg.url) || !['GET', 'POST', 'PUT', 'DELETE'].includes(msg.method)) return { ok: false, error: 'Endereço não permitido.' }
      try {
        const r = await fetch(msg.url, { method: msg.method, headers: { ...msg.headers, ...(msg.body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: msg.body !== undefined ? JSON.stringify(msg.body) : undefined, credentials: 'omit' })
        const t = await r.text()
        let j: unknown = t
        try { j = JSON.parse(t) } catch { /* texto */ }
        return { ok: true, data: { status: r.status, json: j } }
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : 'Falha de rede.' }
      }
    }
    case 'downloads:save':
      return saveDownloads(msg.files)
    case 'hub:test': {
      const base = normalizeHubUrl(msg.hubUrl)
      if (!base) return { ok: false, error: 'Endereço inválido: use https:// (ou http://localhost em desenvolvimento).' }
      try {
        const client = newClient({ hubUrl: base, apiKey: msg.apiKey })
        const me = await client.me()
        if (!me.ok) return reply(me)
        if (!extensionMatches(me.data, EXTENSION_SLUG)) return { ok: false, error: WRONG_EXTENSION_MESSAGE, code: 'wrong_extension' }
        const hs = await client.handshake(VERSION, MANIFEST_NAME)
        handshakeDone = hs.ok
        return { ok: true, data: { ...me.data, handshake: hs.ok ? 'ok' : hs.message } }
      } catch (error) {
        return { ok: false, error: error instanceof Error ? error.message : 'Falha no teste.' }
      }
    }
    case 'hub:pair': {
      // Conexão automática: a chave veio da página do Undercut (origem verificada no listener).
      const base = normalizeHubUrl(msg.hubUrl)
      if (!base || !isValidApiKey(msg.apiKey)) return { ok: false, error: 'Dados de conexão inválidos.' }
      try {
        const client = newClient({ hubUrl: base, apiKey: msg.apiKey })
        const me = await client.me()
        if (!me.ok) return reply(me)
        if (!extensionMatches(me.data, EXTENSION_SLUG)) return { ok: false, error: WRONG_EXTENSION_MESSAGE, code: 'wrong_extension' }
        await chrome.storage.local.set({ [HUB_CONFIG_KEY]: { hubUrl: base, apiKey: msg.apiKey }, [HUB_CHANGED_KEY]: Date.now() })
        const hs = await client.handshake(VERSION, MANIFEST_NAME)
        handshakeDone = hs.ok
        return { ok: true, data: { workspace: me.data.workspace } }
      } catch {
        return { ok: false, error: 'Falha ao conectar.' }
      }
    }
    case 'hub:login': {
      // Senha só trafega nesta chamada (HTTPS) — nunca é guardada.
      const input = {
        email: msg.email,
        password: msg.password,
        workspace_slug: msg.workspaceSlug,
        device_id: await deviceId(),
        device_label: navigator.userAgent.includes('Edg/') ? 'Edge' : 'Chrome',
        extension: EXTENSION_SLUG,
      }
      let usedUrl = msg.hubUrl
      let res = await loginToHub(usedUrl, input)
      // endereço antigo/errado salvo (ex.: localhost)? tenta o servidor de produção antes de desistir
      if (!res.ok && res.code === 'network') {
        for (const alt of KNOWN_HUBS) {
          if (normalizeHubUrl(usedUrl) === alt) continue
          const retry = await loginToHub(alt, input)
          if (retry.ok || retry.code !== 'network') {
            res = retry
            usedUrl = alt
            break
          }
        }
      }
      if (!res.ok) return { ok: false, error: res.message, code: res.code }
      if ('needs_workspace' in res.data) return { ok: true, data: res.data }
      const base = normalizeHubUrl(usedUrl)!
      await chrome.storage.local.set({ [HUB_CONFIG_KEY]: { hubUrl: base, apiKey: res.data.key, email: res.data.user.email, workspace: res.data.workspace.name }, [HUB_CHANGED_KEY]: Date.now() })
      handshakeDone = false
      const client = newClient({ hubUrl: base, apiKey: res.data.key })
      // Confere que a chave é DESTA extensão (senão apaga e pede novo login)
      const who = await client.me()
      if (!who.ok) return reply(who)
      if (!extensionMatches(who.data, EXTENSION_SLUG)) {
        await dropKey()
        return { ok: false, error: WRONG_EXTENSION_MESSAGE, code: 'wrong_extension' }
      }
      const hs = await client.handshake(VERSION, MANIFEST_NAME)
      handshakeDone = hs.ok
      lastHeartbeat = Date.now()
      return { ok: true, data: { workspace: res.data.workspace, user: res.data.user } }
    }
    case 'hub:heartbeat': {
      // Mantém o "Conectada agora" no painel enquanto o portal Anota AI está aberto (no máx. 1×/min).
      const cfg = await loadConfig()
      if (!cfg) return { ok: true, data: { configured: false } }
      if (Date.now() - lastHeartbeat < 60_000) return { ok: true, data: { skipped: true } }
      lastHeartbeat = Date.now()
      try {
        const hs = await newClient(cfg).handshake(VERSION, MANIFEST_NAME)
        return hs.ok ? { ok: true, data: { ok: true } } : reply(hs)
      } catch {
        return { ok: false, error: 'Configuração inválida.' }
      }
    }
    case 'hub:diag': {
      const cfg = await loadConfig()
      let servidor: Record<string, unknown> | null = null
      if (msg.probe && cfg) {
        const c = newClient(cfg)
        const t0 = Date.now()
        const who = await c.me()
        const latenciaMs = Date.now() - t0
        if (!who.ok) servidor = { ok: false, erro: who.message, status: who.status, latenciaMs }
        else {
          const hs = await c.handshake(VERSION, MANIFEST_NAME)
          servidor = { ok: true, latenciaMs, workspace: who.data.workspace.name, canal: who.data.extension ?? null, plataforma: who.data.platform ?? null, canalConfere: extensionMatches(who.data, EXTENSION_SLUG), handshake: hs.ok ? 'ok' : hs.message }
          if (hs.ok) handshakeDone = true
        }
      }
      const st = await chrome.storage.local.get([LOG_KEY, ANALYSIS_KEY, HANDSHAKE_KEY, OUTBOX_KEY])
      return { ok: true, data: { configurado: Boolean(cfg), servidorUrl: cfg ? normalizeHubUrl(cfg.hubUrl) : null, canalDestaExtensao: EXTENSION_SLUG, nomeNoManifest: MANIFEST_NAME, versao: VERSION, ultimoHandshake: st[HANDSHAKE_KEY] ?? null, filaOffline: ((st[OUTBOX_KEY] as unknown[] | undefined) ?? []).length, ultimaAnalise: st[ANALYSIS_KEY] ?? null, chamadas: st[LOG_KEY] ?? [], teste: servidor } }
    }
    case 'hub:status': {
      const cfg = await loadConfig()
      if (!cfg) return { ok: true, data: { configured: false } }
      const client = await hub()
      if (typeof client === 'string') return { ok: false, error: client }
      const me = await client.me()
      if (!me.ok) {
        if (me.status === 401) await dropKey()
        return reply(me)
      }
      if (!extensionMatches(me.data, EXTENSION_SLUG)) {
        await dropKey()
        return { ok: false, error: WRONG_EXTENSION_MESSAGE, code: 'wrong_extension' }
      }
      return { ok: true, data: { configured: true, hubUrl: normalizeHubUrl(cfg.hubUrl), workspace: me.data.workspace, scopes: me.data.scopes } }
    }
    default:
      break
  }

  const client = await hub()
  if (typeof client === 'string') return { ok: false, error: client, code: 'not_configured' }

  switch (msg.type) {
    case 'hub:clients':
      return replyAuthed(await client.clients())
    case 'hub:ensure-client':
      return replyAuthed(await client.ensureClient({ name: msg.name.slice(0, 160), ifood_merchant_id: msg.merchantId }))
    case 'hub:menu':
      return replyAuthed(await client.menu(msg.clientId))
    case 'hub:pending':
      return replyAuthed(await client.pending(msg.clientId))
    case 'hub:sync':
      return replyAuthed(await client.markSynced(msg.itemId, msg.etag, msg.ifoodId ?? null))
    case 'hub:createCombo':
      return replyAuthed(await client.createCombo(msg.body))
    case 'hub:analyze': {
      const r = await client.analyze(msg.body)
      await chrome.storage.local.set({ [ANALYSIS_KEY]: r.ok
        ? { at: new Date().toISOString(), rodada: msg.body.variant ?? null, ia: r.data.ai_status ?? null, concorrentes: r.data.competitors_status ?? null, nConcorrentes: r.data.competitors?.length ?? 0, nFontes: r.data.sources?.length ?? 0, nAjustes: r.data.updates?.length ?? 0, nCombos: r.data.combos?.length ?? 0, avisos: (r.data.notices ?? []).slice(0, 3) }
        : { at: new Date().toISOString(), rodada: msg.body.variant ?? null, erro: r.message, status: r.status } })
      return replyAuthed(r)
    }
    case 'hub:evidence': {
      // limites do servidor: ≤ 6 PNG, nome válido, ≤ 2,5 MB cada, corpo ≤ 4,5 MB (reduz antes de enviar)
      const fitted = await fitEvidence(msg.body.evidence, shrinkPng, JSON.stringify({ ...msg.body, evidence: [] }).length)
      const body: OptimizationUpload = { ...msg.body, evidence: fitted.list }
      const r = await client.saveOptimization(body)
      if (isRetriable(r)) {
        // sem rede / servidor ocupado: guarda e o alarme de 1 min reenvia sozinho
        await enqueue(outbox, body)
        return { ok: true, data: { id: '', evidence: fitted.list.length, queued: true, dropped: fitted.dropped } }
      }
      if (!r.ok) {
        if (r.status === 401) await dropKey()
        return replyAuthed(r)
      }
      return { ok: true, data: { ...r.data, queued: false, dropped: fitted.dropped } }
    }
    case 'hub:import': {
      // Conferência antes de aplicar: lê o ETag atual e envia com If-Match.
      const menu = await client.menu(msg.clientId)
      if (!menu.ok) return replyAuthed(menu)
      const etag = menu.etag ?? menu.data.etag
      return replyAuthed(await client.importSnapshot(etag, snapshotToImport(msg.snapshot, msg.clientId)))
    }
    default:
      return { ok: false, error: 'Mensagem desconhecida.' }
  }
}

chrome.runtime.onMessage.addListener((msg: Msg, sender, sendResponse) => {
  // Só aceita mensagens da própria extensão (content script no portal Anota AI ou páginas da extensão).
  if (sender.id !== chrome.runtime.id) return false
  const fromPortal = /^https:\/\/([a-z0-9-]+\.)*anota\.ai\//.test(sender.url ?? '')
  const fromExtension = sender.url?.startsWith(`chrome-extension://${chrome.runtime.id}/`)
  // Página do Undercut (ponte hub-bridge): só pode pedir 'hub:pair', e para a PRÓPRIA origem.
  const senderOrigin = sender.url ? normalizeHubUrl(sender.url) : null
  const bridgePatterns = (chrome.runtime.getManifest().content_scripts ?? [])
    .filter((cs) => cs.js?.includes('dist/hub-bridge.js'))
    .flatMap((cs) => cs.matches ?? [])
  const fromHub = Boolean(senderOrigin && (KNOWN_HUBS.includes(senderOrigin) || originMatchesPatterns(senderOrigin, bridgePatterns)))
  if (fromHub) {
    if (msg.type !== 'hub:pair' || normalizeHubUrl(msg.hubUrl) !== senderOrigin) return false
  } else if (!fromPortal && !fromExtension) return false
  handle(msg)
    .then(sendResponse)
    .catch(() => sendResponse({ ok: false, error: 'Erro inesperado na extensão.' }))
  return true
})

// Ao instalar NÃO abre nada: a conexão é feita quando o usuário quiser (painel → Conectar, ou ícone da extensão).

chrome.action?.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage()
})

// Sincronização contínua: a cada 1 min (a) avisa o servidor que está online e (b) reenvia a fila offline.
// O painel do Undercut considera a extensão "online" se o último contato tiver < 10 min.
chrome.alarms.create(ALARM, { periodInMinutes: 1 })
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== ALARM) return
  void (async () => {
    const cfg = await loadConfig()
    if (!cfg) return
    try {
      const client = newClient(cfg)
      const hs = await client.handshake(VERSION, MANIFEST_NAME)
      if (!hs.ok && hs.status === 401) return void (await dropKey())
      if (hs.ok) {
        handshakeDone = true
        lastHeartbeat = Date.now()
        await flushOutbox(client)
      }
    } catch {
      /* configuração inválida: nada a fazer */
    }
  })()
})
chrome.runtime.onStartup.addListener(() => {
  void (async () => {
    const cfg = await loadConfig()
    if (cfg) await newClient(cfg).handshake(VERSION, MANIFEST_NAME).catch(() => undefined)
  })()
})
