/**
 * MAIN world no painel do Anota AI — SOMENTE OBSERVA (modo gravador). Guarda, só na memória da aba:
 *  - as respostas JSON (GET) que o próprio painel carregou, para a extensão achar o cardápio sem fazer nenhuma chamada;
 *  - um registro de TODAS as chamadas (método, caminho, forma do pedido/resposta, sem valores), com amostras só das
 *    que parecem cardápio e das gravações (edições) que VOCÊ faz — para eu aprender como o painel salva.
 * Nada é enviado a ninguém; cabeçalhos de login/tokens NUNCA são guardados nem entram em relatório.
 */
;(() => {
  const w = window as unknown as { __orviaAaHook?: boolean }
  if (w.__orviaAaHook) return
  w.__orviaAaHook = true
  const MAX_TEXT = 3_000_000
  type Rec = { seq: number; ts: number; method: string; host: string; path: string; query: string; status: number; reqType: string; reqKeys: string; reqBody?: unknown; resShape: string; resSample?: unknown }
  const log: Rec[] = []
  /** cabeçalhos que o PRÓPRIO painel usou na última chamada à API do cardápio (login). Só na memória desta aba: nunca logados, nunca enviados. */
  let menuHeaders: Record<string, string> = {}
  let catListUrl: string | null = null
  const API_RE = /^https:\/\/api-menu\.anota\.ai\/auth\//
  const SKIP_H = /^(content-length|content-type|host|cookie|origin|referer|user-agent|accept-encoding|accept-language|connection|sec-.*)$/i
  const takeHeaders = (url: string, h: Record<string, string>) => {
    try { if (!API_RE.test(new URL(url, location.href).href)) return } catch { return }
    const next: Record<string, string> = {}
    for (const [k, v] of Object.entries(h)) if (!SKIP_H.test(k) && typeof v === 'string') next[k.toLowerCase()] = v
    if (Object.keys(next).length) menuHeaders = next
  }
  const hdrObj = (h: HeadersInit | undefined): Record<string, string> => {
    const out: Record<string, string> = {}
    if (!h) return out
    if (h instanceof Headers) h.forEach((v, k) => { out[k] = v })
    else if (Array.isArray(h)) for (const [k, v] of h) out[k] = v
    else Object.assign(out, h)
    return out
  }
  const reads: { path: string; ts: number; json: unknown }[] = []
  let seq = 0
  const post = (m: Record<string, unknown>) => window.postMessage({ source: 'orvia-hook', ...m }, window.location.origin)
  const tryJson = (t: unknown): unknown => { if (typeof t !== 'string' || !t || t.length > MAX_TEXT) return undefined; try { return JSON.parse(t) } catch { return undefined } }
  const shape = (v: unknown, d = 0): string => {
    if (v === null) return 'null'
    if (Array.isArray(v)) return d > 3 ? '[…]' : `[${v.length}×${v.length ? shape(v[0], d + 1) : ''}]`
    if (typeof v === 'object') return d > 3 ? '{…}' : `{${Object.entries(v as object).slice(0, 40).map(([k, x]) => `${k}:${shape(x, d + 1)}`).join(',')}}`
    return typeof v
  }
  const SENSITIVE = /token|senha|password|authorization|secret|cpf|cnpj|phone|telefone|email|endereco|address/i
  const trim = (v: unknown, d = 0): unknown => {
    if (Array.isArray(v)) return (v.every((x) => x === null || typeof x !== 'object') ? v.slice(0, 14) : v.slice(0, 2)).map((x) => trim(x, d + 1))
    if (v && typeof v === 'object') return d > 5 ? '{…}' : Object.fromEntries(Object.entries(v as object).slice(0, 50).map(([k, x]) => [k, SENSITIVE.test(k) ? '[oculto]' : trim(x, d + 1)]))
    return typeof v === 'string' && v.length > 120 ? v.slice(0, 120) + '…' : v
  }
  const STATIC = /\.(js|css|png|jpe?g|gif|svg|webp|woff2?|ico|map)(\?|$)/i
  const NOISE = /google-analytics|googletagmanager|facebook|hotjar|sentry|doubleclick|clarity\.ms|intercom|segment|mixpanel/i
  const MENUISH = /categor|item|produto|product|cardapio|menu|catalog|complement|adicion/i

  function report(method: string, rawUrl: string, status: number, reqBody: unknown, text: string | null) {
    let u: URL
    try { u = new URL(rawUrl, location.href) } catch { return }
    if (STATIC.test(u.pathname) || NOISE.test(u.host)) return
    const m = method.toUpperCase()
    const res = text ? tryJson(text) : undefined
    const isForm = typeof FormData !== 'undefined' && reqBody instanceof FormData
    const reqJson = typeof reqBody === 'string' ? tryJson(reqBody) : undefined
    const write = m !== 'GET' && m !== 'OPTIONS' && m !== 'HEAD'
    const menuish = MENUISH.test(u.pathname)
    const rec: Rec = {
      seq: (seq += 1), ts: Date.now(), method: m, host: u.host, path: u.pathname, query: [...u.searchParams.keys()].join('&'), status,
      reqType: isForm ? 'multipart' : reqJson !== undefined ? 'json' : reqBody == null ? '-' : 'outro',
      reqKeys: isForm ? [...(reqBody as FormData).keys()].join(',') : reqJson !== undefined ? shape(reqJson) : '',
      resShape: res === undefined ? (text ? `texto ${text.length}b` : '-') : shape(res),
    }
    if (write && reqJson !== undefined) rec.reqBody = trim(reqJson)
    if (write && isForm) {
      const o: Record<string, unknown> = {}
      for (const [k, v] of (reqBody as FormData).entries()) o[k] = typeof v === 'string' ? (v.length > 120 ? v.slice(0, 120) + '…' : v) : `[arquivo ${(v as File).type || ''} ${(v as File).size}b]`
      rec.reqBody = o
    }
    if ((write || menuish) && res !== undefined) rec.resSample = trim(res)
    if (m === 'GET' && /\/only-categories$/.test(u.pathname)) catListUrl = u.href
    log.unshift(rec)
    if (log.length > 150) log.length = 150
    if (m === 'GET' && res !== undefined && status >= 200 && status < 300 && typeof res === 'object') {
      reads.unshift({ path: u.host + u.pathname, ts: Date.now(), json: res })
      if (reads.length > 40) reads.length = 40
    }
    if (write && status >= 200 && status < 300 && !isForm) post({ kind: 'write', method: m, url: u.href, status, body: reqJson, json: res })
  }

  const of = window.fetch.bind(window)
  window.fetch = async function (input: RequestInfo | URL, init?: RequestInit) {
    try { takeHeaders(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url, { ...(input instanceof Request ? hdrObj(input.headers) : {}), ...hdrObj(init?.headers) }) } catch { /* */ }
    const res = await of(input, init)
    try {
      const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
      const method = init?.method ?? (input instanceof Request ? input.method : 'GET')
      res.clone().text().then((t) => report(method, url, res.status, init?.body, t)).catch(() => {})
    } catch { /* observar nunca pode quebrar o painel */ }
    return res
  }
  type X = XMLHttpRequest & { __o?: { m: string; u: string }; __h?: Record<string, string> }
  const setH = XMLHttpRequest.prototype.setRequestHeader
  XMLHttpRequest.prototype.setRequestHeader = function (this: X, k: string, v: string) { (this.__h ??= {})[k] = v; return setH.call(this, k, v) }
  const open = XMLHttpRequest.prototype.open
  const send = XMLHttpRequest.prototype.send
  XMLHttpRequest.prototype.open = function (this: X, ...a: any[]) { this.__o = { m: String(a[0]), u: String(a[1]) }; return (open as any).apply(this, a) } as typeof open
  XMLHttpRequest.prototype.send = function (this: X, body?: Document | XMLHttpRequestBodyInit | null) {
    if (this.__o && this.__h) takeHeaders(this.__o.u, this.__h)
    this.addEventListener('load', () => { try { if (this.__o) report(this.__o.m, this.__o.u, this.status, body, typeof this.responseText === 'string' ? this.responseText : null) } catch { /* */ } })
    return send.call(this, body)
  }

  window.addEventListener('message', (e: MessageEvent) => {
    const d = e.data as { source?: string; id?: string; action?: string } | null
    if (e.source !== window || !d || d.source !== 'orvia-exec' || !d.id) return
    const reply = (json: unknown) => window.postMessage({ source: 'orvia-exec-result', id: d.id, status: 200, json }, window.location.origin)
    if (d.action === 'dump') return reply({ log, hasAuth: Object.keys(menuHeaders).length > 0, hasCompany: false, headerNames: Object.keys(menuHeaders), reads: reads.length })
    if (d.action === 'authHeaders') return reply({ headers: menuHeaders })
    if (d.action === 'readUrls') return reply({ categories: catListUrl })
    if (d.action === 'request') {
      const q = d as unknown as { method?: string; url?: string; body?: unknown }
      const method = String(q.method ?? 'GET').toUpperCase()
      if (!q.url || !API_RE.test(q.url) || !['GET', 'POST', 'PUT', 'DELETE'].includes(method)) return window.postMessage({ source: 'orvia-exec-result', id: d.id, status: 0, json: { error: 'endereço não permitido' } }, window.location.origin)
      const mk = (credentials: RequestCredentials): RequestInit => ({ method, credentials, headers: { ...menuHeaders, ...(q.body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: q.body !== undefined ? JSON.stringify(q.body) : undefined })
      const parse = (t: string): unknown => { try { return JSON.parse(t) } catch { return t } }
      const viaFetch = async (credentials: RequestCredentials) => {
        const r = await of(q.url!, mk(credentials))
        return { status: r.status, json: parse(await r.text()) }
      }
      const viaXhr = () => new Promise<{ status: number; json: unknown }>((resolve, reject) => {
        const x = new XMLHttpRequest()
        x.open(method, q.url!)
        for (const [k, v] of Object.entries({ ...menuHeaders, ...(q.body !== undefined ? { 'content-type': 'application/json' } : {}) })) x.setRequestHeader(k, v)
        x.onload = () => resolve({ status: x.status, json: parse(x.responseText) })
        x.onerror = () => reject(new Error('XHR: rede/CORS recusou'))
        x.send(q.body !== undefined ? JSON.stringify(q.body) : null)
      })
      // 1) igual ao painel (sem cookies)  2) com cookies  3) XHR (o painel usa XHR em algumas chamadas). Guarda o motivo de cada falha.
      const errs: string[] = []
      const attempt = async () => {
        for (const [name, fn] of [['fetch', () => viaFetch('same-origin')], ['fetch+cookies', () => viaFetch('include')], ['xhr', viaXhr]] as const) {
          try { return await fn() } catch (e) { errs.push(`${name}: ${String(e).slice(0, 80)}`) }
        }
        return { status: 0, json: { error: `${errs.join(' | ')} [cabeçalhos: ${Object.keys(menuHeaders).join(',') || 'nenhum'}]` } }
      }
      attempt().then((out) => window.postMessage({ source: 'orvia-exec-result', id: d.id, status: out.status, json: out.json }, window.location.origin))
      return
    }
    if (d.action === 'payloads') return reply(reads.map((r) => ({ path: r.path, json: r.json })))
  })
})()
