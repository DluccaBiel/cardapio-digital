/**
 * Interpretador GRATUITO de pedidos em texto livre (português), 100% local — sem IA paga e sem servidor.
 * Transforma o que o gestor escreve ("criar combo família com refri", "baixar 5% nas pizzas",
 * "descrição do X-Burger", "pausar o Suco") em AÇÕES verificáveis (source 'voce') e diz o que
 * entendeu e o que NÃO entendeu. Nada é inventado: preços vêm de conta sobre o cardápio e textos
 * criativos são só rascunhos marcados para revisão.
 */
import type { AnalysisContext, MenuItem, MenuSnapshot } from './schema'
import { manualAction, reorderAction, type ProposalAction } from './proposal'

export interface Interpreted {
  actions: ProposalAction[]
  understood: string[]
  /** trechos que não viraram ação (mostrados ao usuário, nunca escondidos) */
  ignored: string[]
}

const strip = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const STOP = new Set(['de', 'da', 'do', 'das', 'dos', 'com', 'e', 'a', 'o', 'as', 'os', 'um', 'uma', 'para', 'pra', 'no', 'na', 'nos', 'nas', 'em', 'ao', 'por'])
const stem = (w: string) => (w.length > 3 && w.endsWith('s') ? w.slice(0, -1) : w)
const tokens = (s: string) => strip(s).replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter(Boolean)
const sig = (s: string) => tokens(s).filter((w) => !STOP.has(w) && w.length >= 3).map(stem)
const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const usable = (i: MenuItem) => i.price !== null && i.price > 0 && i.status === 'active'
const DRINK = /bebida|refri|suco|agua|cerveja|coca|guarana|fanta|sprite|drink|energetico|cha gelado|h2o/
const isDrink = (i: MenuItem) => DRINK.test(strip(`${i.name} ${i.categoryName ?? ''}`))
const round2 = (n: number) => Math.round(n * 100) / 100

/** ,90 mais próximo na direção pedida (sempre diferente do preço atual). */
function trigger90(before: number, raw: number, down: boolean): number {
  let v = Math.floor(raw) + 0.9
  if (down && v >= before) v = Math.floor(before) - 0.1
  if (!down && v <= before) v = Math.floor(before) + 1.9
  return v > 0 ? round2(v) : round2(Math.max(0.9, raw))
}

function itemsIn(t: Set<string>, snapshot: MenuSnapshot): MenuItem[] {
  const hits = snapshot.items
    .map((i) => ({ i, s: sig(i.name) }))
    .filter(({ s }) => s.length > 0 && (s.length > 1 || s[0]!.length >= 4) && s.every((w) => t.has(w)))
  // fica só o mais específico: tira quem tem tokens estritamente contidos em outro item citado
  return hits.filter(({ s }, k) => !hits.some(({ s: o }, m) => m !== k && o.length > s.length && s.every((w) => o.includes(w)))).map(({ i }) => i)
}

function categoriesIn(t: Set<string>, snapshot: MenuSnapshot) {
  const scored = snapshot.categories.map((c) => ({ c, n: sig(c.name).filter((w) => w.length >= 4 && t.has(w)).length })).filter((x) => x.n > 0)
  const best = Math.max(0, ...scored.map((x) => x.n))
  return scored.filter((x) => x.n === best).map((x) => x.c)
}

const quoted = (o: string) => o.match(/["“”'‘’«]([^"“”'‘’»]{2,80})["“”'‘’»]/)?.[1]?.trim() ?? null
const moneyIn = (t: string) => {
  const m = t.match(/r\$\s*(\d{1,4}(?:[.,]\d{1,2})?)|(?:por|para|a)\s+(\d{1,4}[.,]\d{2})\b/)
  const raw = m?.[1] ?? m?.[2]
  return raw ? Number(raw.replace(',', '.')) : null
}
const pctIn = (t: string) => {
  const m = t.match(/(\d{1,2}(?:[.,]\d+)?)\s*(?:%|por\s*cento)/)
  return m ? Number(m[1]!.replace(',', '.')) : null
}

export function interpretRequest(text: string, snapshot: MenuSnapshot, ctx: AnalysisContext): Interpreted {
  const out: Interpreted = { actions: [], understood: [], ignored: [] }
  const seen = new Set<string>()
  const push = (a: ProposalAction) => {
    if (seen.has(a.id)) return false
    seen.add(a.id)
    out.actions.push(a)
    return true
  }
  const clauses = text.split(/[.;\n!?]+/).map((c) => c.trim()).filter((c) => c.length >= 3)

  for (const o of clauses) {
    const t = strip(o)
    const tk = new Set(tokens(o).map(stem))
    const items = itemsIn(tk, snapshot)
    const cats = categoriesIn(tk, snapshot)
    const before = out.actions.length
    const ignBefore = out.ignored.length
    const note = (s: string) => out.understood.push(s)
    const everything = /\b(todos|todas|tudo|cardapio (inteiro|todo)|geral)\b/.test(t)
    const targets = (): MenuItem[] => {
      if (items.length) return items
      if (cats.length) return snapshot.items.filter((i) => cats.some((c) => c.itemIds.includes(i.id)))
      return everything ? snapshot.items : []
    }
    const scopeLabel = () => (items.length ? items.map((i) => `“${i.name}”`).join(', ') : cats.length ? `categoria ${cats.map((c) => `“${c.name}”`).join(', ')}` : 'todo o cardápio')

    // ---- 1) Combo / kit ---------------------------------------------------------------
    if (/\b(combo|kit|familia|promocao de)\b/.test(t) && !/(sem|nao quero|nenhum) combo/.test(t)) {
      const active = snapshot.items.filter(usable)
      const wantsDrink = /refri|bebida|suco|agua|cerveja|coca|guarana|drink/.test(t)
      const family = /familia/.test(t)
      let comps: { item: MenuItem; quantity: number }[] = items.filter(usable).slice(0, 4).map((item) => {
        const nm = sig(item.name)[0] ?? ''
        const q = t.match(new RegExp(`(\\d)\\s*(?:x\\s*)?(?:${nm})`))?.[1] ?? t.match(new RegExp(`(\\d)\\s*x\\s*[a-z ]{0,20}${nm}`))?.[1]
        return { item, quantity: q ? Math.min(6, Number(q)) : 1 }
      })
      const mains = active.filter((i) => !isDrink(i)).sort((a, b) => (b.price ?? 0) - (a.price ?? 0))
      const drinks = active.filter(isDrink).sort((a, b) => (a.price ?? 0) - (b.price ?? 0))
      if (comps.length === 0 && cats.length) {
        const inCat = active.filter((i) => cats.some((c) => c.itemIds.includes(i.id)))
        if (inCat[0]) comps.push({ item: inCat.sort((a, b) => (b.price ?? 0) - (a.price ?? 0))[0]!, quantity: 1 })
      }
      if (comps.length === 0 && mains[0]) comps.push({ item: mains[0], quantity: 1 })
      if (comps.length === 1 && family) comps[0]!.quantity = Math.max(comps[0]!.quantity, 2)
      const hasDrink = comps.some((c) => isDrink(c.item))
      if ((wantsDrink || comps.length < 2) && !hasDrink && drinks[0]) comps.push({ item: drinks[0], quantity: 1 })
      if (comps.length < 2 && mains[1]) comps.push({ item: mains.find((m) => m.id !== comps[0]!.item.id)!, quantity: 1 })
      comps = comps.filter((c, k) => comps.findIndex((d) => d.item.id === c.item.id) === k)
      if (comps.length >= 2) {
        const full = round2(comps.reduce((s, c) => s + (c.item.price as number) * c.quantity, 0))
        const pct = pctIn(t) ?? ctx.comboDiscountPercent ?? 10
        const explicit = moneyIn(t)
        const price = explicit && explicit < full ? explicit : round2(full * (1 - Math.min(50, Math.max(0, pct)) / 100))
        const quotedName = quoted(o)
        const name = quotedName ?? `Combo ${family ? 'Família ' : ''}${comps.map((c) => c.item.name).slice(0, 2).join(' + ')}`
        const ok = push({
          id: `combo:voce:${comps.map((c) => `${c.item.id}x${c.quantity}`).join('+')}`, kind: 'create_combo', itemId: null, itemName: name, before: null, after: price,
          reason: `Combo pedido por você: soma dos itens ${brl(full)}${explicit && explicit < full ? `, preço informado ${brl(price)}` : ` − ${pct}% = ${brl(price)}`}. No portal é criado duplicando um produto da categoria e nasce pausado.`,
          source: 'voce', risk: 'medio', executable: false,
          combo: { name, description: comps.map((c) => `${c.quantity > 1 ? `${c.quantity}× ` : ''}${c.item.name}`).join(' + '), price, fullPrice: full, components: comps.map((c) => ({ itemId: c.item.id, name: c.item.name, quantity: c.quantity })) },
        })
        if (ok) note(`Combo “${name}” por ${brl(price)} (itens: ${comps.map((c) => `${c.quantity > 1 ? `${c.quantity}× ` : ''}${c.item.name}`).join(' + ')}).`)
      } else out.ignored.push(`${o} — não achei itens suficientes no cardápio para montar o combo (cite os produtos pelo nome).`)
    }
    // ---- 2) Renomear -------------------------------------------------------------------
    else if (/(renome|mude o nome|mudar o nome|trocar o nome|troque o nome|novo nome|nome d[oa])/.test(t) && items.length === 1) {
      const val = quoted(o) ?? o.match(/\b(?:para|de)\s+(.{2,60})$/i)?.[1]?.trim()
      const r = val ? manualAction({ kind: 'update_name', itemId: items[0]!.id, value: val.replace(/^["“]|["”]$/g, '') }, snapshot) : null
      if (r?.ok && push(r.action)) note(`Novo nome de “${items[0]!.name}”: “${r.action.after}”.`)
      else out.ignored.push(`${o} — ${r && !r.ok ? r.reason : 'escreva o nome novo entre aspas (ex.: renomear X-Burger para "X-Burger Artesanal").'}`)
    }
    // ---- 3) Descrição -----------------------------------------------------------------
    else if (/(descri[cç]ao|descricoes|descreva|texto vendedor)/.test(t)) {
      const list = items.length ? items : cats.length || everything || /sem descri/.test(t) ? targets().filter((i) => !i.description.trim()) : []
      const custom = quoted(o)
      let n = 0
      for (const it of list.slice(0, 20)) {
        const text = custom && items.length === 1 ? custom : `${it.name}: preparado na hora, com ingredientes selecionados e muito capricho. Peça o seu!`
        const r = manualAction({ kind: 'update_description', itemId: it.id, value: text }, snapshot)
        if (r.ok) {
          if (!custom) { r.action.reason = 'Rascunho genérico: edite com os ingredientes reais antes de aprovar (a extensão não sabe o que vai no produto).'; r.action.risk = 'medio' }
          if (push(r.action)) n += 1
        }
      }
      if (n) note(custom && items.length === 1 ? `Descrição de “${items[0]!.name}” como você escreveu.` : `${n} descrição(ões) como RASCUNHO (revise antes de aprovar — sem IA não sei os ingredientes).`)
      else out.ignored.push(`${o} — cite o produto (ou "sem descrição" / uma categoria) e, se quiser o texto exato, escreva-o entre aspas.`)
    }
    // ---- 4) Preço ---------------------------------------------------------------------
    else if (/(preco|valor|reduz|baix|diminu|barat|aument|suba|subir|sobe|reajust|encarec|mais caro|mais barato)/.test(t)) {
      const down = /(reduz|baix|diminu|barat|menor|abaix|desconto)/.test(t) && !/(aument|suba|subir|sobe|reajust|encarec|mais caro)/.test(t)
      const up = /(aument|suba|subir|sobe|reajust|encarec|mais caro|maior)/.test(t)
      const exact = moneyIn(t)
      if (ctx.doNotTouchPrices) out.ignored.push(`${o} — você pediu para não mexer em preços nesta rodada.`)
      else if (exact !== null && items.length === 1 && !pctIn(t)) {
        const r = manualAction({ kind: 'update_price', itemId: items[0]!.id, value: String(exact) }, snapshot)
        if (r.ok && push(r.action)) note(`Preço de “${items[0]!.name}”: ${brl(exact)}.`)
        else out.ignored.push(`${o} — ${r.ok ? 'já está proposto' : r.reason}`)
      } else if (down || up) {
        const list = targets().filter((i) => i.price !== null && i.price > 0 && !ctx.doNotTouchItemIds.includes(i.id)).slice(0, 40)
        if (!list.length) out.ignored.push(`${o} — diga qual produto/categoria (ou "todos") para eu ${down ? 'baixar' : 'subir'} o preço.`)
        else {
          const pct = Math.min(30, Math.max(1, pctIn(t) ?? 5))
          let n = 0
          for (const it of list) {
            const raw = (it.price as number) * (1 + (down ? -pct : pct) / 100)
            const r = manualAction({ kind: 'update_price', itemId: it.id, value: String(trigger90(it.price as number, raw, down)) }, snapshot)
            if (r.ok) { r.action.reason = `${down ? 'Redução' : 'Aumento'} de cerca de ${pct}% pedido por você, arredondado para terminar em ,90.`; if (push(r.action)) n += 1 }
          }
          if (n) note(`Preço ${down ? '−' : '+'}${pct}% (terminando em ,90) em ${n} produto(s): ${scopeLabel()}.`)
        }
      }
    }
    // ---- 5) Pausar / ativar -----------------------------------------------------------
    else if (/(paus|desativ|tirar do ar|tira do ar|suspend|reativ|ativar|ative|colocar no ar|volt[ae] com)/.test(t)) {
      const pause = /(paus|desativ|tirar do ar|tira do ar|suspend)/.test(t)
      const list = targets().slice(0, 40)
      let n = 0
      for (const it of list) {
        const r = manualAction({ kind: 'set_status', itemId: it.id, value: pause ? 'paused' : 'active' }, snapshot)
        if (r.ok && r.action.before !== r.action.after && push(r.action)) n += 1
      }
      if (n) note(`${pause ? 'Pausar' : 'Ativar'} ${n} produto(s): ${scopeLabel()}.`)
      else out.ignored.push(`${o} — cite o produto ou a categoria (ou já está ${pause ? 'pausado' : 'ativo'}).`)
    }
    // ---- 6) Remover -------------------------------------------------------------------
    else if (/(remov|exclu|apag|delet|tirar do cardapio)/.test(t)) {
      let n = 0
      for (const it of items.slice(0, 10)) {
        const r = manualAction({ kind: 'remove_item', itemId: it.id, value: '' }, snapshot)
        if (r.ok && push(r.action)) n += 1
      }
      if (n) note(`Remover ${n} produto(s) — risco alto, só entra se você aprovar.`)
      else out.ignored.push(`${o} — cite o nome do produto a remover (por segurança não removo categorias inteiras).`)
    }
    // ---- 7) Produto novo ----------------------------------------------------------------
    else if (/\b(cri[ae]\w*|adicion\w*|inclu\w*|lanc\w*|nov[oa])\b.{0,20}\b(produto|item|prato|lanche|pizza|sabor|opcao|hamburguer|burger)\b/.test(t)) {
      const nm = quoted(o) ?? o.match(/(?:chamad[oa]|nome|de nome)\s+(.{2,50})$/i)?.[1]?.trim()
      const base = items[0] ?? (cats.length ? snapshot.items.find((i) => cats[0]!.itemIds.includes(i.id) && usable(i)) : undefined) ?? snapshot.items.find(usable)
      if (!nm || !base) out.ignored.push(`${o} — informe o nome entre aspas (ex.: criar produto "Smash Duplo") e, se puder, o produto/categoria de base.`)
      else {
        const r = manualAction({ kind: 'create_item', name: nm, description: '', price: moneyIn(t) !== null ? String(moneyIn(t)) : '', baseItemId: base.id }, snapshot)
        if (r.ok && push(r.action)) note(`Produto novo “${nm}” (duplicando “${base.name}”${moneyIn(t) !== null ? `, ${brl(moneyIn(t)!)}` : ''}).`)
        else out.ignored.push(`${o} — ${r.ok ? 'já está proposto' : r.reason}`)
      }
    }
    // ---- 8) Ordem das categorias --------------------------------------------------------
    else if (/(categoria|secao|ordem|organiz|ordenar|topo|primeiro)/.test(t)) {
      const top = /(topo|primeir|inicio|cima|destaque)/.test(t)
      const end = /(fim|ultim|final|baixo)/.test(t)
      const cat = cats[0]
      const r = cat && (top || end) ? reorderAction(snapshot, { categoryId: cat.id, position: top ? 1 : snapshot.categories.length }) : /(ordem|organiz|ordenar|boas praticas)/.test(t) ? reorderAction(snapshot, {}) : null
      if (r?.ok && push(r.action)) note(cat && (top || end) ? `Categoria “${cat.name}” ${top ? 'no topo' : 'no fim'} do cardápio.` : 'Reordenar categorias pelas boas práticas.')
      else out.ignored.push(`${o} — ${r && !r.ok ? r.reason : 'diga a categoria e "no topo" ou "no fim".'}`)
    }

    const adjustOnly = /\b(nao|sem|nenhum|nada de)\b.{0,25}\b(mexer|mude|mudar|alterar|altere|trocar|tocar|tirar|combo|preco)|\bdesconto\b|\b(mais|menos|poucos) combos?\b/.test(t)
    if (out.actions.length === before && out.ignored.length === ignBefore && !adjustOnly) out.ignored.push(`${o} — não entendi este pedido.`)
  }
  return out
}
