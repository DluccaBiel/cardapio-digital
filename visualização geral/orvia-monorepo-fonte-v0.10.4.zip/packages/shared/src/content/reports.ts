/** Controlador dos relatórios salvos (por cliente) — igual nas 3 extensões. */
import type { RunReport } from '../lib/runner'
import { clientKeyOf, deleteReport, listReports, reportsOf, saveReport, toJpeg, type KV, type SavedReport } from '../lib/report-store'
import { toReportStep, toSavedView, type KindIcons } from './step-view'
import { el, reportsSection } from './ui'

export interface SaveArgs {
  clientId: string | null | undefined
  clientName: string
  storeName: string | null
  platform: string
  report: RunReport
  version: number
  summary: string
  prints: { name: string; dataUrl: string }[]
}

function downloadDataUrl(name: string, url: string) {
  const a = document.createElement('a')
  a.href = url
  a.download = name
  a.rel = 'noopener'
  document.body.append(a)
  a.click()
  a.remove()
}

export function createReports(kv: KV, icons: KindIcons, render: () => void) {
  let list: SavedReport[] = []
  let scope: 'client' | 'all' = 'client'
  let loaded = false
  const load = async () => { list = await listReports(kv); loaded = true; render() }
  return {
    load,
    async save(a: SaveArgs): Promise<boolean> {
      try {
        const pages: SavedReport['pages'] = []
        for (const [i, p] of a.prints.entries()) {
          try { pages.push({ name: p.name.replace(/\.png$/i, '') + '.jpg', dataUrl: await toJpeg(p.dataUrl) }) } catch { /* sem a imagem, o resto fica salvo */ void i }
        }
        const rec: SavedReport = {
          id: `${a.report.planHash}:${a.report.startedAt}`,
          at: Date.parse(a.report.finishedAt) || Date.now(),
          clientKey: clientKeyOf(a.clientId, a.storeName ?? a.clientName),
          clientName: a.clientName, storeName: a.storeName ?? a.clientName, platform: a.platform, version: a.version, summary: a.summary,
          aborted: a.report.aborted, steps: a.report.steps.map((s) => toReportStep(s, icons)), pages,
        }
        list = await saveReport(kv, rec)
        loaded = true
        render()
        return true
      } catch { return false }
    },
    section(clientId: string | null | undefined, clientName: string, storeName: string | null): HTMLElement {
      if (!loaded) void load()
      const key = clientKeyOf(clientId, storeName ?? clientName)
      const shown = reportsOf(list, scope === 'client' ? key : null)
      return el('div', {},
        el('div', { class: 'chips' },
          el('button', { class: `chip${scope === 'client' ? ' on' : ''}`, type: 'button', onclick: () => { scope = 'client'; render() } }, 'Este cliente'),
          el('button', { class: `chip${scope === 'all' ? ' on' : ''}`, type: 'button', onclick: () => { scope = 'all'; render() } }, 'Todos os clientes')),
        reportsSection({
          reports: shown.map(toSavedView), scopeLabel: scope === 'client' ? clientName : 'todos os clientes', render,
          onDelete: (id) => { void deleteReport(kv, id).then((n) => { list = n; render() }) },
          onDownload: (id) => { const r = list.find((x) => x.id === id); r?.pages.forEach((p) => downloadDataUrl(p.name, p.dataUrl)) },
        }))
    },
  }
}
