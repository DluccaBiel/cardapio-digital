/**
 * Fontes da identidade (Anton · Archivo · JetBrains Mono), empacotadas na extensão.
 * @font-face não funciona dentro do Shadow DOM, então entra uma vez no <head> da página.
 */
const FACES: [string, number, string][] = [
  ['Anton', 400, 'anton-latin-400-normal'],
  ['Archivo', 400, 'archivo-latin-400-normal'], ['Archivo', 600, 'archivo-latin-600-normal'], ['Archivo', 700, 'archivo-latin-700-normal'],
  ['JetBrains Mono', 400, 'jetbrains-mono-latin-400-normal'], ['JetBrains Mono', 500, 'jetbrains-mono-latin-500-normal'], ['JetBrains Mono', 700, 'jetbrains-mono-latin-700-normal'],
]

export function loadBrandFonts(getUrl: (path: string) => string): void {
  try {
    if (document.getElementById('orvia-brand-fonts')) return
    const css = FACES.map(([family, weight, file]) => `@font-face{font-family:"${family}";font-weight:${weight};font-style:normal;font-display:swap;src:url("${getUrl(`assets/fonts/${file}.woff2`)}") format("woff2")}`).join('\n')
    const st = document.createElement('style')
    st.id = 'orvia-brand-fonts'
    st.textContent = css
    ;(document.head ?? document.documentElement).append(st)
  } catch { /* sem fontes: o painel usa as de reserva (Impact/Arial) */ }
}

/** garante as fontes carregadas antes de desenhar o relatório em canvas */
export async function preloadBrandFonts(): Promise<void> {
  try {
    await Promise.all(['400 40px Anton', '400 24px Archivo', '600 24px Archivo', '700 24px Archivo', '500 20px "JetBrains Mono"'].map((f) => document.fonts.load(f)))
  } catch { /* usa as fontes de reserva */ }
}
