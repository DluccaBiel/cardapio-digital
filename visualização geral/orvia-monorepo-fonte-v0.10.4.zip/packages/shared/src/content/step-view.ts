/** Converte passos executados (Step) em dados de cartão e de relatório salvo — comum às 3 extensões. */
import { KIND_LABEL, fmtValue, type ProposalAction } from '../core/proposal'
import { STATUS_LABEL } from '../lib/prints'
import type { Step } from '../lib/runner'
import type { SavedReport } from '../lib/report-store'
import { countSteps } from '../lib/report-store'
import type { SavedReportView, StepCardData } from './ui'

export type KindIcons = Record<ProposalAction['kind'], string>

const short = (s: string, n = 70) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

/** "1. Pizzas  ·  2. Bebidas" → { 'Pizzas': 1 } */
function positions(label: string | null | undefined): Map<string, number> {
  const m = new Map<string, number>()
  for (const part of String(label ?? '').split(/\s+·\s+/)) {
    const r = part.match(/^(\d+)\.\s*(.+)$/)
    if (r) m.set(r[2]!.trim(), Number(r[1]))
  }
  return m
}

export interface StepView { icon: string; title: string; status: Step['status']; statusLabel: string; brief: string; before: string; after: string; message: string; lines?: string[] }

export function stepView(s: Step, icons: KindIcons): StepView {
  const a = s.action
  const base = { icon: icons[a.kind] ?? '•', status: s.status, statusLabel: STATUS_LABEL[s.status], message: s.message }
  if (a.kind === 'reorder_categories' && a.order?.length) {
    const was = positions(a.before as string | null)
    const moved = a.order.map((c, i) => ({ name: c.name, from: was.get(c.name.trim()), to: i + 1 })).filter((x) => x.from !== undefined && x.from !== x.to)
    const lines = a.order.map((c, i) => { const f = was.get(c.name.trim()); return `${i + 1}. ${c.name}${f !== undefined && f !== i + 1 ? `  (era ${f}º)` : ''}` })
    return { ...base, title: 'Ordem das categorias', brief: moved.length ? `${a.order.length} categorias · ${moved.length} mudaram de posição` : `${a.order.length} categorias · sem mudança`, before: '', after: '', lines }
  }
  if (a.kind === 'create_combo') return { ...base, title: `Combo: ${a.itemName}`, brief: short(String(a.after ?? '')), before: '', after: String(a.after ?? '') }
  if (a.kind === 'add_complement' && a.complement) return { ...base, title: `${KIND_LABEL[a.kind]} · ${a.itemName}`, brief: `${a.complement.groupName} · ${a.complement.options.length} opç${a.complement.options.length === 1 ? 'ão' : 'ões'}`, before: '', after: '', lines: a.complement.options.map((o) => `${o.name}${o.price ? ` +R$ ${o.price.toFixed(2).replace('.', ',')}` : ''}`) }
  const before = fmtValue(a.kind, a.before)
  const after = fmtValue(a.kind, a.after)
  return { ...base, title: `${KIND_LABEL[a.kind]} · ${a.itemName}`, brief: `${short(before, 28)} → ${short(after, 34)}`, before, after }
}

export const stepCardData = (steps: Step[], icons: KindIcons, idPrefix = 'live'): StepCardData[] =>
  steps.map((s, i) => { const v = stepView(s, icons); return { id: `${idPrefix}:${s.action.id}:${i}`, icon: v.icon, title: v.title, status: v.status, statusLabel: v.statusLabel, brief: s.status === 'erro' || s.status === 'pulada' ? short(s.message, 90) : v.brief, before: v.lines ? undefined : v.before, after: v.lines ? undefined : v.after, lines: v.lines, message: v.message } })

/** guarda o passo já formatado para o relatório salvo continuar legível mesmo depois */
export const toReportStep = (s: Step, icons: KindIcons): SavedReport['steps'][number] => {
  const v = stepView(s, icons)
  return { kind: s.action.kind, itemName: s.action.itemName, before: v.before, after: v.after, status: s.status, message: s.message, icon: v.icon, title: v.title, statusLabel: v.statusLabel, brief: v.brief, lines: v.lines }
}

export const toSavedView = (r: SavedReport): SavedReportView => ({
  id: r.id, at: r.at, clientName: r.clientName,
  title: `${r.platform} · ${r.storeName || r.clientName} · v${r.version}${r.aborted ? ' · interrompido' : ''}`,
  counts: countSteps(r.steps),
  steps: r.steps.map((s) => ({ icon: s.icon ?? '•', title: s.title ?? `${s.kind} · ${s.itemName}`, status: s.status, statusLabel: s.statusLabel ?? s.status.toUpperCase(), before: s.before, after: s.after, message: s.message, brief: s.brief, lines: s.lines })),
  pages: r.pages.map((p) => p.dataUrl),
})
