/** Luz que acompanha o cursor nos botões: grava a posição do ponteiro em --mx/--my (o CSS desenha o brilho). */
export function enableGlow(root: ShadowRoot | Document): void {
  const SEL = 'button, .btn, .chip, .tab, .syncbtn, .icon, .schead, .rephead, label.act, .act'
  root.addEventListener('pointermove', (ev) => {
    const e = ev as PointerEvent
    const t = (e.target as Element | null)?.closest?.(SEL) as HTMLElement | null
    if (!t) return
    const r = t.getBoundingClientRect()
    t.style.setProperty('--mx', `${Math.round(e.clientX - r.left)}px`)
    t.style.setProperty('--my', `${Math.round(e.clientY - r.top)}px`)
  }, { passive: true })
  // toque/clique: pulso de luz
  root.addEventListener('pointerdown', (e) => {
    const t = (e.target as Element | null)?.closest?.(SEL) as HTMLElement | null
    if (!t) return
    t.classList.remove('pulse')
    void t.offsetWidth
    t.classList.add('pulse')
    setTimeout(() => t.classList.remove('pulse'), 650)
  }, { passive: true })
}
