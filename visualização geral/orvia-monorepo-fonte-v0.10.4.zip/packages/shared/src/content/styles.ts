/** CSS do painel (isolado no Shadow DOM — não vaza para o portal e vice-versa). Tokens Undercut. Tema final: identidade Undercut (preto/vermelho). */
export const CSS = `
:host, * { box-sizing: border-box; }
.fab { position: fixed; right: 20px; bottom: 20px; z-index: 2147483646; width: 52px; height: 52px; border-radius: 50%;
  border: 0; background: #3D8EFF; color: #fff; font: 800 22px/1 Inter, system-ui, sans-serif; cursor: pointer;
  box-shadow: 0 8px 24px rgba(61,142,255,.45); }
.fab:hover { background: #2F6BFF; }
.fab:focus-visible { outline: 3px solid #6EA8FF; outline-offset: 3px; }
.fab .dot { position: absolute; top: 4px; right: 4px; width: 10px; height: 10px; border-radius: 50%; background: #34D399; border: 2px solid #0B1220; }
.panel { position: fixed; top: 0; right: 0; bottom: 0; width: min(420px, 100vw); z-index: 2147483647; display: flex; flex-direction: column;
  background: #0B1220; color: #E6ECFA; border-left: 1px solid #1C2A47; box-shadow: -12px 0 40px rgba(0,0,0,.55);
  font: 13px/1.45 Inter, system-ui, -apple-system, "Segoe UI", sans-serif; }
header { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid #1A2231; }
header .sub { display: block; font-size: 11px; color: #8FA0C4; }
.icon { background: none; border: 0; color: #8FA0C4; font-size: 18px; cursor: pointer; padding: 4px 8px; border-radius: 6px; }
.icon:hover { background: rgba(255,255,255,.06); color: #fff; }
nav { display: flex; gap: 4px; padding: 8px 12px 0; border-bottom: 1px solid #1A2231; }
.tab { flex: 1; background: none; border: 0; border-bottom: 2px solid transparent; color: #8FA0C4; padding: 8px 4px; font-weight: 600; cursor: pointer; font-size: 13px; }
.tab.active { color: #fff; border-color: #3D8EFF; }
.body { flex: 1; overflow-y: auto; padding: 14px 16px 24px; }
h3 { font-size: 12px; text-transform: uppercase; letter-spacing: .1em; color: #8FA0C4; margin: 18px 0 8px; }
p { margin: 4px 0; }
.card { border: 1px solid #1E2738; background: #0D1320; border-radius: 12px; padding: 12px; margin: 10px 0; }
.card.ok { border-color: rgba(52,211,153,.35); }
.card.sev-alto { border-left: 3px solid #F87171; } .card.sev-medio { border-left: 3px solid #FBBF24; } .card.sev-baixo { border-left: 3px solid #3D8EFF; }
.row { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; }
.muted { color: #8FA0C4; font-size: 12px; } .hint { color: #7C8AA1; font-size: 11px; margin-top: 6px; }
.warn { color: #FBBF24; font-size: 12px; } .mono { font-family: ui-monospace, Consolas, monospace; }
.pill { white-space: nowrap; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 999px; border: 1px solid #26314A; color: #B4BFD0; }
.pill.create { color: #C4B5FD; border-color: rgba(167,139,250,.4); } .pill.update { color: #FBBF24; border-color: rgba(251,191,36,.45); }
.field { display: block; margin: 8px 0; } .label { display: block; font-size: 10px; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: #8FA0C4; margin-bottom: 4px; }
.input { width: 100%; height: 36px; border-radius: 8px; border: 1px solid #26314A; background: #080D18; color: #E8EDF7; padding: 0 10px; font: inherit; margin: 6px 0; }
.input:focus { outline: none; border-color: #3D8EFF; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.btn { width: 100%; height: 36px; border-radius: 8px; border: 1px solid #26314A; background: #0D1320; color: #D5DDEA; font: 600 13px Inter, system-ui, sans-serif; cursor: pointer; margin-top: 8px; }
.btn:hover:not(:disabled) { border-color: #3D8EFF; color: #fff; }
.btn.primary { background: #3D8EFF; border-color: #3D8EFF; color: #fff; } .btn.primary:hover:not(:disabled) { background: #2F6BFF; }
.btn:disabled { opacity: .45; cursor: not-allowed; }
.link { background: none; border: 0; color: #6EA8FF; cursor: pointer; font-size: 11px; padding: 0; }
.notice { margin: 10px 16px 0; padding: 8px 10px; border-radius: 8px; font-size: 12px; }
.notice.ok { background: rgba(52,211,153,.1); color: #6EE7B7; } .notice.erro { background: rgba(248,113,113,.12); color: #FCA5A5; } .notice.info { background: rgba(61,142,255,.12); color: #CFE0FF; }
table.diff { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 12px; }
table.diff th { text-align: left; color: #8FA0C4; font-weight: 600; padding: 4px 6px 4px 0; vertical-align: top; width: 70px; }
table.diff td { padding: 4px 6px; vertical-align: top; } td.before { color: #7C8AA1; text-decoration: line-through; } td.after { color: #fff; }
.combo { margin-top: 8px; padding: 8px; border-radius: 8px; background: #080D18; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 8px 0; }
.pill.ok { color: #6EE7B7; border-color: rgba(52,211,153,.4); }
.okText { color: #6EE7B7; font-size: 12px; }
.check { display: flex; gap: 6px; align-items: center; margin-top: 10px; font-size: 12px; color: #B4BFD0; cursor: pointer; }
.log { margin-top: 8px; max-height: 180px; overflow-y: auto; border-top: 1px solid #1A2231; padding-top: 6px; }
.listbar { align-items: center; margin: 4px 0 6px; }
.plist { max-height: 46vh; overflow-y: auto; border: 1px solid #1E2738; border-radius: 10px; background: #080D18; }
.pcat { display: flex; gap: 8px; align-items: center; padding: 8px 10px; background: #0D1320; border-bottom: 1px solid #1A2231; position: sticky; top: 0; cursor: pointer; }
.prow { display: grid; grid-template-columns: 18px 1fr auto auto; gap: 8px; align-items: center; padding: 7px 10px; border-bottom: 1px solid #111827; cursor: pointer; font-size: 12px; }
.prow.on { background: rgba(61,142,255,.07); }
.pname { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #E6ECFA; }
.pprice { font-family: ui-monospace, Consolas, monospace; color: #B4BFD0; }
.tag { margin-left: 6px; font-size: 10px; padding: 1px 6px; border-radius: 999px; border: 1px solid #26314A; color: #8FA0C4; white-space: nowrap; }
.tag.ok { color: #6EE7B7; border-color: rgba(52,211,153,.4); }
.tag.new { color: #C4B5FD; border-color: rgba(167,139,250,.4); }
input[type=checkbox] { accent-color: #3D8EFF; }

.card.hero { text-align: left; }
.btn.big { height: 44px; font-size: 14px; }
.steps { margin: 8px 0; }
.st { font-size: 12px; margin: 3px 0; color: #B4BFD0; } .st.ok { color: #6EE7B7; } .st.warn { color: #FBBF24; } .st.erro { color: #FCA5A5; }
.esc { font-size: 10px; color: #8FA0C4; border: 1px solid #26314A; border-radius: 6px; padding: 2px 6px; margin-right: 6px; }
.catname { font-size: 12px; margin: 14px 0 6px; color: #D5DDEA; }
.pgrid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.pcard { border: 1px solid #1E2738; border-radius: 12px; background: #0D1320; overflow: hidden; display: flex; flex-direction: column; }
.pcard.off { opacity: .6; }
.pimg { width: 100%; aspect-ratio: 1 / 1; object-fit: cover; display: block; background: #080D18; }
.pimg.ph { display: flex; align-items: center; justify-content: center; font: 800 34px Inter, system-ui, sans-serif; color: #3D8EFF; background: linear-gradient(135deg, #0F1B33, #0B1220); }
.pbody { padding: 8px 10px 10px; display: flex; flex-direction: column; gap: 4px; }
.pn { font-size: 12px; font-weight: 600; color: #E6ECFA; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; min-height: 2.8em; }
.pp { font: 12px ui-monospace, Consolas, monospace; color: #B4BFD0; }
.act { display: grid; grid-template-columns: 20px 1fr; gap: 10px; border: 1px solid #1E2738; background: #0D1320; border-radius: 12px; padding: 11px 10px; margin: 8px 0; }
.act.on { border-color: rgba(61,142,255,.55); background: rgba(61,142,255,.06); }
.act .before { color: #7C8AA1; text-decoration: line-through; }
.pill.hi { color: #FCA5A5; border-color: rgba(248,113,113,.45); }
.warn-card { border-color: rgba(251,191,36,.4); }
.ta { height: auto; padding: 10px; resize: vertical; }
.steplist { margin: 8px 0; }
.step { border: 1px solid #1E2738; border-left: 3px solid #26314A; border-radius: 10px; background: #0D1320; padding: 8px 10px; margin: 6px 0; }
.step.ok { border-left-color: #34D399; } .step.erro { border-left-color: #F87171; } .step.assistida { border-left-color: #3D8EFF; } .step.executando { border-left-color: #FBBF24; } .step.pulada { border-left-color: #6B7280; }
.badge { font-size: 10px; font-weight: 800; letter-spacing: .06em; padding: 2px 8px; border-radius: 999px; background: #1A2231; color: #B4BFD0; white-space: nowrap; }
.badge.ok { background: rgba(52,211,153,.16); color: #6EE7B7; } .badge.erro { background: rgba(248,113,113,.16); color: #FCA5A5; }
.badge.assistida { background: rgba(61,142,255,.16); color: #9CC3FF; } .badge.executando { background: rgba(251,191,36,.16); color: #FCD34D; }
.bigtitle { font-size: 16px; }
.print { margin: 10px 0; } .print img { width: 100%; border-radius: 10px; border: 1px solid #1E2738; display: block; }
.diag { border-bottom: 1px solid #111827; padding: 5px 0; } .diag.on .mono:first-child { color: #6EE7B7; }
.diag .hint { word-break: break-all; }
.chk { border-top: 1px solid #111827; padding: 6px 0; } .chk p { margin: 0; } .chk b { font-size: 12px; }
.chk.ok b { color: #6EE7B7; } .chk.atencao b { color: #FBBF24; } .chk.falha b { color: #F87171; }
.catchips { display: flex; flex-wrap: wrap; gap: 6px; margin: 10px 0 4px; }
.grouphead { margin: 16px 0 4px; padding-bottom: 4px; border-bottom: 2px solid var(--line, #E3E8F2); }
.grouphead h3 { margin: 0; }
.prodgroup { margin: 8px 0 0; padding: 4px 8px; border-radius: 8px; background: rgba(61,142,255,.08); font-size: 13px; }
.chip { font: inherit; font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 999px; border: 1px solid #26314A; background: transparent; color: #B4BFD0; cursor: pointer; }
.chip.on { background: #2F6BFF; border-color: #2F6BFF; color: #fff; }
.cathead { display: flex; align-items: center; gap: 8px; width: 100%; margin: 14px 0 6px; padding: 8px 10px; border: 1px solid #1B2540; border-radius: 10px; background: #0F172A; color: #E6ECF7; font: inherit; font-size: 12px; cursor: pointer; text-align: left; }
.cathead b { flex: 1; } .cathead .muted { font-size: 11px; }

.summary { background: linear-gradient(135deg, #0F1B33, #0D1320); border-color: #1C2A47; }
.actbody { min-width: 0; } .act > input[type=checkbox] { align-self: start; margin-top: 3px; width: 16px; height: 16px; }
.acttitle { display: flex; align-items: center; gap: 8px; min-width: 0; } .acttitle b { overflow: hidden; text-overflow: ellipsis; }
.kico { flex: none; width: 22px; height: 22px; border-radius: 7px; display: inline-flex; align-items: center; justify-content: center; font: 700 12px ui-monospace, Consolas, monospace; background: #15213B; color: #9CC3FF; }
.kico.k-update_price { background: rgba(251,191,36,.14); color: #FCD34D; } .kico.k-set_status { background: rgba(167,139,250,.16); color: #C4B5FD; }
.kico.k-create_combo, .kico.k-create_item { background: rgba(52,211,153,.14); color: #6EE7B7; } .kico.k-remove_item { background: rgba(248,113,113,.14); color: #FCA5A5; }
.kindname { font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: #7C8AA1; margin: 2px 0 6px 30px; }
.diff2 { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin: 4px 0; }
.diff2 .was { color: #8FA0C4; text-decoration: line-through; background: #111A2C; padding: 2px 8px; border-radius: 6px; max-width: 100%; overflow-wrap: anywhere; }
.diff2 .arrow { color: #5B6B88; } .diff2 .now { color: #fff; font-weight: 700; background: rgba(61,142,255,.16); padding: 2px 8px; border-radius: 6px; max-width: 100%; overflow-wrap: anywhere; }
.act.risky { border-left: 3px solid #FBBF24; }
.actbtns { display: flex; gap: 14px; margin-top: 8px; }
.bulk { margin: 0 0 4px; }
.ordlist { margin: 4px 0 0 18px; padding: 0; display: grid; gap: 2px; font-size: 12.5px; }
.slot { border: 1px solid rgba(255,255,255,.12); border-radius: 10px; padding: 8px; margin: 6px 0; display: grid; gap: 6px; }
.addcard { border-color: rgba(61,142,255,.45); background: rgba(61,142,255,.05); }
.add-open { border-style: dashed; color: #9CC3FF; }
.sticky { position: sticky; bottom: -24px; margin: 14px -16px -24px; padding: 10px 16px 18px; background: linear-gradient(180deg, rgba(11,18,32,0), #0B1220 30%); z-index: 3; }
.sticky .btn { height: 42px; margin-top: 0; font-size: 14px; }

.conn { display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 700; margin-top: 2px; padding: 1px 8px 1px 6px; border-radius: 999px; border: 1px solid #26314A; }
.conn i { width: 7px; height: 7px; border-radius: 50%; background: #6B7280; display: inline-block; }
.conn.on { color: #6EE7B7; border-color: rgba(52,211,153,.45); background: rgba(52,211,153,.08); } .conn.on i { background: #34D399; box-shadow: 0 0 6px #34D399; }
.conn.off { color: #FCA5A5; border-color: rgba(248,113,113,.4); background: rgba(248,113,113,.07); } .conn.off i { background: #F87171; }
.conn.wait { color: #FCD34D; border-color: rgba(251,191,36,.4); } .conn.wait i { background: #FBBF24; }

/* ───────────── Tema "Undercut Neon" (v2): azul-violeta profundo, ciano→azul, rosa→violeta, tudo arredondado ───────────── */
.panel { --bg1: #070B24; --bg2: #14104A; --cy: #22D3EE; --bl: #3D8EFF; --pk: #FF5D8F; --vi: #8B5CF6; --glass: rgba(255,255,255,.045); --line2: rgba(120,150,255,.22);
  background: radial-gradient(120% 60% at 100% 0%, rgba(139,92,246,.28), transparent 55%), radial-gradient(90% 50% at 0% 100%, rgba(34,211,238,.12), transparent 60%), linear-gradient(180deg, var(--bg2), var(--bg1) 55%);
  border-left: 1px solid var(--line2); border-radius: 22px 0 0 22px; box-shadow: -18px 0 60px rgba(8,6,40,.7), inset 1px 0 0 rgba(255,255,255,.05); }
header { padding: 14px 14px 12px; border-bottom: 1px solid var(--line2); background: linear-gradient(180deg, rgba(255,255,255,.04), transparent); border-radius: 22px 0 0 0; }
header > div:last-child { display: flex; align-items: center; gap: 6px; }
.brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
.orb { flex: none; width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center; font: 800 18px Inter, system-ui, sans-serif; color: #fff;
  background: radial-gradient(circle at 30% 25%, #7DE9FF, var(--bl) 55%, var(--vi)); box-shadow: 0 0 0 2px rgba(255,255,255,.08), 0 6px 22px rgba(61,142,255,.55); }
.brandtxt { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.brandtxt b { font-size: 15px; letter-spacing: .02em; line-height: 1; }
.brandtxt .plat { font-size: 11px; color: #9DB0DA; letter-spacing: .04em; }
.icon { width: 34px; height: 34px; padding: 0; border-radius: 50%; display: inline-grid; place-items: center; font-size: 16px; line-height: 1; color: #B7C6EA; background: var(--glass); border: 1px solid var(--line2); transition: .15s; }
.icon:hover:not(:disabled) { background: rgba(61,142,255,.2); border-color: var(--bl); color: #fff; box-shadow: 0 0 14px rgba(61,142,255,.45); transform: translateY(-1px); }
.icon:disabled { opacity: .5; cursor: progress; }
.icon.spin:disabled { animation: spin 1s linear infinite; }
.esc { border-radius: 999px; padding: 3px 9px; border-color: var(--line2); }
nav { display: flex; gap: 4px; margin: 10px 12px 0; padding: 4px; border: 1px solid var(--line2); border-radius: 999px; background: rgba(5,8,28,.55); }
.tab { border: 0; border-radius: 999px; padding: 8px 4px; transition: .18s; color: #9DB0DA; }
.tab:hover { color: #fff; }
.tab.active { color: #fff; border: 0; background: linear-gradient(135deg, var(--bl), var(--vi)); box-shadow: 0 4px 16px rgba(99,102,241,.5); }
.body { padding: 14px 14px 26px; scrollbar-width: thin; scrollbar-color: #2B3A7A transparent; }
h3 { color: #9DB0DA; }
.card { border: 1px solid var(--line2); background: var(--glass); border-radius: 18px; backdrop-filter: blur(6px); box-shadow: 0 8px 28px rgba(3,4,22,.35); }
.card.hero { background: linear-gradient(140deg, rgba(61,142,255,.16), rgba(139,92,246,.14) 60%, rgba(255,93,143,.08)); border-color: rgba(125,160,255,.35); position: relative; overflow: hidden; }
.card.hero::after { content: ""; position: absolute; right: -40px; top: -40px; width: 140px; height: 140px; border-radius: 50%; background: radial-gradient(circle, rgba(34,211,238,.28), transparent 70%); pointer-events: none; }
.card.summary { background: linear-gradient(135deg, rgba(61,142,255,.14), rgba(139,92,246,.12)); border-color: var(--line2); }
.input { height: 40px; border-radius: 999px; padding: 0 16px; border: 1px solid var(--line2); background: rgba(4,7,26,.7); transition: .15s; }
select.input { padding-right: 12px; }
textarea.input, .ta { border-radius: 16px; padding: 12px 14px; }
.input:focus { border-color: var(--cy); box-shadow: 0 0 0 3px rgba(34,211,238,.18); }
.btn { height: 40px; border-radius: 999px; border: 1px solid var(--line2); background: var(--glass); color: #DDE6FA; transition: .16s; }
.btn:hover:not(:disabled) { border-color: var(--cy); color: #fff; box-shadow: 0 0 16px rgba(34,211,238,.25); transform: translateY(-1px); }
.btn.primary { border: 0; background: linear-gradient(135deg, #1FC6E8, var(--bl) 55%, var(--vi)); box-shadow: 0 6px 20px rgba(61,142,255,.45); }
.btn.primary:hover:not(:disabled) { background: linear-gradient(135deg, #3FD9F5, #5B9DFF 55%, #9B73FF); box-shadow: 0 8px 26px rgba(61,142,255,.6); }
.btn.big { height: 48px; font-size: 14px; letter-spacing: .02em; }
.btn:active:not(:disabled) { transform: scale(.98); }
.chip, .pill, .tag, .badge { border-radius: 999px; }
.chip { padding: 5px 12px; border-color: var(--line2); background: var(--glass); transition: .15s; }
.chip:hover { border-color: var(--cy); color: #fff; }
.chip.on { background: linear-gradient(135deg, var(--bl), var(--vi)); border-color: transparent; box-shadow: 0 3px 12px rgba(99,102,241,.45); }
.pcard, .act, .step, .plist, .slot { border-color: var(--line2); border-radius: 16px; background: var(--glass); }
.pcard { transition: .18s; } .pcard:hover { transform: translateY(-2px); border-color: rgba(125,160,255,.5); box-shadow: 0 10px 26px rgba(8,6,40,.5); }
.pimg { border-radius: 0; }
.pimg.ph { color: var(--cy); background: linear-gradient(135deg, rgba(61,142,255,.25), rgba(139,92,246,.2)); }
.act.on { border-color: rgba(34,211,238,.6); background: rgba(34,211,238,.06); }
.cathead, .pcat { border-color: var(--line2); border-radius: 14px; background: rgba(255,255,255,.05); }
.kico { border-radius: 50%; width: 26px; height: 26px; }
.notice { border-radius: 14px; }
.addcard { border-color: rgba(34,211,238,.4); background: rgba(34,211,238,.05); }
.sticky { background: linear-gradient(180deg, rgba(7,11,36,0), #090C2C 35%); }
.conn { gap: 7px; padding: 2px 10px 2px 8px; border-radius: 999px; background: rgba(255,255,255,.04); }
.conn.on { color: #6EE7B7; border-color: rgba(52,211,153,.5); background: rgba(52,211,153,.1); }
.conn.wait { color: #FCD34D; border-color: rgba(251,191,36,.45); background: rgba(251,191,36,.08); }
.conn.off { color: #FDA4AF; border-color: rgba(248,113,113,.45); background: rgba(248,113,113,.08); }
/* sinal de conexão */
.sig { display: inline-flex; align-items: flex-end; gap: 2px; height: 12px; }
.conn .sig i, .sig i { display: block; width: 3px; border-radius: 2px; background: currentColor; opacity: .25; box-shadow: none; }
.sig i:nth-child(1) { height: 4px } .sig i:nth-child(2) { height: 7px } .sig i:nth-child(3) { height: 10px } .sig i:nth-child(4) { height: 12px }
.sig.on { color: #34D399; } .sig.on i { opacity: 1; filter: drop-shadow(0 0 3px #34D399); }
.sig.on i:nth-child(4) { animation: sigpulse 2.2s ease-in-out infinite; }
.sig.wait { color: #FBBF24; } .sig.wait i { animation: sigwave 1s ease-in-out infinite; }
.sig.wait i:nth-child(2) { animation-delay: .12s } .sig.wait i:nth-child(3) { animation-delay: .24s } .sig.wait i:nth-child(4) { animation-delay: .36s }
.sig.off { color: #F87171; } .sig.off i:nth-child(1) { opacity: .9 }
@keyframes sigwave { 0%, 100% { opacity: .2 } 50% { opacity: 1 } }
@keyframes sigpulse { 0%, 100% { opacity: 1 } 50% { opacity: .35 } }
@keyframes spin { to { transform: rotate(360deg) } }
/* botão flutuante */
.fab { width: 58px; height: 58px; border: 0; background: radial-gradient(circle at 30% 25%, #7DE9FF, var(--bl, #3D8EFF) 55%, #8B5CF6); box-shadow: 0 10px 30px rgba(61,142,255,.55), 0 0 0 1px rgba(255,255,255,.12) inset; transition: transform .18s; }
.fab:hover { transform: scale(1.06); background: radial-gradient(circle at 30% 25%, #9DF0FF, #4E9BFF 55%, #9B73FF); }
.fab::before { content: ""; position: absolute; inset: -5px; border-radius: 50%; border: 2px solid transparent; border-top-color: #22D3EE; border-right-color: rgba(139,92,246,.7); opacity: .85; animation: spin 6s linear infinite; }
.fab.busy::before { animation-duration: .9s; border-top-color: #FF5D8F; }
.fab .dot { top: 2px; right: 2px; width: 13px; height: 13px; border: 2px solid #0B1030; background: #FBBF24; }
.fab.on .dot { background: #34D399; box-shadow: 0 0 8px #34D399; animation: sigpulse 2.2s infinite; }
.fab.off .dot { background: #F87171; }
/* sincronizar */
.syncbtn { position: relative; display: flex; align-items: center; justify-content: center; gap: 10px; width: 100%; height: 52px; margin-top: 12px; border: 0; border-radius: 999px; cursor: pointer;
  font: 700 14px Inter, system-ui, sans-serif; letter-spacing: .03em; color: #fff; background: linear-gradient(135deg, var(--pk), #D946EF 55%, var(--vi)); box-shadow: 0 8px 26px rgba(217,70,239,.45); transition: .18s; overflow: hidden; }
.syncbtn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 12px 34px rgba(217,70,239,.6); }
.syncbtn:active:not(:disabled) { transform: scale(.985); }
.syncbtn .ring { width: 20px; height: 20px; border-radius: 50%; border: 3px solid rgba(255,255,255,.35); border-top-color: transparent; transition: .2s; position: relative; }
.syncbtn:not(.running) .ring { border-color: #fff; border-width: 0; width: 0; height: 0; border-radius: 0; border-left: 11px solid #fff; border-top: 7px solid transparent; border-bottom: 7px solid transparent; margin-right: 2px; }
.syncbtn.running { cursor: progress; background: linear-gradient(135deg, #2B3A7A, #3B2A7A); box-shadow: 0 0 0 1px rgba(125,160,255,.4), 0 0 28px rgba(61,142,255,.35); }
.syncbtn.running .ring { animation: spin .8s linear infinite; border-top-color: var(--cy); }
.syncbtn.running::after { content: ""; position: absolute; inset: 0; background: linear-gradient(110deg, transparent 30%, rgba(255,255,255,.14) 50%, transparent 70%); transform: translateX(-100%); animation: shimmer 1.4s infinite; }
@keyframes shimmer { to { transform: translateX(100%) } }
.loadwrap { margin-top: 10px; }
.loadbar { height: 6px; border-radius: 999px; background: rgba(255,255,255,.08); overflow: hidden; position: relative; }
.loadbar i { position: absolute; inset: 0 auto 0 0; width: 38%; border-radius: 999px; background: linear-gradient(90deg, var(--cy), var(--bl), var(--pk)); box-shadow: 0 0 12px rgba(34,211,238,.6); animation: slide 1.3s ease-in-out infinite; }
@keyframes slide { 0% { transform: translateX(-100%) } 100% { transform: translateX(270%) } }
.loadhint { margin: 6px 2px 0; font-size: 11px; color: #9DB0DA; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card.hero .btn:not(.primary) { margin-top: 8px; }
/* cartão de conexão */
.conncard { padding: 12px 14px; }
.conncard.on { border-color: rgba(52,211,153,.4); } .conncard.off { border-color: rgba(248,113,113,.4); } .conncard.wait { border-color: rgba(251,191,36,.35); }
.conntitle { display: flex; align-items: center; gap: 10px; }
.steps2 { list-style: none; margin: 10px 0 2px; padding: 0; display: grid; gap: 6px; }
.s2 { display: grid; grid-template-columns: 22px 1fr; gap: 10px; align-items: start; font-size: 12px; animation: pop .35s ease-out both; }
.s2 b { display: block; font-weight: 600; color: #E6ECFA; } .s2 .hint { display: block; margin-top: 1px; word-break: break-word; }
.s2 .ic { width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; font-size: 12px; font-weight: 800; background: rgba(255,255,255,.08); color: #9DB0DA; }
.s2.ok .ic { background: rgba(52,211,153,.18); color: #6EE7B7; } .s2.erro .ic { background: rgba(248,113,113,.2); color: #FCA5A5; } .s2.erro .hint { color: #FCA5A5; }
.s2.wait .ic { background: rgba(251,191,36,.18); color: #FCD34D; animation: sigwave 1s infinite; }
@keyframes pop { from { opacity: 0; transform: translateY(4px) } to { opacity: 1; transform: none } }
/* cartões de execução (fechados; abrem ao clicar) */
.steplist2 { display: grid; gap: 8px; margin: 10px 0; }
.sc { border: 1px solid var(--line2); border-radius: 16px; background: var(--glass); overflow: hidden; transition: border-color .15s, box-shadow .15s; }
.sc.open { border-color: rgba(125,160,255,.45); box-shadow: 0 6px 22px rgba(3,4,22,.4); }
.sc.ok { border-left: 3px solid #34D399; } .sc.erro { border-left: 3px solid #F87171; } .sc.executando { border-left: 3px solid #FBBF24; } .sc.assistida { border-left: 3px solid #3D8EFF; }
.schead, .rephead { all: unset; box-sizing: border-box; width: 100%; display: flex; align-items: center; gap: 10px; padding: 10px 12px; cursor: pointer; color: #E6ECFA; }
.schead:hover, .rephead:hover { background: rgba(255,255,255,.04); }
.schead:focus-visible, .rephead:focus-visible { outline: 2px solid var(--cy); outline-offset: -2px; }
.scico { flex: none; width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; font-size: 14px; background: rgba(255,255,255,.08); color: #B7C6EA; }
.sc.ok .scico { background: rgba(52,211,153,.18); color: #6EE7B7; } .sc.erro .scico { background: rgba(248,113,113,.2); color: #FCA5A5; }
.miniring { width: 16px; height: 16px; border-radius: 50%; border: 2.5px solid rgba(255,255,255,.25); border-top-color: var(--cy); animation: spin .8s linear infinite; }
.sctitle { flex: 1; min-width: 0; display: grid; gap: 1px; }
.sctitle b { font-size: 13px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.scbrief { font-size: 11px; color: #9DB0DA; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.chev { flex: none; font-size: 18px; color: #9DB0DA; transition: transform .18s; }
.sc.open > .schead .chev, .rep.open > .rephead .chev { transform: rotate(90deg); }
.scbody { padding: 2px 12px 12px; display: grid; gap: 8px; animation: pop .25s ease-out both; }
.diff2 { display: grid; grid-template-columns: 1fr auto 1fr; gap: 8px; align-items: center; font-size: 12px; }
.diff2 .was { color: #9DB0DA; text-decoration: line-through; word-break: break-word; } .diff2 .now { color: #fff; font-weight: 600; word-break: break-word; } .diff2 .arrow { color: var(--cy); }
.scol { margin: 0; padding: 0; list-style: none; display: grid; gap: 3px; max-height: 220px; overflow: auto; font-size: 12px; color: #DDE6FA; }
.scol li { padding: 4px 10px; border-radius: 999px; background: rgba(255,255,255,.05); }
.badge.pulada { background: rgba(255,255,255,.08); } .badge.pendente { background: rgba(255,255,255,.06); }
/* relatórios salvos */
.reports h3 { margin: 14px 2px 6px; }
.rclient { margin: 10px 0; }
.rclienthead { display: flex; align-items: center; justify-content: space-between; padding: 6px 4px; }
.rep { border: 1px solid var(--line2); border-radius: 16px; background: var(--glass); margin: 6px 0; overflow: hidden; }
.rep.open { border-color: rgba(125,160,255,.45); }
.rep .chips { display: flex; gap: 4px; flex: none; }
.repimgs { display: grid; gap: 8px; } .repimgs img { width: 100%; border-radius: 12px; border: 1px solid var(--line2); }
.actbtns { display: flex; gap: 8px; flex-wrap: wrap; } .actbtns .btn { flex: 1; }
.btn.danger { border-color: rgba(248,113,113,.6); color: #FCA5A5; }
/* ───────────── Identidade "Undercut": preto domina, vermelho decide · Anton / Archivo / JetBrains Mono · caixas retas, borda fina ───────────── */
.panel { --bg1: #0B0B0C; --bg2: #0B0B0C; --asf: #161618; --red: #B5121B; --red2: #D01822; --ice: #F2F0EC; --smoke: #8E8A86; --line2: #2A2A2E; --glass: #161618; --cy: #B5121B; --bl: #B5121B; --pk: #B5121B; --vi: #B5121B;
  --f-title: Anton, Impact, "Arial Narrow Bold", "Helvetica Neue", sans-serif; --f-text: Archivo, "Helvetica Neue", Arial, system-ui, sans-serif; --f-mono: "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
  background: #0B0B0C; color: var(--ice); border-left: 1px solid var(--line2); border-radius: 0; box-shadow: -14px 0 40px rgba(0,0,0,.7); font-family: var(--f-text); }
.panel::before { content: ""; position: absolute; left: 0; right: 0; top: 0; height: 2px; background: linear-gradient(90deg, transparent, var(--red) 30%, var(--red) 70%, transparent); opacity: .9; pointer-events: none; }
header { background: #0B0B0C; border-bottom: 1px solid var(--line2); border-radius: 0; position: relative; overflow: hidden; }
header::after { content: ""; position: absolute; inset: 0; pointer-events: none; opacity: .5; background: repeating-linear-gradient(180deg, transparent 0 5px, rgba(255,255,255,.035) 5px 6px, transparent 6px 11px); mask-image: linear-gradient(90deg, transparent 20%, #000 100%); -webkit-mask-image: linear-gradient(90deg, transparent 20%, #000 100%); }
header > * { position: relative; z-index: 1; }
.orb { border-radius: 50%; background: var(--red); color: var(--ice); font: 400 22px/1 var(--f-title); box-shadow: none; position: relative; overflow: hidden; }
.orb::after { content: ""; position: absolute; inset: 0; background: linear-gradient(162deg, transparent 46%, #0B0B0C 46% 52%, transparent 52%); }
.brandtxt b { font: 400 21px/1 var(--f-title); letter-spacing: .02em; text-transform: uppercase; color: var(--ice); }
.brandtxt .plat { font: 500 10px var(--f-mono); letter-spacing: .16em; text-transform: uppercase; color: var(--smoke); }
.icon { border-radius: 50%; background: transparent; border: 1px solid var(--line2); color: var(--smoke); }
.icon:hover:not(:disabled) { background: var(--red); border-color: var(--red); color: #fff; box-shadow: none; transform: none; }
.esc { border-radius: 2px; font: 500 10px var(--f-mono); letter-spacing: .1em; }
nav { margin: 0; padding: 0 12px; gap: 0; border: 0; border-bottom: 1px solid var(--line2); border-radius: 0; background: #0B0B0C; }
.tab { border-radius: 0; border-bottom: 2px solid transparent; padding: 11px 4px 9px; font: 500 10.5px var(--f-mono); letter-spacing: .14em; text-transform: uppercase; color: var(--smoke); }
.tab:hover { color: var(--ice); }
.tab.active { background: none; color: var(--ice); border-bottom-color: var(--red); box-shadow: none; }
.body { background: #0B0B0C; scrollbar-color: #3A3A40 transparent; }
h3 { font: 400 18px/1.1 var(--f-title); letter-spacing: .03em; text-transform: uppercase; color: var(--ice); margin: 20px 0 8px; }
h3::before { content: ""; display: inline-block; width: 8px; height: 8px; background: var(--red); margin-right: 8px; transform: translateY(-1px); }
.card { background: var(--asf); border: 1px solid var(--line2); border-radius: 2px; backdrop-filter: none; box-shadow: none; }
.card.ok { border-color: rgba(52,211,153,.4); }
.card.hero { background: #161618; border-color: var(--line2); border-left: 3px solid var(--red); }
.card.hero::after { display: none; }
.card.hero > b, .bigtitle { font: 400 22px/1.05 var(--f-title); text-transform: uppercase; letter-spacing: .02em; }
.card.summary { background: #161618; border-color: var(--line2); }
.card.warn-card { border-left: 3px solid #FBBF24; }
.muted, .hint { color: var(--smoke); }
.input { height: 40px; border-radius: 2px; background: #0B0B0C; border: 1px solid var(--line2); color: var(--ice); font-family: var(--f-text); }
textarea.input, .ta { border-radius: 2px; }
.input:focus { border-color: var(--red); box-shadow: 0 0 0 2px rgba(181,18,27,.35); }
.btn { border-radius: 2px; background: transparent; border: 1px solid #3A3A40; color: var(--ice); font: 600 12px var(--f-mono); letter-spacing: .08em; text-transform: uppercase; }
.btn:hover:not(:disabled) { border-color: var(--red); color: #fff; background: rgba(181,18,27,.14); box-shadow: none; transform: none; }
.btn.primary { background: var(--red); border: 1px solid var(--red); color: #fff; box-shadow: none; }
.btn.primary:hover:not(:disabled) { background: var(--red2); border-color: var(--red2); box-shadow: 0 0 0 2px rgba(181,18,27,.3); }
.btn.big { height: 48px; font-size: 13px; }
.btn.danger { border-color: var(--red); color: #FCA5A5; }
.chip, .pill, .tag, .badge { border-radius: 2px; font-family: var(--f-mono); letter-spacing: .06em; }
.chip { background: transparent; border-color: #3A3A40; color: var(--smoke); text-transform: uppercase; font-size: 10.5px; padding: 5px 10px; }
.chip:hover { border-color: var(--red); color: var(--ice); }
.chip.on { background: var(--red); border-color: var(--red); color: #fff; box-shadow: none; }
.pill { background: #1E1E22; color: var(--smoke); } .pill.ok { background: rgba(52,211,153,.12); color: #6EE7B7; } .pill.hi { background: rgba(181,18,27,.25); color: #FCA5A5; }
.badge { background: #1E1E22; color: var(--smoke); font-size: 9.5px; }
.badge.executando { background: rgba(251,191,36,.14); color: #FCD34D; } .badge.erro { background: rgba(181,18,27,.3); color: #FCA5A5; } .badge.assistida { background: rgba(242,240,236,.1); color: var(--ice); }
.pcard, .act, .step, .plist, .slot, .rep, .sc { border-color: var(--line2); border-radius: 2px; background: var(--asf); }
.pcard:hover { transform: none; border-color: var(--red); box-shadow: none; }
.pimg.ph { background: #1E1E22; color: var(--smoke); }
.act.on { border-color: var(--red); background: rgba(181,18,27,.08); }
.cathead, .pcat { border-color: var(--line2); border-radius: 2px; background: #1B1B1F; }
.kico { border-radius: 50%; }
.notice { border-radius: 2px; }
.addcard { border-color: var(--red); background: rgba(181,18,27,.06); }
.sticky { background: linear-gradient(180deg, rgba(11,11,12,0), #0B0B0C 35%); }
.conn { border-radius: 2px; font: 500 9.5px var(--f-mono); letter-spacing: .1em; text-transform: uppercase; background: transparent; }
.conn.on { background: rgba(52,211,153,.08); } .conn.wait { background: rgba(251,191,36,.07); } .conn.off { color: #FCA5A5; border-color: rgba(181,18,27,.7); background: rgba(181,18,27,.14); }
.sig.off { color: var(--red2); }
/* botão flutuante: avatar redondo vermelho com o corte */
.fab { width: 56px; height: 56px; border-radius: 50%; background: var(--red, #B5121B); font: 400 26px/1 Anton, Impact, sans-serif; color: #F2F0EC; box-shadow: 0 8px 26px rgba(0,0,0,.6), 0 0 0 2px #0B0B0C, 0 0 0 3px rgba(242,240,236,.25); overflow: visible; }
.fab:hover { background: #D01822; transform: scale(1.05); }
.fab::before { inset: -6px; border: 2px solid transparent; border-top-color: #F2F0EC; border-right-color: rgba(242,240,236,.25); opacity: .8; }
.fab::after { content: ""; position: absolute; inset: 0; border-radius: 50%; background: linear-gradient(162deg, transparent 46%, #0B0B0C 46% 52%, transparent 52%); pointer-events: none; }
.fab .dot { z-index: 2; border-color: #0B0B0C; }
/* sincronizar: bloco vermelho com rastro de velocidade ao carregar */
.syncbtn { border-radius: 2px; height: 54px; background: var(--red); box-shadow: none; font: 400 19px var(--f-title); letter-spacing: .06em; text-transform: uppercase; }
.syncbtn:hover:not(:disabled) { background: var(--red2); box-shadow: 0 0 0 2px rgba(181,18,27,.35); transform: none; }
.syncbtn .ring { border-color: #fff; }
.syncbtn.running { background: #161618; box-shadow: inset 0 0 0 1px var(--red); color: var(--ice); }
.syncbtn.running .ring { border-top-color: var(--red); border-color: rgba(242,240,236,.3); }
.syncbtn.running::after { background: repeating-linear-gradient(180deg, transparent 0 4px, rgba(242,240,236,.06) 4px 5px), linear-gradient(110deg, transparent 30%, rgba(181,18,27,.35) 50%, transparent 70%); }
.loadbar { height: 3px; border-radius: 0; background: #1E1E22; }
.loadbar i { border-radius: 0; background: linear-gradient(90deg, transparent, var(--red) 60%, #fff); box-shadow: 0 0 10px rgba(181,18,27,.8); }
.loadhint { font-family: var(--f-mono); color: var(--smoke); }
/* cartões de execução e relatórios */
.sc.open, .rep.open { border-color: var(--red); box-shadow: none; }
.sc.ok { border-left-color: #34D399; } .sc.erro { border-left-color: var(--red2); } .sc.executando { border-left-color: #FBBF24; } .sc.assistida { border-left-color: var(--ice); }
.schead, .rephead { color: var(--ice); }
.scico { border-radius: 2px; background: #1E1E22; font-family: var(--f-mono); }
.sc.erro .scico { background: rgba(181,18,27,.3); }
.miniring { border-top-color: var(--red2); }
.sctitle b { font: 400 15px/1.1 var(--f-title); letter-spacing: .03em; text-transform: uppercase; }
.scbrief { font-family: var(--f-mono); font-size: 10.5px; color: var(--smoke); }
.diff2, .scol { font-family: var(--f-mono); font-size: 11.5px; }
.diff2 .arrow { color: var(--red2); }
.scol li { border-radius: 2px; background: #1E1E22; }
.rclienthead b { font: 400 17px var(--f-title); letter-spacing: .03em; text-transform: uppercase; }
.repimgs img { border-radius: 2px; }
/* conexão */
.conncard.on { border-color: rgba(52,211,153,.5); } .conncard.off { border-color: var(--red); }
.s2 .ic { border-radius: 2px; font-family: var(--f-mono); }
.s2.erro .ic { background: rgba(181,18,27,.35); }
/* ───────────── UNDERCUT · vidro futurista: tudo redondo, transparente, duas cores (vermelho + grafite/gelo) e luz nos botões ───────────── */
.panel { --glowc: rgba(224,32,44,.6); --glass2: rgba(255,255,255,.05); --hair: rgba(255,255,255,.14); --line2: rgba(255,255,255,.12);
  background: linear-gradient(118deg, rgba(112,10,18,.93) 0%, rgba(70,8,14,.9) 30%, rgba(12,12,14,.9) 30.2%, rgba(8,8,10,.94) 100%);
  backdrop-filter: blur(22px) saturate(1.35); -webkit-backdrop-filter: blur(22px) saturate(1.35);
  border: 1px solid var(--hair); border-right: 0; border-radius: 30px 0 0 30px; box-shadow: -20px 0 70px rgba(0,0,0,.65), inset 1px 1px 0 rgba(255,255,255,.12); overflow: hidden; }
.panel::before { height: 3px; background: linear-gradient(90deg, transparent, #FF3B47 25%, #F2F0EC 50%, #FF3B47 75%, transparent); filter: blur(.4px); box-shadow: 0 0 16px rgba(255,59,71,.8); }
header { background: linear-gradient(100deg, rgba(224,32,44,.22) 0 36%, rgba(255,255,255,.03) 36% 100%); border-bottom: 1px solid var(--hair); border-radius: 30px 0 0 0; }
.orb { background: radial-gradient(circle at 30% 25%, #FF5963, #B5121B 60%, #6E0A10); box-shadow: 0 0 0 2px rgba(255,255,255,.14), 0 0 22px rgba(255,59,71,.65); }
.orb::after { background: linear-gradient(162deg, transparent 46%, rgba(11,11,12,.9) 46% 52%, transparent 52%); }
.brandtxt b { text-shadow: 0 0 18px rgba(255,59,71,.45); }
nav { margin: 10px 12px 0; padding: 4px; gap: 4px; border: 1px solid var(--hair); border-radius: 999px; background: rgba(255,255,255,.04); box-shadow: inset 0 0 20px rgba(0,0,0,.3); }
.tab { border: 0; border-radius: 999px; padding: 9px 4px; font-size: 10px; letter-spacing: .1em; }
.tab.active { background: linear-gradient(135deg, #E02029, #B5121B 55%, #7C0C13); color: #fff; box-shadow: 0 0 18px var(--glowc), inset 0 1px 0 rgba(255,255,255,.35); border: 0; }
.body { background: transparent; }
h3::before { border-radius: 50%; box-shadow: 0 0 10px #FF3B47; background: #FF3B47; }
/* cartões: vidro com divisão em duas cores */
.card, .pcard, .act, .step, .plist, .slot, .rep, .sc, .conncard { border: 1px solid var(--hair); border-radius: 22px; background: linear-gradient(115deg, rgba(224,32,44,.24) 0 22%, rgba(255,255,255,.055) 22.2% 100%), rgba(8,8,10,.55); backdrop-filter: blur(8px); box-shadow: 0 10px 30px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.08); overflow: hidden; }
.card.hero { background: linear-gradient(115deg, rgba(224,32,44,.34) 0 28%, rgba(255,255,255,.07) 28.2% 100%), rgba(8,8,10,.55); border-left: 1px solid var(--hair); box-shadow: 0 12px 38px rgba(0,0,0,.4), 0 0 30px rgba(181,18,27,.18), inset 0 1px 0 rgba(255,255,255,.1); }
.card.warn-card { border-left: 1px solid rgba(251,191,36,.5); box-shadow: 0 0 22px rgba(251,191,36,.12); }
.card.ok { border-color: rgba(52,211,153,.5); box-shadow: 0 0 22px rgba(52,211,153,.12); }
.card.sev-alto, .card.sev-medio, .card.sev-baixo { border-left-width: 1px; }
.card.sev-alto { box-shadow: -4px 0 16px rgba(248,113,113,.28); } .card.sev-medio { box-shadow: -4px 0 16px rgba(251,191,36,.25); } .card.sev-baixo { box-shadow: -4px 0 16px rgba(255,59,71,.25); }
.pcard:hover, .act:hover { border-color: rgba(255,90,100,.6); box-shadow: 0 0 26px rgba(224,32,44,.3); }
.act.on { border-color: #FF3B47; background: linear-gradient(115deg, rgba(224,32,44,.30) 0 22%, rgba(255,255,255,.07) 22.2% 100%); box-shadow: 0 0 22px rgba(224,32,44,.3); }
.cathead, .pcat { border-radius: 16px; background: rgba(255,255,255,.06); border-color: var(--hair); }
.plist { border-radius: 22px; background: rgba(0,0,0,.25); }
.pimg, .pimg.ph { border-radius: 0; }
.pcard .pimg { border-radius: 0; }
.notice { border-radius: 18px; }
.addcard { border-radius: 22px; border: 1px dashed rgba(255,90,100,.6); background: rgba(224,32,44,.07); }
/* avisos (era azul) */
.notice, .notice.info { background: rgba(255,255,255,.07); border: 1px solid var(--hair); color: #F2F0EC; }
.notice.ok { background: rgba(52,211,153,.12); border-color: rgba(52,211,153,.45); color: #6EE7B7; }
.notice.erro { background: rgba(224,32,44,.18); border-color: rgba(255,90,100,.6); color: #FFC2C6; }
/* campos */
.input, select.input { border-radius: 999px; padding: 0 18px; background: rgba(0,0,0,.35); border: 1px solid var(--hair); transition: .18s; }
textarea.input, .ta { border-radius: 22px; padding: 12px 16px; }
.input:focus { border-color: #FF3B47; box-shadow: 0 0 0 3px rgba(224,32,44,.28), 0 0 18px rgba(224,32,44,.35); }
input[type=checkbox] { accent-color: #E02029; filter: drop-shadow(0 0 4px rgba(224,32,44,.6)); }
/* botões: redondos, com luz que acompanha o cursor e pulsa ao clicar */
.btn, .chip, .tab, .syncbtn, .icon, .schead, .rephead { position: relative; overflow: hidden; --mx: 50%; --my: 50%; }
.btn::before, .chip::before, .tab::before, .syncbtn::before, .icon::before, .schead::before, .rephead::before {
  content: ""; position: absolute; inset: 0; border-radius: inherit; pointer-events: none; opacity: 0; transition: opacity .18s;
  background: radial-gradient(110px circle at var(--mx) var(--my), rgba(255,110,118,.55), rgba(224,32,44,.18) 45%, transparent 70%); }
.btn:hover::before, .chip:hover::before, .tab:hover::before, .syncbtn:hover::before, .icon:hover::before, .schead:hover::before, .rephead:hover::before { opacity: 1; }
.pulse::after { content: ""; position: absolute; inset: 0; border-radius: inherit; pointer-events: none; background: radial-gradient(circle at var(--mx) var(--my), rgba(255,255,255,.7), rgba(255,59,71,.5) 30%, transparent 62%); animation: lightpulse .65s ease-out forwards; }
@keyframes lightpulse { from { opacity: 1; transform: scale(.3) } to { opacity: 0; transform: scale(1.6) } }
.btn { border-radius: 999px; border: 1px solid var(--hair); background: rgba(255,255,255,.06); backdrop-filter: blur(6px); transition: .18s; }
.btn:hover:not(:disabled) { border-color: rgba(255,90,100,.8); background: rgba(224,32,44,.12); box-shadow: 0 0 20px var(--glowc), inset 0 0 12px rgba(255,59,71,.18); }
.btn:active:not(:disabled) { transform: scale(.97); box-shadow: 0 0 30px rgba(255,90,100,.9); }
.btn:focus-visible, .tab:focus-visible, .chip:focus-visible, .icon:focus-visible, .schead:focus-visible, .rephead:focus-visible { outline: 2px solid #FF6B73; outline-offset: 2px; box-shadow: 0 0 20px var(--glowc); }
.btn.primary { background: linear-gradient(135deg, #E02029, #B5121B 55%, #7C0C13); border: 1px solid rgba(255,140,146,.55); box-shadow: 0 0 18px rgba(224,32,44,.45), inset 0 1px 0 rgba(255,255,255,.3); animation: breathe 3.2s ease-in-out infinite; }
.btn.primary:hover:not(:disabled) { background: linear-gradient(135deg, #FF3B47, #D01822 55%, #8E0F17); box-shadow: 0 0 34px rgba(255,59,71,.85), inset 0 1px 0 rgba(255,255,255,.4); }
@keyframes breathe { 0%, 100% { box-shadow: 0 0 14px rgba(224,32,44,.35), inset 0 1px 0 rgba(255,255,255,.3) } 50% { box-shadow: 0 0 28px rgba(255,59,71,.7), inset 0 1px 0 rgba(255,255,255,.3) } }
.btn.danger { border-color: rgba(255,90,100,.7); }
.btn:disabled { opacity: .45; animation: none; }
.icon { background: rgba(255,255,255,.06); border: 1px solid var(--hair); }
.icon:hover:not(:disabled) { background: rgba(224,32,44,.25); border-color: #FF6B73; box-shadow: 0 0 20px var(--glowc); transform: none; }
.link { color: #FF8A92; text-decoration: none; border-radius: 999px; padding: 2px 8px; transition: .15s; }
.link:hover { background: rgba(224,32,44,.18); color: #fff; box-shadow: 0 0 12px rgba(224,32,44,.45); }
.chip { border-radius: 999px; background: rgba(255,255,255,.05); border: 1px solid var(--hair); color: #D9D6D1; padding: 6px 12px; line-height: 1.25; text-transform: none; letter-spacing: .02em; font: 500 11px "JetBrains Mono", ui-monospace, monospace; }
.chip:hover { border-color: rgba(255,90,100,.8); color: #fff; box-shadow: 0 0 16px rgba(224,32,44,.4); }
.chip.on { background: linear-gradient(135deg, #E02029, #8E0F17); border-color: rgba(255,140,146,.6); box-shadow: 0 0 18px rgba(224,32,44,.55); }
.pill, .tag, .badge { border-radius: 999px; }
.pill.ok, .badge.ok { box-shadow: 0 0 10px rgba(52,211,153,.25); }
.tag { border-color: rgba(255,90,100,.5); color: #FFB0B5; background: rgba(224,32,44,.12); }
.badge.assistida { background: rgba(255,255,255,.12); color: #F2F0EC; }
.kico { border-radius: 50%; background: rgba(255,255,255,.08); color: #FFB0B5; }
.diff2 .was { background: rgba(255,255,255,.06); border-radius: 999px; padding: 3px 12px; }
.diff2 .now { background: rgba(224,32,44,.22); border-radius: 999px; padding: 3px 12px; box-shadow: 0 0 12px rgba(224,32,44,.25); }
table.diff td.after { color: #fff; }
.pimg.ph { color: #FF6B73; background: linear-gradient(135deg, rgba(224,32,44,.25), rgba(255,255,255,.05)); }
.add-open { border-radius: 999px; color: #FFB0B5; border-color: rgba(255,90,100,.6); }
.sticky { background: linear-gradient(180deg, rgba(10,10,12,0), rgba(10,10,12,.92) 35%); }
/* conexão: luz */
.conn { border-radius: 999px; padding: 3px 10px 3px 8px; }
.conn.on { box-shadow: 0 0 14px rgba(52,211,153,.35); } .conn.off { box-shadow: 0 0 14px rgba(224,32,44,.4); } .conn.wait { box-shadow: 0 0 14px rgba(251,191,36,.3); }
.sig.on i { filter: drop-shadow(0 0 4px #34D399); }
/* sincronizar */
.syncbtn { border-radius: 999px; height: 56px; background: linear-gradient(135deg, #FF3B47, #B5121B 55%, #6E0A10); border: 1px solid rgba(255,150,156,.55); box-shadow: 0 0 26px rgba(224,32,44,.55), inset 0 1px 0 rgba(255,255,255,.35); animation: breathe 3.2s ease-in-out infinite; }
.syncbtn:hover:not(:disabled) { box-shadow: 0 0 44px rgba(255,59,71,.95), inset 0 1px 0 rgba(255,255,255,.45); transform: translateY(-1px); background: linear-gradient(135deg, #FF5963, #D01822 55%, #8E0F17); }
.syncbtn.running { animation: none; background: linear-gradient(135deg, rgba(224,32,44,.25), rgba(255,255,255,.06)); box-shadow: 0 0 0 1px rgba(255,90,100,.7), 0 0 30px rgba(224,32,44,.5); }
.loadbar { border-radius: 999px; height: 5px; background: rgba(255,255,255,.1); } .loadbar i { border-radius: 999px; background: linear-gradient(90deg, transparent, #FF3B47 55%, #fff); box-shadow: 0 0 14px #FF3B47; }
/* cartões de execução e relatórios */
.sc, .rep { border-radius: 22px; }
.sc.ok { box-shadow: 0 0 18px rgba(52,211,153,.14), 0 10px 30px rgba(0,0,0,.35); } .sc.erro { box-shadow: 0 0 20px rgba(224,32,44,.32), 0 10px 30px rgba(0,0,0,.35); } .sc.executando { box-shadow: 0 0 22px rgba(251,191,36,.3), 0 10px 30px rgba(0,0,0,.35); }
.sc.ok, .sc.erro, .sc.executando, .sc.assistida { border-left: 1px solid var(--hair); }
.sc.executando { animation: breathe 1.6s ease-in-out infinite; }
.sc.open, .rep.open { border-color: rgba(255,90,100,.7); box-shadow: 0 0 26px rgba(224,32,44,.3); }
.scico { border-radius: 50%; background: rgba(255,255,255,.08); }
.scol li { border-radius: 999px; padding: 5px 12px; }
.repimgs img, .print img { border-radius: 18px; }
.rclienthead b { text-shadow: 0 0 14px rgba(224,32,44,.4); }
.s2 .ic { border-radius: 50%; }
.fab { box-shadow: 0 0 0 2px rgba(10,10,12,.9), 0 0 0 3px rgba(255,255,255,.25), 0 0 34px rgba(224,32,44,.75), 0 12px 30px rgba(0,0,0,.6); background: radial-gradient(circle at 30% 25%, #FF5963, #B5121B 60%, #6E0A10); animation: breathe 3.2s ease-in-out infinite; }
.fab:hover { box-shadow: 0 0 0 2px rgba(10,10,12,.9), 0 0 0 3px rgba(255,255,255,.4), 0 0 48px rgba(255,59,71,.95), 0 12px 30px rgba(0,0,0,.6); }
`
