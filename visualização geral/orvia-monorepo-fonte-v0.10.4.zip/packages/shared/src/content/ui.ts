/**
 * Peças visuais compartilhadas pelas três extensões (iFood, Cardápio Web, Anota AI): marca, sinal de conexão,
 * botão de sincronizar com estado de carregamento e o cartão "Conexão com o Undercut" (teste passo a passo).
 * Só monta DOM — o estilo está em styles.ts (classes `.brand`, `.sig`, `.syncbtn`, `.loadbar`, `.conncard`…).
 */

type Child = Node | string | null | undefined | false

export function el<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, unknown> = {}, ...kids: Child[]): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag)
  for (const [k, v] of Object.entries(props)) {
    if (v === undefined || v === null || v === false) continue
    if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v as EventListener)
    else if (k === 'class') node.className = String(v)
    else node.setAttribute(k, String(v === true ? '' : v))
  }
  for (const c of kids) if (c) node.append(c)
  return node
}

export type SignalKind = 'on' | 'wait' | 'off'

/** Barrinhas de sinal animadas: verde = conectado, âmbar = verificando, vermelho = sem conexão. */
export function signal(kind: SignalKind): HTMLElement {
  return el('span', { class: `sig ${kind}`, 'aria-hidden': 'true' }, el('i'), el('i'), el('i'), el('i'))
}

/** Selo de conexão do cabeçalho: sinal + texto. */
export function connChip(kind: SignalKind, label: string, title = ''): HTMLElement {
  return el('span', { class: `conn ${kind}`, title }, signal(kind), label)
}

/** Marca do cabeçalho: orbe com a inicial, nome da plataforma e o selo de conexão. */
export function brand(platform: string, chip: Node): HTMLElement {
  return el('div', { class: 'brand' },
    el('span', { class: 'orb', 'aria-hidden': 'true' }, 'U'),
    el('div', { class: 'brandtxt' }, el('b', {}, 'Undercut'), el('span', { class: 'plat' }, platform), chip),
  )
}

/** Botão grande e arredondado de sincronizar; ao clicar mostra SEMPRE “Carregando…” com o anel girando. */
export function syncButton(opts: { running: boolean; label: string; runningLabel?: string; onClick: () => void }): HTMLButtonElement {
  return el('button', { class: `syncbtn${opts.running ? ' running' : ''}`, disabled: opts.running, 'aria-busy': opts.running ? 'true' : null, onclick: opts.onClick },
    el('span', { class: 'ring', 'aria-hidden': 'true' }),
    el('span', { class: 'lbl' }, opts.running ? 'Carregando…' : opts.label),
  ) as HTMLButtonElement
}

/** Barra de carregamento indeterminada + a última linha do andamento. Só aparece enquanto `running`. */
export function loadBar(running: boolean, _hint?: string): HTMLElement | null {
  if (!running) return null
  return el('div', { class: 'loadwrap', role: 'status', 'aria-live': 'polite' },
    el('div', { class: 'loadbar' }, el('i')),
  )
}

/** Botão redondo só com ícone (⚙, ×, ↻…). */
export function roundBtn(icon: string, title: string, onClick: () => void): HTMLButtonElement {
  return el('button', { class: 'icon', title, 'aria-label': title, onclick: onClick }, icon) as HTMLButtonElement
}

// ───────────────────────── Conexão com o Undercut ─────────────────────────

interface DiagData {
  configurado?: boolean
  servidorUrl?: string | null
  canalDestaExtensao?: string
  nomeNoManifest?: string
  versao?: string
  ultimoHandshake?: unknown
  /** resultado do teste real (o worker devolve em `teste`) */
  teste?: DiagData['servidor']
  servidor?: { ok?: boolean; erro?: string; status?: number; workspace?: string; canal?: string | null; plataforma?: string | null; canalConfere?: boolean; handshake?: string; latenciaMs?: number } | null
}
type Send = (msg: { type: 'hub:diag'; probe: boolean }) => Promise<{ ok: boolean; data?: unknown; error?: string }>

const probe: { running: boolean; at: number | null; data: DiagData | null; error: string | null; auto: boolean } = { running: false, at: null, data: null, error: null, auto: false }

type StepState = 'ok' | 'erro' | 'wait' | 'skip'
interface Step { name: string; state: StepState; detail: string }

/** Transforma o resultado do teste em passos legíveis (puro — testado). */
export function connectionSteps(d: DiagData | null, running: boolean, error: string | null, platform: string): Step[] {
  if (running) return [{ name: 'Testando a conexão com o servidor…', state: 'wait', detail: '' }]
  if (error) return [{ name: 'Falha ao testar', state: 'erro', detail: error }]
  if (!d) return []
  const out: Step[] = []
  out.push(d.configurado
    ? { name: 'Chave do Undercut neste navegador', state: 'ok', detail: d.servidorUrl ? d.servidorUrl.replace(/^https?:\/\//, '') : '' }
    : { name: 'Chave do Undercut neste navegador', state: 'erro', detail: 'Não conectada. Clique na engrenagem (⚙) e entre com seu e-mail e senha do Undercut.' })
  if (!d.configurado) return out
  const s = d.teste ?? d.servidor
  if (!s) return [...out, { name: 'Servidor Undercut', state: 'skip', detail: 'Não testado.' }]
  if (s.ok === false) {
    const unreachable = !s.status
    out.push({ name: 'Servidor Undercut respondeu', state: unreachable ? 'erro' : 'ok', detail: unreachable ? (s.erro ?? 'Sem resposta do servidor.') : `HTTP ${s.status}` })
    out.push({ name: 'Chave aceita pelo servidor', state: 'erro', detail: s.erro ?? `Recusada (HTTP ${s.status}).` })
    return out
  }
  out.push({ name: 'Servidor Undercut respondeu', state: 'ok', detail: [s.latenciaMs != null ? `${s.latenciaMs} ms` : '', s.workspace ? `Workspace: ${s.workspace}` : ''].filter(Boolean).join(' · ') })
  out.push({ name: 'Chave aceita pelo servidor', state: 'ok', detail: '' })
  out.push(s.canalConfere
    ? { name: `Integração ${platform} liberada`, state: 'ok', detail: `Canal ${s.canal ?? d.canalDestaExtensao ?? ''}${s.plataforma ? ` · plataforma ${s.plataforma}` : ''}` }
    : { name: `Integração ${platform} liberada`, state: 'erro', detail: `O servidor ainda não reconhece esta extensão (canal recebido: ${s.canal ?? 'nenhum'}; esperado: ${d.canalDestaExtensao ?? '?'}). Libere a integração no servidor e entre de novo.` })
  out.push(s.handshake === 'ok'
    ? { name: 'Handshake (extensão registrada)', state: 'ok', detail: `v${d.versao ?? ''}` }
    : { name: 'Handshake (extensão registrada)', state: 'erro', detail: s.handshake ?? 'Sem resposta.' })
  return out
}

const ICON: Record<StepState, string> = { ok: '✓', erro: '✕', wait: '…', skip: '–' }

/** Cartão "Conexão com o Undercut": botão redondo que testa servidor, chave, integração e handshake, passo a passo. */
export function connectionCard(opts: { platform: string; send: Send; render: () => void; configured: boolean }): HTMLElement {
  const run = async () => {
    if (probe.running) return
    probe.running = true
    probe.error = null
    opts.render()
    try {
      const res = await opts.send({ type: 'hub:diag', probe: true })
      if (res.ok) { probe.data = res.data as DiagData; probe.at = Date.now() } else probe.error = res.error ?? 'Sem resposta da extensão.'
    } catch (e) {
      probe.error = e instanceof Error ? e.message : 'Falha ao testar.'
    }
    probe.running = false
    opts.render()
  }
  if (!probe.auto && opts.configured) { probe.auto = true; window.setTimeout(() => void run(), 400) }
  const steps = connectionSteps(probe.data, probe.running, probe.error, opts.platform)
  const allOk = steps.length > 0 && !probe.running && steps.every((s) => s.state === 'ok')
  const kind: SignalKind = probe.running ? 'wait' : allOk ? 'on' : steps.some((s) => s.state === 'erro') ? 'off' : 'wait'
  return el('div', { class: `card conncard ${kind}` },
    el('div', { class: 'row' },
      el('div', { class: 'conntitle' }, signal(kind), el('b', {}, 'Conexão com o Undercut')),
      el('button', { class: 'icon spin', title: 'Testar conexão', 'aria-label': 'Testar conexão', disabled: probe.running, onclick: () => void run() }, '↻'),
    ),
    steps.length
      ? el('ul', { class: 'steps2' }, ...steps.map((s, i) => el('li', { class: `s2 ${s.state}`, style: `animation-delay:${i * 70}ms` },
        el('span', { class: 'ic' }, ICON[s.state]), el('div', {}, el('b', {}, s.name), s.detail ? el('span', { class: 'hint' }, s.detail) : null))))
      : el('p', { class: 'muted' }, opts.configured ? 'Clique em ↻ para testar.' : 'Entre pela engrenagem (⚙) para conectar.'),
    probe.at && !probe.running ? el('p', { class: 'hint' }, `Testado às ${new Date(probe.at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`) : null,
  )
}

/** Cor do sinal do botão flutuante: reflete a conexão com o Undercut. */
export function fabState(kind: SignalKind, busy: boolean): string {
  return `fab ${kind}${busy ? ' busy' : ''}`
}

// ───────────────────────── Andamento da execução (cartões que abrem ao clicar) ─────────────────────────

export interface StepCardData {
  id: string
  icon: string
  title: string
  status: 'pendente' | 'executando' | 'ok' | 'erro' | 'assistida' | 'pulada' | 'nao_feita'
  statusLabel: string
  /** uma linha curta, sempre visível */
  brief: string
  /** só aparece quando o cartão é aberto */
  before?: string
  after?: string
  message: string
  /** lista longa (ex.: nova ordem das categorias), só no cartão aberto */
  lines?: string[]
}

const openCards = new Set<string>()

/** Lista de ações: cada uma é uma linha compacta (ícone, título, selo); clicar abre antes/depois e a mensagem. Em execução mostra o giro. */
export function stepCards(items: StepCardData[], render: () => void): HTMLElement {
  return el('div', { class: 'steplist2' }, ...items.map((it) => {
    const open = openCards.has(it.id)
    const toggle = () => { if (open) openCards.delete(it.id); else openCards.add(it.id); render() }
    return el('div', { class: `sc ${it.status}${open ? ' open' : ''}` },
      el('button', { class: 'schead', type: 'button', 'aria-expanded': open ? 'true' : 'false', onclick: toggle },
        el('span', { class: 'scico' }, it.status === 'executando' ? el('span', { class: 'miniring' }) : it.icon),
        el('span', { class: 'sctitle' }, el('b', {}, it.title), el('span', { class: 'scbrief' }, it.brief)),
        el('span', { class: `badge ${it.status}` }, it.statusLabel),
        el('span', { class: 'chev', 'aria-hidden': 'true' }, '›'),
      ),
      open ? el('div', { class: 'scbody' },
        it.before !== undefined || it.after !== undefined ? el('div', { class: 'diff2' }, el('span', { class: 'was' }, it.before || '—'), el('span', { class: 'arrow' }, '→'), el('span', { class: 'now' }, it.after || '—')) : null,
        it.lines?.length ? el('ol', { class: 'scol' }, ...it.lines.map((l) => el('li', {}, l))) : null,
        el('p', { class: it.status === 'erro' ? 'warn' : 'hint' }, it.message),
      ) : null,
    )
  }))
}

// ───────────────────────── Relatórios salvos por cliente ─────────────────────────

export interface SavedReportView {
  id: string
  at: number
  clientName: string
  title: string
  counts: { ok: number; erro: number; outras: number }
  steps: { icon: string; title: string; status: string; statusLabel: string; before: string; after: string; message: string; brief?: string; lines?: string[] }[]
  pages: string[]
}

const openReports = new Set<string>()
const confirmDel = new Set<string>()

export function reportsSection(opts: {
  reports: SavedReportView[]
  scopeLabel: string
  render: () => void
  onDelete: (id: string) => void
  onDownload: (id: string) => void
}): HTMLElement {
  const { reports, render } = opts
  const byClient = new Map<string, SavedReportView[]>()
  for (const r of reports) byClient.set(r.clientName, [...(byClient.get(r.clientName) ?? []), r])
  return el('div', { class: 'reports' },
    el('h3', {}, `Relatórios salvos · ${opts.scopeLabel}`),
    reports.length === 0 ? el('div', { class: 'card' }, el('p', { class: 'muted' }, 'Nenhum relatório ainda. Cada otimização executada fica salva aqui, separada por cliente.')) : null,
    ...[...byClient.entries()].map(([client, list]) => el('div', { class: 'rclient' },
      el('div', { class: 'rclienthead' }, el('b', {}, client), el('span', { class: 'pill' }, `${list.length} relatório${list.length > 1 ? 's' : ''}`)),
      ...list.map((r) => {
        const open = openReports.has(r.id)
        return el('div', { class: `rep${open ? ' open' : ''}` },
          el('button', { class: 'rephead', type: 'button', 'aria-expanded': open ? 'true' : 'false', onclick: () => { if (open) openReports.delete(r.id); else openReports.add(r.id); render() } },
            el('span', { class: 'sctitle' }, el('b', {}, r.title), el('span', { class: 'scbrief' }, new Date(r.at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }))),
            el('span', { class: 'chips' }, el('span', { class: 'pill ok' }, `${r.counts.ok} ok`), r.counts.erro ? el('span', { class: 'pill hi' }, `${r.counts.erro} erro`) : null, r.counts.outras ? el('span', { class: 'pill' }, `${r.counts.outras} outras`) : null),
            el('span', { class: 'chev', 'aria-hidden': 'true' }, '›')),
          open ? el('div', { class: 'scbody' },
            stepCards(r.steps.map((s, i) => ({ id: `${r.id}:${i}`, icon: s.icon, title: s.title, status: s.status as StepCardData['status'], statusLabel: s.statusLabel, brief: s.brief ?? (s.after ? `${s.before || '—'} → ${s.after}` : ''), before: s.lines?.length ? undefined : s.before, after: s.lines?.length ? undefined : s.after, lines: s.lines, message: s.message })), render),
            r.pages.length ? el('div', { class: 'repimgs' }, ...r.pages.map((src, i) => el('img', { src, alt: `Página ${i + 1} do relatório` }))) : null,
            el('div', { class: 'actbtns' },
              r.pages.length ? el('button', { class: 'btn', type: 'button', onclick: () => opts.onDownload(r.id) }, 'Baixar imagens') : null,
              confirmDel.has(r.id)
                ? el('button', { class: 'btn danger', type: 'button', onclick: () => { confirmDel.delete(r.id); opts.onDelete(r.id) } }, 'Confirmar exclusão')
                : el('button', { class: 'btn', type: 'button', onclick: () => { confirmDel.add(r.id); render() } }, 'Excluir')),
          ) : null)
      }))),
  )
}
