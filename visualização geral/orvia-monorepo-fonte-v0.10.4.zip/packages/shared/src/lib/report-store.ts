/**
 * Relatórios de otimização salvos NO NAVEGADOR, separados por cliente. Cada execução vira um registro
 * (o que foi pedido, o resultado de cada ação e as páginas do relatório em JPEG leve).
 * O armazenamento é injetado (chrome.storage.local no painel, um objeto em memória nos testes).
 */

export interface ReportStep { kind: string; itemName: string; before: string; after: string; status: string; message: string; icon?: string; title?: string; statusLabel?: string; brief?: string; lines?: string[] }

export interface SavedReport {
  id: string
  at: number
  /** chave estável do cliente (id do Undercut, senão o nome da loja) */
  clientKey: string
  clientName: string
  storeName: string
  platform: string
  version: number
  summary: string
  aborted: boolean
  steps: ReportStep[]
  /** páginas do relatório (data URLs JPEG) */
  pages: { name: string; dataUrl: string }[]
}

export interface KV {
  get(key: string): Promise<Record<string, unknown>>
  set(items: Record<string, unknown>): Promise<void>
}

export const REPORTS_KEY = 'orvia.reports.v1'
export const MAX_REPORTS = 60

export const clientKeyOf = (clientId: string | null | undefined, storeName: string | null | undefined): string =>
  clientId ? `c:${clientId}` : `s:${(storeName ?? 'sem-loja').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim()}`

export async function listReports(kv: KV): Promise<SavedReport[]> {
  const raw = (await kv.get(REPORTS_KEY))[REPORTS_KEY]
  const list = Array.isArray(raw) ? (raw as SavedReport[]) : []
  return list.filter((r) => r && typeof r.id === 'string').sort((a, b) => b.at - a.at)
}

export async function saveReport(kv: KV, report: SavedReport): Promise<SavedReport[]> {
  const cur = await listReports(kv)
  const next = [report, ...cur.filter((r) => r.id !== report.id)].slice(0, MAX_REPORTS)
  await kv.set({ [REPORTS_KEY]: next })
  return next
}

export async function deleteReport(kv: KV, id: string): Promise<SavedReport[]> {
  const next = (await listReports(kv)).filter((r) => r.id !== id)
  await kv.set({ [REPORTS_KEY]: next })
  return next
}

/** relatórios de um cliente (ou de todos, com `clientKey` vazio) */
export const reportsOf = (list: SavedReport[], clientKey: string | null): SavedReport[] => (clientKey ? list.filter((r) => r.clientKey === clientKey) : list)

export function countSteps(steps: ReportStep[]): { ok: number; erro: number; outras: number } {
  const ok = steps.filter((s) => s.status === 'ok').length
  const erro = steps.filter((s) => s.status === 'erro').length
  return { ok, erro, outras: steps.length - ok - erro }
}

/** PNG → JPEG pequeno (largura máx. 760 px) para caber folgado no armazenamento. Só no navegador. */
export async function toJpeg(dataUrl: string, maxWidth = 760, quality = 0.72): Promise<string> {
  const img = new Image()
  await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error('imagem inválida')); img.src = dataUrl })
  const scale = Math.min(1, maxWidth / img.naturalWidth)
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(img.naturalWidth * scale))
  canvas.height = Math.max(1, Math.round(img.naturalHeight * scale))
  const ctx = canvas.getContext('2d')
  if (!ctx) return dataUrl
  ctx.fillStyle = '#fff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL('image/jpeg', quality)
}
