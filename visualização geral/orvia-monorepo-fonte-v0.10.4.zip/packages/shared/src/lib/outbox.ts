/** Fila offline de otimizações (reenvio no alarme de 1 min). Erro de rede/5xx/429 → fica; 4xx → descarta. */
import type { HubResult, OptimizationUpload } from './hub'

export const MAX_QUEUE = 10
export interface Outbox {
  read(): Promise<OptimizationUpload[]>
  write(list: OptimizationUpload[]): Promise<void>
}

export const isRetriable = (r: HubResult<unknown>) => !r.ok && (r.code === 'network' || r.status === 0 || r.status === 429 || r.status >= 500)

export async function enqueue(box: Outbox, o: OptimizationUpload): Promise<number> {
  const q = (await box.read()).filter((x) => !(x.plan_hash === o.plan_hash && x.client_id === o.client_id))
  q.push(o)
  const kept = q.slice(-MAX_QUEUE)
  await box.write(kept)
  return kept.length
}

export async function flush(box: Outbox, send: (o: OptimizationUpload) => Promise<HubResult<unknown>>): Promise<{ sent: number; kept: number; dropped: number }> {
  const q = await box.read()
  if (!q.length) return { sent: 0, kept: 0, dropped: 0 }
  const keep: OptimizationUpload[] = []
  let sent = 0
  let dropped = 0
  for (const o of q) {
    const r = await send(o)
    if (r.ok) sent += 1
    else if (isRetriable(r)) keep.push(o)
    else dropped += 1
  }
  // o que entrou na fila durante o envio não pode ser perdido
  const now = await box.read()
  const added = now.filter((x) => !q.some((y) => y.plan_hash === x.plan_hash && y.client_id === x.client_id))
  await box.write([...keep, ...added].slice(-MAX_QUEUE))
  return { sent, kept: keep.length, dropped }
}
