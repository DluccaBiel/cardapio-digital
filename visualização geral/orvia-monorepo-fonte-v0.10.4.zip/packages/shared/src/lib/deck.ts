/**
 * Apresentação em PDF (slides A4 paisagem, tema dashboard) — sem dependências.
 * Desenha retângulos, barras e texto (Helvetica, cp1252) direto no PDF.
 */
import { KIND_LABEL, type ActionKind, type Proposal, type ProposalAction } from '../core/proposal'
import { AREA_LABEL, describeAction, forecast, LEVEL_LABEL, type Area, type Level } from './impact'
import { textWidth, toWinAnsi, wrapLines } from './pdf'

type RGB = [number, number, number]
const hexRgb = (h: string): RGB => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255]
const C = {
  bg: hexRgb('#0B1324'), panel: hexRgb('#121C33'), panel2: hexRgb('#1A2745'), line: hexRgb('#2A3B63'),
  text: hexRgb('#EAF0FF'), muted: hexRgb('#93A4C8'), blue: hexRgb('#3B82F6'), cyan: hexRgb('#22D3EE'),
  green: hexRgb('#34D399'), amber: hexRgb('#FBBF24'), red: hexRgb('#F87171'), purple: hexRgb('#A78BFA'), white: hexRgb('#FFFFFF'),
}
const KIND_COLOR: Record<ActionKind, RGB> = {
  update_price: C.amber, update_name: C.cyan, update_description: C.cyan, set_status: C.muted, create_combo: C.purple,
  create_item: C.green, remove_item: C.red, update_schedule: C.blue, reorder_categories: C.blue, add_complement: C.green, update_image: C.green, recommend: C.amber,
}
const LEVEL_COLOR: Record<Level, RGB> = { alto: C.green, medio: C.amber, baixo: C.muted }
const AREA_COLOR: Record<Area, RGB> = { conversao: C.cyan, ticket: C.purple, margem: C.amber, organizacao: C.blue }

const W = 842
const H = 595
const PAD = 40

class Page {
  ops: string[] = []
  private f = (c: RGB) => `${c[0].toFixed(3)} ${c[1].toFixed(3)} ${c[2].toFixed(3)}`
  rect(x: number, y: number, w: number, h: number, fill: RGB, r = 0) {
    const Y = H - y - h
    if (r <= 0) this.ops.push(`${this.f(fill)} rg ${x.toFixed(1)} ${Y.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re f`)
    else {
      const k = Math.min(r, w / 2, h / 2)
      const b = k * 0.5523
      const x2 = x + w
      const y2 = Y + h
      this.ops.push(`${this.f(fill)} rg ${(x + k).toFixed(1)} ${Y.toFixed(1)} m ${(x2 - k).toFixed(1)} ${Y.toFixed(1)} l ${(x2 - k + b).toFixed(1)} ${Y.toFixed(1)} ${x2.toFixed(1)} ${(Y + k - b).toFixed(1)} ${x2.toFixed(1)} ${(Y + k).toFixed(1)} c ${x2.toFixed(1)} ${(y2 - k).toFixed(1)} l ${x2.toFixed(1)} ${(y2 - k + b).toFixed(1)} ${(x2 - k + b).toFixed(1)} ${y2.toFixed(1)} ${(x2 - k).toFixed(1)} ${y2.toFixed(1)} c ${(x + k).toFixed(1)} ${y2.toFixed(1)} l ${(x + k - b).toFixed(1)} ${y2.toFixed(1)} ${x.toFixed(1)} ${(y2 - k + b).toFixed(1)} ${x.toFixed(1)} ${(y2 - k).toFixed(1)} c ${x.toFixed(1)} ${(Y + k).toFixed(1)} l ${x.toFixed(1)} ${(Y + k - b).toFixed(1)} ${(x + k - b).toFixed(1)} ${Y.toFixed(1)} ${(x + k).toFixed(1)} ${Y.toFixed(1)} c f`)
    }
  }
  /** texto numa linha; (x, yTop) = topo da linha. align: l | r | c (dentro de `w`). */
  text(str: string, x: number, yTop: number, size: number, color: RGB, o: { bold?: boolean; align?: 'l' | 'r' | 'c'; w?: number } = {}) {
    const bytes = toWinAnsi(str)
    const tw = textWidth(bytes, size, !!o.bold)
    const px = o.align === 'r' ? x + (o.w ?? 0) - tw : o.align === 'c' ? x + ((o.w ?? 0) - tw) / 2 : x
    const base = H - yTop - size * 0.82
    this.ops.push(`BT /${o.bold ? 'F2' : 'F1'} ${size} Tf ${this.f(color)} rg 1 0 0 1 ${px.toFixed(1)} ${base.toFixed(1)} Tm <${bytes.map((b) => b.toString(16).padStart(2, '0')).join('')}> Tj ET`)
  }
  /** bloco com quebra de linha; devolve a altura usada. maxLines corta com “…”. */
  block(str: string, x: number, yTop: number, w: number, size: number, color: RGB, o: { bold?: boolean; maxLines?: number; lead?: number } = {}): number {
    const lead = o.lead ?? size * 1.32
    let lines = wrapLines(str, size, !!o.bold, w).filter((l, i, a) => l.length || i < a.length - 1)
    if (o.maxLines && lines.length > o.maxLines) {
      lines = lines.slice(0, o.maxLines)
      let last = lines[o.maxLines - 1]!.slice()
      while (last.length && textWidth([...last, 0x2e, 0x2e, 0x2e], size, !!o.bold) > w) last.pop()
      lines[o.maxLines - 1] = [...last, 0x2e, 0x2e, 0x2e]
    }
    lines.forEach((ln, i) => {
      const y = yTop + i * lead
      this.ops.push(`BT /${o.bold ? 'F2' : 'F1'} ${size} Tf ${this.f(color)} rg 1 0 0 1 ${x.toFixed(1)} ${(H - y - size * 0.82).toFixed(1)} Tm <${ln.map((b) => b.toString(16).padStart(2, '0')).join('')}> Tj ET`)
    })
    return lines.length * lead
  }
  pill(label: string, x: number, yTop: number, color: RGB, o: { size?: number; solid?: boolean } = {}): number {
    const size = o.size ?? 8
    const w = textWidth(toWinAnsi(label), size, true) + 14
    this.rect(x, yTop, w, size + 8, o.solid ? color : C.panel2, (size + 8) / 2)
    this.text(label, x, yTop + 4, size, o.solid ? C.bg : color, { bold: true, align: 'c', w })
    return w
  }
}

const pct = (v: number, d = 1) => `${v >= 0 ? '+' : ''}${v.toFixed(d).replace('.', ',')}%`
const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const brlSigned = (v: number) => `${v >= 0 ? '+' : '-'}R$ ${Math.abs(v).toFixed(2).replace('.', ',')}`

export interface DeckMeta {
  clientName: string
  merchantName: string | null
  city: string
  itemCount: number
  date: Date
  platform?: string
  avgItemPrice?: number | null
}
export interface DeckOptions {
  /** resumo = uma linha por produto (rápida); completo = um cartão por produto */
  format?: 'resumo' | 'completo'
  sections: { resumo: boolean; combos: boolean; ajustes: boolean; atencao: boolean; regiao: boolean; fontes: boolean }
  title?: string
  note?: string
}

export function deckPdf(p: Proposal, picked: ProposalAction[], meta: DeckMeta, opts: DeckOptions): Uint8Array {
  const pages: Page[] = []
  const platform = meta.platform ?? 'cardápio'
  const exec = picked.filter((a) => a.kind !== 'create_combo' && a.kind !== 'recommend')
  const combos = picked.filter((a) => a.kind === 'create_combo')
  const recs = picked.filter((a) => a.kind === 'recommend')
  const fc = forecast(picked, meta.avgItemPrice ?? null)
  const slide = (title: string, subtitle?: string): Page => {
    const pg = new Page()
    pg.rect(0, 0, W, H, C.bg)
    pg.rect(0, 0, W, 5, C.blue)
    pg.rect(W - 160, 0, 160, 5, C.purple)
    pg.text('UNDERCUT', PAD, 22, 10, C.blue, { bold: true })
    pg.text(title, PAD, 40, 22, C.text, { bold: true })
    if (subtitle) pg.text(subtitle, PAD, 68, 10.5, C.muted)
    pages.push(pg)
    return pg
  }
  const card = (pg: Page, x: number, y: number, w: number, h: number, fill = C.panel) => {
    pg.rect(x, y, w, h, fill, 10)
  }
  const kpi = (pg: Page, x: number, y: number, w: number, value: string, label: string, color: RGB) => {
    card(pg, x, y, w, 74)
    pg.rect(x, y + 14, 4, 46, color, 2)
    pg.text(value, x + 16, y + 12, 24, color, { bold: true })
    pg.text(label, x + 16, y + 46, 9.5, C.muted)
  }

  // 1 — capa
  {
    const pg = new Page()
    pages.push(pg)
    pg.rect(0, 0, W, H, C.bg)
    pg.rect(0, 0, 14, H, C.blue)
    pg.rect(14, 0, 6, H, C.purple)
    pg.rect(560, 380, 240, 150, C.panel, 14)
    ;[0.35, 0.55, 0.8, 1].forEach((k, i) => pg.rect(585 + i * 48, 505 - 110 * k, 32, 110 * k, [C.blue, C.cyan, C.purple, C.green][i]!, 5))
    pg.text('UNDERCUT', 60, 56, 13, C.blue, { bold: true })
    pg.block(opts.title?.trim() || 'Proposta de otimização de cardápio', 60, 110, 640, 38, C.text, { bold: true, maxLines: 2, lead: 46 })
    pg.text(`${meta.clientName}${meta.merchantName && meta.merchantName !== meta.clientName ? ` · ${meta.merchantName}` : ''}`, 60, 230, 18, C.cyan, { bold: true })
    pg.text(`${meta.date.toLocaleDateString('pt-BR')}  ·  ${meta.itemCount} produtos analisados${meta.city ? `  ·  ${meta.city}` : ''}  ·  versão ${p.version}`, 60, 262, 11, C.muted)
    const chips: [string, RGB][] = [[`${exec.length} ajustes`, C.amber], [`${combos.length} combos`, C.purple], [`${recs.length} pontos de atenção`, C.cyan]]
    let cx = 60
    for (const [t, col] of chips) cx += pg.pill(t, cx, 310, col, { size: 10 }) + 10
  }

  // 2 — dashboard
  if (opts.sections.resumo) {
    const pg = slide('Visão geral e previsão', `${meta.itemCount} produtos analisados · o que muda e o que esperar`)
    const kw = (W - 2 * PAD - 3 * 14) / 4
    kpi(pg, PAD, 90, kw, String(picked.length), 'itens nesta apresentação', C.blue)
    kpi(pg, PAD + (kw + 14), 90, kw, String(fc.priceCount), 'preços ajustados', C.amber)
    kpi(pg, PAD + 2 * (kw + 14), 90, kw, String(fc.comboCount), 'combos novos', C.purple)
    kpi(pg, PAD + 3 * (kw + 14), 90, kw, String(fc.levels.alto), 'com potencial alto', C.green)
    // esquerda: onde as mudanças atuam
    const lw = 400
    card(pg, PAD, 180, lw, 200)
    pg.text('Onde as mudanças atuam', PAD + 16, 194, 12, C.text, { bold: true })
    const areas = (Object.keys(AREA_LABEL) as Area[])
    const max = Math.max(1, ...areas.map((a) => fc.areas[a]))
    areas.forEach((a, i) => {
      const y = 224 + i * 38
      pg.text(AREA_LABEL[a], PAD + 16, y, 9.5, C.muted)
      pg.rect(PAD + 16, y + 16, lw - 80, 9, C.panel2, 4)
      if (fc.areas[a] > 0) pg.rect(PAD + 16, y + 16, Math.max(8, ((lw - 80) * fc.areas[a]) / max), 9, AREA_COLOR[a], 4)
      pg.text(String(fc.areas[a]), PAD + lw - 52, y + 11, 13, AREA_COLOR[a], { bold: true, w: 36, align: 'r' })
    })
    // direita: simulação
    const rx = PAD + lw + 16
    const rw = W - PAD - rx
    card(pg, rx, 180, rw, 200)
    pg.text('Previsão com as alterações', rx + 16, 194, 12, C.text, { bold: true })
    let y = 222
    const stat = (value: string, label: string, color: RGB) => {
      pg.text(value, rx + 16, y, 17, color, { bold: true })
      const used = pg.block(label, rx + 16, y + 22, rw - 32, 9, C.muted, { maxLines: 2 })
      y += 22 + used + 8
    }
    if (fc.priceCount) {
      const down = fc.perUnitDelta < 0
      stat(down ? `${fc.priceCount} preços mais atrativos` : `${fc.avgPricePct !== null ? pct(fc.avgPricePct) : fc.priceCount} no preço médio`,
        down ? `Média ${fc.avgPricePct !== null ? pct(fc.avgPricePct) : '—'} (${brlSigned(fc.perUnitDelta)} por unidade): centavos a menos para mais cliques. Simulação, ${fc.simUnits} vendas de cada: ${brlSigned(fc.simDelta)}.` : `${brlSigned(fc.perUnitDelta)} por unidade somando os ${fc.priceCount} itens. Simulação, ${fc.simUnits} vendas de cada: ${brlSigned(fc.simDelta)}.`, C.amber)
    }
    if (fc.comboCount) stat(fc.avgComboSavingPct !== null ? `Combos com ${fc.avgComboSavingPct.toFixed(0)}% de economia` : `${fc.comboCount} combos`, fc.avgComboPrice !== null && fc.avgItemPrice ? `Ticket de combo (${brl(fc.avgComboPrice)}) contra ${brl(fc.avgItemPrice)} de um item avulso médio: cada pedido com combo vende mais.` : 'Mais de um item por pedido e economia visível para o cliente.', C.purple)
    if (fc.textCount) stat(`${fc.textCount} textos melhorados`, 'Nome e descrição que explicam o produto: o cliente entende melhor o que compra.', C.cyan)
    if (!fc.priceCount && !fc.comboCount && !fc.textCount) pg.text('Selecione ajustes de preço, combos ou textos para ver a previsão.', rx + 16, y, 10, C.muted)
    // potencial
    card(pg, PAD, 396, W - 2 * PAD, 62)
    pg.text('Potencial de impacto dos itens', PAD + 16, 408, 11, C.text, { bold: true })
    const total = Math.max(1, picked.length)
    let bx = PAD + 16
    const bw = W - 2 * PAD - 32
    ;(['alto', 'medio', 'baixo'] as Level[]).forEach((l) => {
      const w = (bw * fc.levels[l]) / total
      if (w > 0) {
        pg.rect(bx, 430, Math.max(w - 3, 2), 14, LEVEL_COLOR[l], 5)
        if (w > 60) pg.text(`${LEVEL_LABEL[l]} · ${fc.levels[l]}`, bx + 6, 432, 8.5, C.bg, { bold: true })
        bx += w
      }
    })
    pg.block(`Valores são simulações por conta simples sobre os preços do cardápio e referências de mercado; não usam seu volume real de vendas e não garantem resultado. Nada é alterado no ${platform} sem a sua aprovação.`, PAD, 474, W - 2 * PAD, 8.5, C.muted, { maxLines: 2 })
    if (opts.note?.trim()) {
      card(pg, PAD, 510, W - 2 * PAD, 40, C.panel2)
      pg.text('Observações', PAD + 14, 518, 9, C.cyan, { bold: true })
      pg.block(opts.note.trim(), PAD + 14, 532, W - 2 * PAD - 28, 9.5, C.text, { maxLines: 1 })
    }
  } else if (opts.note?.trim()) {
    const pg = slide('Observações')
    pg.block(opts.note.trim(), PAD, 100, W - 2 * PAD, 14, C.text, { maxLines: 12 })
  }

  // combos
  if (opts.sections.combos && combos.length) {
    const per = 3
    for (let i = 0; i < combos.length; i += per) {
      const chunk = combos.slice(i, i + per)
      const pg = slide(`Combos sugeridos (${combos.length})`, `${Math.floor(i / per) + 1}/${Math.ceil(combos.length / per)} · vender mais de um item por pedido`)
      const cw = (W - 2 * PAD - (per - 1) * 14) / per
      chunk.forEach((a, k) => {
        const x = PAD + k * (cw + 14)
        const d = describeAction(a)
        const c = a.combo
        card(pg, x, 92, cw, 440)
        pg.rect(x, 92, cw, 6, C.purple, 3)
        pg.block(a.itemName, x + 16, 112, cw - 32, 13, C.text, { bold: true, maxLines: 3 })
        if (c) {
          const save = c.fullPrice > 0 ? ((c.fullPrice - c.price) / c.fullPrice) * 100 : 0
          pg.text(brl(c.price), x + 16, 170, 26, C.green, { bold: true })
          pg.text(`avulso ${brl(c.fullPrice)}`, x + 16, 204, 10, C.muted)
          pg.pill(`${save.toFixed(0)}% de economia`, x + 16, 222, C.green, { size: 9, solid: true })
          pg.text('COMPÕE', x + 16, 256, 8, C.muted, { bold: true })
          pg.block(c.components.map((k2) => `${k2.quantity > 1 ? `${k2.quantity}x ` : ''}${k2.name}`).join(' + '), x + 16, 270, cw - 32, 10, C.text, { maxLines: 3 })
        }
        let y = 330
        const sec = (label: string, text: string, color: RGB, lines: number) => {
          pg.text(label, x + 16, y, 8, color, { bold: true })
          const used = pg.block(text, x + 16, y + 12, cw - 32, 9.5, C.text, { maxLines: lines })
          y += 12 + used + 10
        }
        sec('HOJE (PONTO FRACO)', d.negative, C.red, 3)
        sec('DEPOIS', d.improvement, C.green, 3)
        sec('PARA QUE SERVE', d.purpose, C.cyan, 3)
      })
    }
  }

  // ajustes por tipo
  if (opts.sections.ajustes && exec.length) {
    const order: ActionKind[] = ['update_price', 'update_name', 'update_description', 'set_status', 'update_schedule', 'reorder_categories', 'add_complement', 'update_image', 'create_item', 'remove_item']
    for (const kind of order) {
      const list = exec.filter((a) => a.kind === kind)
      if (!list.length) continue
      const col = KIND_COLOR[kind]
      if (opts.format === 'completo') {
        const per = 4
        for (let i = 0; i < list.length; i += per) {
          const pg = slide(`${KIND_LABEL[kind]} (${list.length})`, `${Math.floor(i / per) + 1}/${Math.ceil(list.length / per)} · ponto fraco de hoje e o que melhora`)
          list.slice(i, i + per).forEach((a, k) => {
            const cw = (W - 2 * PAD - 14) / 2
            const ch = 205
            const x = PAD + (k % 2) * (cw + 14)
            const y = 92 + Math.floor(k / 2) * (ch + 14)
            const d = describeAction(a)
            card(pg, x, y, cw, ch)
            pg.rect(x, y + 12, 4, ch - 24, col, 2)
            pg.block(a.itemName, x + 16, y + 12, cw - 150, 12.5, C.text, { bold: true, maxLines: 2 })
            pg.pill(`Potencial ${LEVEL_LABEL[d.level].toLowerCase()}`, x + cw - 116, y + 12, LEVEL_COLOR[d.level], { size: 8 })
            let yy = y + 46
            const sec = (label: string, text: string, color: RGB, lines: number) => {
              pg.text(label, x + 16, yy, 8, color, { bold: true })
              const used = pg.block(text, x + 16, yy + 11, cw - 32, 9.5, C.text, { maxLines: lines })
              yy += 11 + used + 8
            }
            sec('HOJE (PONTO FRACO)', d.negative, C.red, 2)
            sec('DEPOIS', d.improvement, C.green, 2)
            sec('PARA QUE SERVE', d.purpose, C.cyan, 2)
            if (a.kind === 'update_price' && typeof a.before === 'number' && typeof a.after === 'number') {
              pg.rect(x + 16, y + ch - 56, cw - 32, 42, C.panel2, 8)
              pg.text(brl(a.before as number), x + 28, y + ch - 46, 13, C.red, { bold: true })
              pg.text('→', x + 28 + cw / 2 - 70, y + ch - 46, 13, C.muted, { bold: true })
              pg.text(brl(a.after as number), x + 28 + cw / 2 - 40, y + ch - 46, 17, C.green, { bold: true })
              pg.text(pct(((a.after as number) - (a.before as number)) / (a.before as number) * 100), x + cw - 90, y + ch - 44, 11, C.amber, { bold: true, w: 62, align: 'r' })
            }
          })
        }
      } else {
        const per = 7
        const rh = 58
        for (let i = 0; i < list.length; i += per) {
          const pg = slide(`${KIND_LABEL[kind]} (${list.length})`, `${Math.floor(i / per) + 1}/${Math.ceil(list.length / per)} · o que muda e por quê`)
          const cols = [PAD + 12, PAD + 196, PAD + 396, PAD + 596]
          const widths = [170, 184, 184, 150]
          ;['PRODUTO', 'HOJE (PONTO FRACO)', 'DEPOIS', 'PARA QUE SERVE'].forEach((t, k) => pg.text(t, cols[k]!, 88, 8, k === 1 ? C.red : k === 2 ? C.green : C.muted, { bold: true }))
          list.slice(i, i + per).forEach((a, k) => {
            const y = 104 + k * (rh + 4)
            const d = describeAction(a)
            card(pg, PAD, y, W - 2 * PAD, rh)
            pg.rect(PAD, y + 8, 4, rh - 16, col, 2)
            pg.block(a.itemName, cols[0]!, y + 9, widths[0]!, 10.5, C.text, { bold: true, maxLines: 2 })
            pg.pill(LEVEL_LABEL[d.level], cols[0]!, y + rh - 20, LEVEL_COLOR[d.level], { size: 7 })
            pg.block(d.negative, cols[1]!, y + 9, widths[1]!, 8.5, C.text, { maxLines: 4, lead: 10.8 })
            pg.block(d.improvement, cols[2]!, y + 9, widths[2]!, 8.5, C.text, { maxLines: 4, lead: 10.8 })
            pg.block(d.purpose, cols[3]!, y + 9, widths[3]!, 8.5, C.muted, { maxLines: 4, lead: 10.8 })
          })
        }
      }
    }
  }

  // pontos de atenção
  if (opts.sections.atencao && recs.length) {
    const per = 4
    for (let i = 0; i < recs.length; i += per) {
      const pg = slide(`Pontos de atenção (${recs.length})`, `${Math.floor(i / per) + 1}/${Math.ceil(recs.length / per)} · ganhos que não mexem em preço`)
      recs.slice(i, i + per).forEach((a, k) => {
        const y = 92 + k * 108
        const d = describeAction(a)
        card(pg, PAD, y, W - 2 * PAD, 98)
        pg.rect(PAD, y + 12, 4, 74, C.amber, 2)
        pg.text(a.itemName, PAD + 16, y + 12, 12, C.text, { bold: true })
        pg.pill(`Potencial ${LEVEL_LABEL[d.level].toLowerCase()}`, W - PAD - 118, y + 10, LEVEL_COLOR[d.level], { size: 8 })
        const half = (W - 2 * PAD - 48) / 2
        pg.text('HOJE (PONTO FRACO)', PAD + 16, y + 38, 8, C.red, { bold: true })
        pg.block(d.negative, PAD + 16, y + 50, half, 9.5, C.text, { maxLines: 4 })
        pg.text('O QUE FAZER', PAD + 32 + half, y + 38, 8, C.green, { bold: true })
        pg.block(d.improvement, PAD + 32 + half, y + 50, half, 9.5, C.text, { maxLines: 4 })
      })
    }
  }

  // região
  if (opts.sections.regiao && (p.competitors.length || p.insights.length)) {
    const pg = slide('O que a região está fazendo', 'referências públicas de concorrentes')
    const half = (W - 2 * PAD - 14) / 2
    card(pg, PAD, 92, half, 440)
    pg.text('Tendências', PAD + 16, 108, 12, C.cyan, { bold: true })
    let y = 134
    for (const t of p.insights.slice(0, 7)) y += pg.block(`• ${t}`, PAD + 16, y, half - 32, 10, C.text, { maxLines: 3 }) + 6
    card(pg, PAD + half + 14, 92, half, 440)
    pg.text('Concorrentes', PAD + half + 30, 108, 12, C.purple, { bold: true })
    y = 134
    for (const c of p.competitors.slice(0, 4)) {
      pg.text(c.name, PAD + half + 30, y, 10.5, C.text, { bold: true })
      y += 16
      for (const t of c.highlights.slice(0, 2)) y += pg.block(`• ${t}`, PAD + half + 30, y, half - 32, 9, C.muted, { maxLines: 2 }) + 2
      const ex = c.examples.slice(0, 3).map((e) => `${e.name}${e.price !== null ? ` ${brl(e.price)}` : ''}`).join('  ·  ')
      if (ex) y += pg.block(ex, PAD + half + 30, y, half - 32, 8.5, C.muted, { maxLines: 2 })
      y += 10
    }
  }

  // fechamento
  {
    const pg = slide('Próximos passos', 'como seguir')
    const steps: [string, string, string][] = [['1', 'Aprovar', 'Você marca o que faz sentido para a sua loja.'], ['2', 'Executar', `A extensão aplica exatamente o aprovado no ${platform}, com status de cada ação.`], ['3', 'Acompanhar', 'Veja o relatório final e compare as vendas nas próximas semanas.']]
    const cw = (W - 2 * PAD - 28) / 3
    steps.forEach(([n, t, d], i) => {
      const x = PAD + i * (cw + 14)
      card(pg, x, 100, cw, 130)
      pg.rect(x + 16, 116, 30, 30, [C.blue, C.purple, C.green][i]!, 15)
      pg.text(n, x + 16, 123, 15, C.bg, { bold: true, align: 'c', w: 30 })
      pg.text(t, x + 58, 123, 14, C.text, { bold: true })
      pg.block(d, x + 16, 162, cw - 32, 10, C.muted, { maxLines: 4 })
    })
    if (opts.sections.fontes && p.sources.length) {
      pg.text('Fontes consultadas (informações públicas)', PAD, 260, 11, C.text, { bold: true })
      let y = 282
      for (const s of p.sources.slice(0, 9)) y += pg.block(`${s.title} - ${s.url}`, PAD, y, W - 2 * PAD, 8, C.muted, { maxLines: 1 }) + 2
    }
    pg.block(`Valores e dados de concorrentes são referências públicas no momento da consulta e podem mudar. Previsões são simulações, não garantia de resultado. Nada é alterado no ${platform} sem a sua aprovação.`, PAD, 530, W - 2 * PAD, 8, C.muted, { maxLines: 2 })
  }

  return assemble(pages, `Undercut  |  ${meta.clientName}`)
}

function assemble(pages: Page[], footer: string): Uint8Array {
  const foot = toWinAnsi(footer)
  const hex = (b: number[]) => `<${b.map((x) => x.toString(16).padStart(2, '0')).join('')}>`
  const streams = pages.map((pg, i) => {
    const num = toWinAnsi(`${i + 1}/${pages.length}`)
    return [
      ...pg.ops,
      `BT /F1 8 Tf 0.576 0.643 0.784 rg 1 0 0 1 ${PAD} 16 Tm ${hex(foot)} Tj ET`,
      `BT /F1 8 Tf 0.576 0.643 0.784 rg 1 0 0 1 ${W - PAD - 30} 16 Tm ${hex(num)} Tj ET`,
    ].join('\n')
  })
  const objs: string[] = []
  objs[1] = '<< /Type /Catalog /Pages 2 0 R >>'
  objs[2] = `<< /Type /Pages /Kids [${pages.map((_, i) => `${5 + i * 2} 0 R`).join(' ')}] /Count ${pages.length} >>`
  objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'
  objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'
  streams.forEach((content, i) => {
    objs[5 + i * 2] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>`
    objs[6 + i * 2] = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  })
  let out = '%PDF-1.4\n'
  const offsets: number[] = []
  for (let i = 1; i < objs.length; i += 1) {
    offsets[i] = out.length
    out += `${i} 0 obj\n${objs[i]}\nendobj\n`
  }
  const xref = out.length
  out += `xref\n0 ${objs.length}\n0000000000 65535 f \n`
  for (let i = 1; i < objs.length; i += 1) out += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`
  out += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`
  const bytes = new Uint8Array(out.length)
  for (let i = 0; i < out.length; i += 1) bytes[i] = out.charCodeAt(i) & 0xff
  return bytes
}
