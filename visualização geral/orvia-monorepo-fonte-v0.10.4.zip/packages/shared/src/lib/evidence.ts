/**
 * Prints do relatório → limites do servidor (docs/integracao-extensoes-hub.md, seção 1 item 8):
 * até 6 PNG, nome ^[A-Za-z0-9 ._()-]{1,76}\.png$, cada ≤ 2,5 MB, corpo total ≤ 4,5 MB.
 * Puro: a compressão real (OffscreenCanvas) entra como função `shrink`.
 */
export const MAX_EVIDENCE = 6
export const MAX_PNG_BYTES = 2_500_000
export const MAX_BODY_BYTES = 4_500_000
export const EVIDENCE_NAME_RE = /^[A-Za-z0-9 ._()-]{1,76}\.png$/

export type Evidence = { name: string; content_base64: string }
export type Shrink = (base64: string, factor: number) => Promise<string | null>

/** bytes decodificados de um base64 */
export const base64Bytes = (b64: string) => Math.floor((b64.length * 3) / 4) - (b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0)

/** nome inválido vira "print N.png" (sem acento/símbolos); repetidos ganham sufixo */
export function safeName(name: string, index: number, used: Set<string>): string {
  let out = EVIDENCE_NAME_RE.test(name) ? name : `${(name.replace(/\.png$/i, '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9 ._()-]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60)) || `print ${index + 1}`}.png`
  if (!EVIDENCE_NAME_RE.test(out)) out = `print ${index + 1}.png`
  let n = 2
  const base = out.replace(/\.png$/, '')
  while (used.has(out)) out = `${base.slice(0, 66)} (${n++}).png`
  used.add(out)
  return out
}

export async function fitEvidence(input: Evidence[], shrink: Shrink, otherBytes = 3000): Promise<{ list: Evidence[]; dropped: string[]; shrunk: number }> {
  const dropped: string[] = []
  const used = new Set<string>()
  let list: Evidence[] = []
  input.forEach((e, i) => {
    if (typeof e.content_base64 !== 'string' || !/^[A-Za-z0-9+/]+=*$/.test(e.content_base64)) { dropped.push(e.name); return }
    list.push({ name: safeName(e.name, i, used), content_base64: e.content_base64 })
  })
  if (list.length > MAX_EVIDENCE) {
    dropped.push(...list.slice(MAX_EVIDENCE).map((e) => e.name))
    list = list.slice(0, MAX_EVIDENCE)
  }
  let shrunk = 0
  const total = () => list.reduce((s, e) => s + e.content_base64.length, otherBytes)
  const reduce = async (e: Evidence): Promise<boolean> => {
    const before = e.content_base64.length
    const next = await shrink(e.content_base64, 0.75)
    if (next && next.length < before) { e.content_base64 = next; shrunk += 1; return true }
    return false
  }
  for (const e of list) {
    for (let k = 0; k < 6 && base64Bytes(e.content_base64) > MAX_PNG_BYTES; k += 1) if (!(await reduce(e))) break
  }
  list = list.filter((e) => (base64Bytes(e.content_base64) <= MAX_PNG_BYTES ? true : (dropped.push(e.name), false)))
  for (let guard = 0; total() > MAX_BODY_BYTES && list.length && guard < 20; guard += 1) {
    const biggest = list.reduce((a, b) => (b.content_base64.length > a.content_base64.length ? b : a))
    if (!(await reduce(biggest))) {
      list = list.filter((e) => e !== biggest)
      dropped.push(biggest.name)
    }
  }
  return { list, dropped, shrunk }
}
