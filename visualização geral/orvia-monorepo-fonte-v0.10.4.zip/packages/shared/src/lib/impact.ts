/**
 * Tradução de cada ação da proposta para linguagem de cliente: o ponto fraco de HOJE,
 * o que MELHORA, para que serve, o nível de potencial e a área em que atua.
 * Puro e determinístico — nada aqui inventa dado de venda: os números do dashboard vêm
 * de conta simples sobre os preços do cardápio (ver `forecast`).
 */
import { fmtValue, type ProposalAction } from '../core/proposal'

export type Level = 'alto' | 'medio' | 'baixo'
export type Area = 'conversao' | 'ticket' | 'margem' | 'organizacao'
export const AREA_LABEL: Record<Area, string> = { conversao: 'Conversão (o cliente decide comprar)', ticket: 'Ticket médio', margem: 'Margem / preço', organizacao: 'Organização do cardápio' }
export const LEVEL_LABEL: Record<Level, string> = { alto: 'Alto', medio: 'Médio', baixo: 'Baixo' }

export interface Described {
  negative: string
  improvement: string
  purpose: string
  level: Level
  area: Area
}

const brl = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`
const cents = (v: number) => Math.round((v - Math.floor(v)) * 100)
const short = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)

const areaOfRecommend = (a: ProposalAction): Area => {
  const t = a.itemName.toLowerCase()
  if (/foto|descri|nome|duplicad|equivalent/.test(t)) return 'conversao'
  if (/complement|combo|ticket|upsell/.test(t)) return 'ticket'
  if (/pre[çc]o|margem/.test(t)) return 'margem'
  return 'organizacao'
}

export function describeAction(a: ProposalAction): Described {
  switch (a.kind) {
    case 'update_price': {
      const b = typeof a.before === 'number' ? a.before : Number(a.before)
      const n = typeof a.after === 'number' ? a.after : Number(a.after)
      if (!Number.isFinite(b) || !Number.isFinite(n) || b <= 0) return { negative: 'Preço fora do padrão do cardápio.', improvement: `Novo preço: ${fmtValue(a.kind, a.after)}.`, purpose: 'Ajustar o preço à faixa que o cliente espera pagar.', level: 'medio', area: 'margem' }
      const pct = ((n - b) / b) * 100
      const trigger = cents(n) === 90 && cents(b) !== 90
      const up = n > b
      return {
        negative: trigger ? `${brl(b)} é um número “redondo”: parece mais caro e não usa preço-gatilho.` : up ? `${brl(b)} deixa margem na mesa em relação ao que o cliente aceita pagar.` : `${brl(b)} está acima do que o cliente espera neste tipo de produto.`,
        improvement: `${brl(n)} (${pct >= 0 ? '+' : ''}${pct.toFixed(1).replace('.', ',')}%)${trigger ? ': termina em ,90 e parece mais acessível' : up ? ': mais margem por venda' : ': mais atrativo para decidir'}.`,
        purpose: trigger ? 'Preço-gatilho: aumenta a chance de clique sem mexer no valor percebido.' : up ? 'Recuperar margem mantendo o preço dentro da faixa do mix.' : 'Reduzir a barreira de compra e destravar a venda.',
        level: Math.abs(pct) > 5 ? 'alto' : 'medio',
        area: 'margem',
      }
    }
    case 'update_name':
      return { negative: `Nome atual (“${short(String(a.before ?? ''), 40)}”) não deixa claro o que é o produto.`, improvement: `Novo nome: “${short(String(a.after ?? ''), 48)}”.`, purpose: 'Nome claro e atrativo ajuda o cliente a entender e escolher mais rápido.', level: 'medio', area: 'conversao' }
    case 'update_description': {
      const empty = !String(a.before ?? '').trim()
      return { negative: empty ? 'Sem descrição: o cliente não sabe o que vem e tende a pular o produto.' : 'Descrição curta ou genérica: não vende o produto.', improvement: `Descrição vendedora: “${short(String(a.after ?? ''), 90)}”.`, purpose: 'Mostrar ingredientes e diferencial aumenta a conversão do produto.', level: empty ? 'alto' : 'medio', area: 'conversao' }
    }
    case 'set_status':
      return { negative: `Produto está ${String(a.before ?? '—')}.`, improvement: `Passa a ${String(a.after ?? '—')}.`, purpose: 'Manter no cardápio só o que pode ser vendido, evitando pedido cancelado.', level: 'baixo', area: 'organizacao' }
    case 'update_schedule':
      return { negative: 'Produto aparece em horários em que não vende bem.', improvement: String(a.after ?? 'Novo horário de venda.'), purpose: 'Mostrar o produto quando o cliente mais compra.', level: 'medio', area: 'organizacao' }
    case 'update_image':
      return { negative: 'Produto sem foto (ou com foto fraca): sem imagem o cliente tende a pular o item.', improvement: `Nova foto: ${String(a.after ?? '')}.`, purpose: 'Foto boa é o fator de conversão mais direto no cardápio.', level: 'alto', area: 'conversao' }
    case 'add_complement':
      return { negative: 'Produto sem opções de acompanhamento/adicional: o cliente leva só o básico.', improvement: String(a.after ?? 'Novo grupo de complementos.'), purpose: 'Complementos pagos aumentam o ticket médio e deixam o pedido do jeito do cliente.', level: 'alto', area: 'ticket' }
    case 'reorder_categories':
      return { negative: 'Categorias em ordem que esconde promoções e destaques.', improvement: 'Promoções e destaques no topo; bebidas e sobremesas no fim.', purpose: 'O cliente vê primeiro o que mais vende e faz o ticket crescer.', level: 'medio', area: 'organizacao' }
    case 'create_combo':
      return { negative: 'Itens vendidos só separados: o cliente leva um item por pedido.', improvement: a.combo ? `Combo por ${brl(a.combo.price)} em vez de ${brl(a.combo.fullPrice)} avulsos.` : 'Novo combo no cardápio.', purpose: 'Vender mais de um item por pedido e destacar a economia.', level: 'alto', area: 'ticket' }
    case 'create_item':
      return { negative: 'Falta uma opção como esta no cardápio.', improvement: a.newItem ? `Novo produto “${a.itemName}”${a.newItem.price !== null ? ` por ${brl(a.newItem.price)}` : ''}.` : 'Novo produto.', purpose: 'Ampliar o mix e dar uma opção a mais para fechar o pedido.', level: 'medio', area: 'ticket' }
    case 'remove_item':
      return { negative: 'Produto duplicado, parado ou que confunde o cliente.', improvement: 'Sai do cardápio.', purpose: 'Cardápio mais enxuto: o cliente decide mais rápido.', level: 'baixo', area: 'organizacao' }
    case 'recommend':
    default:
      return { negative: short(String(a.before ?? ''), 140), improvement: short(String(a.after ?? ''), 160), purpose: 'Ponto de atenção para ganhar vendas sem mexer em preço.', level: a.risk === 'alto' ? 'alto' : a.risk === 'medio' ? 'medio' : 'baixo', area: areaOfRecommend(a) }
  }
}

export interface Forecast {
  priceCount: number
  /** variação média em % dos preços alterados */
  avgPricePct: number | null
  /** soma (novo − atual) de todos os preços alterados, por unidade vendida de cada um */
  perUnitDelta: number
  /** simulação: cada item de preço alterado vende `simUnits` unidades */
  simUnits: number
  simDelta: number
  comboCount: number
  avgComboSavingPct: number | null
  /** preço médio dos combos e do item avulso do cardápio (se conhecido) */
  avgComboPrice: number | null
  avgItemPrice: number | null
  textCount: number
  levels: Record<Level, number>
  areas: Record<Area, number>
}

export function forecast(actions: ProposalAction[], avgItemPrice: number | null = null, simUnits = 100): Forecast {
  const prices = actions.filter((a) => a.kind === 'update_price' && typeof a.before === 'number' && typeof a.after === 'number' && (a.before as number) > 0)
  const pcts = prices.map((a) => (((a.after as number) - (a.before as number)) / (a.before as number)) * 100)
  const delta = prices.reduce((s, a) => s + ((a.after as number) - (a.before as number)), 0)
  const combos = actions.filter((a) => a.kind === 'create_combo' && a.combo && a.combo.fullPrice > 0)
  const savings = combos.map((a) => ((a.combo!.fullPrice - a.combo!.price) / a.combo!.fullPrice) * 100)
  const levels: Record<Level, number> = { alto: 0, medio: 0, baixo: 0 }
  const areas: Record<Area, number> = { conversao: 0, ticket: 0, margem: 0, organizacao: 0 }
  for (const a of actions) {
    const d = describeAction(a)
    levels[d.level] += 1
    areas[d.area] += 1
  }
  const avg = (xs: number[]) => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null)
  return {
    priceCount: prices.length,
    avgPricePct: avg(pcts),
    perUnitDelta: delta,
    simUnits,
    simDelta: delta * simUnits,
    comboCount: combos.length,
    avgComboSavingPct: avg(savings),
    avgComboPrice: avg(combos.map((a) => a.combo!.price)),
    avgItemPrice,
    textCount: actions.filter((a) => a.kind === 'update_name' || a.kind === 'update_description').length,
    levels,
    areas,
  }
}
