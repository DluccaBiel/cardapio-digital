import { writeFileSync } from 'node:fs'
import { describe, it, expect } from 'vitest'
import { proposalPdf } from '../src/lib/pdf'
import type { Proposal, ProposalAction } from '../src/core/proposal'

const mk = (o: Partial<ProposalAction> & { id: string; kind: ProposalAction['kind']; itemName: string }): ProposalAction => ({ itemId: o.id, before: null, after: null, reason: '', source: 'regras', risk: 'baixo', executable: true, ...o })
const prices = ['SELETA', 'Pizza Calabresa G', 'Pizza Mussarela G', 'Esfiha de Carne', 'Refri Lata', 'Suco 500ml', 'Pastel de Queijo', 'Brotinho Doce', 'Calzone'].map((n, i) => mk({ id: `p${i}`, kind: 'update_price', itemName: n, before: 10 + i * 4, after: 9.9 + i * 4 }))
const p: Proposal = {
  version: 1, createdAt: '', summary: 'x', notices: [], feedback: [], insights: ['Combos com bebida ficam 8-12% abaixo da soma dos itens', 'Fotos aumentam a conversão'], sources: [{ title: 'Fonte', url: 'https://exemplo.com' }],
  competitors: [{ name: 'Pizzaria Exemplo', url: null, highlights: ['Combo família com refri 2L'], examples: [{ name: 'Combo Família', price: 89.9 }] }],
  actions: [...prices,
    mk({ id: 'c1', kind: 'create_combo', itemName: 'Combo PEPERONI COM CREAM CHEESE + ÁGUA SEM GÁS', after: 72.9, executable: false, combo: { name: 'Combo', description: '', price: 72.9, fullPrice: 81, components: [{ itemId: '1', name: 'PEPERONI COM CREAM CHEESE', quantity: 1 }, { itemId: '2', name: 'ÁGUA SEM GÁS', quantity: 1 }] } }),
    mk({ id: 'd1', kind: 'update_description', itemName: 'Astro Bacon', before: '', after: 'Pão brioche, blend 150g, queijo prato e molho da casa.' }),
    mk({ id: 'n1', kind: 'update_name', itemName: 'X', before: 'X', after: 'X-Burger Clássico 150g' }),
    mk({ id: 'r1', kind: 'reorder_categories', itemName: 'Ordem das categorias', before: 'a', after: 'b' }),
    mk({ id: 'rec1', kind: 'recommend', itemName: 'Itens sem foto', before: '1 de 3 itens ativos sem foto (33%): “Astro Bacon”.', after: 'Fotografar os itens de maior saída primeiro.', risk: 'medio' }),
    mk({ id: 'rec2', kind: 'recommend', itemName: 'Oportunidade de complementos', before: '3 de 3 itens sem complementos.', after: 'Adicionar acompanhamentos como complementos pagos.', risk: 'baixo' }),
  ],
}
const meta = { clientName: 'Catálogo', merchantName: null, city: 'Brasília', itemCount: 199, date: new Date('2026-11-09T12:00:00Z'), platform: 'Cardápio Web', avgItemPrice: 32 }
describe('deck preview', () => {
  it('gera resumo e completo', () => {
    const a = proposalPdf(p, meta)
    const b = proposalPdf(p, meta, { format: 'completo' })
    writeFileSync(process.env.DECK_OUT ?? '/tmp/deck-resumo.pdf', a)
    writeFileSync((process.env.DECK_OUT ?? '/tmp/deck') + '-completo.pdf', b)
    expect(a.length).toBeGreaterThan(3000)
    expect(b.length).toBeGreaterThan(a.length * 0.5)
  })
})
