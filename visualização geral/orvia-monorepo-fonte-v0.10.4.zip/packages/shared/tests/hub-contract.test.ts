import { describe, expect, it, vi } from 'vitest'
import { extensionMatches, HubClient, loginToHub, type HubResult, type OptimizationUpload } from '../src/lib/hub'
import { base64Bytes, EVIDENCE_NAME_RE, fitEvidence, MAX_BODY_BYTES, MAX_PNG_BYTES, safeName } from '../src/lib/evidence'
import { enqueue, flush, isRetriable, MAX_QUEUE, type Outbox } from '../src/lib/outbox'

const KEY = `ck_live_${'a'.repeat(43)}`
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })

describe('login com canal (extension)', () => {
  it('manda extension no corpo e devolve extension/platform', async () => {
    const f = vi.fn(async (_u: string, _i?: RequestInit) => json(200, { data: { key: KEY, workspace: { name: 'W', slug: 'w' }, user: { email: 'a@b.c' }, extension: 'orvia-cardapioweb', platform: 'cardapioweb' } }))
    const r = await loginToHub('https://orvia-gestao.vercel.app', { email: 'a@b.c', password: 'x', device_id: 'abcdefgh-1', extension: 'orvia-cardapioweb' }, f as any)
    expect(r.ok).toBe(true)
    expect(JSON.parse(String(f.mock.calls[0]![1]!.body))).toMatchObject({ extension: 'orvia-cardapioweb', device_id: 'abcdefgh-1' })
    expect(f.mock.calls[0]![0]).toBe('https://orvia-gestao.vercel.app/api/v1/extension-auth/login')
  })
  it('/me com extensão errada (ou ausente) não confere → o worker apaga a chave e pede novo login', () => {
    expect(extensionMatches({ extension: 'orvia-cardapioweb' }, 'orvia-cardapioweb')).toBe(true)
    expect(extensionMatches({ extension: 'orvia-ifood' }, 'orvia-cardapioweb')).toBe(false)
    expect(extensionMatches({ extension: null }, 'orvia-ifood')).toBe(false)
    expect(extensionMatches({}, 'orvia-ifood')).toBe(false)
  })
  it('handshake manda o nome real do manifest (e a chave só no header)', async () => {
    const f = vi.fn(async (_u: string, _i?: RequestInit) => json(200, { data: { id: '1', version: '0.4.3', status: 'ok', last_seen_at: 'x' } }))
    await new HubClient({ hubUrl: 'https://orvia-gestao.vercel.app', apiKey: KEY }, f as any).handshake('0.4.3', 'Undercut · Otimizador Cardápio Web')
    const init = f.mock.calls[0]![1]!
    expect(JSON.parse(String(init.body))).toEqual({ version: '0.4.3', manifest_name: 'Undercut · Otimizador Cardápio Web' })
    expect((init.headers as Record<string, string>)['X-API-Key']).toBe(KEY)
    expect(String(init.body)).not.toContain(KEY)
  })
})

describe('prints: limites do servidor', () => {
  const b64 = (n: number) => 'A'.repeat(Math.ceil((n * 4) / 3 / 4) * 4)
  it('nomes inválidos viram nomes válidos e únicos', () => {
    const used = new Set<string>()
    const a = safeName('relatório/ação #1.png', 0, used)
    const b = safeName('print 1.png', 1, used)
    const c = safeName('print 1.png', 2, used)
    for (const n of [a, b, c]) expect(EVIDENCE_NAME_RE.test(n)).toBe(true)
    expect(new Set([a, b, c]).size).toBe(3)
  })
  it('até 6 imagens; o resto é descartado e avisado', async () => {
    const list = Array.from({ length: 8 }, (_, i) => ({ name: `print ${i + 1}.png`, content_base64: b64(1000) }))
    const r = await fitEvidence(list, async () => null)
    expect(r.list).toHaveLength(6)
    expect(r.dropped).toEqual(['print 7.png', 'print 8.png'])
  })
  it('imagem > 2,5 MB é reduzida; se não der, é descartada', async () => {
    const big = { name: 'print 1.png', content_base64: b64(3_400_000) }
    const shrunk = await fitEvidence([big], async (s) => s.slice(0, Math.floor(s.length * 0.5)))
    expect(shrunk.list).toHaveLength(1)
    expect(base64Bytes(shrunk.list[0]!.content_base64)).toBeLessThanOrEqual(MAX_PNG_BYTES)
    const fail = await fitEvidence([{ ...big }], async () => null)
    expect(fail.list).toHaveLength(0)
    expect(fail.dropped).toEqual(['print 1.png'])
  })
  it('corpo total ≤ 4,5 MB: reduz as maiores primeiro', async () => {
    const list = Array.from({ length: 4 }, (_, i) => ({ name: `print ${i + 1}.png`, content_base64: b64(2_400_000) }))
    const r = await fitEvidence(list, async (s) => s.slice(0, Math.floor(s.length * 0.75)))
    expect(r.list.reduce((n, e) => n + e.content_base64.length, 0)).toBeLessThanOrEqual(MAX_BODY_BYTES)
    expect(r.list.length).toBeGreaterThan(0)
  })
  it('lixo (não base64) é descartado', async () => {
    const r = await fitEvidence([{ name: 'a.png', content_base64: 'data:image/png;base64,xx' }], async () => null)
    expect(r.list).toHaveLength(0)
  })
})

describe('fila offline', () => {
  const o = (n: number): OptimizationUpload => ({ client_id: 'c', plan_hash: `h${n}`, version: 1, summary: '', aborted: false, approved: [], results: [], evidence: [] })
  const mem = (): Outbox & { data: OptimizationUpload[] } => {
    const box = { data: [] as OptimizationUpload[], read: async () => box.data, write: async (l: OptimizationUpload[]) => { box.data = l } }
    return box
  }
  const res = (ok: boolean, status = 0, code = 'x'): HubResult<unknown> => (ok ? { ok: true, data: {}, etag: null } : { ok: false, status, code, message: 'm' })
  it('só rede/5xx/429 são reenviáveis; 4xx não', () => {
    expect(isRetriable(res(false, 0, 'network'))).toBe(true)
    expect(isRetriable(res(false, 503))).toBe(true)
    expect(isRetriable(res(false, 429))).toBe(true)
    expect(isRetriable(res(false, 422, 'validation_failed'))).toBe(false)
    expect(isRetriable(res(false, 401, 'unauthorized'))).toBe(false)
    expect(isRetriable(res(true))).toBe(false)
  })
  it('guarda no máx. 10 e não duplica o mesmo plano', async () => {
    const box = mem()
    for (let i = 0; i < 12; i += 1) await enqueue(box, o(i))
    await enqueue(box, o(11))
    expect(box.data).toHaveLength(MAX_QUEUE)
    expect(box.data.map((x) => x.plan_hash)).toContain('h11')
    expect(box.data.filter((x) => x.plan_hash === 'h11')).toHaveLength(1)
  })
  it('reenvia quando volta; mantém em rede/5xx; descarta 4xx', async () => {
    const box = mem()
    for (const n of [1, 2, 3, 4]) await enqueue(box, o(n))
    const answers: Record<string, HubResult<unknown>> = { h1: res(true), h2: res(false, 0, 'network'), h3: res(false, 422, 'validation_failed'), h4: res(false, 502) }
    const r = await flush(box, async (x) => answers[x.plan_hash]!)
    expect(r).toEqual({ sent: 1, kept: 2, dropped: 1 })
    expect(box.data.map((x) => x.plan_hash)).toEqual(['h2', 'h4'])
    const again = await flush(box, async () => res(true))
    expect(again).toMatchObject({ sent: 2, kept: 0 })
    expect(box.data).toEqual([])
  })
})

describe('registro de chamadas (Diagnóstico)', () => {
  it('registra método, caminho sem query, status e tempo — nunca a chave nem o corpo', async () => {
    const logs: any[] = []
    const f = vi.fn(async () => json(200, { data: { ok: 1 } }))
    const c = new HubClient({ hubUrl: 'https://orvia-gestao.vercel.app', apiKey: KEY }, f as any, (e) => logs.push(e))
    await c.menu('segredo-do-cliente-123')
    await c.analyze({ client_id: 'x', goal: 'ticket', niche: '', city: 'Brasília', competitors: true, max_price_change_pct: 10 })
    expect(logs.map((l) => `${l.method} ${l.path} ${l.status}`)).toEqual(['GET /menu 200', 'POST /analysis 200'])
    expect(JSON.stringify(logs)).not.toContain(KEY)
    expect(JSON.stringify(logs)).not.toContain('segredo-do-cliente')
    expect(JSON.stringify(logs)).not.toContain('Brasília')
  })
  it('falha de rede também é registrada e a chamada continua devolvendo erro normal', async () => {
    const logs: any[] = []
    const c = new HubClient({ hubUrl: 'https://orvia-gestao.vercel.app', apiKey: KEY }, (async () => { throw new Error('off') }) as any, (e) => logs.push(e))
    const r = await c.clients()
    expect(r).toMatchObject({ ok: false, code: 'network' })
    expect(logs[0]).toMatchObject({ status: 0, code: 'network' })
  })
})
