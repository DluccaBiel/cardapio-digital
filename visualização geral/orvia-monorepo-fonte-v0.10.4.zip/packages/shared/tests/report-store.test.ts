import { describe, expect, it } from 'vitest'
import { clientKeyOf, countSteps, deleteReport, listReports, reportsOf, saveReport, type KV, type SavedReport } from '../src/lib/report-store'

const memory = (): KV => { const db: Record<string, unknown> = {}; return { get: async (k) => ({ [k]: db[k] }), set: async (i) => { Object.assign(db, i) } } }
const rep = (id: string, at: number, key: string, name: string): SavedReport => ({ id, at, clientKey: key, clientName: name, storeName: name, platform: 'Anota AI', version: 1, summary: 's', aborted: false, steps: [{ kind: 'update_price', itemName: 'X', before: '1', after: '2', status: 'ok', message: 'ok' }], pages: [] })

describe('relatórios salvos por cliente', () => {
  it('salva, lista do mais novo ao mais antigo e separa por cliente', async () => {
    const kv = memory()
    await saveReport(kv, rep('a', 1, 'c:1', 'Capixaba'))
    await saveReport(kv, rep('b', 3, 'c:2', 'Guaporé'))
    await saveReport(kv, rep('c', 2, 'c:1', 'Capixaba'))
    const all = await listReports(kv)
    expect(all.map((r) => r.id)).toEqual(['b', 'c', 'a'])
    expect(reportsOf(all, 'c:1').map((r) => r.id)).toEqual(['c', 'a'])
    expect(reportsOf(all, null)).toHaveLength(3)
  })
  it('mesmo id substitui; exclui só o escolhido; limita a 60', async () => {
    const kv = memory()
    await saveReport(kv, rep('a', 1, 'c:1', 'A'))
    await saveReport(kv, { ...rep('a', 5, 'c:1', 'A'), summary: 'novo' })
    expect((await listReports(kv))).toHaveLength(1)
    for (let i = 0; i < 70; i++) await saveReport(kv, rep(`r${i}`, 10 + i, 'c:1', 'A'))
    expect((await listReports(kv))).toHaveLength(60)
    await deleteReport(kv, 'r69')
    expect((await listReports(kv)).some((r) => r.id === 'r69')).toBe(false)
  })
  it('chave do cliente: id do Undercut ou nome da loja sem acento/caixa', () => {
    expect(clientKeyOf('abc', 'X')).toBe('c:abc')
    expect(clientKeyOf('', ' Açaí  da Praça ')).toBe('s:acai da praca')
  })
  it('conta ok/erro/outras', () => {
    expect(countSteps([{ kind: 'k', itemName: '', before: '', after: '', status: 'ok', message: '' }, { kind: 'k', itemName: '', before: '', after: '', status: 'erro', message: '' }, { kind: 'k', itemName: '', before: '', after: '', status: 'pulada', message: '' }])).toEqual({ ok: 1, erro: 1, outras: 1 })
  })
})
