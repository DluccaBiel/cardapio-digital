import { describe, expect, it } from 'vitest'
import { connectionSteps } from '../src/content/ui'

const base = { configurado: true, servidorUrl: 'https://orvia-gestao.vercel.app', canalDestaExtensao: 'orvia-anotaai', versao: '0.3.0' }

describe('passos do teste de conexão', () => {
  it('tudo certo → todos os passos ok', () => {
    const st = connectionSteps({ ...base, servidor: { ok: true, workspace: 'Alpha', canal: 'orvia-anotaai', plataforma: 'anotaai', canalConfere: true, handshake: 'ok' } }, false, null, 'Anota AI')
    expect(st.every((s) => s.state === 'ok')).toBe(true)
    expect(st.map((s) => s.name)).toContain('Integração Anota AI liberada')
  })
  it('servidor que não reconhece a extensão aponta o canal recebido e o esperado', () => {
    const st = connectionSteps({ ...base, servidor: { ok: true, workspace: 'Alpha', canal: null, plataforma: null, canalConfere: false, handshake: 'Extensão desconhecida' } }, false, null, 'Anota AI')
    const integ = st.find((s) => s.name.startsWith('Integração'))!
    expect(integ.state).toBe('erro')
    expect(integ.detail).toMatch(/nenhum.*orvia-anotaai/)
  })
  it('sem chave: só o primeiro passo, com a instrução da engrenagem', () => {
    const st = connectionSteps({ configurado: false }, false, null, 'iFood')
    expect(st).toHaveLength(1)
    expect(st[0]!.detail).toMatch(/engrenagem/)
  })
  it('servidor fora do ar vs. chave recusada', () => {
    expect(connectionSteps({ ...base, servidor: { ok: false, erro: 'Failed to fetch' } }, false, null, 'iFood')[1]!.state).toBe('erro')
    const refused = connectionSteps({ ...base, servidor: { ok: false, erro: 'Chave inválida', status: 401 } }, false, null, 'iFood')
    expect(refused[1]!.state).toBe('ok') // o servidor respondeu
    expect(refused[2]!.state).toBe('erro')
  })
  it('testando → um passo em andamento', () => {
    expect(connectionSteps(null, true, null, 'iFood')[0]!.state).toBe('wait')
  })
})
