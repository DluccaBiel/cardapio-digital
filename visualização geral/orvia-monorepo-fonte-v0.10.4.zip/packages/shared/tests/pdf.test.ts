import { describe, expect, it } from 'vitest'
import { writeFileSync } from 'node:fs'
import menuFixture from './fixtures/menu-payload.json'
import { buildSnapshot } from '../src/core/capture'
import { buildLocalProposal, defaultContext, mergeAi } from '../src/core/proposal'
import { buildPdf, proposalPdf, toWinAnsi } from '../src/lib/pdf'

const snap = buildSnapshot([{ path: null, payload: menuFixture }], { origin: 'active', domUrl: 'x' }).snapshot!
const latin1 = (b: Uint8Array) => Buffer.from(b).toString('latin1')

describe('pdf', () => {
  it('toWinAnsi: acentos viram 1 byte e símbolos exóticos não quebram', () => {
    expect(toWinAnsi('ção é ã')).toEqual([0xe7, 0xe3, 0x6f, 0x20, 0xe9, 0x20, 0xe3])
    expect(toWinAnsi('a → b “x” —')).toEqual([...'a -> b '].map((c) => c.charCodeAt(0)).concat([0x93, 0x78, 0x94, 0x20, 0x97]))
    expect(toWinAnsi('🍔 ok')).toEqual([0x20, 0x6f, 0x6b])
  })
  it('estrutura válida: xref aponta para os objetos e há várias páginas quando precisa', () => {
    const blocks = Array.from({ length: 120 }, (_, i) => ({ text: `Linha ${i} com texto longo `.repeat(6) }))
    const pdf = latin1(buildPdf(blocks, 'rodapé'))
    expect(pdf.startsWith('%PDF-1.4')).toBe(true)
    expect(pdf.trimEnd().endsWith('%%EOF')).toBe(true)
    const startx = Number(/startxref\n(\d+)/.exec(pdf)![1])
    expect(pdf.slice(startx, startx + 4)).toBe('xref')
    const entries = [...pdf.slice(startx).matchAll(/(\d{10}) 00000 n /g)].map((m) => Number(m[1]))
    entries.forEach((off, i) => expect(pdf.slice(off, off + 10)).toMatch(new RegExp(`^${i + 1} 0 obj`)))
    expect(Number(/\/Count (\d+)/.exec(pdf)![1])).toBeGreaterThan(1)
  })
  it('proposta completa gera PDF (salvo para conferência visual)', () => {
    const ctx = defaultContext('hamburgueria', 10)
    const p = mergeAi(buildLocalProposal(snap, ctx), {
      summary: 'Sugestões para aumentar o ticket médio com combos e descrições.',
      updates: [{ ifood_id: 'IF-ITEM-1', item_name: 'X-Burger Clássico (Demo)', before: { name: 'X-Burger Clássico (Demo)', description: 'Hambúrguer 150g', price: 32.9 }, after: { description: 'Pão brioche, blend 150g, queijo prato derretido e molho da casa. Serve 1 pessoa.' }, reason: 'Concorrentes da região destacam o pão e o ponto da carne.', from_competitors: true }],
      combos: [], insights: ['Combos com bebida ficam entre 8% e 12% abaixo da soma dos itens na região.'],
      competitors: [{ name: 'Hamburgueria Exemplo', url: 'https://exemplo.com.br', highlights: ['Combo casal com batata'], examples: [{ name: 'Combo Casal', price: 59.9 }] }],
      sources: [{ title: 'Cardápio público Exemplo', url: 'https://exemplo.com.br/cardapio' }],
    }, snap, ctx)
    const bytes = proposalPdf(p, { clientName: 'Hamburgueria Astro', merchantName: null, city: 'Asa Norte, Brasília', itemCount: snap.items.length, date: new Date('2026-11-07T12:00:00Z') })
    expect(bytes.length).toBeGreaterThan(1500)
    writeFileSync(process.env.PDF_OUT ?? '/tmp/orvia-proposta-teste.pdf', bytes)
  })
  it('PDF personalizado: só os itens/seções escolhidos, título e observação', () => {
    const ctx = defaultContext('hamburgueria', 10)
    const p = mergeAi(buildLocalProposal(snap, ctx), {
      summary: 'Resumo', updates: [
        { ifood_id: 'IF-ITEM-1', item_name: 'X-Burger Clássico (Demo)', before: { name: 'X-Burger Clássico (Demo)', description: 'Hambúrguer 150g', price: 32.9 }, after: { description: 'Pão brioche, blend 150g e molho da casa.' }, reason: 'Boa prática.', from_competitors: false },
      ], combos: [], insights: ['Insight regional único'], competitors: [], sources: [],
    }, snap, ctx)
    const meta = { clientName: 'Cliente', merchantName: null, city: '', itemCount: snap.items.length, date: new Date('2026-11-07T12:00:00Z') }
    const hex = (t: string) => toWinAnsi(t).map((x) => x.toString(16).padStart(2, '0')).join('')
    const txt = (b: Uint8Array) => Buffer.from(b).toString('latin1')
    const one = p.actions.find((a) => a.kind !== 'recommend' && a.itemName.length < 26)!
    const full = txt(proposalPdf(p, meta))
    const custom = txt(proposalPdf(p, meta, { actionIds: new Set([one.id]), sections: { regiao: false, fontes: false }, title: 'Plano para Maria', note: 'Válido por 7 dias' }))
    expect(custom.length).toBeLessThan(full.length)
    expect(custom).toContain(hex('Plano para Maria'))
    expect(custom).toContain(hex('Válido por 7 dias'))
    expect(custom).toContain(hex(one.itemName))
    expect(custom).not.toContain(hex('Insight regional único'))
    expect(full).toContain(hex('Insight regional único'))
    const other = p.actions.find((a) => a.id !== one.id && a.kind !== 'recommend' && a.itemName !== one.itemName)
    if (other) expect(custom).not.toContain(hex(other.itemName))
  })
})
