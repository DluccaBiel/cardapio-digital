import { describe, expect, it } from 'vitest'
import { paginateCards, reportFileName, type ReportCard } from '../src/lib/prints'

const card = (i: number, order = false): ReportCard => ({ status: 'ok', kindLabel: 'x', result: '', view: null, title: `c${i}`, change: '', imageUrl: null, ...(order ? { order: [] } : {}) }) as unknown as ReportCard

describe('relatório em várias páginas', () => {
  it('1ª página leva o cabeçalho (5 pesos) e as demais 7; cartão da ordem pesa 2', () => {
    const cards = [card(0, true), ...Array.from({ length: 19 }, (_, i) => card(i + 1))]
    const pages = paginateCards(cards)
    expect(pages.map((p) => p.length)).toEqual([4, 7, 7, 2])
    expect(pages.flat()).toHaveLength(20)
  })
  it('poucos cartões → 1 página com o nome de sempre; várias → numeradas e válidas para o servidor', () => {
    expect(paginateCards([card(1), card(2)])).toHaveLength(1)
    expect(reportFileName(0, 1)).toBe('relatorio-cardapio.png')
    expect(reportFileName(1, 4)).toBe('relatorio-cardapio-2-de-4.png')
    expect(/^[A-Za-z0-9 ._()-]{1,76}\.png$/.test(reportFileName(1, 4))).toBe(true)
    expect(paginateCards(Array.from({ length: 24 }, (_, i) => card(i))).length).toBeLessThanOrEqual(6)
  })
})
