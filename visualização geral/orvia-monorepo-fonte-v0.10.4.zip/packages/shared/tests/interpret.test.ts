import { describe, expect, it } from 'vitest'
import menuFixture from './fixtures/menu-payload.json'
import { buildSnapshot } from '../src/core/capture'
import { defaultContext } from '../src/core/proposal'
import { interpretRequest } from '../src/core/interpret'

const snapshot = buildSnapshot([{ path: null, payload: menuFixture }], { origin: 'active', domUrl: 'https://portal.ifood.com.br/menu/list' }).snapshot!
const ctx = defaultContext('hamburgueria', 10)
const first = snapshot.items.find((i) => i.price && i.status === 'active')!

describe('interpretador de pedidos em texto livre', () => {
  it('lista os itens do fixture', () => { console.log(snapshot.items.map((i) => `${i.name} | ${i.categoryName} | ${i.price} | ${i.status}`).join('\n')) })
  it('combo família gera ação create_combo de origem voce', () => {
    const r = interpretRequest('criar combo família com refri', snapshot, ctx)
    console.log(JSON.stringify(r.understood), JSON.stringify(r.ignored))
    expect(r.actions.some((a) => a.kind === 'create_combo' && a.source === 'voce')).toBe(true)
  })
  it('baixar 5% de um produto citado', () => {
    const r = interpretRequest(`reduzir 5% o preço do ${first.name}`, snapshot, ctx)
    const a = r.actions.find((x) => x.kind === 'update_price')!
    expect(a).toBeTruthy()
    expect(a.after as number).toBeLessThan(first.price!)
    expect(String((a.after as number).toFixed(2))).toMatch(/90$/)
  })
  it('respeita não mexer em preços', () => {
    const r = interpretRequest(`reduzir o preço do ${first.name}`, snapshot, { ...ctx, doNotTouchPrices: true })
    expect(r.actions).toHaveLength(0)
    expect(r.ignored[0]).toMatch(/não mexer em preços/)
  })
  it('pausar produto', () => {
    const r = interpretRequest(`pausar o ${first.name}`, snapshot, ctx)
    expect(r.actions[0]).toMatchObject({ kind: 'set_status', after: 'paused' })
  })
  it('produto novo com nome entre aspas e preço', () => {
    const r = interpretRequest(`criar produto novo "Smash Duplo" por R$ 31,90 como o ${first.name}`, snapshot, ctx)
    expect(r.actions[0]).toMatchObject({ kind: 'create_item', itemName: 'Smash Duplo' })
  })
  it('texto sem sentido vira "não entendi", sem ação', () => {
    const r = interpretRequest('blá blá qualquer coisa', snapshot, ctx)
    expect(r.actions).toHaveLength(0)
    expect(r.ignored).toHaveLength(1)
  })
})

describe('pedidos já tratados pelos ajustes', () => {
  it('"não mexer em preços" e "desconto 15%" não viram "não entendi"', () => {
    const r = interpretRequest('não mexer em preços. desconto de 15%', snapshot, ctx)
    expect(r.ignored).toHaveLength(0)
  })
})
